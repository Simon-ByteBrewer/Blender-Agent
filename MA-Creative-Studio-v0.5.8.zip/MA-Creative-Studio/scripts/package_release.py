#!/usr/bin/env python3
"""Build a credential-free versioned sharing ZIP.

Run: .venv/bin/python scripts/package_release.py [--force]
Requires installed backend dependencies, npm frontend dependencies, and FFmpeg
only for running the application (not for this package operation).
"""
import argparse
import sys
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tempfile
import zipfile


root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--force', action='store_true', help='Replace the same-version release after all checks pass')
args = parser.parse_args()
version = (root / 'VERSION').read_text().strip()
if not re.fullmatch(r'\d+\.\d+\.\d+', version):
    raise SystemExit('VERSION must use X.Y.Z')
out = root / 'release' / f'MA-Creative-Studio-v{version}.zip'
out.parent.mkdir(exist_ok=True)
if out.exists() and not args.force:
    raise SystemExit('Release already exists; use --force to replace it after validation')
subprocess.run(['npm', '--prefix', 'frontend', 'run', 'build'], cwd=root, check=True)
from release_audit import Auditor
auditor = Auditor(root)
audit = auditor.check

with tempfile.TemporaryDirectory(prefix='studio-share-') as scratch:
    scratch = Path(scratch)
    package = scratch / 'MA-Creative-Studio'
    package.mkdir()
    try:
        files = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=root, stderr=subprocess.DEVNULL).decode().split('\0')
        commit = subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip()
    except subprocess.CalledProcessError:
        files = [p.relative_to(root).as_posix() for prefix in ('backend/src', 'blender_scripts', 'skills/blender-whitebox-previz', 'frontend/src', 'frontend/public') for p in (root / prefix).rglob('*') if p.is_file()]
        commit = None
    exact = {'README.md','VERSION','start.command','create-desktop-shortcut.command','pyproject.toml','uv.lock','backend/pyproject.toml','backend/README.md',
             'frontend/package.json','frontend/package-lock.json','frontend/index.html','frontend/tsconfig.json','frontend/vite.config.ts',
             'scripts/package_release.py','macos/StudioShell.swift','macos/build_app.sh','macos/start_bundled.sh','macos/build_dmg.py','macos/README.md','backend/config/ma_models.json','backend/config/ma_custom_tools.json','backend/config/ma_custom_tools.md','backend/config/ma_system_prompt.md'}
    files = sorted(set(files) | {name for name in exact if (root / name).is_file()})
    prefixes = ('backend/src/','blender_scripts/','skills/blender-whitebox-previz/','frontend/src/','frontend/public/')
    for name in files:
        if not name or not (name in exact or name.startswith(prefixes)): continue
        source = root / name
        if any(part.startswith('.') or part in {'__pycache__', 'node_modules'} for part in Path(name).parts): continue
        if source.is_symlink(): raise RuntimeError('Symlink in release input: '+name)
        if source.suffix.lower() not in {'.py','.swift','.json','.md','.sh','.command','.conf','.toml','.lock','.ts','.tsx','.css','.html','.svg','.png','.jpg','.jpeg','.woff','.woff2','.ttf',''}:
            continue
        # Internal deployment notes are not needed by recipients.
        if name.startswith('backend/src/') and source.suffix == '.md': continue
        dest = package / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)
    for source in (root / 'frontend/dist').rglob('*'):
        if source.is_file():
            if source.is_symlink() or source.suffix == '.map':
                raise RuntimeError('Unexpected frontend build entry: ' + source.name)
            dest = package / 'frontend/dist' / source.relative_to(root / 'frontend/dist')
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
    doc = package / 'backend/config/ma_custom_tools.md'
    text = doc.read_text()
    text = re.sub(r'(?ms)^# 7\. 发布记录.*?(?=^# 8\.)', '', text)
    text = '\n'.join(line for line in text.splitlines() if not line.startswith('- 对照项目的声明')) + '\n'
    doc.write_text(text)
    # Generate a blank example rather than copying any environment file.
    (package / '.env.example').write_text('# Set your own API Key in the application Settings UI.\nARK_API_KEY=\n'
                                          '# MA platform: volcengine (default) or byteplus-ap (BytePlus, Johor).\nARK_PLATFORM=\n'
                                          'BYTEPLUS_API_KEY=\n')
    (package / '开始使用.md').write_text(f'''# MA Creative Studio v{version}

这是浏览器版，已包含编译好的页面，不需要安装 Node.js 来使用。

1. 将 ZIP 完整解压到自己可写的目录，例如“文稿”，不要直接在压缩包中启动。
2. 安装 Blender 到 `/Applications/Blender.app` 并正常打开一次。项目已验证 Blender 5.2。
3. 安装 uv 和 FFmpeg。已使用 Homebrew 的用户可运行 `brew install uv ffmpeg`。
4. 双击 `start.command`；首次启动联网安装 Python 及依赖、准备 Blender MCP 插件。若不能双击，在解压目录的终端运行 `zsh blender_scripts/start.sh`。
5. 浏览器打开 `http://127.0.0.1:7860`。进入左下角“设置”，填写自己的方舟 API Key；使用自定义模型时再配置自己的 BYOK 参数和密钥。
6. 保持启动终端运行；按 Ctrl+C 停止服务。

可选（推荐）：Mac 原生应用。在解压目录的终端运行 `zsh macos/build_app.sh --install`，几秒内生成约 300 KB 的「MA Creative Studio」并安装到“应用程序”（~/Applications），以后从启动台或程序坞打开即可，无需浏览器和终端窗口。需要 Xcode Command Line Tools（安装 Homebrew 时已自带；否则运行 `xcode-select --install`）。应用只是窗口外壳，更新本目录后无需重新构建。

可选：双击 `create-desktop-shortcut.command`，在自己的桌面创建带紫色立方体图标的 `MA Creative Studio.command`。以后双击桌面快捷方式即可启动；应用目录移动后重新创建即可。快捷方式及图标由 macOS 自带工具设置，不需要先安装 Python 或 Node.js，也不会复制任何密钥。

本包不含 API Key、账号状态、历史会话、个人项目或虚拟环境。首次下载后可直接使用现有前端；首次后端安装仍需要网络，模型服务用量由用户自己的账号承担。

`local_pipeline.extract_frames` 可对已生成的预演 MP4 抽取最多 3 帧。由后端 FFmpeg 执行，不调用 Blender 重新渲染。Seedance 工具保留，生成视频可由人工在页面中单独操作。

使用后配置保存于本目录 `.env`，运行状态在 `.local/`，项目在 `data/`，日志在 `logs/`。这些内容包含个人信息，不要直接将使用过的目录再次压缩分发；再次分享应使用原始 ZIP。请勿将 API Key 填入聊天或截图中。

详细使用方法见 `README.md`，工具说明见 `backend/config/ma_custom_tools.md`。
''')
    lock = json.loads((root / 'frontend/package-lock.json').read_text())
    license_inventory = []
    for name, details in lock['packages'].items():
        if not name or details.get('dev'): continue
        source = root / 'frontend' / name
        dest = package / 'third_party_licenses' / name.replace('node_modules/', '')
        copied = []
        if source.is_dir():
            for item in source.iterdir():
                if item.is_file() and re.match(r'^(licen[cs]e|copying|notice)', item.name, re.I):
                    dest.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(item, dest / item.name)
                    copied.append(item.name)
        license_inventory.append({'package':name.replace('node_modules/',''),'version':details.get('version'),'license':details.get('license'),'files':copied})
    (package / 'third_party_licenses').mkdir(exist_ok=True)
    (package / 'third_party_licenses/manifest.json').write_text(json.dumps(license_inventory, ensure_ascii=False, indent=2)+'\n')
    entries = sorted(p for p in package.rglob('*') if p.is_file())
    # Project docs (requirements, integration notes) are internal and never shipped.
    forbidden = {'.git','.local','.venv','data','docs','logs','outputs','node_modules','__pycache__','tmp','tests'}
    for path in entries:
        name = path.relative_to(package).as_posix()
        if (any(part in forbidden for part in path.relative_to(package).parts)
                or path.name.startswith('.env') and path.name != '.env.example'
                or path.suffix in {'.sqlite3','.db','.pem','.key','.pyc'}):
            raise RuntimeError('Forbidden release entry: ' + name)
        audit(name, path.read_bytes())
    if not (package / 'frontend/dist/index.html').is_file():
        raise RuntimeError('Frontend build is missing')
    if 'extract_frames' not in (package / 'backend/config/ma_custom_tools.json').read_text():
        raise RuntimeError('Current tool configuration is missing')
    # Verify imports using isolated, empty runtime state. Do not inherit credentials.
    runtime = scratch / 'isolated-runtime'
    env = {'PATH':os.environ['PATH'],'HOME':str(scratch),'PYTHONPATH':str(package/'backend/src'),
           'PYTHONDONTWRITEBYTECODE':'1','STUDIO_HOME':str(runtime),'STUDIO_RESOURCE_ROOT':str(package)}
    check = """from studio.config import config, api_key_status
assert not api_key_status()['api_key_configured']
from studio.app import app
from ma_custom_tools.skills import read_skill
from studio.video_frames import validate_arguments
assert read_skill()['content']
assert validate_arguments({'action':'extract_frames','artifact':'video.mp4'}) == ('video.mp4',None)
assert any(r.path == '/api/health' for r in app.routes)
print('isolated_import_and_blank_credentials=passed')
"""
    subprocess.run([sys.executable,'-c',check],cwd=package,env=env,check=True)
    records = [{'path':p.relative_to(package).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in entries]
    (package / 'PACKAGE_MANIFEST.json').write_text(json.dumps({'version':version,'commit':commit,'files':records},ensure_ascii=False,indent=2)+'\n')
    entries.append(package / 'PACKAGE_MANIFEST.json')
    temporary_zip = scratch / out.name
    with zipfile.ZipFile(temporary_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(entries):
            relative = path.relative_to(package)
            info = zipfile.ZipInfo('MA-Creative-Studio/'+relative.as_posix())
            info.create_system = 3
            mode = 0o755 if path.suffix in {'.command','.sh'} else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info,path.read_bytes())
    with zipfile.ZipFile(temporary_zip) as z:
        if z.testzip() is not None:
            raise RuntimeError('ZIP integrity check failed')
        for info in z.infolist(): audit(info.filename,z.read(info))
        for launcher in ('start.command', 'create-desktop-shortcut.command'):
            if not z.getinfo('MA-Creative-Studio/' + launcher).external_attr >> 16 & 0o111:
                raise RuntimeError('Launcher is not executable: ' + launcher)
        members = len(z.infolist())
    digest = hashlib.sha256(temporary_zip.read_bytes()).hexdigest()
    # Publish only after the ZIP's decompressed contents pass the full audit.
    staged = out.with_suffix('.zip.partial')
    shutil.copyfile(temporary_zip, staged)
    os.replace(staged, out)
    out.with_suffix('.zip.sha256').write_text(digest+'  '+out.name+'\n')
    report={'archive':out.name,'version':version,'bytes':out.stat().st_size,'files':members,'sha256':digest,
            'checks':{'zip_integrity':'passed','file_allowlist':'passed','env_credentials_and_encoded_variants':'no matches','secret_patterns':'no matches','personal_identifiers':'no matches','blank_credentials_isolated_import':'passed','executable_launcher':'passed'},
            'excludes':['.env and other real environment files','.local','data','logs','.git','.venv','node_modules','tests','internal research and deployment notes'],
            'includes':['source','frontend production build','blank .env.example','startup guide','third-party frontend licenses']}
    (out.parent / (out.stem+'-audit.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False))
