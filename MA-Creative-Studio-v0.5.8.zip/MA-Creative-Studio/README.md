# MA 导演 Agent

Mac 本地三维创作工作室：输入提示词，通过 MA 控制 Blender 搭建场景、制作运镜，导出工程和视频，再用 Seedance 生成写实画面。

本项目通过浏览器使用，FastAPI 服务在本机运行。项目、配置和日志分别保存在 `data/`、`.env` 和 `logs/`。启动后访问 **http://127.0.0.1:7860**；开发热加载使用 Vite。

## 安装依赖

- **Blender**：安装到 `/Applications/Blender.app`，先正常打开一次。已验证 Blender 5.2。
- **uv、FFmpeg**：已安装 Homebrew 时执行：

  ```bash
  brew install uv ffmpeg
  ```

  uv 的其他安装方式见 [官方说明](https://docs.astral.sh/uv/getting-started/installation/)。
- **Python 3.12+、后端依赖、Blender MCP 插件**：首次启动自动准备，需要联网。
- **Node.js / npm**：用于安装前端依赖和构建浏览器页面，首次启动缺少页面构建时会自动执行。

后端包包括 `mcp`、`blender-mcp`、`fastapi`、`uvicorn`、`python-multipart`、`httpx`、`python-dotenv`、`pillow`；具体版本由 `uv.lock` 固定，无需逐个安装。

## 1. 一键启动

进入项目目录，双击 **start.command**。

想从桌面启动，可先双击 **create-desktop-shortcut.command**。它会在当前用户桌面创建带紫色立方体图标的 **MA Creative Studio.command**，以后双击该快捷方式即可启动服务并打开浏览器；服务已运行时直接打开页面。快捷方式自动指向本次解压的应用目录，不包含密钥。图标使用包内 `frontend/public/app-icon.png`，通过 macOS 自带接口设置，不需要额外安装工具；若设置失败，快捷方式仍可正常启动。移动应用目录后，重新运行创建脚本即可。

### Mac 安装版（DMG，推荐分发）

打开 `MA-Creative-Studio-v<版本>-macOS.dmg`，把「MA Creative Studio」拖到“应用程序”，之后从启动台打开。安装版已用 Developer ID 签名并经 Apple 公证，双击即可运行。

- 前置依赖仍需自行安装：Blender（`/Applications/Blender.app`，先正常打开一次）、uv 和 FFmpeg（`brew install uv ffmpeg`）。缺少时窗口会提示。
- 首次启动联网安装 Python 依赖，约 1–3 分钟；之后秒开。在左下角「设置」填写自己的 API Key。
- 程序只读地放在 App 内；Python 环境、`.env`、项目、日志都保存在 `~/Library/Application Support/MA Creative Studio/`（菜单「文件 → 打开数据目录」）。删除 App 不会删除数据。
- 与源码目录运行的版本数据相互独立，两者都使用 7860 端口，同一时间只运行一个。

构建：`.venv/bin/python macos/build_dmg.py --notarize`。脚本先用 `scripts/package_release.py` 生成白名单发布包并做凭据审计，再组装通用二进制 App、签名（hardened runtime）、生成 DMG，对 App 和 DMG 的每个文件再次扫描本机 `.env` / 部署状态中的密钥及其编码形式、常见密钥格式、本机路径和 git 邮箱，最后公证并 staple。公证的代码、凭据配置与说明只保存在本机 `.local/notarization/`（不提交、不进入发布包），详见其中的 `README.md`；发布时用 `zsh -lic '.venv/bin/python macos/build_dmg.py --notarize'` 加载 shell 配置中的凭据。

### Mac 开发版（指向项目目录）

```bash
zsh macos/build_app.sh --install
```

几秒内生成约 300 KB 的 **MA Creative Studio.app** 并安装到 `~/Applications`，之后从启动台或程序坞打开。应用在独立窗口中显示工作室页面，服务未运行时自动启动（日志在 `logs/mac-app.log`），退出应用时只停止由它启动的服务。应用只是 WKWebView 外壳，项目更新后无需重新构建。需要 Xcode Command Line Tools，详见 [macos/README.md](macos/README.md)。

也可以在该目录的终端执行：

```bash
zsh blender_scripts/start.sh
```

服务就绪后自动打开 **http://127.0.0.1:7860**。保持终端运行，按 `Ctrl+C` 停止服务。

## 2. 设置 API Key

点击页面左侧底部 **设置**，在 **服务平台** 中选择火山方舟（华北 2 北京）或 BytePlus ModelArk（亚太柔佛，目前 BytePlus 仅支持该地域），输入该平台与地域的 API Key，点击 **保存 API Key** 即可开始创作。

密钥按平台分别保存到项目目录 `.env`：火山方舟为 `ARK_API_KEY`，BytePlus 为 `BYTEPLUS_API_KEY`；当前平台保存在 `ARK_PLATFORM`。切换平台不会覆盖其他平台的 Key，立即生效，下次启动自动读取。已配置时仅显示脱敏值。密钥需具备 MA / Seedance 对应服务的调用权限。各平台可用模型与差异见 [docs/v0.5.6-byteplus.md](docs/v0.5.6-byteplus.md)。

界面语言可在左侧活动栏底部的 **EN / 中** 按钮或 **设置 → 语言** 中切换（English / 中文），英文界面标题为 **MA Director Studio**。语言选择只保存在当前浏览器。

## 使用说明

新建会话 → 输入场景与运镜要求 → Blender 自动启动并创作 → 在右侧预览、下载 `.blend` 工程和视频。

- 所有项目数据统一保存在 `data/projects/<项目 ID 或名称>/`，包括 `.blend` 工程、渲染帧、参考视频、Seedance 成片、提示词、项目脚本及检查报告。原 `outputs/` 中的项目已迁入此目录，`outputs/` 已删除；后续新建和导出也使用 `data/projects/`。
- 平台 Agent 验证配置保存在 `data/config/platform_agent_verified.json`。
- 运行日志：`logs/`
- `.env`、历史会话、工程、视频及本机虚拟环境不纳入源码版本管理。

输入框默认显示 2 行，随内容增高至最多 10 行，之后内部滚动。Enter 发送，Shift+Enter 换行；生成时同一按钮切换为停止。输入组件悬浮在对话底部，历史消息可在其下方滚动。

手机端（页面宽度不超过 820px）使用顶部导航切换会话、对话、预览、视频生成和设置，切换面板会保留输入草稿。手机端回车换行，点击箭头发送；输入区随可用视口高度调整。PC 端保持原有多栏布局和键盘操作。顶部部署标签右侧显示版本号，开发及构建时从根目录 `VERSION` 读取，更新版本后重新构建即可随页面发布。

输入框支持直接粘贴、拖入多张 PNG/JPG 图片，也可通过「＋」选择素材，每个文件最大 50 MB。图片以缩略图显示在文字上方，右上角可移除，点击可放大并下载原图。点击发送时上传素材；发送失败会保留文字和附件，成功后在对话中仍可点击图片查看。

新项目 ID 使用上海时间的 `YYMMDD-HHMMSS-ffffff`，最后 6 位是创建时的微秒。已有项目 ID 不变，新建工程命名为 `previz-项目ID.blend`。每次通过平台或 CLI 渲染、编码生成白膜 MP4，都会保存独立的 `previz-项目ID-N.mp4` 文件。N 按项目从 1 开始单调递增，删除视频或生成失败后不会复用编号，因此可能存在跳号。成功后将其设为默认参考视频，旧版本继续保留。右侧「对比视频」可选择两个 MP4 并排查看、从头一起播放或全部暂停，也可分别拖动进度条和下载。

### Seedance 视频生成

右侧「视频生成」使用 Seedance 2.5 全模态参考（`doubao-seedance-2-5-260628`）；MA 也可在用户要求时通过 `seedance_video` 工具使用同样的能力（含人像库）。默认把当前 Blender 预演视频作为「视频1」，还可以叠加：

- **项目文件 / 上传**：PNG、JPG、WEBP 图片（≤ 30 MB，短边 ≥ 300 px，宽高比 0.4–2.5）和 MP4、MOV 视频（≤ 200 MB）。
- **音频参考**：MP3、WAV（≤15 MB，2–30秒），可单独用于音色、节奏或表演参考，也可配合图片、视频。
- **网络地址**：`https://` 图片或视频，或 `asset://asset-…` 素材 ID。
- **人像库**：Seedance 官方虚拟人像库没有开放检索接口，需在 [方舟体验中心 → 虚拟人像库](https://ark.volcengine.com/region:cn-beijing/experience/vision?modelId=doubao-seedance-2-5-260628&tab=GenVideo)（BytePlus 为 [预置数字人像](https://docs.byteplus.com/en/docs/modelark/seedance-portrait-asset-guide#preset-avatar)）挑选人像并复制素材 ID（也可直接粘贴模板代码，自动提取 ID），保存到本地人像库后在任意项目复用，提交时以 `asset://<ID>` 传给模型。已授权的真人人像素材同样适用。直接上传含真人人脸的图片或视频会被平台拦截。

提示词按同类素材顺序用「图片1」「图片2」「视频1」「音频1」引用，面板中每个素材旁显示其编号。上限为 30 张图、10 个视频、10 个音频，视频和音频各自合计 ≤30 秒。不添加任何素材时为文生视频。可选时长（智能或 4–30 秒）、分辨率（480p / 720p / 1080p）、画面比例和是否生成声音；480p 适合低成本试效果。

「生成方式」支持自动判断、参考生成、延长视频1、编辑视频1。延长从首个参考视频的结尾续写，时长表示新增秒数，比例自动跟随源视频；编辑保持源视频时长与比例。连续多段时，先下载并检查上一段，再把它作为下一段的视频1。展开「合成多个片段」，按点击顺序选择已下载视频即可拼接，保留各片段原声，输出所选分辨率、24 fps。合成在本地执行，不调用模型；当前不添加字幕或额外配乐。

对应的 Agent 工具与 CLI、轨迹分析及 API 请求示例见 [Seedance 2.5 接入记录](docs/seedance-2.5-integration.md)。修改工具声明后，重启应用并新建会话以使用更新后的 Agent 版本；历史会话固定使用创建时的版本。

参考图和音频以 Base64 直接提交，不需要对象存储。**本地参考视频**（包括 Blender 预演视频）在已有 MA Session 的项目中，通过 Files API 自动上传至方舟托管存储，只需现有 ARK API Key；后台取得签名 HTTPS 地址后提交 Seedance，不需要手动上传、TOS AK/SK，也不复制其他 Session 的 Agent。相同 Session 中的相同文件会复用已上传文件并刷新下载地址。CLI 可传 `--session-id sesn-…` 使用此链路。

项目仅使用方舟托管上传，不需要 TOS 的 AK、SK 或 Bucket 配置。Seedance 接收签名 HTTPS 地址，不能把 Files API 文件 ID 直接当作视频输入。

## 常见问题

- **页面未打开**：手动访问 `http://127.0.0.1:7860`，检查启动终端是否报错。
- **找不到 Blender**：确认路径为 `/Applications/Blender.app`。
- **下载依赖失败**：检查网络后重新启动。
- **Blender MCP 连接超时**：查看 `logs/blender-*.log`；已有旧插件时，可执行 `.venv/bin/blender-mcp install-addon` 更新，再重启 Blender 窗口。

## 开发

```bash
uv sync --frozen --all-packages
.venv/bin/python -m pytest -q
npm ci --prefix frontend
npm run build --prefix frontend
```

后端位于 `backend/`，前端位于 `frontend/`，Blender 脚本位于 `blender_scripts/`。前端使用 React、TypeScript、Vite，依赖固定在 `frontend/package-lock.json`。

后端测试在收集测试模块前将 `STUDIO_HOME` 指向临时目录，结束后自动清理；测试数据库和项目产物不会写入开发者的 `.local/`、`data/projects/`。正常新建项目仍会预建一个项目目录，尚未生成或上传文件时为空；清理空目录不会删除项目记录，后续上传或打开项目文件夹时会自动重建。

修改前端文字和样式时，保持 7860 后端运行，在另一个终端执行 `npm run dev --prefix frontend`，打开 **http://127.0.0.1:5173**。保存前端文件后页面会热更新；API、文件预览和远程桌面连接通过开发服务转发到原后端。发布页面仍使用 `npm run build --prefix frontend` 构建后从 7860 访问。

macOS App 使用 WKWebView（与 Safari 同为 WebKit 内核），点击按钮不会让按钮获得焦点，与 Chrome 不同。`frontend/src/clickFocus.ts` 在全局统一为 Chrome 的行为，避免“失焦即关闭”的弹出菜单吞掉点击。改动交互后，用真实 WebKit 与 Chromium 回归：首次执行 `npx --prefix frontend playwright install webkit chromium`，之后运行 `npm run test:browser --prefix frontend`。

### 自定义模型（BYOK）

在 **设置 → 自定义模型 BYOK** 添加模型名称、模型 ID、Provider、完整 HTTPS 接口地址、API 协议、三个 Token 上限和模型 API Key。表单不预填任何模型，各项按自己的服务商填写；Token 上限按所选模型的实际能力填写。支持 OpenAI Responses、Chat Completions 和 Anthropic Messages。

页面自动选择常用鉴权方式：ModelHub 使用 `Ak`，Direct 的 OpenAI 协议使用 `Authorization: Bearer`，Direct 的 Anthropic 协议使用 `x-api-key`。已有配置更新名称或密钥时保留原鉴权方式；非标准接口仍可通过设置 API 显式传入 `auth_header` / `auth_scheme`。ARK API Key 仍用于 Managed Agent 平台鉴权。保存后，**新建会话，在输入框下方的模型菜单在「自定义模型 BYOK」分组选择模型**。已有云端 Session 固定模型；可更换该配置的密钥，更换模型或接口需添加新配置。移除配置后，使用它的旧会话不能继续推理。

配置和密钥写入当前数据目录的 `.env`（仅当前用户可读写），页面只返回脱敏 Key。模型配置按 Session 保存，密钥仅在触发推理的请求头中发送，不写入云端 Agent / Session 或本地会话数据库。远程 Worker 的工具结果由本机网关注入模型凭证。

在同一 BYOK 页面点击 **导出配置**，页面会自动生成 32 位随机口令，点击 **复制口令** 保存后，即可下载 `byok-config.encrypted.json`。文件包含全部 BYOK 模型和密钥，**不包含 MA API Key**；模型参数和密钥整体采用 AES-256-GCM 加密，以随机盐和 PBKDF2-HMAC-SHA256（600,000 次）派生密钥，每次导出使用新随机 nonce。口令由浏览器 Web Crypto 生成，下载后仍可复制，关闭面板后清除，不持久保存。请与文件分开传递；遗失口令无法恢复该文件。

点击 **导入配置**，选择文件并输入口令。导入先验证整个文件，再一次性保存；错误口令、损坏文件或任一非法模型均不会修改配置。相同模型参数及鉴权方式视为重复项，保留现有名称、密钥和会话绑定，新增模型会获得新的本地 ID；最多保留 50 个模型。文件上限为 1 MB。

加密仅保护导出的文件。运行时密钥仍保存在本机 `.env`（权限 `0600`），导入解密在本地后端完成；口令仅在请求和处理期间使用。远程部署需使用 HTTPS，调用模型也仍需正常发送鉴权凭证。

热加载开发（若 5173 已被占用，可使用 5174）：

```bash
STUDIO_ORIGIN=http://127.0.0.1:5174 .venv/bin/python -m uvicorn studio.app:app --host 127.0.0.1 --port 7860 --reload --reload-dir backend/src --timeout-graceful-shutdown 2 --no-access-log
npm run dev --prefix frontend -- --port 5174
```

访问 `http://127.0.0.1:5174/`；`STUDIO_ORIGIN` 要与前端地址一致。关闭超时可避免热加载被长连接拖住。

## 打包分发

安装开发依赖后，在仓库中运行：

```bash
.venv/bin/python scripts/package_release.py
```

脚本读取根目录 `VERSION`、构建前端，将发布包写入 `release/MA-Creative-Studio-v<版本号>.zip`，同时生成 SHA-256 文件和 `-audit.json` 检查报告。重复打同版本时使用 `--force`；只有新包通过全部检查后才替换旧包。

发布采用源码和资源白名单，包含预编译页面、启动说明和前端第三方许可证；排除 `.env`、账号状态、数据、日志、Git 历史、虚拟环境和依赖目录，仅生成空白 `.env.example`。脚本在内存中读取本机环境配置以检查凭证值及常见编码形式，不输出密钥；命中已知凭证或疑似密钥时中止发布。打包后再次检查 ZIP 内容，并在隔离的空账号目录验证后端导入。

接收方完整解压后按 `开始使用.md` 操作，并在设置中填写自己的 API Key。包内已编译前端，使用者无需安装 Node.js；首次启动仍需联网安装 Python 后端依赖，并自行安装 Blender、uv 和 FFmpeg。
