#!/bin/zsh
STUDIO_ROOT="$(cd "$(dirname "$0")" && pwd)"
/bin/zsh "$STUDIO_ROOT/blender_scripts/start.sh"
STUDIO_EXIT=$?
if (( STUDIO_EXIT != 0 )); then
  echo "Startup failed. Check the messages above and README.md."
  read -r "?Press Enter to close this window..."
fi
exit "$STUDIO_EXIT"
