"""Deploy the independent cloud edition to the existing Elsa host over SSH."""

import asyncio
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import tarfile
import tempfile

from dotenv import set_key
from studio.config import RESOURCES, STATE, safe_error
from studio.store import Store
from ma_self_hosted.execution import settings
from ma_self_hosted.download_proxy import DownloadProxy


def bundle(path):
    def source_permissions(info):
        # Only these explicitly bundled code/assets are shared with service users.
        # Runtime configuration and databases are outside the release archive.
        info.mode |= 0o444
        return info

    with tarfile.open(path, 'w:gz') as archive:
        for name in ('pyproject.toml', 'uv.lock', 'backend/pyproject.toml'):
            archive.add(RESOURCES / name, arcname=name, recursive=False, filter=source_permissions)
        for root in ('backend/src', 'backend/config', 'blender_scripts', 'skills/blender-whitebox-previz', 'frontend/dist'):
            for item in sorted((RESOURCES / root).rglob('*')):
                if item.is_file() and '__pycache__' not in item.parts and item.suffix not in {'.pyc', '.blend', '.blend1'}:
                    archive.add(item, arcname=str(item.relative_to(RESOURCES)), recursive=False, filter=source_permissions)


def private_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2))
    path.chmod(0o600)


async def main():
    os.umask(0o077)
    store = Store()
    current = settings(store)
    server = store.get('execution_server:' + str(current.get('server_id')))
    if not server or server.get('ip') != '10.35.139.81':
        raise RuntimeError('Expected the existing Elsa server configuration')
    state_path = STATE / 'cloud-elsa.json'
    saved = json.loads(state_path.read_text()) if state_path.exists() else {}
    saved.setdefault('token', secrets.token_urlsafe(48))
    saved.setdefault('server_id', 'elsa-cloud-' + hashlib.sha256((saved.get('environment_id') or saved['token']).encode()).hexdigest()[:12])
    private_json(state_path, saved)
    target = 'tiger@10.35.139.81'
    options = ['-o','BatchMode=yes','-o','ConnectTimeout=12']
    ssh = ['/usr/bin/ssh' if sys.platform=='darwin' else 'ssh', *options, target]
    scp = ['/usr/bin/scp' if sys.platform=='darwin' else 'scp', *options]
    sid = saved['server_id']
    cloud = {'server':{'id':sid, 'name':'Elsa', 'username':'elsa', 'ip':'10.35.139.81',
        'transport':'loopback', 'api_port':17961, 'gateway_port':17962, 'desktop_port':8444,
        'environment_id':saved.get('environment_id'), 'token':saved['token']}}
    # Build the page from this checkout so the deployed UI (and its VERSION label) match.
    subprocess.run(['npm', '--prefix', str(RESOURCES / 'frontend'), 'run', 'build'], check=True,
                   stdout=subprocess.DEVNULL)
    with tempfile.TemporaryDirectory(prefix='ma-cloud-deploy-') as folder:
        folder = Path(folder)
        bundle(folder/'app.tar.gz')
        private_json(folder/'cloud.json', cloud)
        private_json(folder/'worker.json', {k:cloud['server'][k] for k in ('environment_id','token','api_port','gateway_port')})
        # Business credentials are never copied from the Mac. Configure them
        # in the cloud UI, or only transfer them with explicit user approval.
        set_key(folder/'app.env', 'STUDIO_CLOUD_ORIGIN', 'http://10.35.139.81:7860')
        (folder/'app.env').chmod(0o600)
        stage = subprocess.check_output(ssh+['mktemp -d /tmp/ma-cloud.XXXXXXXX'], text=True).strip()
        import re
        if not re.fullmatch(r'/tmp/ma-cloud\.[A-Za-z0-9]+', stage): raise RuntimeError('Invalid stage directory')
        try:
            subprocess.run(scp+[str(folder/name) for name in ('app.tar.gz','cloud.json','worker.json','app.env')]+
                           [str(Path(__file__).with_name('install.sh')), target+':'+stage+'/'], check=True)
            # Temporary relay downloads public dependencies only. Runtime traffic
            # does not depend on the Mac or this installation-only tunnel.
            relay = DownloadProxy()
            port = await relay.start()
            try:
                remote_port = int(subprocess.check_output(ssh + [
                    "python3 -c 'import socket; s=socket.socket(); s.bind((\"127.0.0.1\",0)); print(s.getsockname()[1]); s.close()'"
                ], text=True).strip())
                if not 1024 <= remote_port <= 65535:
                    raise RuntimeError('Invalid temporary dependency relay port')
                # A dedicated SSH connection closes the forwarding socket on exit.
                # Reusing a ControlPersist master can leave fixed ports occupied.
                forwarded = ssh[:-1] + ['-o', 'ControlPath=none', '-o', 'ControlMaster=no',
                    '-o', 'ExitOnForwardFailure=yes', '-R',
                    f'127.0.0.1:{remote_port}:127.0.0.1:{port}', target]
                await asyncio.to_thread(subprocess.run, forwarded+[
                    f'sudo -n env HTTPS_PROXY=http://127.0.0.1:{remote_port} HTTP_PROXY=http://127.0.0.1:{remote_port} NO_PROXY= bash '
                    +stage+'/install.sh '+stage], check=True)
            finally:
                await relay.close()
        finally:
            subprocess.run(ssh+['rm -f '+ ' '.join(stage+'/'+name for name in ('app.tar.gz','cloud.json','worker.json','app.env','install.sh'))+' && rmdir '+stage], check=True)
    note = STATE/'Elsa云版本访问.txt'
    note.write_text('云版本：http://n35-139-081.byted.org/ma-creative-studio/\n内网直接访问，无需登录。\n\n本地版本：http://127.0.0.1:7860\n两个版本的项目与 Session 独立保存。\n')
    note.chmod(0o600)
    print(json.dumps({'url':'http://n35-139-081.byted.org/ma-creative-studio/','access_note':str(note)},ensure_ascii=False))


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except Exception as exc:
        print(safe_error(exc), file=sys.stderr)
        raise SystemExit(1)
