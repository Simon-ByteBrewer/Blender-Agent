"""Single-owner server login for HTTP and desktop WebSockets."""

import hashlib
import hmac
import secrets
import time
from http.cookies import SimpleCookie
from urllib.parse import parse_qs, urlsplit

from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, RedirectResponse

COOKIE = "studio_cloud_session"
MAX_AGE = 7 * 24 * 3600
LOGIN = '''<!doctype html><html lang="zh"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>登录 · MA 导演 Agent 云版本</title><style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f5f5f7;color:#1d1d1f;font:15px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}main{width:min(380px,calc(100vw - 40px));padding:32px;background:white;border:1px solid #e5e5ea;border-radius:20px;box-shadow:0 12px 40px #00000008}h1{font-size:22px;margin:0 0 8px}p{color:#86868b;line-height:1.6;margin:0 0 24px}label{display:block;margin-bottom:8px}input,button{width:100%;font:inherit;padding:12px;border-radius:9px}input{border:1px solid #d2d2d7;outline-color:#007aff}button{margin-top:16px;background:#007aff;border:0;color:white;cursor:pointer}.error{color:#b42318;font-size:13px;margin-top:12px}.tag{display:inline-block;margin-bottom:16px;color:#346591;background:#edf4fc;border-radius:6px;padding:4px 8px;font-size:12px}
</style><main><span class="tag">Elsa · 云版本</span><h1>MA 导演 Agent</h1><p>服务运行在 Elsa，关闭浏览器后任务仍会继续。</p><form method="post" action="login"><label for="password">访问密码</label><input id="password" name="password" type="password" required autofocus autocomplete="current-password" maxlength="256"><button>登录</button>ERROR</form></main></html>'''


def same_request_origin(headers, scheme, *, require_origin=False):
    """Cloud aliases use the actual request address, not a fixed deployment IP."""
    host = headers.get("host", "")
    scheme = {"ws": "http", "wss": "https"}.get(scheme, scheme)
    origin = headers.get("origin")
    try:
        target = urlsplit(f"{scheme}://{host}")
        if not target.hostname or target.path or target.username or target.query or target.fragment:
            return False
        if origin is None:
            return not require_origin
        source = urlsplit(origin)
        if source.path or source.query or source.fragment or source.username:
            return False
        return (source.scheme, source.hostname, source.port or (443 if source.scheme == "https" else 80)) == (
            target.scheme, target.hostname, target.port or (443 if target.scheme == "https" else 80))
    except ValueError:
        return False


class CloudAccess:
    def __init__(self, app, *, password, origin=None):
        if len(password) < 20:
            raise ValueError("Cloud access password must contain at least 20 characters")
        self.app, self.origin = app, origin.rstrip("/") if origin else None
        self.password = password.encode()
        self.authority = urlsplit(self.origin).netloc.lower() if self.origin else None
        self.failures = {}

    def session(self):
        value = str(int(time.time())) + "." + secrets.token_hex(16)
        return value + "." + hmac.new(self.password, value.encode(), hashlib.sha256).hexdigest()

    def valid(self, cookie):
        try:
            issued, nonce, signature = cookie.split(".")
            age = time.time() - int(issued)
            return 0 <= age <= MAX_AGE and hmac.compare_digest(signature,
                hmac.new(self.password, f"{issued}.{nonce}".encode(), hashlib.sha256).hexdigest())
        except (ValueError, TypeError):
            return False

    async def __call__(self, scope, receive, send):
        if scope["type"] not in {"http", "websocket"}:
            return await self.app(scope, receive, send)
        headers = {k.decode().lower(): v.decode() for k, v in scope["headers"]}
        trusted = same_request_origin(headers, scope["scheme"], require_origin=scope["type"] == "websocket")
        if self.origin:
            trusted = trusted and headers.get("host", "").lower() == self.authority and headers.get("origin", self.origin) == self.origin
        cookie = SimpleCookie()
        try:
            cookie.load(headers.get("cookie", ""))
            authenticated = self.valid(cookie[COOKIE].value) if COOKIE in cookie else False
        except Exception:
            authenticated = False
        if scope["type"] == "websocket":
            if not trusted or not authenticated:
                return await send({"type": "websocket.close", "code": 1008})
            return await self.app(scope, receive, send)
        if not trusted:
            return await JSONResponse({"detail": "Invalid server origin"}, 403)(scope, receive, send)
        root = scope.get("root_path", "")
        path, method = scope["path"], scope["method"]
        if root and path.startswith(root + "/"):
            path = path[len(root):]
        response = None
        if path == "/login" and method == "GET":
            response = HTMLResponse(LOGIN.replace("ERROR", ""))
        elif path == "/login" and method == "POST":
            now = time.monotonic()
            self.failures = {k: v for k, v in self.failures.items() if now - v[0] < 300}
            address = (scope.get("client") or ("unknown",))[0]
            failed = self.failures.get(address, (now, 0))
            if failed[1] >= 10:
                response = JSONResponse({"detail": "请稍后再试"}, 429)
            else:
                body = bytearray()
                async for chunk in Request(scope, receive).stream():
                    body.extend(chunk)
                    if len(body) > 8192:
                        return await JSONResponse({"detail": "Request too large"}, 413)(scope, receive, send)
                values = parse_qs(body.decode(errors="replace"))
                supplied = values.get("password", [""])[0].encode()
                if hmac.compare_digest(supplied, self.password):
                    self.failures.pop(address, None)
                    response = RedirectResponse(root + "/", status_code=303)
                    response.set_cookie(COOKIE, self.session(), max_age=MAX_AGE, httponly=True,
                                        secure=scope["scheme"] == "https", samesite="strict")
                else:
                    self.failures[address] = (failed[0], failed[1] + 1)
                    response = HTMLResponse(LOGIN.replace("ERROR", '<p class="error">密码不正确，请重试。</p>'), 401)
        elif not authenticated:
            response = RedirectResponse(root + "/login", 303) if method == "GET" and not path.startswith(("/api/", "/artifacts/")) else JSONResponse({"detail": "请先登录云版本"}, 401)
        if response is not None:
            response.headers.update({"Cache-Control": "no-store", "Referrer-Policy": "same-origin", "X-Content-Type-Options": "nosniff"})
            return await response(scope, receive, send)
        return await self.app(scope, receive, send)
