"""Grant only the two service users traversal through Tiger's private home."""

import ctypes
import ctypes.util
import os
import pwd


def allow_service_traversal():
    lib = ctypes.CDLL(ctypes.util.find_library('acl') or 'libacl.so.1', use_errno=True)
    lib.acl_get_file.argtypes = [ctypes.c_char_p, ctypes.c_int]
    lib.acl_get_file.restype = ctypes.c_void_p
    lib.acl_to_text.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.acl_to_text.restype = ctypes.c_void_p
    lib.acl_from_text.argtypes = [ctypes.c_char_p]
    lib.acl_from_text.restype = ctypes.c_void_p
    lib.acl_set_file.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_void_p]
    lib.acl_free.argtypes = [ctypes.c_void_p]
    path, access = b'/home/tiger', 0x8000
    acl = lib.acl_get_file(path, access)
    if not acl:
        raise OSError(ctypes.get_errno(), 'Cannot read home directory ACL')
    raw = lib.acl_to_text(acl, None)
    if not raw:
        lib.acl_free(acl)
        raise OSError(ctypes.get_errno(), 'Cannot read ACL text')
    try:
        entries = ctypes.string_at(raw).decode().splitlines()
    finally:
        lib.acl_free(raw)
        lib.acl_free(acl)
    for user in ('ma-studio-cloud', 'elsa'):
        uid = pwd.getpwnam(user).pw_uid
        prefixes = (f'user:{user}:', f'user:{uid}:')
        found = next((i for i, row in enumerate(entries) if row.startswith(prefixes)), None)
        if found is None:
            entries.append(f'user:{uid}:--x')
        else:
            # Preserve any existing permissions, adding only traversal.
            entry = entries[found].split()[0]
            entries[found] = entry[:-1] + 'x'
    mask = next((i for i, row in enumerate(entries) if row.startswith('mask::')), None)
    if mask is None:
        group = next(row for row in entries if row.startswith('group::')).split()[0]
        entries.append('mask::' + group.split(':')[-1][:2] + 'x')
    else:
        entries[mask] = entries[mask].split()[0][:-1] + 'x'
    updated = lib.acl_from_text(('\n'.join(entries) + '\n').encode())
    if not updated:
        raise OSError(ctypes.get_errno(), 'Cannot construct directory ACL')
    try:
        if lib.acl_set_file(path, access, updated) != 0:
            raise OSError(ctypes.get_errno(), 'Cannot grant service directory traversal')
    finally:
        lib.acl_free(updated)


if __name__ == '__main__':
    if os.geteuid() != 0:
        raise SystemExit('Run this deployment helper as root on Elsa')
    allow_service_traversal()
