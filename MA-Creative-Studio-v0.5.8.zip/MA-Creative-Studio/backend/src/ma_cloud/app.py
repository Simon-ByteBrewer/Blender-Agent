"""Factory for an independent Elsa-hosted application and local Worker gateway."""

import json
import os
from contextlib import asynccontextmanager
from pathlib import Path

from .access import CloudAccess
from .settings import configure
from .mount import CloudMount


def create_app():
    from studio import app as runtime
    from studio.config import config
    from ma_self_hosted import execution

    values = config()
    cloud = json.loads(Path(os.environ["STUDIO_CLOUD_CONFIG"]).read_text())
    origin = values["STUDIO_CLOUD_ORIGIN"].rstrip("/")
    server = cloud["server"]
    if server.get("transport") != "loopback":
        raise ValueError("Cloud edition requires a same-host Worker")
    configure(runtime.store, server)
    runtime.store.set("worker_deployment", {"state": "ready", "message": "云版本在 Elsa 同机执行。"})
    runtime.app.state.cloud_origin = origin
    runtime.app.state.edition = "cloud"
    if values.get("STUDIO_CLOUD_PASSWORD"):
        runtime.app.add_middleware(CloudAccess, password=values["STUDIO_CLOUD_PASSWORD"])
    runtime.app.add_middleware(CloudMount)
    original = runtime.app.router.lifespan_context

    @asynccontextmanager
    async def lifespan(app):
        active = {job.get("project_id") for job in runtime.jobs.list()
                  if job["kind"] == "ma" and job["status"] in {"running", "queued"}}
        async with original(app):
            await runtime.remote({"execution": execution.binding(runtime.store)}).connect()
            for saved in runtime.projects.list():
                p = runtime.project(saved["id"])
                if execution.is_self_hosted(p) and p.get("session_id"):
                    await runtime.remote(p).connect()
            # Keep watching saved sessions after service restart; never send a duplicate prompt.
            for pid in active:
                if not pid:
                    continue
                p = runtime.project(pid)
                if p.get("session_id"):
                    runtime.jobs.submit("ma", lambda p=p: runtime.run_project(p), pid)
            yield
    runtime.app.router.lifespan_context = lifespan
    return runtime.app
