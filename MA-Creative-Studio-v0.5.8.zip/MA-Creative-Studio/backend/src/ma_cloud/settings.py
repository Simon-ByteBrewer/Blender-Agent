"""Cloud execution preferences; each Session keeps its original tool protocol."""

import asyncio
import json

from ma_self_hosted import execution

selection_lock = asyncio.Lock()


def configure(store, server):
    original_id = server["id"]
    previous = store.get("execution_server:" + original_id, {})
    worker = {**server, "tool_protocol": "self_hosted"}
    worker["environment_id"] = previous.get("environment_id") or server.get("environment_id")
    custom = {**server, "id": original_id + "-custom", "tool_protocol": "custom_tools", "environment_id": None}
    with store.connect() as db:
        rows = dict(db.execute("SELECT key,value FROM kv"))
        write = lambda k, v: db.execute("INSERT OR REPLACE INTO kv VALUES(?,?)", (k, json.dumps(v, ensure_ascii=False)))
        write("execution_server:" + original_id, worker)
        write("execution_server:" + custom["id"], custom)
        write("cloud_server_id", original_id)
        if store.get("cloud_protocol_selection_initialized"):
            return
        projects = json.loads(rows.get("projects", "[]"))
        for project in projects:
            if project.get("execution") != {"mode": "self_hosted", "server_id": original_id}:
                continue
            prefix = "project_session:" + project["id"] + ":"
            old_suffix = ":self_hosted:" + original_id
            related = {k: v for k, v in rows.items() if k.startswith(prefix) and old_suffix in k}
            if project.get("session_id") or any(k.endswith(old_suffix) and json.loads(v) for k, v in related.items()):
                continue  # Existing MA Sessions keep the worker and their bindings.
            project["execution"] = {"mode": "colocated", "server_id": custom["id"]}
            for k, v in related.items():
                write(k.replace(old_suffix, ":colocated:" + custom["id"], 1), json.loads(v))
        if "projects" in rows:
            write("projects", projects)
        write("execution_settings", {"mode": "colocated", "server_id": custom["id"]})
        write("cloud_protocol_selection_initialized", True)


async def select(runtime, body):
    if not isinstance(body, dict) or set(body) != {"mode"} or body["mode"] not in {"colocated", "self_hosted"}:
        raise ValueError("请选择 Custom Tool 或 Self-hosted")
    async with selection_lock:
        sid = runtime.store.get("cloud_server_id")
        if body["mode"] == "colocated":
            sid += "-custom"
        server = runtime.store.get("execution_server:" + sid)
        if body["mode"] == "self_hosted" and not server.get("environment_id"):
            created = await runtime.ark.request("POST", "environments", json={
                "name": "ma-studio-cloud-worker", "config": {"type": "self_hosted"}})
            server["environment_id"] = created["id"]
            runtime.store.set("execution_server:" + sid, server)
        binding = {"mode": body["mode"], "server_id": sid}
        await runtime.remote({"execution": binding}).connect()
        runtime.store.set("execution_settings", binding)
        return {**execution.settings(runtime.store), "edition": "cloud"}
