"""Same-host Blender executor, with an optional MA Self-hosted Work Queue."""

import asyncio
import json
import os
import time
from pathlib import Path


def main():
    import uvicorn
    config = json.loads(Path(os.environ["STUDIO_WORKER_CONFIG"]).read_text())
    os.environ["ARK_API_KEY"] = config["token"]
    os.environ["ARK_BASE_URL"] = f"http://127.0.0.1:{config['gateway_port']}/api/v3"
    from studio import app as runtime
    from ma_self_hosted.server import create_app
    from ma_self_hosted.collect_resources import Sampler
    from ma_self_hosted.collect_tool_status import sample, identifier
    from fastapi import HTTPException, Request

    # Custom Tool requests execute directly over loopback. A Work Queue is
    # started only when the cloud application selects a Self-hosted Session.
    app = create_app(runtime, config["token"], work_queue=False)
    if os.environ.get("STUDIO_SHARED_RENDER_POOL"):
        os.environ["STUDIO_RENDER_POOL"] = os.environ["STUDIO_SHARED_RENDER_POOL"]
    sampler = Sampler(runtime.ROOT)
    cache, lock = {}, asyncio.Lock()

    @app.post("/work-queue")
    async def work_queue(request: Request):
        body = await request.json()
        await app.state.enable_work_queue(body.get("environment_id"))
        return {"status": "ready", "environment_id": body.get("environment_id")}

    @app.get("/resources")
    async def resources():
        async with lock:
            if not cache or time.monotonic() - cache["at"] >= 30:
                cache.update(at=time.monotonic(), value=await asyncio.to_thread(sampler.sample))
            return cache["value"]

    @app.get("/journal/{sid}")
    async def journal(sid: str):
        if not identifier(sid) or not runtime.store.get("worker_session:" + sid):
            raise HTTPException(404, "Session not bound")
        data = await asyncio.to_thread(sample, [sid], runtime.store.path)
        return {**data["sessions"][sid], "sampled_at": data["sampled_at"], "session_id": sid,
                "source": "worker_journal", "age_seconds": 0, "stale": False}

    @app.post("/projects/{pid}/open-folder")
    async def open_folder(pid: str):
        try:
            p = runtime.projects.get(pid)
        except KeyError:
            raise HTTPException(404, "Project not bound") from None
        directory = runtime.projects.directory(p).resolve()
        if not directory.is_relative_to(runtime.OUTPUT.resolve()) or not directory.is_dir():
            raise HTTPException(404, "Project directory unavailable")
        env = dict(os.environ)
        if app.state.desktops and app.state.desktops.display(pid):
            env["DISPLAY"] = app.state.desktops.display(pid)  # The project's own desktop.
        process = await asyncio.create_subprocess_exec("thunar", str(directory), env=env,
            stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
        try:
            await asyncio.wait_for(process.wait(), 3)
        except TimeoutError:
            pass  # GUI may remain open until the user closes its window.
        return {"status": "opened", "location": "server_desktop"}

    uvicorn.run(app, host="127.0.0.1", port=config["api_port"], access_log=False)


if __name__ == "__main__":
    main()
