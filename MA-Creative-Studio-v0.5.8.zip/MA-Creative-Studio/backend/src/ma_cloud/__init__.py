"""Independent server edition; the default Mac application remains unchanged."""
