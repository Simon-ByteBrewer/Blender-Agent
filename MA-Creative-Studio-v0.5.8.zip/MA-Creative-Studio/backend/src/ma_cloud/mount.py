"""Recognize the fixed mount forwarded by the Elsa Nginx location."""

PREFIX = "/ma-creative-studio"


class CloudMount:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] in {"http", "websocket"}:
            headers = dict(scope["headers"])
            if headers.get(b"x-forwarded-prefix") == PREFIX.encode():
                # Nginx removes the prefix; reconstruct the ASGI mounted path so
                # routing, redirects and desktop WebSocket URLs share one base.
                scope = {**scope, "root_path": PREFIX, "path": PREFIX + scope["path"],
                         "raw_path": PREFIX.encode() + scope.get("raw_path", scope["path"].encode())}
        await self.app(scope, receive, send)
