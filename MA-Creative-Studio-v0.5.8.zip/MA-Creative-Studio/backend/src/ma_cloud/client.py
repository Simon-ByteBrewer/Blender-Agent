"""Same-host Worker transport: loopback HTTP, with no SSH dependency."""

import asyncio
import time
import httpx
from ma_self_hosted.remote import DesktopStopped, RemoteClient


class WorkerResources:
    def __init__(self, client):
        self.client = client

    async def snapshot(self):
        return await self.client.request("GET", "/resources")

    async def close(self):
        pass


class WorkerJournal(WorkerResources):
    async def snapshot(self, sid):
        from ma_self_hosted.collect_tool_status import identifier
        if not identifier(sid):
            raise ValueError("Invalid Session ID")
        return await self.client.request("GET", "/journal/" + sid)


class ColocatedClient(RemoteClient):
    def __init__(self, server, store):
        if server.get("tool_protocol") == "self_hosted":
            super().__init__(server, store)
        else:
            self.server, self.lock = server, asyncio.Lock()
            self.port = self.desktop_port = self.process = self.gateway = None
            self.bound = {}
        self.resources = WorkerResources(self)
        self.tool_status = WorkerJournal(self)
        self.desktops = {}

    async def desktop_port_for(self, project, *, start=True, activity=True):
        """The project's own desktop port from the executor; the shared desktop if disabled.
        Page assets (no start, no activity) reuse a recent lookup."""
        cached = self.desktops.get(project["id"])
        if cached and not start and not activity and time.monotonic() - cached[1] < 30:
            return cached[0]
        try:
            result = await self.project_request(project, "POST", "desktop",
                params={"start": int(start), "activity": int(activity)})
        except RuntimeError as exc:
            if str(exc).endswith(": Not Found"):  # Executor predates per-project desktops.
                result = {"isolated": False}
            elif "已因空闲自动关闭" in str(exc):
                self.desktops.pop(project["id"], None)
                raise DesktopStopped(str(exc)) from None
            else:
                raise
        await self.connect()
        port = result["port"] if result.get("isolated") else self.desktop_port
        self.desktops[project["id"]] = (port, time.monotonic())
        return port

    async def desktop_state(self, project):
        try:
            return await self.project_request(project, "GET", "desktop")
        except RuntimeError as exc:
            if str(exc).endswith(": Not Found"):
                return {"isolated": False, "running": True}
            raise

    async def connect(self):
        async with self.lock:
            self.port = self.server["api_port"]
            self.desktop_port = self.server["desktop_port"]
            if self.gateway is not None:
                await self.gateway.start()
                async with httpx.AsyncClient(trust_env=False, timeout=20) as client:
                    result = await client.post(f"http://127.0.0.1:{self.port}/work-queue",
                        headers={"Authorization": "Bearer " + self.server["token"]},
                        json={"environment_id": self.server["environment_id"]})
                    result.raise_for_status()

    async def close(self):
        await self.resources.close()
        await self.tool_status.close()
        if self.gateway is not None:
            await self.gateway.close()
