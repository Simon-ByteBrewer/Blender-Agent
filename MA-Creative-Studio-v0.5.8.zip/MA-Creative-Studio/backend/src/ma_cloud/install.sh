#!/usr/bin/env bash
# Install the cloud application and same-host executor; keep Mac services independent.
set -euo pipefail
stage=$1
base=/home/tiger/projects/ma-creative-studio
app_home=$base/runtime
worker_home=/home/elsa/ma-studio-cloud-worker
release=$base/releases/$(date +%Y%m%d-%H%M%S)
getent passwd ma-studio-cloud >/dev/null || useradd --system --home-dir "$app_home" --shell /usr/sbin/nologin ma-studio-cloud
install -d -m 755 "$release" "$base/releases"
install -d -m 700 -o ma-studio-cloud -g ma-studio-cloud "$app_home"
install -d -m 700 -o elsa -g elsa "$worker_home"
tar -xzf "$stage/app.tar.gz" -C "$release"
python3 "$release/backend/src/ma_cloud/directory_access.py"
export UV_PYTHON_INSTALL_DIR=/opt/ma-creative-studio/python
cd "$release"
/opt/ma-creative-studio/bootstrap/bin/uv sync --python 3.12 --frozen --all-packages --no-dev
if ! test -f "$app_home/.env"; then
  install -m 600 -o ma-studio-cloud -g ma-studio-cloud "$stage/app.env" "$app_home/.env"
fi
# Desktop credentials already reside on Elsa; they never pass through the Mac.
python3 - "$stage/cloud.json" <<'PY'
import json, sys
from pathlib import Path
path = Path(sys.argv[1])
cloud = json.loads(path.read_text())
existing = json.loads(Path('/home/elsa/ma-creative-studio/worker.json').read_text())
cloud['server']['desktop_password'] = existing['desktop_password']
path.write_text(json.dumps(cloud))
PY
install -m 600 -o ma-studio-cloud -g ma-studio-cloud "$stage/cloud.json" "$app_home/cloud.json"
install -m 600 -o elsa -g elsa "$stage/worker.json" "$worker_home/worker.json"
ln -sfn "$release" "$base/current"
# Per-project desktops run the same full XFCE session as :1, each with its own D-Bus.
install -d -m 700 -o elsa -g elsa /home/elsa/.vnc
cat > /home/elsa/.vnc/xstartup-project <<'SCRIPT'
#!/bin/sh
unset SESSION_MANAGER
unset DBUS_SESSION_BUS_ADDRESS
exec dbus-launch --exit-with-session startxfce4
SCRIPT
chown elsa:elsa /home/elsa/.vnc/xstartup-project
chmod 700 /home/elsa/.vnc/xstartup-project
cat > /etc/systemd/system/ma-studio-cloud.service <<'UNIT'
[Unit]
Description=MA 导演 Agent cloud edition
After=network-online.target ma-studio-cloud-executor.service
Wants=network-online.target
Wants=ma-studio-cloud-executor.service
[Service]
Type=simple
User=ma-studio-cloud
Group=ma-studio-cloud
WorkingDirectory=/home/tiger/projects/ma-creative-studio/runtime
Environment=HOME=/home/tiger/projects/ma-creative-studio/runtime
Environment=STUDIO_HOME=/home/tiger/projects/ma-creative-studio/runtime
Environment=STUDIO_RESOURCE_ROOT=/home/tiger/projects/ma-creative-studio/current
Environment=STUDIO_CLOUD_CONFIG=/home/tiger/projects/ma-creative-studio/runtime/cloud.json
Environment=PYTHONUNBUFFERED=1
ExecStart=/home/tiger/projects/ma-creative-studio/current/.venv/bin/python -m uvicorn ma_cloud.app:create_app --factory --host 10.35.139.81 --port 7860 --timeout-graceful-shutdown 8 --no-access-log
Restart=on-failure
RestartSec=3
UMask=0077
NoNewPrivileges=true
[Install]
WantedBy=multi-user.target
UNIT
cat > /etc/systemd/system/ma-studio-cloud-executor.service <<'UNIT'
[Unit]
Description=MA 导演 Agent Blender executor and optional Self-hosted Worker
After=network-online.target ma-studio-desktop.service
Requires=ma-studio-desktop.service
[Service]
Type=simple
User=elsa
Group=elsa
WorkingDirectory=/home/elsa/ma-studio-cloud-worker
Environment=HOME=/home/elsa
Environment=DISPLAY=:1
Environment=STUDIO_HOME=/home/elsa/ma-studio-cloud-worker
Environment=STUDIO_RESOURCE_ROOT=/home/tiger/projects/ma-creative-studio/current
Environment=STUDIO_WORKER_CONFIG=/home/elsa/ma-studio-cloud-worker/worker.json
Environment=STUDIO_BLENDER_SCRIPTS=/opt/ma-creative-studio/addons
Environment=STUDIO_SHARED_RENDER_POOL=/home/elsa/ma-creative-studio/.local/render-pool
Environment=STUDIO_MCP_PORT_START=29000
Environment=STUDIO_PER_PROJECT_DESKTOP=1
Environment=STUDIO_DESKTOP_DISPLAY_START=20
Environment=STUDIO_DESKTOP_PORT_START=39000
Environment=STUDIO_DESKTOP_IDLE=1800
Environment=STUDIO_DESKTOP_XSTARTUP=/home/elsa/.vnc/xstartup-project
Environment=BLENDER_BIN=/opt/ma-creative-studio/blender-5.2.1-linux-x64/blender
Environment=LIBGL_ALWAYS_SOFTWARE=1
Environment=LP_NUM_THREADS=8
Environment=OMP_NUM_THREADS=8
Environment=PYTHONUNBUFFERED=1
ExecStart=/home/tiger/projects/ma-creative-studio/current/.venv/bin/python -m ma_cloud.executor
Restart=on-failure
RestartSec=3
UMask=0077
NoNewPrivileges=true
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
if systemctl cat ma-studio-cloud-worker.service >/dev/null 2>&1; then
  systemctl disable --now ma-studio-cloud-worker.service
fi
systemctl enable ma-studio-cloud.service ma-studio-cloud-executor.service
systemctl restart ma-studio-cloud-executor.service
systemctl restart ma-studio-cloud.service
systemctl is-active ma-studio-cloud.service ma-studio-cloud-executor.service
python3 "$release/backend/src/ma_cloud/proxy_install.py"
