"""Install the Studio location without replacing Elsa's existing Nginx site."""

from datetime import datetime
from pathlib import Path
import shutil
import subprocess

INCLUDE = "    include /etc/nginx/snippets/ma-creative-studio.conf;\n"


def with_location(text):
    if INCLUDE.strip() in text:
        return text
    anchor = "    location / {"
    if text.count(anchor) != 1:
        raise RuntimeError("Expected one existing root location; Nginx configuration left unchanged")
    return text.replace(anchor, INCLUDE + "\n" + anchor, 1)


def main():
    site = Path('/etc/nginx/sites-enabled/dsh-web').resolve(strict=True)
    location = Path('/etc/nginx/snippets/ma-creative-studio.conf')
    mapping = Path('/etc/nginx/conf.d/ma-creative-studio.conf')
    original = site.read_text()
    updated = with_location(original)
    previous = {p: p.read_bytes() if p.exists() else None for p in (site, location, mapping)}
    if updated != original:
        backups = Path('/etc/nginx/studio-backups')
        backups.mkdir(mode=0o700, exist_ok=True)
        backup = backups / (site.name + '-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
        shutil.copy2(site, backup)
        backup.chmod(0o600)
    try:
        location.parent.mkdir(exist_ok=True)
        location.write_text(Path(__file__).with_name('nginx-location.conf').read_text())
        mapping.write_text('map $http_upgrade $ma_studio_connection {\n    default upgrade;\n    "" close;\n}\n')
        location.chmod(0o644)
        mapping.chmod(0o644)
        site.write_text(updated)
        subprocess.run(['/usr/sbin/nginx', '-t'], check=True)
        subprocess.run(['systemctl', 'reload', 'nginx'], check=True)
    except BaseException:
        for path, data in previous.items():
            if data is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(data)
        raise


if __name__ == '__main__':
    main()
