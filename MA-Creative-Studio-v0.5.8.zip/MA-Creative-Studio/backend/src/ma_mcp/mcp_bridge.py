"""Original Blender MCP over official SDK stdio; no reimplementation of Blender tools."""

import asyncio, os, json, sys
from pathlib import Path
from contextlib import asynccontextmanager
from datetime import timedelta
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from studio.config import ROOT

DIRECT = {
    "execute_blender_code",
    "get_scene_info",
    "get_object_info",
    "get_viewport_screenshot",
}
ALLOWED = DIRECT | {
    "get_polyhaven_status",
    "get_polyhaven_categories",
    "search_polyhaven_assets",
    "download_polyhaven_asset",
    "set_texture",
    "get_sketchfab_status",
    "search_sketchfab_models",
    "get_sketchfab_model_preview",
    "download_sketchfab_model",
    "get_addon_status",
}


class MCPBridge:
    def __init__(self, port=9876):
        self.port = port
        self.lock = asyncio.Lock()
        self.catalog = {}

    @asynccontextmanager
    async def session(self):
        # Deliberately don't pass cloud credentials to the third-party process.
        env = {k: os.environ[k] for k in ["PATH", "HOME", "TMPDIR"] if k in os.environ}
        env["DISABLE_TELEMETRY"] = "true"
        env["BLENDER_HOST"] = "127.0.0.1"
        env["BLENDER_PORT"] = str(self.port)
        executable = Path(sys.executable).parent / ("blender-mcp.exe" if os.name == "nt" else "blender-mcp")
        p = StdioServerParameters(command=str(executable), env=env)
        with (ROOT / "logs/mcp.log").open("a") as err:
            async with stdio_client(p, errlog=err) as (read, write):
                async with ClientSession(
                    read, write, read_timeout_seconds=timedelta(seconds=180)
                ) as session:
                    await session.initialize()
                    yield session

    async def discover(self):
        async with self.lock, self.session() as s:
            result = await s.list_tools()
            self.catalog = {
                t.name: t.model_dump(mode="json", by_alias=True)
                for t in result.tools
                if t.name in ALLOWED
            }
        return list(self.catalog.values())

    async def call(self, name, arguments):
        if name not in ALLOWED:
            raise ValueError("MCP tool is not enabled: " + name)
        async with self.lock, self.session() as s:
            result = await s.call_tool(name, arguments=arguments)
            return result.model_dump(mode="json", by_alias=True)


def to_ma_result(call_id, result):
    blocks = []
    for c in result.get("content", []):
        if c["type"] == "text":
            blocks.append({"type": "text", "text": c["text"]})
        elif c["type"] == "image":
            blocks.append(
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": c["mimeType"],
                        "data": c["data"],
                    },
                }
            )
        elif c["type"] == "resource" and "text" in c.get("resource", {}):
            blocks.append({"type": "text", "text": c["resource"]["text"]})
        else:
            blocks.append({"type": "text", "text": json.dumps(c, ensure_ascii=False)})
    if result.get("structuredContent") is not None:
        blocks.append(
            {
                "type": "text",
                "text": json.dumps(result["structuredContent"], ensure_ascii=False),
            }
        )
    if not blocks:
        blocks = [{"type": "text", "text": "Tool completed without content."}]
    error = result.get("isError", False) or any(
        c.get("text", "").lower().startswith(("error", "failed")) for c in blocks
    )
    return {
        "type": "user.custom_tool_result",
        "custom_tool_use_id": call_id,
        "is_error": bool(error),
        "content": blocks,
    }
