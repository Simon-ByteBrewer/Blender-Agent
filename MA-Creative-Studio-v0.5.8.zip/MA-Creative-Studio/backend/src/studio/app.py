"""Local MA 导演 Agent API: project orchestration, original MCP adapter and Seedance."""

import asyncio
import contextlib
import json
import time
import os
import sys
import httpx
from contextlib import asynccontextmanager
from contextvars import ContextVar
from pathlib import Path
from typing import Literal
from fastapi import FastAPI, HTTPException, Request, UploadFile, File
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from .config import ROOT, RESOURCES, OUTPUT, output_path, safe_error, key_identity, save_api_key, api_key_status, save_platform, platform_status
from .store import Store, event_time
from .conversation import archive_session, archived_events, conversation_events
from .ark import Ark
from .projects import Projects, DuplicateProjectName, normalize_title
from .jobs import Jobs
from .message_queue import MessageQueue
from .input_images import message_content
from .video_frames import extract_frames, is_frame_extraction, validate_arguments as validate_frame_arguments
from .models import DEFAULT_MODEL, LEGACY_MODEL, agent_model, default_model, list_models, session_agent, default_effort
from .session_model import (remember_session_model, refresh_session_model, verify_session_model,
                            pending_model, apply_pending_model)
from .previs import PREVIS_POLICY
from .blender_instances import BlenderInstances
from ma_self_hosted import execution
from ma_self_hosted.remote import Remotes
from ma_mcp.mcp_bridge import MCPBridge, DIRECT, to_ma_result
from ma_custom_tools.ma import MARunner
from ma_custom_tools.setup_ma import setup
from ma_custom_tools.skills import read_skill, skill_root, guidance
from seedance.client import Seedance, PROMPT
from seedance.compose import compose, clip_paths
from ma_custom_tools.tool_names import (BLENDER_PROJECT, PREVIZ_RENDER, PREVIZ_SKILL, SEEDANCE_VIDEO,
                                        LEGACY_TOOLS, canonical, wire)
from seedance.portraits import Portraits

store = Store()
projects = Projects(store)
projects.import_demo()
ark = Ark(store=store)
bridge = MCPBridge()
jobs = Jobs(store)
seedance = Seedance(ark, store)
portraits = Portraits(store)
active_project = ContextVar("active_project", default=None)
setup_lock = asyncio.Lock()
project_locks = {}
blender_runtime = BlenderInstances(store, projects)
remotes = Remotes()


def remote(p):
    return remotes.for_project(store, p)


async def sync_remote(p):
    state = await remote(p).project_request(p, "GET", "state")
    merged = {j["id"]: j for j in jobs.list()}
    for job in state.get("jobs", []):
        old = merged.get(job["id"], {})
        merged[job["id"]] = {**job, "credential_scope": old.get("credential_scope", key_identity()), "remote": True}
    if state.get("jobs"):
        store.set("jobs", list(merged.values())[-100:])
    if state.get("reference") and state["reference"] != p.get("reference"):
        p["reference"] = state["reference"]
        projects.put(p)
    return state


def instance(p):
    return blender_runtime.for_project(p)


def blender_lock(p):
    return instance(p).operation_lock


def project(project_id):
    try:
        p = projects.get(project_id or "tiananmen-demo")
        p["session_id"] = store.get(session_key(p))
        return p
    except KeyError:
        raise HTTPException(404, "Project not found")


def session_key(p):
    suffix = ":" + p["execution"]["mode"] + ":" + p["execution"]["server_id"] if execution.is_remote(p) else ""
    return "project_session:" + p["id"] + ":" + key_identity() + suffix


def selected_model(p=None):
    if p:
        saved = store.get(session_key(p) + ":model")
        if saved and (p.get("session_id") or not saved.startswith("byok:") or any(m["id"] == saved for m in list_models())):
            return saved
        if p.get("session_id"):
            cfg_key = "platform_ma:" + key_identity()
            if execution.is_self_hosted(p):
                cfg_key += ":self_hosted:" + execution.server_for(store, p)["environment_id"]
            return store.get(cfg_key, {}).get("model", agent_model())
    selected = store.get("ma_model:" + key_identity(), default_model())
    if selected != LEGACY_MODEL and not any(m["id"] == selected for m in list_models()):
        return default_model()
    return selected


def selected_effort(p=None):
    if p:
        saved = store.get(session_key(p) + ":effort", {})
        if saved.get("model") == selected_model(p):
            if p.get("session_id"):
                return saved.get("value")
            return saved.get("value") or default_effort(selected_model(p))
        return None if p.get("session_id") else default_effort(selected_model(p))
    return store.get("ma_effort:" + key_identity() + ":" + selected_model()) or default_effort(selected_model())


def text_result(data):
    return {"content": [{"type": "text", "text": json.dumps(data, ensure_ascii=False)}]}


def busy(project_id=None):
    return any(
        j["kind"] in {"ma", "render"} and j["status"] in {"running", "queued"}
        and (project_id is None or j.get("project_id") == project_id)
        for j in jobs.list()
    )


def require_idle(project_id=None):
    if busy(project_id):
        raise HTTPException(409, "当前会话正在执行任务；可在其他会话并行创作。")


@asynccontextmanager
async def project_request(p):
    async with project_locks.setdefault(p["id"], asyncio.Lock()):
        require_idle(p["id"])
        yield


async def require_blender(p):
    if execution.is_remote(p):
        await remote(p).project_request(p, "POST", "open")
        return
    try:
        # The first launch (fresh Python, addon, .blend) can exceed the default wait.
        await instance(p).ensure_connected(timeout=90)
    except RuntimeError as exc:
        raise HTTPException(503, str(exc)) from exc


async def checked_code(code, p=None):
    connection = instance(p).bridge if p else bridge
    result = await connection.call("execute_blender_code", {"code": code})
    if to_ma_result("check", result)["is_error"]:
        if "Could not connect to Blender" in json.dumps(result):
            raise RuntimeError("Blender MCP 连接已断开。请启动 Blender，连接成功后继续原任务。")
        raise RuntimeError(json.dumps(result, ensure_ascii=False))
    return result


def autosave_code():
    path = str(RESOURCES / "blender_scripts/autosave.py")
    return f"""import sys, importlib.util
if 'ma_studio_autosave' not in sys.modules:
    spec = importlib.util.spec_from_file_location('ma_studio_autosave', {path!r})
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    sys.modules['ma_studio_autosave'] = module
studio_autosave = sys.modules['ma_studio_autosave']
"""


async def activate(p):
    """Select the project scene only inside its independently owned process."""
    if execution.is_remote(p):
        return await remote(p).project_request(p, "POST", "open")
    await require_blender(p)
    path = str(projects.path(p, p["blend"]))
    name = p["scene"]
    width, height = {"720p": (1280, 720), "1080p": (1920, 1080)}[
        p["settings"]["resolution"]
    ]
    code = f"""import bpy, os
name = {name!r}
{autosave_code()}
if bpy.context.scene.name != name and bpy.context.scene.name in studio_autosave._paths:
    studio_autosave.save_scene(bpy.context.scene)
s = bpy.data.scenes.get(name)
main_file = bool(bpy.data.filepath) and os.path.realpath(bpy.data.filepath) == os.path.realpath({path!r})
if s is None and os.path.isfile({path!r}) and not main_file:
    with bpy.data.libraries.load({path!r}, link=False) as (source, target):
        target.scenes = [name] if name in source.scenes else []
    s = bpy.data.scenes.get(name)
if s is None and main_file:
    # This dedicated process holds only this project. If the scene was replaced or
    # renamed (e.g. a new scene created and the old one removed), keep the user's work
    # by adopting the active scene under the project name instead of failing forever.
    s = bpy.context.window.scene
    print("PROJECT_SCENE_ADOPTED", s.name, "->", name)
    s.name = name
if s is None:
    s = bpy.data.scenes.new(name)
    s.render.engine = "BLENDER_WORKBENCH"
    s.render.resolution_x = {width}
    s.render.resolution_y = {height}
    s.render.resolution_percentage = 100
    s.render.fps = {p["settings"]["fps"]}
    s.frame_start = 1
    s.frame_end = {p["settings"]["fps"] * p["settings"]["duration"]}
bpy.context.window.scene = s
import sys
skill_scripts = {str(skill_root() / "scripts")!r}
if skill_scripts not in sys.path:
    sys.path.insert(0, skill_scripts)
import wb_lib
if not hasattr(wb_lib, "attach_scene"):
    import importlib
    importlib.reload(wb_lib)
wb_lib.attach_scene(s)
{autosave_code()}
studio_autosave.register_scene(s, {path!r}, native=True)
if not os.path.isfile({path!r}):
    studio_autosave.save_scene(s, {path!r})
print("PROJECT_READY", s.name)
"""
    result = await checked_code(code, p)
    return result


async def save(p):
    if execution.is_remote(p):
        return await remote(p).tool(p, "local_pipeline", {"action": "save"})
    # The dedicated process contains only this project's data and main file.
    path = str(projects.path(p, p["blend"]))
    return await checked_code(f"""import bpy
s = bpy.data.scenes.get({p["scene"]!r})
assert s is not None, "Project scene is missing"
{autosave_code()}
studio_autosave.register_scene(s, {path!r}, native=True)
studio_autosave.save_scene(s, {path!r})
print("PROJECT_SAVED", {path!r})""", p)


async def close_blender(p):
    """Save, then end only this project's own Blender process. Raises (keeping Blender
    running) when it cannot save, so unsaved work is never discarded."""
    import signal
    state = await instance(p).status()
    if not state["running"]:
        return
    if not state["mcp_connected"] or not state["pid"]:
        raise RuntimeError("Blender 未连接，无法先保存工程；请稍后重试")
    async with blender_lock(p):
        await activate(p)
        await save(p)
    try:
        # Launched with its own session, so the process group is this Blender only.
        os.killpg(state["pid"], signal.SIGTERM)
    except ProcessLookupError:
        return
    for _ in range(100):
        if not (await instance(p).status())["running"]:
            return
        await asyncio.sleep(0.1)
    with contextlib.suppress(ProcessLookupError):
        os.killpg(state["pid"], signal.SIGKILL)


def scoped_reference(p, reference):
    return str(projects.path(p, reference).relative_to(OUTPUT))


def render_summary(p):
    """Only what MA needs to decide its next step, not every job record and artifact URL."""
    render_jobs = [j for j in jobs.list() if j.get("project_id") == p["id"] and j.get("kind") == "render"]
    active = [j for j in render_jobs if j["status"] in {"running", "queued"}]
    videos = [a["name"] for a in projects.artifacts(p) if a["name"].lower().endswith(".mp4")]
    return {"running": bool(active),
            "jobs": [{k: j.get(k) for k in ("id", "status", "error", "result") if j.get(k) is not None}
                     for j in render_jobs[-5:]],
            "videos": videos,
            "message": "渲染进行中，稍后再查询" if active else
                ("没有正在执行的渲染任务。" + ("" if videos else "尚无视频，可调用 all 开始渲染。"))
                + "MA 会话运行状态不代表渲染运行状态。"}


def artifact_summary(p):
    return [{k: a[k] for k in ("name", "bytes", "video") if a.get(k) is not None} for a in projects.artifacts(p)]


async def prepare_seed_args(p, values):
    """Shared by the page and the MA tool: resolve project-relative references safely."""
    args = {k: v for k, v in values.items() if v is not None}
    references = args.get("references")
    if references is not None:
        local = [r["source"] for r in references
                 if not r["source"].startswith(("https://", "asset://", "http://", "data:"))]
        for name in local:
            projects.path(p, name)  # Rejects paths outside this project.
        remote_files = [r["source"] for r in references if r["source"] in local
                        and not projects.path(p, r["source"]).is_file()]
        if execution.is_remote(p) and remote_files:
            await sync_remote(p)
            for name in remote_files:
                await remote(p).download(p, name, projects.path(p, name))
        args["directory"] = str(projects.directory(p).relative_to(OUTPUT))
    elif execution.is_remote(p):
        await sync_remote(p)
        reference = args.get("reference") or p["reference"]
        await remote(p).download(p, reference, projects.path(p, reference))
    args["reference"] = scoped_reference(p, args.get("reference") or projects.get(p["id"])["reference"])
    args["source"] = (args.get("source") or "").strip() or None
    args["upload_session_id"] = p.get("session_id")
    return args


def seed_task_summary(result):
    progress = result.get("studio_progress") or {}
    summary = {k: result.get(k) for k in ("id", "status", "duration", "resolution", "ratio") if result.get(k) is not None}
    summary["progress"] = {k: progress.get(k) for k in ("percent", "elapsed_seconds", "remaining_seconds")}
    if result.get("error"):
        summary["error"] = result["error"]
    if result.get("status") == "succeeded":
        summary["next"] = "调用 download 将视频保存到项目"
    return summary


async def submit_composition(p, clips, resolution="720p", ratio="16:9"):
    if not isinstance(clips, list) or not 1 <= len(clips) <= 50 or any(not isinstance(name, str) for name in clips):
        raise ValueError("clips 需要 1–50 个按播放顺序排列的项目视频文件名")
    # Reuse the project/remote path checks without uploading references to TOS.
    await prepare_seed_args(p, {"references": [{"type": "video", "source": name} for name in clips]})
    directory = str(projects.directory(p).relative_to(OUTPUT))
    clip_paths(directory, clips)
    return jobs.submit("compose", lambda: compose(directory, clips, resolution, ratio), p["id"])


async def dispatch(name, args):
    p = active_project.get()
    if p is None:
        raise ValueError("A project context is required")
    # Sessions created with an older Agent version still call the earlier tool names.
    name, args = canonical(name, args)
    if is_frame_extraction(name, args):
        artifact, _ = validate_frame_arguments(args)
        # Downloaded Seedance videos can be local even for a remote project.
        if execution.is_remote(p) and not projects.path(p, artifact).is_file():
            return await remote(p).tool(p, *wire(name, args))
        return await extract_frames(projects, p, args)
    if execution.is_remote(p) and name != SEEDANCE_VIDEO:
        return await remote(p).tool(p, *wire(name, args))
    if name in DIRECT:
        return await project_tool(p, name, args)
    if name == "blender_tools_list":
        return text_result(await bridge.discover())
    if name == "blender_tools_call":
        return await project_tool(p, args["name"], args.get("arguments", {}))
    if name == PREVIZ_SKILL:
        return text_result(read_skill(args.get("path") or "SKILL.md"))
    if name == BLENDER_PROJECT:
        action = args.get("action")
        if action == "status":
            return text_result(await instance(p).status())
        if action == "open":
            async with blender_lock(p):
                await activate(p)
            return text_result({**await instance(p).status(), "message": "Blender 已启动并加载当前项目场景"})
        if action == "save":
            async with blender_lock(p):
                await activate(p)
                return await save(p)
        if action == "close":
            await close_blender(p)
            return text_result({**await instance(p).status(),
                "message": "已保存并关闭本项目的 Blender；下次调用 Blender 工具时会自动重新启动"})
        raise ValueError("blender_project 的 action 必须是 status、open、save 或 close")
    if name == PREVIZ_RENDER:
        action = args.get("action")
        if action == "status":
            return text_result(render_summary(p))
        if action == "artifacts":
            return text_result(artifact_summary(p))
        if action not in {"preview", "render", "encode", "validate", "all"}:
            raise ValueError("previz_render 不支持该 action")
        async with blender_lock(p):
            if any(j.get("project_id") == p["id"] and j.get("kind") == "render" and j["status"] in {"running", "queued"} for j in jobs.list()):
                raise ValueError("当前项目的渲染任务仍在运行，请用 status 查询")
            if action in {"preview", "render", "all"}:
                await activate(p)
                await save(p)
            job = jobs.submit("render", lambda: jobs.pipeline(action, p, projects), p["id"])
            return text_result({"job_id": job["id"], "status": job["status"], "action": action,
                                "next": "用 previz_render status 查询进度"})
    if name == SEEDANCE_VIDEO:
        action = args.pop("action", None)
        if action == "status" and args.get("job_id"):
            job = next((j for j in jobs.list() if j["id"] == args["job_id"]
                        and j["kind"] == "compose" and j.get("project_id") == p["id"]
                        and j.get("credential_scope") == key_identity()), None)
            if job is None:
                raise ValueError("未找到当前项目的合成任务")
            return text_result(job)
        if action == "portraits":
            return text_result([{"name": i["name"], "type": i["kind"], "source": "asset://" + i["asset_id"]}
                                for i in portraits.list()])
        if action == "compose":
            job = await submit_composition(p, args.get("clips", []), args.get("resolution", "720p"), args.get("ratio", "16:9"))
            return text_result({"job_id": job["id"], "status": job["status"], "next": "用 status 和 job_id 查询合成结果"})
        if action == "submit":
            allowed = {"prompt", "references", "duration", "resolution", "ratio", "generate_audio", "reference", "source", "mode"}
            unknown = set(args) - allowed
            if unknown:
                raise ValueError("submit 不支持参数：" + ", ".join(sorted(unknown)))
            result = await seedance.submit(**await prepare_seed_args(p, args), project_id=p["id"])
            return text_result({**result, "next": "生成通常需要数分钟，用 status 查询"})
        if action not in {"status", "download"} or not args.get("task_id"):
            raise ValueError("seedance_video 的 action 必须是 portraits、submit、status、download 或 compose；生成 status/download 需要 task_id，合成 status 需要 job_id")
        ensure_seed_task(p, args["task_id"])
        if action == "status":
            return text_result(seed_task_summary(await seedance.status(args["task_id"])))
        return text_result(await seedance.download(args["task_id"]))
    raise ValueError("Unknown tool " + name)


async def project_tool(p, name, args):
    if execution.is_remote(p):
        return await remote(p).tool(p, name, args)
    # Only operations within the same project share a lock and MCP process.
    async with blender_lock(p):
        await activate(p)
        result = await instance(p).bridge.call(name, args)
        if name in {"execute_blender_code", "download_polyhaven_asset", "download_sketchfab_model", "set_texture"}:
            await save(p)
        return result


class SessionModelSwitch:
    """Applies a model chosen during a Session at its next idle turn boundary."""

    def binding(self, sid):
        p = active_project.get()
        return session_key(p) if p and p.get("session_id") == sid else None

    def pending(self, sid):
        binding = self.binding(sid)
        return bool(binding and pending_model(store, binding))

    async def apply(self, sid):
        binding = self.binding(sid)
        return bool(binding) and await apply_pending_model(ark, store, binding)


model_switch = SessionModelSwitch()
runner = MARunner(ark, store, dispatch, tool_context=PREVIS_POLICY + "\n" + guidance(), model_switch=model_switch)
# Self-hosted Sessions: the server Worker runs Blender tools; this app runs Seedance and
# frame extraction of videos it holds.
remote_observer = MARunner(ark, store, dispatch, owned_tools={SEEDANCE_VIDEO, PREVIZ_RENDER, *LEGACY_TOOLS},
    tool_filter=lambda name, args: canonical(name, args)[0] == SEEDANCE_VIDEO or is_frame_extraction(name, args),
    model_switch=model_switch)


async def ensure_session(p, fresh=False):
    if p.get("session_id") and not fresh:
        await verify_session_model(ark, store, session_key(p))
        if execution.is_remote(p):
            await remote(p).bind(p)
        return p["session_id"]
    async with setup_lock:
        model_id = selected_model(p)
        effort = selected_effort(p)
        if execution.is_self_hosted(p):
            cfg = await setup(ark, store, remote(p), environment_id=execution.server_for(store, p)["environment_id"])
        elif execution.is_remote(p):
            cfg = await setup(ark, store, remote(p), remote_execution=True)
        else:
            cfg = await setup(ark, store, bridge)
        agent_ref = session_agent(cfg["agent_id"], model_id, effort, base_agent=cfg.get("session_base_agent"))
        s = await ark.request(
            "POST",
            "sessions",
            json={
                "agent": agent_ref,
                "environment_id": cfg["environment_id"],
                "title": p["title"],
            },
        )
        # A user may rename the project while cloud resource creation is pending.
        p["title"] = projects.get(p["id"])["title"]
        if fresh and p.get("session_id"):
            archive_session(store, p["id"], key_identity(), p["session_id"])
            p["session_history"] = [
                *p.get("session_history", []),
                p["session_id"],
            ]
        p["session_id"] = s["id"]
        store.set(session_key(p) + ":model", model_id)
        store.set(session_key(p) + ":effort", {"model": model_id, "value": effort})
        store.set(session_key(p), s["id"])
        store.set(session_key(p) + ':model_expected', {"session_id": s['id'], "model": model_id, "effort": effort})
        if model_id.startswith("byok:"):
            from .byok import bind_session
            snapshot = agent_ref["model"]
            store.set(session_key(p) + ":byok", {"profile_id": model_id, "model": snapshot})
            bind_session(store, s["id"], model_id, snapshot)
        else:
            store.set(session_key(p) + ":byok", None)
        remember_session_model(store, session_key(p), s)
        projects.put(p)
        await verify_session_model(ark, store, session_key(p), s)
        if execution.is_remote(p):
            await remote(p).bind(p)
        return s["id"]


async def run_project(p, message=None, fresh=False):
    token = active_project.set(p)
    try:
        sid = await ensure_session(p, fresh=fresh)
        executor = remote_observer if execution.is_self_hosted(p) else runner
        return await executor.run(sid, message, inbox=MessageQueue(
            store, p["id"], key_identity(), content_builder=lambda text: message_content(
                text, projects.directory(p), "/artifacts/" + p["directory"])))
    finally:
        active_project.reset(token)


async def run_after_render(p):
    while any(j.get("project_id") == p["id"] and j["kind"] == "render" and j["status"] in {"queued", "running"} for j in jobs.list()):
        await asyncio.sleep(1)
    return await run_project(p)


@asynccontextmanager
async def lifespan(app):
    (ROOT / "logs").mkdir(exist_ok=True)
    MessageQueue.recover(store)
    for p in projects.list():
        if normalize_title(p["title"]) != p["title"]:
            projects.put(p)
    for j in jobs.list():
        if j["status"] in {"running", "queued"}:
            j["status"] = "interrupted"
            jobs.update(j)
    yield
    for task in jobs.tasks.values():
        if not task.done():
            task.cancel()
    await asyncio.gather(*jobs.tasks.values(), return_exceptions=True)
    await remotes.close()


app = FastAPI(title="MA 导演 Agent", lifespan=lifespan)


@app.exception_handler(DuplicateProjectName)
async def duplicate_project_name(request, exc):
    return JSONResponse({"detail": str(exc)}, status_code=409)


@app.middleware("http")
async def local_only(request: Request, call_next):
    host = request.headers.get("host", "").split(":")[0]
    origin = request.headers.get("origin")
    cloud_origin = getattr(request.app.state, "cloud_origin", None)
    if cloud_origin:
        from ma_cloud.access import same_request_origin
        invalid = not same_request_origin(request.headers, request.url.scheme)
    else:
        invalid = host not in {"localhost", "127.0.0.1", "testserver"} or (
        origin
        and origin
        not in {
            os.environ.get("STUDIO_ORIGIN", "http://127.0.0.1:7860"),
            "http://localhost:7860",
            "http://127.0.0.1:7860",
            "http://localhost:5173",
            "http://127.0.0.1:5173",
        }
        )
    if invalid:
        return JSONResponse({"detail": "Same origin required" if cloud_origin else "Local origin required"}, 403)
    try:
        return await call_next(request)
    except Exception as e:
        return JSONResponse({"detail": safe_error(e)}, 500)


@app.get("/api/blender")
async def blender_status(project_id: str | None = None):
    if not project_id:
        return {"running": False, "mcp_connected": False, "launching": False, "window_process_count": 0, "project_title": None}
    p = project(project_id)
    if execution.is_remote(p):
        status = await remote(p).project_request(p, "GET", "blender")
        return {**status, "project_title": p["title"]}
    status = await instance(p).status()
    return {**status, "project_title": p["title"] if status["running"] else None}


@app.post("/api/blender/screenshot")
async def blender_screenshot(project_id: str | None = None):
    p = project(project_id)
    return await project_tool(p, "get_viewport_screenshot", {"max_size": 1200})


@app.post("/api/blender/open")
async def blender_open(project_id: str | None = None):
    p = project(project_id)
    if execution.is_remote(p):
        return await remote(p).project_request(p, "POST", "open")
    await require_blender(p)
    async with blender_lock(p):
        await activate(p)
        await save(p)
    await instance(p).open()
    return await blender_status(p["id"])


@app.get("/api/health")
async def health(project_id: str | None = None):
    p = project(project_id) if project_id else None
    if p and p.get("session_id"):
        await refresh_session_model(ark, store, session_key(p), p["session_id"])
    cfg_key = "platform_ma:" + key_identity()
    if p and execution.is_self_hosted(p):
        cfg_key += ":self_hosted:" + execution.server_for(store, p)["environment_id"]
    cfg = store.get(cfg_key, {})
    progress = projects.directory(p) / "render_progress.json" if p else None
    remote_state, remote_error = None, None
    if p and execution.is_remote(p):
        try:
            remote_state = await sync_remote(p)
        except (RuntimeError, OSError, httpx.HTTPError) as exc:
            remote_error = safe_error(exc) or "服务器连接超时，请检查 SSH 登录"
    from ma_self_hosted.activity import snapshot as tool_activity_snapshot
    tool_activity = await tool_activity_snapshot(
        store, p.get("session_id") if p else None,
        worker_active=remote_state.get("worker_active", False) if p and execution.is_self_hosted(p) else bool(
            p and any(j["kind"] == "ma" and j["status"] == "running" for j in project_jobs(p["id"]))),
        remote_client=remote(p) if p and execution.is_self_hosted(p) else None,
    ) if not remote_error else {
        "session_id": p.get("session_id") or "", "available": False,
        "sampled_at": None, "worker_active": False, "calls": [],
    }
    return {
        "edition": getattr(app.state, "edition", "local"),
        **api_key_status(),
        **platform_status(),
        "execution": execution.describe(store, p) if p else execution.settings(store),
        "remote_error": remote_error,
        "ma": {**cfg, "model": selected_model(p), "reasoning_effort": selected_effort(p),
               "session_id": p.get("session_id") if p else None,
               "pending": pending_model(store, session_key(p)) if p and p.get("session_id") else None},
        "ma_models": list_models(),
        "mcp_tool_count": len(bridge.catalog),
        "busy": busy(),
        "project_busy": busy(p["id"]) if p else False,
        "tool_activity": tool_activity,
        "reference_upload_available": bool(p and p.get("session_id")),
        "render_progress": remote_state.get("render_progress") if remote_state is not None else (
            json.loads(progress.read_text()) if progress and progress.exists() else None),
    }


@app.post("/api/settings/api-key")
async def update_api_key(request: Request):
    # Validate without echoing submitted credentials in validation errors.
    if getattr(app.state, "edition", "local") == "cloud" and busy():
        raise HTTPException(409, "请在当前任务完成后修改 API Key。")
    try:
        body = await request.json()
    except (ValueError, UnicodeError):
        raise HTTPException(400, "请求格式无效") from None
    try:
        save_api_key(body.get("api_key") if isinstance(body, dict) else None)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from None
    except OSError:
        raise HTTPException(500, "无法保存 API Key，请检查项目 .env 的写入权限") from None
    if getattr(app.state, "edition", "local") == "cloud":
        await remotes.close()
        remotes.clients.clear()
        await remote({"execution": execution.binding(store)}).connect()
    return api_key_status()


@app.post("/api/settings/platform")
async def update_platform(request: Request):
    # MA resources are regional: switching re-scopes agents, sessions and models.
    if busy():
        raise HTTPException(409, "请在当前任务完成后切换服务平台。")
    try:
        body = await request.json()
    except (ValueError, UnicodeError):
        raise HTTPException(400, "请求格式无效") from None
    try:
        save_platform(body.get("platform") if isinstance(body, dict) else None)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from None
    except OSError:
        raise HTTPException(500, "无法保存服务平台，请检查项目 .env 的写入权限") from None
    if getattr(app.state, "edition", "local") == "cloud":
        await remotes.close()
        remotes.clients.clear()
        await remote({"execution": execution.binding(store)}).connect()
    return {**api_key_status(), **platform_status(), "ma_models": list_models()}


@app.get("/api/settings/byok")
async def byok_settings():
    from .byok import profiles, public_profile
    return {"models": [public_profile(p) for p in profiles()]}


byok_crypto_limit = asyncio.Semaphore(2)


@app.post("/api/settings/byok/export")
@app.post("/api/settings/byok/import")
async def transfer_byok(request: Request):
    from . import byok_transfer as transfer
    exporting = request.url.path.endswith("/export")
    headers = {"Cache-Control": "no-store"}
    try:
        raw = bytearray()
        async for chunk in request.stream():
            raw.extend(chunk)
            if len(raw) > transfer.MAX_FILE_BYTES + 8192:
                return JSONResponse({"detail": "配置文件不能超过 1 MB"}, status_code=413, headers=headers)
        try:
            body = json.loads(raw)
        except (ValueError, RecursionError):
            raise ValueError("请求格式无效") from None
        fields = {"password"} if exporting else {"password", "document"}
        if not isinstance(body, dict) or set(body) != fields:
            raise ValueError("请求格式无效")
        transfer.password_bytes(body["password"])
        async with byok_crypto_limit:
            if exporting:
                result = await asyncio.to_thread(transfer.encrypt, transfer.snapshot(), body["password"])
                headers["Content-Disposition"] = 'attachment; filename="byok-config.encrypted.json"'
            else:
                models = await asyncio.to_thread(transfer.decrypt, body["document"], body["password"])
                result = transfer.merge(models)
        return JSONResponse(result, headers=headers)
    except (ValueError, UnicodeError) as exc:
        return JSONResponse({"detail": str(exc)}, status_code=400, headers=headers)
    except OSError:
        return JSONResponse({"detail": "无法读写 BYOK 配置，请检查本地配置文件权限"}, status_code=500, headers=headers)


@app.post("/api/settings/byok")
@app.put("/api/settings/byok/{profile_id}")
async def update_byok(request: Request, profile_id: str | None = None):
    from .byok import save_profile
    try:
        body = await request.json()
        return save_profile(body, profile_id)
    except (ValueError, UnicodeError) as exc:
        raise HTTPException(400, safe_error(exc)) from None
    except OSError:
        raise HTTPException(500, "无法保存 BYOK 配置，请检查 .env 写入权限") from None


@app.delete("/api/settings/byok/{profile_id}")
async def remove_byok(profile_id: str):
    from .byok import delete_profile
    if busy():
        raise HTTPException(409, "请在当前任务完成后移除 BYOK 模型")
    try:
        delete_profile(profile_id)
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from None
    except OSError:
        raise HTTPException(500, "无法移除 BYOK 配置，请检查 .env 写入权限") from None
    return {"deleted": True}


def switch_session_model(p, model, effort):
    """Record a switch for an existing Session; the runner applies it between turns."""
    current = selected_model(p)
    if model.startswith("byok:") or current.startswith("byok:"):
        # BYOK credentials are bound to the Session when it is created.
        raise HTTPException(409, "自定义模型 BYOK 需新建会话后切换")
    binding = session_key(p)
    canonical = lambda mid: DEFAULT_MODEL if mid == LEGACY_MODEL else mid
    if canonical(model) == canonical(current) and effort == selected_effort(p):
        store.set(binding + ":model_pending", None)
    else:
        store.set(binding + ":model_pending", {"session_id": p["session_id"], "model": model, "effort": effort})
    return {"model": current, "reasoning_effort": selected_effort(p), "pending": pending_model(store, binding)}


class ModelRequest(BaseModel):
    model: str = Field(min_length=1, max_length=200)
    reasoning_effort: str | None = Field(default=None, max_length=20)


@app.post("/api/ma/model")
async def select_model(body: ModelRequest, project_id: str | None = None):
    definition = next((m for m in list_models() if m["id"] == body.model), None)
    if not definition:
        raise HTTPException(400, "请选择模型清单中的模型")
    if body.reasoning_effort is not None and body.reasoning_effort not in definition["reasoning_effort_options"]:
        raise HTTPException(400, f"MA 当前不支持 {definition['name']} / {body.reasoning_effort.title()}，"
                                f"请选择 {'、'.join(value.title() for value in definition['reasoning_effort_options'])}")
    effort = body.reasoning_effort if body.reasoning_effort is not None else definition.get('reasoning_effort_default')
    if project_id:
        p = project(project_id)
        if p.get("session_id"):
            # Only records the choice; safe while a turn runs, as the runner
            # applies it at the next turn boundary.
            return switch_session_model(p, body.model, effort)
        async with project_request(p):
            store.set(session_key(p) + ":model", body.model)
            store.set(session_key(p) + ":effort", {"model": body.model, "value": effort})
    else:
        store.set("ma_model:" + key_identity(), body.model)
        store.set("ma_effort:" + key_identity() + ":" + body.model, effort)
    return {"model": body.model, "reasoning_effort": effort}


class ProjectRequest(BaseModel):
    title: str = Field(min_length=1, max_length=100)
    prompt: str = Field(default="", max_length=20000)
    duration: int = Field(default=8, ge=4, le=30)
    fps: Literal[12, 24, 30] = 24
    resolution: Literal["720p", "1080p"] = "720p"


@app.get("/api/projects")
async def project_list():
    result = []
    for item in projects.list():
        p = project(item["id"])
        p["execution_info"] = execution.describe(store, p)
        work = project_jobs(p["id"])
        active = [j for j in work if j["status"] in {"queued", "running"}]
        latest = (active or work)[-1] if work else None
        p["activity"] = (
            {"status": latest["status"], "kind": latest["kind"]} if latest else None
        )
        history = store.events(p.get('session_id') or '')
        p['updated_at'] = max(
            p.get('updated_at', p['created_at']),
            max((j.get('updated_at', j['created_at']) for j in work), default=0),
            event_time(history[-1]) if history else 0,
        )
        result.append(p)
    return sorted(result, key=lambda p: (p['updated_at'], p['created_at']), reverse=True)


@app.post("/api/projects")
async def project_create(body: ProjectRequest):
    if not normalize_title(body.title):
        raise HTTPException(400, "项目名称不能为空")
    values = body.model_dump()
    values["title"] = normalize_title(body.title)
    p = projects.create(**values)
    p["execution"] = execution.binding(store)
    store.set(session_key(p) + ":model", selected_model())
    store.set(session_key(p) + ":effort", {"model": selected_model(), "value": selected_effort()})
    projects.put(p)
    return p


class RenameRequest(BaseModel):
    title: str = Field(min_length=1, max_length=100)


@app.patch("/api/projects/{project_id}")
async def rename_project(project_id: str, body: RenameRequest):
    title = normalize_title(body.title)
    if not title:
        raise HTTPException(400, "会话名称不能为空")
    p = project(project_id)
    p["title"] = title
    return projects.put(p)


@app.get("/api/artifacts")
async def artifacts(project_id: str | None = None):
    p = project(project_id)
    local = projects.artifacts(p)
    if execution.is_remote(p):
        state = await sync_remote(p)
        merged = {a["name"]: a for a in local}
        merged.update({a["name"]: a for a in state.get("artifacts", [])})
        return list(merged.values())
    return local


class RevealArtifactRequest(BaseModel):
    name: str


@app.post("/api/artifacts/open-folder")
async def open_artifact_folder(body: RevealArtifactRequest, project_id: str):
    p = project(project_id)
    if getattr(app.state, "edition", "local") == "cloud" and execution.is_remote(p):
        if not any(a["name"] == body.name for a in (await sync_remote(p)).get("artifacts", [])):
            raise HTTPException(404, "产物不存在")
        return await remote(p).project_request(p, "POST", "open-folder")
    try:
        path = projects.path(p, body.name)
    except ValueError:
        raise HTTPException(403, "文件路径必须位于当前项目内")
    if execution.is_remote(p):
        state = await sync_remote(p)
        if any(a["name"] == body.name for a in state.get("artifacts", [])):
            await remote(p).download(p, body.name, path)
    if not path.is_file() or not any(
        a["name"] == body.name for a in projects.artifacts(p)
    ):
        raise HTTPException(404, "产物不存在或已被移走，请刷新列表")
    return await open_in_finder(path, reveal=True)


@app.post("/api/projects/{project_id}/open-folder")
async def open_project_folder(project_id: str):
    p = project(project_id)
    if getattr(app.state, "edition", "local") == "cloud" and execution.is_remote(p):
        return await remote(p).project_request(p, "POST", "open-folder")
    path = projects.directory(p)
    # Empty project directories may have been cleaned up; metadata remains valid.
    if not path.exists():
        path.mkdir(parents=True, exist_ok=True)
    if not path.is_dir():
        raise HTTPException(404, "项目文件夹不存在或已被移走")
    return await open_in_finder(path)


async def open_in_finder(path, reveal=False):
    if sys.platform != "darwin":
        raise HTTPException(501, "当前平台暂不支持打开文件夹")
    process = await asyncio.create_subprocess_exec(
        "/usr/bin/open", *(["-R"] if reveal else []), str(path),
        stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
    )
    try:
        code = await asyncio.wait_for(process.wait(), timeout=5)
    except asyncio.TimeoutError:
        try:
            process.kill()
        except ProcessLookupError:
            pass
        await process.wait()
        raise HTTPException(504, "打开文件夹超时，请重试")
    if code:
        raise HTTPException(500, "无法打开文件夹，请重试")
    return {"status": "opened"}


@app.get("/artifacts/{path:path}")
async def artifact(path: str):
    try:
        p = output_path(path)
    except ValueError:
        raise HTTPException(403, "Invalid path")
    parts = Path(path).parts
    if len(parts) >= 3 and parts[0] == "projects":
        try:
            owner = project(parts[1])
        except HTTPException:
            owner = None
        if owner and execution.is_remote(owner):
            state = await sync_remote(owner)
            relative = "/".join(parts[2:])
            entry = next((a for a in state.get("artifacts", []) if a["name"] == relative), None)
            if entry and (not p.exists() or p.stat().st_size != entry["bytes"] or p.stat().st_mtime < entry.get("modified_at", 0)):
                await remote(owner).download(owner, relative, p)
                if entry.get("modified_at"):
                    os.utime(p, (entry["modified_at"], entry["modified_at"]))
    if not p.is_file() or p.suffix.lower() not in {
        ".blend",
        ".mp4",
        ".mov",
        ".png",
        ".webp",
        ".mp3",
        ".wav",
        ".json",
        ".jpg",
        ".jpeg",
    }:
        raise HTTPException(404, "Artifact not found")
    return FileResponse(p)


@app.get("/api/tools")
async def tool_list():
    return await bridge.discover()


class ToolCall(BaseModel):
    name: str
    arguments: dict = Field(default_factory=dict)


@app.post("/api/tools/call")
async def call(body: ToolCall, project_id: str | None = None):
    p = project(project_id)
    async with project_request(p):
        await require_blender(p)
        token = active_project.set(p)
        try:
            return await dispatch(body.name, body.arguments)
        finally:
            active_project.reset(token)


def project_jobs(pid):
    return [
        j
        for j in jobs.list()
        if j.get("project_id") == pid
        and (j.get("credential_scope") == key_identity() or j["kind"] == "render")
    ]


@app.get("/api/jobs")
async def job_list(project_id: str | None = None):
    if project_id:
        p = project(project_id)
        if execution.is_remote(p):
            await sync_remote(p)
        return project_jobs(project_id)
    return [j for j in jobs.list() if j.get("credential_scope") == key_identity()]


class PipelineRequest(BaseModel):
    action: str


@app.post("/api/pipeline")
async def pipeline(body: PipelineRequest, project_id: str | None = None):
    if body.action not in {"save", "preview", "render", "encode", "validate", "all"}:
        raise HTTPException(400, "Unsupported action")
    p = project(project_id)
    if execution.is_remote(p):
        async with project_request(p):
            result = await remote(p).tool(p, "local_pipeline", {"action": body.action})
            if to_ma_result("pipeline", result)["is_error"]:
                raise HTTPException(500, "远程任务失败：" + str(result.get("content", [])))
            state = await sync_remote(p)
            if body.action == "save":
                return {"status": "saved", "artifacts": state.get("artifacts", [])}
            return json.loads(result["content"][0]["text"])
    async with project_request(p):
        if body.action in {"save", "preview", "render", "all"}:
            await require_blender(p)
            async with blender_lock(p):
                await activate(p)
                await save(p)
        if body.action == "save":
            return {"status": "saved", "artifacts": projects.artifacts(p)}
        return jobs.submit("render", lambda: jobs.pipeline(body.action, p, projects), p["id"])


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=20000)
    duration: int | None = Field(default=None, ge=4, le=30)
    resolution: Literal["720p", "1080p"] | None = None
    message_id: str | None = Field(default=None, min_length=1, max_length=100)


@app.post("/api/chat")
async def chat(body: ChatRequest, project_id: str | None = None):
    if not body.message.strip():
        raise HTTPException(400, "请输入创作提示词")
    p = project(project_id)
    async with project_locks.setdefault(p["id"], asyncio.Lock()):
        active = next((j for j in reversed(jobs.list()) if j.get("project_id") == p["id"] and j["kind"] == "ma" and j["status"] in {"running", "queued"}), None)
        if active:
            try:
                item = MessageQueue(store, p["id"], key_identity()).add(body.message, message_id=body.message_id)
            except ValueError as exc:
                raise HTTPException(409, str(exc)) from exc
            return {"status": "queued", "message": item, "job_id": active["id"]}
        if busy(p["id"]):
            try:
                item = MessageQueue(store, p["id"], key_identity()).add(body.message, message_id=body.message_id)
            except ValueError as exc:
                raise HTTPException(409, str(exc)) from exc
            job = jobs.submit("ma", lambda: run_after_render(p), p["id"])
            return {"status": "queued", "message": item, "job_id": job["id"]}
        # Never wait for Blender here: the message is accepted at once and Blender is
        # started by the first Blender tool call (or local_pipeline blender_open).
        p = project(project_id)
        if p.get("session_id"):
            latest = await ark.request("GET", f"sessions/{p['session_id']}/events", params={"order": "desc", "limit": 100})
            terminal = next((e for e in latest.get("data", []) if e["type"] in {"session.status_idle", "session.error"}), None)
            if terminal and (terminal.get("stop_reason") or {}).get("type") == "requires_action":
                try:
                    item = MessageQueue(store, p["id"], key_identity()).add(body.message, message_id=body.message_id)
                except ValueError as exc:
                    raise HTTPException(409, str(exc)) from exc
                job = jobs.submit("ma", lambda: run_project(p), p["id"])
                return {"status": "queued", "message": item, "job_id": job["id"]}
        if not p.get("session_id"):
            if body.duration is not None:
                p["settings"]["duration"] = body.duration
            if body.resolution is not None:
                p["settings"]["resolution"] = body.resolution
        if not p["prompt"]:
            p["prompt"] = body.message
        projects.put(p)
        return jobs.submit("ma", lambda: run_project(p, body.message), p["id"])


@app.get("/api/chat/queue")
async def chat_queue(project_id: str | None = None):
    p = project(project_id)
    return MessageQueue(store, p["id"], key_identity()).list()


@app.delete("/api/chat/queue/{message_id}")
async def cancel_queued_message(message_id: str, project_id: str | None = None):
    p = project(project_id)
    async with project_locks.setdefault(p["id"], asyncio.Lock()):
        try:
            MessageQueue(store, p["id"], key_identity()).cancel(message_id)
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
    return {"status": "cancelled"}

@app.post("/api/ma/resume")
async def resume(project_id: str | None = None):
    p = project(project_id)
    async with project_request(p):
        if not p.get("session_id"):
            raise HTTPException(409, "No MA session")
        from ma_custom_tools.errors import needs_reference_recovery, recovery_prompt

        history = store.events(p["session_id"])
        # Setup may have created a session before local scene activation failed.
        # Inspect cloud history before deciding whether its first prompt was delivered.
        if not history:
            page = await ark.events(p["session_id"], None)
            history = page.get("data", [])
            for event in history:
                store.event(p["session_id"], event)
            if not any(e["type"] == "user.message" for e in history) and p["prompt"]:
                return jobs.submit("ma", lambda: run_project(p, p["prompt"]), p["id"])
        if needs_reference_recovery(history):
            message = recovery_prompt(p, history)
            return jobs.submit(
                "ma", lambda: run_project(p, message, fresh=True), p["id"]
            )
        return jobs.submit("ma", lambda: run_project(p), p["id"])

@app.post("/api/ma/session")
async def new_session(project_id: str | None = None):
    p = project(project_id)
    async with project_request(p):
        await ensure_session(p, fresh=True)
    return p


@app.post("/api/ma/setup")
async def initialize_ma():
    require_idle()
    async with setup_lock:
        return await setup(ark, store, bridge)


@app.get("/api/events")
async def events(project_id: str | None = None):
    p = project(project_id)
    sid = p.get("session_id") or ""
    return JSONResponse(conversation_events(store, p, key_identity()), headers={"X-MA-Session-ID": sid})


@app.get("/api/events/stream")
async def events_stream(request: Request, project_id: str | None = None):
    from .event_stream import browser_events
    project(project_id)  # Resolve invalid projects before sending stream headers.
    scope = key_identity()
    def resolve_session():
        if key_identity() != scope:
            return None
        try:
            return project(project_id).get("session_id") or ""
        except HTTPException:
            return None
    def history(sid):
        return archived_events(store, project(project_id), scope, sid)
    return StreamingResponse(browser_events(store, resolve_session, request, history=history), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no"})


@app.post("/api/ma/interrupt")
async def interrupt(project_id: str | None = None):
    p = project(project_id)
    async with project_locks.setdefault(p["id"], asyncio.Lock()):
        sid = p.get("session_id")
        # Keep cancelled text available in the UI, but never silently replay it.
        MessageQueue(store, p["id"], key_identity()).cancel()
        if sid:
            await ark.send(sid, [{"type": "user.interrupt"}])
        remote_error = None
        if execution.is_remote(p):
            try:
                await remote(p).project_request(p, "POST", "interrupt")
            except Exception as exc:
                remote_error = safe_error(exc)
        active = [j for j in jobs.list() if j.get("project_id") == p["id"]
                  and j["kind"] == "ma" and j["status"] in {"running", "queued"}]
        cancelled = []
        for job in active:
            task = jobs.tasks.get(job["id"])
            if task and not task.done():
                task.cancel()
                cancelled.append(task)
        if cancelled:
            await asyncio.gather(*cancelled, return_exceptions=True)
        # A queued task cancelled before its first step never enters work()'s finally.
        active_ids = {j["id"] for j in active}
        for job in jobs.list():
            if job["id"] in active_ids and job["status"] in {"running", "queued"}:
                job["status"] = "interrupted"
                jobs.update(job)
        events_synced = not sid
        if sid:
            try:
                async with asyncio.timeout(5):
                    latest = await ark.request("GET", f"sessions/{sid}/events",
                                               params={"order": "desc", "limit": 100})
                for event in latest.get("data", []):
                    store.event(sid, event)
                events_synced = True
            except Exception:
                # Cloud interruption already succeeded. Keep the local interrupted
                # status authoritative for the composer if this read fails.
                pass
        if remote_error:
            raise HTTPException(503, "本机任务已停止；远程停止结果尚未确认：" + remote_error)
        return {"status": "interrupt_requested", "events_synced": events_synced}


class SeedReference(BaseModel):
    type: Literal["image", "video", "audio"]
    source: str = Field(min_length=1, max_length=4096)


class SeedRequest(BaseModel):
    reference: str | None = None
    prompt: str = Field(default=PROMPT, min_length=1, max_length=20000)
    duration: int = Field(default=8, ge=-1, le=30)
    resolution: Literal["480p", "720p", "1080p"] = "720p"
    ratio: Literal["16:9", "4:3", "1:1", "3:4", "9:16", "21:9", "adaptive"] = "16:9"
    generate_audio: bool = False
    mode: Literal["auto", "reference", "extend", "edit"] = "auto"
    source: str | None = None
    # Ordered omni references. Omitted: the legacy single project reference video.
    references: list[SeedReference] | None = Field(default=None, max_length=50)


class PortraitRequest(BaseModel):
    name: str
    asset_id: str
    kind: Literal["image", "video"] = "image"
    note: str = ""


def ensure_seed_task(p, tid):
    task = store.get("seedance:" + tid, {})
    if (
        task.get("project_id") != p["id"]
        or task.get("credential_scope") != key_identity()
    ):
        raise HTTPException(404, "Seedance task does not belong to this project")


@app.post("/api/seedance")
async def seed_submit(body: SeedRequest, project_id: str | None = None):
    p = project(project_id)
    values = body.model_dump()
    if values["references"] is None:
        values.pop("references")
    try:
        args = await prepare_seed_args(p, values)
        seedance.validate(**args)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    if any(j["kind"] == "seedance" and j.get("project_id") == p["id"]
           and j["status"] in {"queued", "running"} for j in jobs.list()):
        raise HTTPException(409, "参考视频正在上传或提交中，请等待当前提交完成。")
    return jobs.submit(
        "seedance", lambda: seedance.submit(**args, project_id=p["id"]), p["id"]
    )


@app.get("/api/seedance/portraits")
async def portrait_list():
    return portraits.list()


class ComposeRequest(BaseModel):
    clips: list[str] = Field(min_length=1, max_length=50)
    resolution: Literal["480p", "720p", "1080p"] = "720p"
    ratio: Literal["16:9", "9:16", "1:1", "4:3", "3:4", "21:9"] = "16:9"


@app.post("/api/seedance/compose")
async def seed_compose(body: ComposeRequest, project_id: str | None = None):
    try:
        return await submit_composition(project(project_id), **body.model_dump())
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post("/api/seedance/portraits")
async def portrait_add(body: PortraitRequest):
    try:
        return portraits.add(body.name, body.asset_id, body.kind, body.note)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.delete("/api/seedance/portraits/{portrait_id}")
async def portrait_remove(portrait_id: str):
    try:
        portraits.remove(portrait_id)
    except KeyError as exc:
        raise HTTPException(404, "人像不存在") from exc
    return {"ok": True}


@app.get("/api/seedance/{task_id}")
async def seed_status(task_id: str, project_id: str | None = None):
    ensure_seed_task(project(project_id), task_id)
    return await seedance.status(task_id)


@app.post("/api/seedance/{task_id}/download")
async def seed_download(task_id: str, project_id: str | None = None):
    ensure_seed_task(project(project_id), task_id)
    return await seedance.download(task_id)


@app.post("/api/upload")
async def upload(file: UploadFile = File(...), project_id: str | None = None):
    p = project(project_id)
    name = Path(file.filename or "").name
    suffix = Path(name).suffix.lower()
    if suffix not in {".mp4", ".mov", ".png", ".jpg", ".jpeg", ".webp", ".mp3", ".wav"}:
        raise HTTPException(400, "Upload MP4/MOV/JPG/PNG/WEBP/MP3/WAV only")
    limit = (200 if suffix in {".mp4", ".mov"} else 15 if suffix in {".mp3", ".wav"} else 50) * 1024 * 1024
    dest = projects.path(p, "uploads/" + str(time.time_ns()) + "_" + name)
    dest.parent.mkdir(parents=True, exist_ok=True)
    total = 0
    try:
        with dest.open("wb") as f:
            while chunk := await file.read(1024 * 1024):
                total += len(chunk)
                if total > limit:
                    raise HTTPException(413, f"Maximum {limit // 1024 // 1024}MB")
                f.write(chunk)
    except BaseException:
        dest.unlink(missing_ok=True)
        raise
    if execution.is_remote(p):
        await remote(p).upload(p, str(dest.relative_to(projects.directory(p))), dest)
    return {
        "name": str(dest.relative_to(projects.directory(p))),
        "url": "/artifacts/" + str(dest.relative_to(OUTPUT)),
    }


from ma_self_hosted.routes import router as self_hosted_router
app.include_router(self_hosted_router(sys.modules[__name__]))

if (RESOURCES / "frontend/dist").exists():
    app.mount(
        "/", StaticFiles(directory=RESOURCES / "frontend/dist", html=True), name="frontend"
    )
