"""Public MA model catalog. Credentials and display-only inference hints stay local."""

import json
from .config import RESOURCES, platform

DEFAULT_MODEL = "doubao-seed-evolving"
LEGACY_MODEL = "doubao-seed-evolving-latest-version"
# Evolving models only run when inherited from the Agent definition (all platforms).
EVOLVING_MODELS = {DEFAULT_MODEL, LEGACY_MODEL, "dola-seed-evolving"}
CATALOG = RESOURCES / "backend/config/ma_models.json"


def default_model():
    """The selectable catalog default for the configured platform."""
    return platform()["default_model"]


def agent_model():
    """The model a newly created shared Agent is defined with."""
    return platform()["agent_model"]


def list_models():
    raw = json.loads(CATALOG.read_text(encoding="utf-8"))
    family = platform()["family"]
    models = []
    seen = set()
    for provider in raw.get("providers", {}).values():
        for model in provider.get("models", []):
            mid = model.get("id")
            if not isinstance(mid, str) or not mid or mid in seen:
                continue
            if family not in model.get("platforms", ["volcengine"]):
                continue
            seen.add(mid)
            models.append({"id": mid, "name": model.get("name") or mid,
                           "contextWindow": model.get("contextWindow"),
                           "thinking": model.get("thinking"),
                           "reasoning_effort_options": model.get("reasoning_effort_options", []),
                           "reasoning_effort_default": model.get("reasoning_effort_default")})
    from .byok import catalog
    return models + catalog()


def default_effort(model_id):
    mid = DEFAULT_MODEL if model_id == LEGACY_MODEL else model_id
    definition = next((m for m in list_models() if m['id'] == mid), {})
    return definition.get('reasoning_effort_default')


def session_agent(agent_id, model_id, reasoning_effort=None, *, base_agent=None):
    # Official SDK AgentRef / ModelOverrides: freeze only this Session's model,
    # preserving the shared Agent's tools, skills and other sessions.
    if model_id.startswith("byok:"):
        from .byok import find_profile
        profile = find_profile(model_id)
        if not profile:
            raise ValueError("BYOK 模型配置已移除，请重新选择模型")
        return {"type": "agent_with_overrides", "id": agent_id, "model": profile["model"]}
    model = {"id": model_id}
    if reasoning_effort is not None:
        canonical = DEFAULT_MODEL if model_id == LEGACY_MODEL else model_id
        definition = next((m for m in list_models() if m['id'] == canonical), None)
        if definition and reasoning_effort not in definition['reasoning_effort_options']:
            raise ValueError(f"MA 当前不支持 {definition['name']} / {reasoning_effort.title()}，"
                             f"请选择 {'、'.join(value.title() for value in definition['reasoning_effort_options'])}")
        model.update(reasoning_effort=reasoning_effort, thinking="enabled")
    reference = {"type": "agent_with_overrides", "id": agent_id, "model": model}
    # MA currently rejects explicit Evolving ID overrides with ModelNotOpen,
    # even when direct inference and inheriting that Agent model both work.
    # Only inherit from a freshly read, matching Agent snapshot. Pin its version
    # so a concurrent Agent update cannot silently change the selected model.
    evolving_ids = EVOLVING_MODELS
    base_agent = base_agent or {}
    version = base_agent.get("version")
    if (model_id in evolving_ids and base_agent.get("id") == agent_id
            and (base_agent.get("model") or {}).get("id") in evolving_ids
            and type(version) is int and version > 0):
        model.pop("id")
        reference["version"] = version
    return reference
