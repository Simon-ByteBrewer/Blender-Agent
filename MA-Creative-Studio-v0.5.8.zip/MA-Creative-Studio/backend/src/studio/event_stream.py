"""Best-effort Ark text previews and the local browser event stream.

Only public text blocks are accumulated. Final cloud events are authoritative;
preview frames do not drive tool execution or the durable MA execution cursor.
"""

import asyncio
from copy import deepcopy
from datetime import datetime, timezone
import json
import time


TEXT_EVENTS = {"agent.message", "agent.thinking"}


class StreamPreviews:
    def __init__(self):
        self.pending = {}
        self.completed = set()

    def accept(self, frame):
        if not isinstance(frame, dict):
            return []
        kind = frame.get("type")
        if kind == "event_start":
            event = frame.get("event") or {}
            if not isinstance(event, dict):
                return []
            eid = event.get("id")
            if not eid or event.get("type") not in TEXT_EVENTS or eid in self.completed:
                return []
            # A repeated start replaces its preview buffer, never appends a
            # second message. Store protects visible text from short replays.
            self.pending[eid] = {"id": eid, "type": event["type"], "content": [],
                "created_at": datetime.now(timezone.utc).isoformat(), "_streaming": True}
            return [deepcopy(self.pending[eid])]
        if kind == "event_delta":
            eid = frame.get("event_id")
            event = self.pending.get(eid)
            delta = frame.get("delta") or {}
            if event is None or not isinstance(delta, dict) or delta.get("type") != "content_delta":
                return []
            index = delta.get("index", 0)
            if not isinstance(index, int) or isinstance(index, bool) or not 0 <= index < 256:
                return []
            content = delta.get("content")
            blocks = content if isinstance(content, list) else [content]
            text = "".join(block["text"] for block in blocks if isinstance(block, dict)
                           and block.get("type") == "text" and isinstance(block.get("text"), str))
            if not text:
                return []
            while len(event["content"]) <= index:
                event["content"].append({"type": "text", "text": ""})
            block = event["content"][index]
            block["text"] = (block["text"] + text)[:1000000]
            return [deepcopy(event)]
        if not frame.get("id") or not kind:
            return []
        updates = []
        if kind in TEXT_EVENTS:
            self.pending.pop(frame["id"], None)
            self.completed.add(frame["id"])
        elif kind in {"span.model_request_end", "session.status_idle", "session.error", "session.status_terminated"}:
            for event in self.pending.values():
                updates.append({**deepcopy(event), "_streaming": False, "_stream_incomplete": True})
            self.pending.clear()
        updates.append(frame)
        return updates


def preview_extends(previous, incoming):
    """Replayed or delayed previews must not erase text already displayed."""
    before, after = previous.get("content") or [], incoming.get("content") or []
    return all(index < len(after) and isinstance(block, dict) and isinstance(after[index], dict)
               and str(after[index].get("text", "")).startswith(str(block.get("text", "")))
               for index, block in enumerate(before))


def _sse(kind, value):
    return "event: " + kind + "\ndata: " + json.dumps(value, ensure_ascii=False, separators=(",", ":")) + "\n\n"


async def browser_events(store, resolve_session, request, *, history=None):
    """Every connection starts with history; updates are coalesced by event ID."""
    while not await request.is_disconnected():
        sid = resolve_session()
        if sid is None:
            yield _sse("snapshot", {"session_id": "", "events": []})
            return
        with store.subscribe(sid) as changed:
            known = {}
            from .store import event_time
            snapshot = sorted([*(history(sid) if history else []), *store.events(sid)], key=event_time)
            for event in snapshot:
                known[event["id"]] = json.dumps(event, sort_keys=True, ensure_ascii=False)
            yield _sse("snapshot", {"session_id": sid, "events": snapshot})
            last_heartbeat = time.monotonic()
            while not await request.is_disconnected() and resolve_session() == sid:
                changed.clear()
                updates = []
                for event in store.events(sid):
                    encoded = json.dumps(event, sort_keys=True, ensure_ascii=False)
                    if known.get(event["id"]) != encoded:
                        known[event["id"]] = encoded
                        updates.append(event)
                if updates:
                    yield _sse("events", {"session_id": sid, "events": updates})
                if time.monotonic() - last_heartbeat >= 15:
                    yield ": heartbeat\n\n"
                    last_heartbeat = time.monotonic()
                try:
                    await asyncio.wait_for(changed.wait(), 1)
                    await asyncio.sleep(.03)
                except TimeoutError:
                    pass
