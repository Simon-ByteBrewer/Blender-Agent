"""Password-encrypted, versioned BYOK backups. Never include MA credentials."""
import base64
import json
import os
import tempfile
import uuid
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from dotenv import set_key

from . import byok

MAX_FILE_BYTES = 1024 * 1024
HEADER = {"format": "scene-studio-byok", "version": 1, "cipher": "AES-256-GCM",
          "kdf": "PBKDF2-HMAC-SHA256", "iterations": 600_000}
AAD = json.dumps(HEADER, sort_keys=True, separators=(",", ":")).encode()


def password_bytes(password):
    if not isinstance(password, str) or not 12 <= len(password) <= 256 or not password.strip():
        raise ValueError("请使用 12–256 个字符的独立加密口令")
    try:
        return password.encode("utf-8")
    except UnicodeError:
        raise ValueError("加密口令包含无效字符") from None


def derive(password, salt):
    return PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt,
                     iterations=HEADER["iterations"]).derive(password_bytes(password))


def snapshot():
    values = byok.config()
    models = [{k: p[k] for k in ("name", "model", "auth_header", "auth_scheme")} |
              {"api_key": values.get(p["key_env"]) or ""} for p in byok.profiles()]
    if not models:
        raise ValueError("暂无可导出的 BYOK 模型")
    validate_models({"models": models})
    return {"models": models}


def encrypt(payload, password):
    salt, nonce = os.urandom(16), os.urandom(12)
    ciphertext = AESGCM(derive(password, salt)).encrypt(
        nonce, json.dumps(payload, ensure_ascii=False).encode(), AAD)
    encode = lambda value: base64.b64encode(value).decode("ascii")
    return {**HEADER, "salt": encode(salt), "nonce": encode(nonce), "ciphertext": encode(ciphertext)}


def decrypt(document, password):
    password_bytes(password)
    try:
        if not isinstance(document, dict) or set(document) != {*HEADER, "salt", "nonce", "ciphertext"}:
            raise ValueError()
        if any(type(document[k]) is not type(v) or document[k] != v for k, v in HEADER.items()):
            raise ValueError()
        def decode(name):
            value = document[name]
            if not isinstance(value, str) or len(value) > MAX_FILE_BYTES:
                raise ValueError()
            return base64.b64decode(value, validate=True)
        salt, nonce, ciphertext = decode("salt"), decode("nonce"), decode("ciphertext")
        if len(salt) != 16 or len(nonce) != 12 or len(ciphertext) < 16:
            raise ValueError()
    except (ValueError, TypeError):
        raise ValueError("不是受支持的 BYOK 加密配置文件，或文件已损坏") from None
    try:
        plaintext = AESGCM(derive(password, salt)).decrypt(nonce, ciphertext, AAD)
    except InvalidTag:
        raise ValueError("口令错误或文件已损坏，未导入任何配置") from None
    try:
        return validate_models(json.loads(plaintext))
    except (ValueError, TypeError, RecursionError):
        raise ValueError("文件中的模型配置无效，未导入任何配置") from None


def validate_models(payload):
    if not isinstance(payload, dict) or set(payload) != {"models"}:
        raise ValueError("模型配置无效")
    models = payload["models"]
    if not isinstance(models, list) or not 1 <= len(models) <= 50:
        raise ValueError("配置文件需包含 1–50 个模型")
    result = []
    for item in models:
        try:
            data = byok.ProfileInput.model_validate(item)
            byok.resolve_auth(data)
            if not data.api_key:
                raise ValueError()
        except ValueError:
            raise ValueError("模型配置无效或缺少 API Key") from None
        result.append(data.model_dump())
    return result


def merge(models):
    """Validate everything before a single atomic replacement of the local .env.

    Called on the app event loop, like other settings writes, with no await
    between reading the current configuration and replacing it.
    """
    models = validate_models({"models": models})
    records = byok.profiles()
    def identity(p):
        return json.dumps([p["model"], p["auth_header"], p["auth_scheme"]], sort_keys=True)
    existing = {identity(p) for p in records}
    secrets = {}
    skipped = 0
    for data in models:
        marker = identity(data)
        if marker in existing:
            skipped += 1
            continue
        existing.add(marker)
        uid = uuid.uuid4().hex
        key_env = "BYOK_KEY_" + uid.upper()
        secrets[key_env] = data.pop("api_key")
        records.append({"id": "byok:" + uid, **data, "key_env": key_env})
    if len(records) > 50:
        raise ValueError("导入后将超过 50 个模型，未导入任何配置")
    if secrets:
        path = byok.ROOT / ".env"
        # Stage in the same directory (0600), preserve unrelated settings, and
        # replace only after all writes succeed. Failed imports leave no keys.
        fd, name = tempfile.mkstemp(prefix=".byok-import-", dir=byok.ROOT)
        staged = Path(name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                stream.write(path.read_text() if path.exists() else "")
            for key, value in secrets.items():
                set_key(staged, key, value, quote_mode="always")
            set_key(staged, "BYOK_MODELS", json.dumps(records, ensure_ascii=False), quote_mode="always")
            staged.chmod(0o600)
            os.replace(staged, path)
        finally:
            staged.unlink(missing_ok=True)
    return {"imported": len(secrets), "skipped": skipped,
            "models": [byok.public_profile(p) for p in records]}
