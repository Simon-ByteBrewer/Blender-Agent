import sqlite3, json
import asyncio
import re
from datetime import datetime, timezone
from contextlib import contextmanager
from .config import STATE


def event_time(event):
    value = event.get('processed_at') or event.get('created_at')
    if isinstance(value, (int, float)):
        return value
    if value:
        try:
            return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()
        except ValueError:
            pass
    match = re.search(r'-(\d{14})-', event.get('id', ''))
    return datetime.strptime(match[1], '%Y%m%d%H%M%S').replace(tzinfo=timezone.utc).timestamp() if match else 0


class Store:
    def __init__(self, path=None):
        self.path = str(path or STATE / "state.sqlite3")
        self._subscribers = {}
        with self.connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS events(sid TEXT,id TEXT,payload TEXT,PRIMARY KEY(sid,id));
CREATE TABLE IF NOT EXISTS calls(sid TEXT,id TEXT,status TEXT,result TEXT,PRIMARY KEY(sid,id));""")

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=20)
        try:
            with db:
                yield db
        finally:
            db.close()

    def get(self, k, default=None):
        with self.connect() as db:
            r = db.execute("SELECT value FROM kv WHERE key=?", (k,)).fetchone()
        return json.loads(r[0]) if r else default

    def set(self, k, v):
        with self.connect() as db:
            db.execute(
                "INSERT OR REPLACE INTO kv VALUES(?,?)",
                (k, json.dumps(v, ensure_ascii=False)),
            )

    def event(self, sid, e):
        with self.connect() as db:
            previous = db.execute("SELECT payload FROM events WHERE sid=? AND id=?", (sid, e["id"])).fetchone()
            if previous:
                previous = json.loads(previous[0])
                if previous == e or previous.get("processed_at") and not e.get("processed_at"):
                    return
                if e.get("_streaming") or e.get("_stream_incomplete"):
                    from .event_stream import preview_extends
                    if (not previous.get("_streaming") and not previous.get("_stream_incomplete")) or not preview_extends(previous, e):
                        return
            db.execute(
                "INSERT INTO events VALUES(?,?,?) ON CONFLICT(sid,id) DO UPDATE SET payload=excluded.payload",
                (sid, e["id"], json.dumps(e, ensure_ascii=False)),
            )
        for loop, changed in tuple(self._subscribers.get(sid, ())):
            if not loop.is_closed():
                loop.call_soon_threadsafe(changed.set)

    @contextmanager
    def subscribe(self, sid):
        changed = asyncio.Event()
        subscriber = (asyncio.get_running_loop(), changed)
        self._subscribers.setdefault(sid, set()).add(subscriber)
        try:
            yield changed
        finally:
            self._subscribers[sid].discard(subscriber)
            if not self._subscribers[sid]:
                self._subscribers.pop(sid, None)

    def events(self, sid):
        with self.connect() as db:
            rows = db.execute(
                "SELECT payload FROM events WHERE sid=? ORDER BY rowid", (sid,)
            ).fetchall()
        return sorted((json.loads(r[0]) for r in rows), key=event_time)

    def call(self, sid, cid):
        with self.connect() as db:
            r = db.execute(
                "SELECT status,result FROM calls WHERE sid=? AND id=?", (sid, cid)
            ).fetchone()
        return (r[0], json.loads(r[1]) if r[1] else None) if r else None

    def save_call(self, sid, cid, status, result=None):
        with self.connect() as db:
            db.execute(
                "INSERT OR REPLACE INTO calls VALUES(?,?,?,?)",
                (sid, cid, status, json.dumps(result) if result else None),
            )
