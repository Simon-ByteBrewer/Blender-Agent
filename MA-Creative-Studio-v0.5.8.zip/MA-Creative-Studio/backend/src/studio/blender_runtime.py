"""Mac GUI Blender lifecycle. Never close or replace the user's existing windows."""

import asyncio
import shlex
import time
from pathlib import Path
from .config import RESOURCES


def gui_processes(output):
    result = []
    for line in output.splitlines():
        parts = line.strip().split(None, 1)
        if len(parts) != 2 or not parts[0].isdigit():
            continue
        try:
            argv = shlex.split(parts[1])
        except ValueError:
            continue
        if (
            argv
            and (
                argv[0].endswith("/Blender.app/Contents/MacOS/Blender")
                or argv[0] == "Blender"
                or Path(argv[0]).name == "blender"
            )
            and not any(a in {"-b", "--background"} for a in argv[1:])
        ):
            result.append(int(parts[0]))
    return result


class BlenderRuntime:
    def __init__(self):
        self.lock = asyncio.Lock()
        self.connection_lock = asyncio.Lock()
        self.connecting = False
        self.started_at = 0

    async def status(self):
        process = await asyncio.create_subprocess_exec(
            "ps", "-axo", "pid=,args=", stdout=asyncio.subprocess.PIPE
        )
        stdout, _ = await process.communicate()
        pids = gui_processes(stdout.decode(errors="replace"))
        connected = False
        try:
            _, writer = await asyncio.wait_for(
                asyncio.open_connection("127.0.0.1", 9876), timeout=0.4
            )
            writer.close()
            await writer.wait_closed()
            connected = True
        except (OSError, TimeoutError):
            pass
        return {
            "running": bool(pids),
            "window_process_count": len(pids),
            "mcp_connected": connected,
            "launching": not connected and (self.connecting or time.monotonic() - self.started_at < 20),
        }

    async def ensure_connected(self, timeout=30):
        async with self.connection_lock:
            try:
                async with asyncio.timeout(timeout):
                    state = await self.status()
                    if state["mcp_connected"]:
                        return state
                    await self.open()
                    self.connecting = True
                    while True:
                        state = await self.status()
                        if state["mcp_connected"]:
                            return state
                        await asyncio.sleep(0.5)
            except TimeoutError:
                raise RuntimeError("Blender 自动连接超时，请检查 Blender 插件后重试。") from None
            finally:
                self.connecting = False

    async def open(self):
        async with self.lock:
            state = await self.status()
            if state["launching"]:
                return state
            if state["running"] and state["mcp_connected"]:
                command = ["open", "-a", "Blender"]
            else:
                command = [
                    "open",
                    "-n",
                    "-a",
                    "Blender",
                    "--args",
                    "--python",
                    str(RESOURCES / "blender_scripts/start_blender.py"),
                ]
                self.started_at = time.monotonic()
            process = await asyncio.create_subprocess_exec(
                *command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await process.communicate()
            if process.returncode:
                self.started_at = 0
                raise RuntimeError(
                    "无法打开 Blender：" + stderr.decode(errors="replace")[:400]
                )
            return await self.status()
