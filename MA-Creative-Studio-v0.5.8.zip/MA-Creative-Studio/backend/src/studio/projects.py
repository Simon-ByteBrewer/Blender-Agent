"""Project metadata and output isolation. The Tiananmen project is an imported demo."""

import time
import re
from datetime import datetime
from zoneinfo import ZoneInfo
from .config import OUTPUT, output_path
from .previs import PREVIS_POLICY
from .media import video_metadata


def normalize_title(title):
    title = re.sub(r"[\s·•・.。…—–－]+", "-", title.strip())
    return re.sub(r"-+", "-", title).strip("-")


class DuplicateProjectName(ValueError):
    pass


def suggest_title(prompt):
    """Extract a scene subject rather than tool names or output instructions."""
    text = re.sub(r"[ \t]+", " ", prompt).strip()
    opening = re.split(r"[。！？!?\n]", text, maxsplit=1)[0]
    quoted = re.search(r'(?:制作|创建|设计|搭建|生成|建模)[^“「\"]{0,12}[“「\"]([^”」\"]{2,80})[”」\"]', opening)
    cleaned = re.sub(
        r"(?:请)?(?:使用|通过|用)\s*(?:Blender(?:\s*MCP)?|MA(?:\s*Agent)?|MCP)[，,:：\s]*",
        "", opening, flags=re.I,
    )
    clauses = re.split(r"[，；,;]", cleaned)
    subject = quoted.group(1) if quoted else next(
        (part.strip() for part in clauses if part.strip() and not re.fullmatch(
            r"(?:请)?(?:先)?(?:使用|通过|用)?\s*(?:Blender|MCP|MA|Agent|3D)[\s.]*", part.strip(), re.I
        )), "新创作"
    )
    subject = re.sub(
        r"^(?:(?:请你|请|帮我|帮忙|我想要|我想|我要|创建|制作|生成|设计|搭建|建模|一个|一座|一款|一段|一幅)\s*)+",
        "", subject,
    ).strip(" ：:、\"“”")
    subject = re.sub(r"(?:及|与|和)周边(?:廊道|环境|建筑|空间).*$", "", subject)
    subject = re.sub(r"(?:的)?(?:3D场景|3D 场景|三维场景|场景)$", "", subject).strip()
    subject = subject or "新创作"
    subject = normalize_title(subject)
    if len(subject) > 22:
        subject = subject[:22].rstrip("-")
    if "漫游" in opening:
        return subject if "漫游" in subject else subject + ("漫游" if "-" in subject else "-沉浸漫游")
    for keywords, label in (
        (("游客",), "游客视角"),
        (("环绕", "绕拍"), "环绕展示"),
        (("推进",), "镜头推进"),
        (("宣传片",), "宣传短片"),
    ):
        if any(word in text for word in keywords) and label not in subject:
            return f"{subject}-{label}"
    return subject if "-" in subject else f"{subject}-场景创作"


class Projects:
    def __init__(self, store):
        self.store = store

    def list(self):
        return self.store.get("projects", [])

    def put(self, project):
        project['updated_at'] = time.time()
        project["title"] = normalize_title(project["title"])
        self.check_title(project["title"], project["id"])
        items = [p for p in self.list() if p["id"] != project["id"]]
        self.store.set("projects", [*items, project])
        return project

    def check_title(self, title, exclude_id=None):
        canonical = normalize_title(title).casefold()
        if any(p["id"] != exclude_id and normalize_title(p["title"]).casefold() == canonical for p in self.list()):
            raise DuplicateProjectName("任务名称已存在，请换一个名称。")

    def get(self, pid):
        for p in self.list():
            if p["id"] == pid:
                return p
        raise KeyError("Project not found")

    def create(self, title, prompt="", duration=8, fps=24, resolution="720p"):
        self.check_title(title)
        existing_ids = {p["id"] for p in self.list()}
        for _ in range(100):
            created = datetime.now(ZoneInfo("Asia/Shanghai"))
            pid = created.strftime("%y%m%d-%H%M%S-%f")
            if pid in existing_ids:
                continue
            try:
                output_path("projects/" + pid).mkdir(parents=True)
            except FileExistsError:
                continue
            break
        else:
            raise RuntimeError("无法分配唯一项目时间戳，请重试")
        project = dict(
            id=pid,
            title=title,
            prompt=prompt,
            created_at=created.timestamp(),
            directory="projects/" + pid,
            scene="Studio_" + pid,
            blend="previz-" + pid + ".blend",
            reference="reference.mp4",
            session_id=None,
            settings=dict(duration=duration, fps=fps, resolution=resolution),
            demo=False,
        )
        return self.put(project)

    def import_demo(self):
        if any(p["id"] == "tiananmen-demo" for p in self.list()):
            return
        if not (OUTPUT / "tiananmen_tourist.blend").exists():
            return
        self.put(
            dict(
                id="tiananmen-demo",
                title="天安门 · 游客视角",
                prompt="北京天安门宣传片，游客视角，自然步行与机位切换。",
                created_at=0,
                directory="",
                scene="Tiananmen_Tourist",
                blend="tiananmen_tourist.blend",
                reference="tiananmen_reference.mp4",
                session_id=None,
                settings=dict(duration=12, fps=24, resolution="720p"),
                demo=True,
            )
        )

    def directory(self, p):
        return output_path(p["directory"])

    def path(self, p, name):
        root = self.directory(p)
        dest = (root / name).resolve()
        if not dest.is_relative_to(root) or (
            p["demo"] and dest.is_relative_to(OUTPUT / "projects")
        ):
            raise ValueError("Path must stay inside this project")
        return dest

    def artifacts(self, p):
        root = self.directory(p)
        result = []
        for f in sorted(root.rglob("*")):
            relative = f.relative_to(root)
            if any(
                part in {"frames", "archive", "projects"} for part in relative.parts
            ):
                continue
            if f.is_file() and f.suffix.lower() in {
                ".blend",
                ".mp4",
                ".mov",
                ".png",
                ".jpg",
                ".jpeg",
                ".webp",
                ".mp3",
                ".wav",
                ".json",
            }:
                result.append(
                    dict(
                        name=str(relative),
                        url="/artifacts/" + str(f.relative_to(OUTPUT)),
                        bytes=f.stat().st_size,
                        modified_at=f.stat().st_mtime,
                        **({'video': video_metadata(f)} if f.suffix.lower() in {'.mp4', '.mov'} else {}),
                    )
                )
        return result

    def context(self, p):
        return (
            f"[平台项目上下文] 项目：{p['title']}；Blender 场景：{p['scene']}。"
            f"只修改该场景。产物目录：{self.directory(p)}；工程：{self.path(p, p['blend'])}。"
            f"多个项目可能同时创作。仅操作 bpy.context.scene 内的对象；新增对象、材质、集合名称使用 {p['id']}_ 前缀。"
            "禁止遍历删除全局 bpy.data.objects/scenes，禁止重置或打开整个主文件，禁止用定时器在工具返回后继续修改场景。"
            f"初始视频设置（仅用户未指定时使用）：{p['settings']}。用户提示词中的时长、分辨率与帧率优先，"
            "请据此设置 Blender 场景与相机动画，渲染读取场景实际设置。从当前用户提示词决定场景题材、视觉风格、相机和光线。"
            "制作步骤：检查场景，建模并设置相机动画，获取截图检查，blender_project save 保存工程；"
            "用户要求输出视频时调用 previz_render all，再查 status 和 artifacts。"
            "未返回真实产物不能声称完成。Seedance 仅在用户要求生成时提交。\n"
            + PREVIS_POLICY + "\n"
        )
