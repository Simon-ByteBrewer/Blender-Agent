"""Allocate persistent, per-project video numbers shared by the server and CLI."""

import fcntl
import os
from pathlib import Path
import re


def reserve_video(directory, project_id):
    out = Path(directory)
    if Path(project_id).name != project_id or project_id in {"", ".", ".."}:
        raise ValueError("Invalid project ID")
    prefix = f"previz-{project_id}-"
    pattern = re.compile(rf"(?:{re.escape(prefix)}([1-9][0-9]*)\.mp4|\.{re.escape(prefix)}([1-9][0-9]*)\.mp4\.reserved)")
    counter = out / f".previz-{project_id}.sequence"
    with (out / f".previz-{project_id}.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        number = int(counter.read_text()) if counter.exists() else 0
        if number < 0:
            raise ValueError("Invalid video sequence")
        for path in out.iterdir():
            match = pattern.fullmatch(path.name)
            if match:
                number = max(number, int(match[1] or match[2]))
        while True:
            number += 1
            movie = f"{prefix}{number}.mp4"
            reservation = out / f".{movie}.reserved"
            if (out / movie).exists():
                continue
            try:
                reservation.touch(exist_ok=False)
            except FileExistsError:
                continue
            try:
                temporary = counter.with_suffix(".sequence.tmp")
                with temporary.open("w") as output:
                    output.write(str(number) + "\n")
                    output.flush()
                    os.fsync(output.fileno())
                temporary.replace(counter)
            except BaseException:
                reservation.unlink(missing_ok=True)
                raise
            return movie, reservation
