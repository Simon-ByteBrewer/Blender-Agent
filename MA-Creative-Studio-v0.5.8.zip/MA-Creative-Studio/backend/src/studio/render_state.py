"""Shared, bpy-free frame bookkeeping for serial and parallel renderers."""

import hashlib
import json
import os
import shutil
import struct
import time
import zlib
from pathlib import Path

PROTOCOL = "STUDIO_RENDER_EVENT "


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + f".{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False))
    temporary.replace(path)


def valid_png(path):
    """Reject truncated/corrupt cached frames, including pre-atomic legacy output."""
    try:
        with Path(path).open("rb") as source:
            if source.read(8) != b"\x89PNG\r\n\x1a\n":
                return False
            first, image_data = True, False
            while True:
                header = source.read(8)
                if len(header) != 8:
                    return False
                size, kind = struct.unpack(">I4s", header)
                if first and (kind != b"IHDR" or size != 13):
                    return False
                first = False
                checksum = zlib.crc32(kind)
                remaining = size
                while remaining:
                    data = source.read(min(remaining, 1024 * 1024))
                    if not data:
                        return False
                    checksum = zlib.crc32(data, checksum)
                    remaining -= len(data)
                crc = source.read(4)
                if len(crc) != 4 or struct.unpack(">I", crc)[0] != checksum:
                    return False
                image_data |= kind == b"IDAT"
                if kind == b"IEND":
                    return size == 0 and image_data and not source.read(1)
    except OSError:
        return False


def prepare_frames(out, metadata, mode, blend_digest):
    """Only the coordinator calls this; worker frame ranges never enter signatures."""
    folder = Path(out) / ("previews" if mode == "preview" else "frames")
    folder.mkdir(parents=True, exist_ok=True)
    signature = blend_digest + json.dumps(metadata, sort_keys=True)
    manifest = folder / "manifest.json"
    try:
        old = json.loads(manifest.read_text()).get("signature")
    except (OSError, ValueError):
        old = None
    if old != signature and any(folder.glob("frame_*.png")):
        archive = Path(out) / "archive" / str(time.time_ns())
        archive.parent.mkdir(exist_ok=True)
        shutil.move(str(folder), str(archive))
        folder.mkdir()
    write_json(manifest, dict(signature=signature, **metadata))
    if mode == "render":
        write_json(Path(out) / "render_metadata.json", metadata)
    # Orphaned temporary images are never eligible for resume.
    for pattern in (".frame_*.png", ".frame_*.tmp"):
        for path in folder.glob(pattern):
            path.unlink(missing_ok=True)
    return folder


def blend_hash(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def sequential_reasons(scene, handlers=()):
    """Conservative fallback: unknown/stateful simulations keep ordered evaluation."""
    reasons = set()
    if handlers:
        reasons.add("frame-change handlers")
    if getattr(scene, "rigidbody_world", None):
        reasons.add("rigid body simulation")
    seen = set()

    def simulation_nodes(tree):
        if tree is None or id(tree) in seen:
            return False
        seen.add(id(tree))
        return any(getattr(node, "bl_idname", "") in {
            "GeometryNodeSimulationInput", "GeometryNodeSimulationOutput"}
            or simulation_nodes(getattr(node, "node_tree", None))
            for node in getattr(tree, "nodes", ()))

    objects = list(scene.objects)
    visited = set()
    while objects:
        obj = objects.pop()
        if id(obj) in visited:
            continue
        visited.add(id(obj))
        collection = getattr(obj, "instance_collection", None)
        if collection:
            objects.extend(collection.all_objects)
        if getattr(obj, "particle_systems", ()):
            reasons.add("particle simulation")
        for modifier in getattr(obj, "modifiers", ()):
            if modifier.type in {"CLOTH", "SOFT_BODY", "FLUID", "DYNAMIC_PAINT"}:
                reasons.add(modifier.type.lower())
            if modifier.type == "NODES" and simulation_nodes(getattr(modifier, "node_group", None)):
                reasons.add("geometry nodes simulation")
    return sorted(reasons)
