import asyncio, httpx, json
from .config import key, config, base_url, safe_error, redact_payload, STORAGE_SUFFIXES


class ArkHTTPError(RuntimeError):
    def __init__(self, status_code, body):
        self.status_code = status_code
        super().__init__(f"Ark HTTP {status_code}: {body[:1200]}")


class Ark:
    def __init__(self, transport=None, store=None):
        self.transport = transport
        self.store = store
        self.send_locks = {}

    async def request(self, method, path, **kwargs):
        base = base_url(config())
        async with httpx.AsyncClient(
            base_url=base + "/",
            headers={"Authorization": "Bearer " + key()},
            timeout=60,
            transport=self.transport,
        ) as c:
            # Read-only retries. Never blindly retry an ambiguous cloud write.
            for attempt in range(3):
                try:
                    r = await c.request(method, path.lstrip("/"), **kwargs)
                    if (
                        method == "GET"
                        and (r.status_code == 429 or r.status_code >= 500)
                        and attempt < 2
                    ):
                        await asyncio.sleep(2**attempt)
                        continue
                    if r.is_error:
                        raise ArkHTTPError(r.status_code, safe_error(r.text))
                    return redact_payload(r.json()) if r.content else {}
                except httpx.TransportError as exc:
                    if method != "GET" or attempt == 2:
                        message = (f"Ark {method} {path.split('?')[0]}: {type(exc).__name__}；"
                                   + ("读取失败，可继续原任务。" if method == "GET" else "提交结果未知，请先查询状态，不要重复提交。"))
                        raise type(exc)(message, request=exc.request) from exc
                    await asyncio.sleep(2**attempt)

    async def events(self, sid, after=None):
        # Some live deployments ignore `after`. Read newest-first when resuming,
        # stopping locally at the known event instead of replaying the full history.
        params = {"order": "desc" if after else "asc", "limit": 100}
        if after:
            params["after"] = after
        events = []
        seen = set()
        for _ in range(100):
            result = await self.request("GET", f"sessions/{sid}/events", params=params)
            batch = result.get("data", [])
            if after:
                boundary = next((i for i, event in enumerate(batch) if event.get("id") == after), None)
                if boundary is not None:
                    events.extend(batch[:boundary])
                    return {"data": list(reversed(events))}
            events.extend(batch)
            page = result.get("next_page")
            if not page:
                return {"data": list(reversed(events)) if after else events}
            if page in seen:
                raise RuntimeError("MA events returned a repeated pagination cursor")
            seen.add(page)
            params["page"] = page
        raise RuntimeError("MA event pagination exceeded 100 pages; cursor preserved")

    async def download(self, path, max_bytes=128 * 1024 * 1024):
        """Download a Skill archive; storage redirects never receive API credentials."""
        from urllib.parse import urljoin, urlparse
        base = base_url(config())
        url = base + "/" + path.lstrip("/")
        headers = {"Authorization": "Bearer " + key()}
        async with httpx.AsyncClient(transport=self.transport, timeout=60, follow_redirects=False) as client:
            for _ in range(4):
                async with client.stream("GET", url, headers=headers) as response:
                    if response.is_redirect:
                        url = urljoin(url, response.headers.get("location", ""))
                        parsed = urlparse(url)
                        if (parsed.scheme != "https" or not parsed.hostname
                                or not parsed.hostname.endswith(STORAGE_SUFFIXES)
                                or parsed.username or parsed.password or parsed.port not in (None, 443)):
                            raise RuntimeError("Skill download redirected outside trusted storage")
                        headers = {}  # A signed storage URL authenticates itself.
                        continue
                    if response.is_error:
                        raise ArkHTTPError(response.status_code, "Skill archive download failed")
                    chunks, count = [], 0
                    async for chunk in response.aiter_bytes():
                        count += len(chunk)
                        if count > max_bytes:
                            raise RuntimeError("Skill archive exceeds download limit")
                        chunks.append(chunk)
                    return b"".join(chunks)
        raise RuntimeError("Too many Skill download redirects")

    async def send(self, sid, events):
        from .byok import event_headers
        # The live service supports one event per request; preserve order.
        async with self.send_locks.setdefault(sid, asyncio.Lock()):
            results = []
            for event in events:
                results.append(
                    await self.request(
                        "POST", f"sessions/{sid}/events", json={"events": [event]},
                        **({"headers": event_headers(self.store, sid)} if self.store else {})
                    )
                )
            return results

    async def watch(self, sid, on_event, wake, ready):
        """Opt in to public text deltas; polling still reconciles final events."""
        from .event_stream import StreamPreviews
        delay = 1
        deltas = True
        while True:
            try:
                base = base_url(config())
                async with httpx.AsyncClient(transport=self.transport, timeout=httpx.Timeout(60, read=90)) as client:
                    async with client.stream("GET", f"{base}/sessions/{sid}/events/stream",
                                             params=[("event_deltas", "agent.message"), ("event_deltas", "agent.thinking")] if deltas else None,
                                             headers={"Authorization": "Bearer " + key(), "Accept": "text/event-stream"}) as response:
                        if deltas and response.status_code in {400, 422}:
                            deltas = False  # Compatibility endpoints may only support full events.
                            continue
                        response.raise_for_status()
                        ready.set()
                        wake.set()  # Reconcile history on initial connect and reconnect.
                        data = []
                        previews = StreamPreviews()
                        frame_id = ""
                        seen_frames = set()
                        async for line in response.aiter_lines():
                            if line.startswith("data:"):
                                data.append(line[5:].lstrip())
                            elif line.startswith("id:"):
                                frame_id = line[3:].strip()
                            elif not line and data:
                                payload = "\n".join(data)
                                data = []
                                if payload != "[DONE]":
                                    try:
                                        frame = redact_payload(json.loads(payload))
                                        # Repeated text can be legitimate. Only a
                                        # transport ID, when supplied, proves a duplicate frame.
                                        duplicate = frame_id and frame_id in seen_frames
                                        if frame_id:
                                            seen_frames.add(frame_id)
                                        if not duplicate:
                                            for event in previews.accept(frame):
                                                on_event(event)
                                            if isinstance(frame, dict) and frame.get("type") not in {"event_start", "event_delta"}:
                                                wake.set()
                                    except ValueError:
                                        pass
                                delay = 1
                                frame_id = ""
            except (httpx.HTTPError, RuntimeError):
                ready.set()  # History polling remains available when SSE is unavailable.
            await asyncio.sleep(delay)
            delay = min(30, delay * 2)
