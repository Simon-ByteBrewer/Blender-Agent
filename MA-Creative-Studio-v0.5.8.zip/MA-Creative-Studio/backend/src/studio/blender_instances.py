"""One owned GUI process and original MCP connection per project."""

import asyncio
import json
import os
from pathlib import Path
import shlex
import socket
import time
import uuid
import sys

from .config import ROOT, RESOURCES, STATE
from .blender_runtime import BlenderRuntime, gui_processes
from ma_mcp.mcp_bridge import MCPBridge


def process_display(pid):
    """DISPLAY a Linux process was started with, or None."""
    try:
        environ = Path(f'/proc/{pid}/environ').read_bytes().split(b'\0')
    except OSError:
        return None
    for item in environ:
        if item.startswith(b'DISPLAY='):
            return item[8:].decode(errors='replace')
    return None


class ProjectBlender(BlenderRuntime):
    def __init__(self, project, record, projects, display_for=None):
        super().__init__()
        self.project = project
        self.record = record
        self.projects = projects
        # Optional async callback returning this project's own X display (cloud executor).
        self.display_for = display_for
        self.operation_lock = asyncio.Lock()
        self.bridge = MCPBridge(port=record['port'])

    def x_env(self, display=None):
        env = dict(os.environ)
        if display:
            env['DISPLAY'] = display
        return env

    async def status(self):
        process = await asyncio.create_subprocess_exec('ps', '-axo', 'pid=,args=', stdout=asyncio.subprocess.PIPE)
        stdout, _ = await process.communicate()
        matching = []
        for line in stdout.decode(errors='replace').splitlines():
            pids = gui_processes(line)
            if not pids:
                continue
            try:
                args = shlex.split(line.strip().split(None, 1)[1])
                if args[args.index('--studio-token') + 1] == self.record['token'] and args[args.index('--studio-project') + 1] == self.project['id']:
                    matching.extend(pids)
            except (ValueError, IndexError):
                continue
        connected = False
        if len(matching) == 1:
            # A listening unrelated process must never count as this project's MCP.
            probe = await asyncio.create_subprocess_exec('lsof', '-a', '-p', str(matching[0]), '-iTCP:' + str(self.record['port']), '-sTCP:LISTEN', '-t', stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
            data, _ = await probe.communicate()
            connected = str(matching[0]) in data.decode().split()
        return {
            'running': bool(matching), 'window_process_count': len(matching),
            'pid': matching[0] if len(matching) == 1 else None,
            'mcp_port': self.record['port'], 'project_id': self.project['id'],
            'mcp_connected': connected,
            'launching': not connected and (self.connecting or time.monotonic() - self.started_at < 30),
            **({'display': process_display(matching[0])} if len(matching) == 1 and sys.platform != 'darwin' else {}),
        }

    async def open(self):
        display = await self.display_for(self.project) if self.display_for else None
        async with self.lock:
            state = await self.status()
            if state['running']:
                if state['pid'] and state['mcp_connected'] and sys.platform == 'darwin':
                    # NSRunningApplication activates the specific PID, not an
                    # arbitrary window selected by `open -a Blender`.
                    script = 'ObjC.import("AppKit"); $.NSRunningApplication.runningApplicationWithProcessIdentifier(' + str(state['pid']) + ').activateWithOptions(3);'
                    focus = await asyncio.create_subprocess_exec('osascript', '-l', 'JavaScript', '-e', script, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
                    await focus.communicate()
                elif state['pid'] and state['mcp_connected'] and sys.platform != 'darwin':
                    search = await asyncio.create_subprocess_exec('xdotool', 'search', '--onlyvisible', '--pid', str(state['pid']),
                        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL, env=self.x_env(state.get('display')))
                    windows, _ = await search.communicate()
                    if windows.split():
                        focus = await asyncio.create_subprocess_exec('xdotool', 'windowactivate', windows.split()[-1].decode(),
                            stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL, env=self.x_env(state.get('display')))
                        await focus.wait()
                return state
            if state['launching']:
                return state
            directory = STATE / 'blender-projects'
            directory.mkdir(exist_ok=True)
            config_path = directory / (self.project['id'] + '.json')
            config_path.write_text(json.dumps({**self.record, 'project': self.project, 'blend_path': str(self.projects.path(self.project, self.project['blend']))}))
            command = [os.environ.get('BLENDER_BIN', '/Applications/Blender.app/Contents/MacOS/Blender' if sys.platform == 'darwin' else 'blender'), '--factory-startup', '--python', str(RESOURCES / 'blender_scripts/start_blender.py'), '--', '--studio-config', str(config_path), '--studio-project', self.project['id'], '--studio-token', self.record['token']]
            # Direct launch gives this project its own native process; credentials
            # are excluded from its environment.
            env = {k: os.environ[k] for k in ['PATH', 'HOME', 'TMPDIR', 'LANG'] if k in os.environ}
            if sys.platform != 'darwin':
                env.update({k: os.environ[k] for k in ['DISPLAY', 'XAUTHORITY', 'XDG_RUNTIME_DIR', 'LIBGL_ALWAYS_SOFTWARE', 'LP_NUM_THREADS', 'OMP_NUM_THREADS'] if k in os.environ})
                if display:
                    env['DISPLAY'] = display
            if os.environ.get('STUDIO_BLENDER_SCRIPTS'):
                env['BLENDER_USER_SCRIPTS'] = os.environ['STUDIO_BLENDER_SCRIPTS']
            self.started_at = time.monotonic()
            try:
                with (ROOT / 'logs' / ('blender-' + self.project['id'] + '.log')).open('a') as log:
                    await asyncio.create_subprocess_exec(*command, env=env, stdin=asyncio.subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
            except BaseException:
                self.started_at = 0
                raise
            return await self.status()


class BlenderInstances:
    def __init__(self, store, projects):
        self.store = store
        self.projects = projects
        self.instances = {}
        self.display_for = None

    def for_project(self, project):
        pid = project['id']
        if pid not in self.instances:
            records = self.store.get('blender_instances', {})
            if pid not in records:
                used = {r['port'] for r in records.values()}
                first = int(os.environ.get('STUDIO_MCP_PORT_START', '19000'))
                if not 1024 <= first <= 55536:
                    raise ValueError('STUDIO_MCP_PORT_START 必须在 1024–55536 之间')
                for port in range(first, first + 10000):
                    if port in used:
                        continue
                    try:
                        with socket.socket() as listener:
                            listener.bind(('127.0.0.1', port))
                    except PermissionError:
                        raise RuntimeError('无法分配本地 Blender MCP 端口：请检查进程权限') from None
                    except OSError:
                        continue
                    records[pid] = {'port': port, 'token': uuid.uuid4().hex}
                    self.store.set('blender_instances', records)
                    break
                else:
                    raise RuntimeError('没有可用的 Blender MCP 端口')
            self.instances[pid] = ProjectBlender(project, records[pid], self.projects)
        self.instances[pid].project = project
        self.instances[pid].display_for = self.display_for
        return self.instances[pid]
