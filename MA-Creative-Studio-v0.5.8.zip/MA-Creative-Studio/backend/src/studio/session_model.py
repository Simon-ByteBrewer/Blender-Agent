"""Read the effective Session model, rather than guessing from model defaults."""

import asyncio
import time
from .ark import ArkHTTPError
from .models import DEFAULT_MODEL, LEGACY_MODEL

UPGRADE_TIMEOUT = 120


async def verify_session_model(ark, store, binding, session=None):
    expected = store.get(binding + ':model_expected')
    sid = store.get(binding)
    if not expected or expected.get('session_id') != sid:
        return
    model = ((session or {}).get('agent') or {}).get('model') or {}
    byok = store.get(binding + ":byok")
    if (not model.get("id") or (expected.get("effort") is not None and not model.get("reasoning_effort"))
            or byok and any(k not in model for k in byok["model"])):
        session = await ark.request('GET', f'sessions/{sid}')
        model = (session.get('agent') or {}).get('model') or {}
    if store.get(binding) != sid:
        raise RuntimeError('会话已切换，请重试')
    if session.get('id') != sid:
        raise RuntimeError('MA 返回的会话 ID 不一致；尚未发送创作任务')
    remember_session_model(store, binding, session)
    byok = store.get(binding + ':byok')
    if byok and expected['model'] == byok['profile_id']:
        if any(model.get(k) != v for k, v in byok['model'].items()):
            raise RuntimeError("MA 会话 BYOK 配置与选择不一致；尚未发送创作任务")
        store.set(binding + ':model_expected', None)
        return
    canonical = lambda mid: DEFAULT_MODEL if mid == LEGACY_MODEL else mid
    if (canonical(model.get('id')) != canonical(expected['model'])
            or expected.get('effort') is not None and model.get('reasoning_effort') != expected['effort']):
        raise RuntimeError(f"MA 会话配置与选择不一致：期望 {expected['model']} / {expected.get('effort') or 'Default'}，"
                           f"实际 {model.get('id') or '未知'} / {model.get('reasoning_effort') or '未知'}；尚未发送创作任务")
    store.set(binding + ':model_expected', None)


def remember_session_model(store, binding, session):
    sid = session.get("id")
    model = (session.get("agent") or {}).get("model")
    if not sid or store.get(binding) != sid or not isinstance(model, dict):
        return False
    mid = model.get("id")
    if not isinstance(mid, str) or not mid:
        return False
    byok = store.get(binding + ":byok")
    if byok:
        # Keep the local profile identity, even if a built-in model has the same ID.
        if any(model.get(k) != v for k, v in byok["model"].items()):
            return False
        mid = byok["profile_id"]
    effort = model.get("reasoning_effort")
    effort = effort if isinstance(effort, str) and effort else None
    # These existing display keys also let older running backends pick up a
    # verified snapshot without restarting an active creative task.
    store.set(binding + ":model", mid)
    store.set(binding + ":effort", {"model": mid, "value": effort})
    store.set(binding + ":model_checked", {"session_id": sid, "checked_at": time.time()})
    return True


async def refresh_session_model(ark, store, binding, sid):
    if not sid or store.get(binding) != sid:
        return
    cached = store.get(binding + ":model_checked", {})
    now = time.time()
    if cached.get("session_id") == sid and now - cached.get("checked_at", 0) < 30:
        return
    # Throttle concurrent health polling and failures as well as successful reads.
    store.set(binding + ":model_checked", {"session_id": sid, "checked_at": now})
    try:
        session = await asyncio.wait_for(ark.request("GET", f"sessions/{sid}"), timeout=5)
    except Exception:
        return  # Keep the last known value; never invent a model default.
    remember_session_model(store, binding, session)


def pending_model(store, binding):
    """A model chosen after the Session started, waiting for the next turn boundary."""
    pending = store.get(binding + ":model_pending")
    return pending if pending and pending.get("session_id") == store.get(binding) else None


async def apply_pending_model(ark, store, binding):
    """Switch the Session's model in place via POST sessions/{id}/upgrades.

    MA accepts an upgrade only while the Session is idle after end_turn, so this
    runs right before new user input. Returns False (switch stays pending) while
    the Session is busy; raises on any other failure, before input is sent.
    """
    pending = pending_model(store, binding)
    if not pending:
        return False
    sid = pending["session_id"]
    session = await ark.request("GET", f"sessions/{sid}")
    if session.get("status") != "idle":
        return False
    model = {"id": pending["model"]}
    if pending.get("effort"):
        model.update(reasoning_effort=pending["effort"], thinking="enabled")
    agent = {"id": (session.get("agent") or {}).get("id"), "type": "agent_with_upgrades", "model": model}
    try:
        await ark.request("POST", f"sessions/{sid}/upgrades", json={"agent": agent})
    except ArkHTTPError as exc:
        if "SessionNotIdle" in str(exc):
            return False
        store.set(binding + ":model_pending", None)
        raise RuntimeError(f"切换模型失败，已保留原模型：{exc}；消息尚未发送") from None
    deadline = time.monotonic() + UPGRADE_TIMEOUT
    while (session := await ark.request("GET", f"sessions/{sid}")).get("status") == "upgrading":
        if time.monotonic() > deadline:
            raise RuntimeError("切换模型超时，会话仍在升级；消息尚未发送，请稍后继续")
        await asyncio.sleep(2)
    store.set(binding + ":model_pending", None)
    store.set(binding + ":model_expected", {"session_id": sid, "model": pending["model"], "effort": pending.get("effort")})
    await verify_session_model(ark, store, binding, session)
    return True
