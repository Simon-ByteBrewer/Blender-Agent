"""Project chat history across execution environments, scoped to an API key.

Archived events are for display only. The runner and live status continue to use
the active Session, which can be empty immediately after a project migration.
"""

from .store import event_time


def history_key(project_id, scope):
    return f"project_session:{project_id}:{scope}:history"


def archive_session(store, project_id, scope, sid):
    key = history_key(project_id, scope)
    previous = store.get(key, [])
    if sid and sid not in previous:
        store.set(key, [*previous, sid])


def archived_events(store, project, scope, current_session):
    sessions = list(store.get(history_key(project['id'], scope), []))
    # Earlier migrations kept the old binding but predate the scoped archive.
    # Do not trust the project's unscoped session_history alone: the retained
    # binding must prove that this Session belongs to the current credentials.
    for entry in project.get('execution_history', []):
        execution = entry.get('execution') or {}
        mode, server = execution.get('mode'), execution.get('server_id')
        binding = f"project_session:{project['id']}:{scope}"
        if mode in {'self_hosted', 'colocated'} and server:
            binding += f':{mode}:{server}'
        elif mode != 'local':
            continue
        sid = entry.get('session_id')
        if sid and store.get(binding) == sid:
            sessions.append(sid)
    return sorted((
        {**event, '_archived': True, '_session_id': sid, '_streaming': False}
        for sid in dict.fromkeys(sessions) if sid and sid != current_session
        for event in store.events(sid)
    ), key=event_time)


def conversation_events(store, project, scope):
    sid = project.get('session_id') or ''
    return sorted([*archived_events(store, project, scope, sid), *store.events(sid)], key=event_time)
