"""Turn local reference-image links into actual MA multimodal input."""

import base64
import io
import json
import re
from pathlib import Path
from urllib.parse import unquote, urlsplit

from PIL import Image, ImageOps

MAX_EVENT_BYTES = 512 * 1024
MAX_IMAGE_BYTES = 192 * 1024  # Base64 bytes, within the event budget.
IMAGE_LINK = re.compile(r'!\[((?:\\.|[^\]\\])*)\]\(([^\s)]+)\)')


def _image_source(path, budget):
    if path.stat().st_size > 50 * 1024 * 1024:
        raise ValueError(f"参考图超过 50 MB：{path.name}")
    with Image.open(path) as original:
        if original.format not in {'PNG', 'JPEG'}:
            raise ValueError(f"参考图必须是 PNG 或 JPG：{path.name}")
        im = ImageOps.exif_transpose(original).convert('RGBA')
        background = Image.new('RGB', im.size, 'white')
        background.paste(im, mask=im.getchannel('A'))
    background.thumbnail((1600, 1600))
    for _ in range(12):
        output = io.BytesIO()
        background.save(output, format='JPEG', quality=85, optimize=True)
        encoded = base64.b64encode(output.getvalue()).decode('ascii')
        if len(encoded) <= budget:
            return {'type': 'base64', 'media_type': 'image/jpeg', 'data': encoded}
        background.thumbnail((max(1, int(background.width * .8)), max(1, int(background.height * .8))))
    raise ValueError(f"参考图无法压缩到发送限制内：{path.name}")


def message_content(text, project_directory, artifact_prefix):
    """Only resolve current-project local links; never fetch arbitrary URLs."""
    root = Path(project_directory).resolve()
    images = []
    seen = set()

    def reference(match):
        url = urlsplit(match[2])
        if url.scheme or url.netloc or not url.path.startswith('/artifacts/'):
            return match[0]
        path = unquote(url.path)
        if not path.startswith(artifact_prefix + '/'):
            raise ValueError('参考图必须属于当前项目，请在当前项目重新上传')
        relative = path[len(artifact_prefix) + 1:]
        target = (root / relative).resolve()
        if not target.is_relative_to(root) or target.suffix.lower() not in {'.png', '.jpg', '.jpeg'}:
            raise ValueError('参考图片路径无效')
        if not target.is_file():
            raise ValueError(f'参考图文件不存在，请重新上传：{target.name}')
        if target not in seen:
            images.append(target)
            seen.add(target)
        # Keep an original-file link for the UI, alongside the actual image blocks.
        return match[0][1:]

    rendered = IMAGE_LINK.sub(reference, text)
    if not images:
        return [{'type': 'text', 'text': text}]
    content = [{'type': 'text', 'text': rendered}, {'type': 'text', 'text': '参考图已附在本条消息中，请直接查看以下图像内容。'}]
    overhead = len(json.dumps(content, ensure_ascii=False).encode('utf-8')) + sum(len(p.name.encode('utf-8')) for p in images) + 4096
    budget = min(MAX_IMAGE_BYTES, (MAX_EVENT_BYTES - overhead) // len(images) - 512)
    if budget < 16 * 1024:
        raise ValueError('参考图或提示词过多，请分成多条消息发送')
    for path in images:
        try:
            source = _image_source(path, budget)
        except (OSError, Image.DecompressionBombError) as exc:
            raise ValueError(f'参考图无法读取，请重新上传：{path.name}') from exc
        content.extend([{'type': 'text', 'text': f'参考图：{path.name}'}, {'type': 'image', 'source': source}])
    if len(json.dumps({'events': [{'type': 'user.message', 'content': content}]}, ensure_ascii=False).encode('utf-8')) > MAX_EVENT_BYTES:
        raise ValueError('参考图或提示词过多，请分成多条消息发送')
    return content
