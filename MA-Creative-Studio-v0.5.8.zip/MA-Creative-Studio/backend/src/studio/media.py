"""Read actual video properties once per file revision for artifact previews."""

from fractions import Fraction
from functools import lru_cache
import json
import math
import subprocess


def audio_metadata(path):
    """Probe reference audio without requiring a video stream."""
    try:
        result = subprocess.run([
            'ffprobe', '-v', 'error', '-select_streams', 'a:0',
            '-show_entries', 'stream=codec_type:format=duration', '-of', 'json', str(path),
        ], capture_output=True, text=True, check=True, timeout=3)
        data = json.loads(result.stdout)
        duration = float(data['format']['duration'])
        if data['streams'] and math.isfinite(duration) and duration > 0:
            return {'duration': duration}
    except (OSError, subprocess.SubprocessError, ValueError, KeyError, TypeError):
        pass
    return None


def video_metadata(path):
    try:
        stat = path.stat()
        return _probe(str(path), stat.st_mtime_ns, stat.st_size)
    except OSError:
        return None


@lru_cache(maxsize=256)
def _probe(path, modified, size):
    try:
        result = subprocess.run([
            'ffprobe', '-v', 'error', '-select_streams', 'v:0',
            '-show_entries', 'stream=width,height,avg_frame_rate:format=duration',
            '-of', 'json', path,
        ], capture_output=True, text=True, check=True, timeout=3)
        data = json.loads(result.stdout)
        stream = data['streams'][0]
        width, height = int(stream['width']), int(stream['height'])
        duration = float(data['format']['duration'])
        if width <= 0 or height <= 0 or not math.isfinite(duration) or duration <= 0:
            return None
        video = {'width': width, 'height': height, 'duration': round(duration, 3)}
        try:
            fps = float(Fraction(stream.get('avg_frame_rate', '0/0')))
            if math.isfinite(fps) and fps > 0:
                video['fps'] = round(fps, 3)
        except (ValueError, ZeroDivisionError):
            pass
        return video
    except (OSError, subprocess.SubprocessError, ValueError, KeyError, IndexError, TypeError):
        return None
