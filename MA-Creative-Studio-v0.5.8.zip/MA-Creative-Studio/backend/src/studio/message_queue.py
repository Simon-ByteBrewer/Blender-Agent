"""Durable follow-up input; one session runner owns delivery to Ark."""

import asyncio
import time
import uuid
from .ark import ArkHTTPError
from .config import safe_error


class MessageQueue:
    @staticmethod
    def recover(store):
        with store.connect() as db:
            keys = [row[0] for row in db.execute("SELECT key FROM kv WHERE key LIKE 'chat_outbox:%'")]
        for key in keys:
            items = store.get(key, [])
            for item in items:
                if item["status"] == "sending":
                    item.update(status="unknown", error="服务重启前的投递结果未确认，请核对会话记录")
                elif item["status"] == "queued":
                    item.update(status="paused", error="服务已重启，消息已保留，可重新编辑发送")
            store.set(key, items)

    def __init__(self, store, project_id, scope, content_builder=None):
        self.store = store
        self.key = f"chat_outbox:{project_id}:{scope}"
        self.content = content_builder or (lambda text: [{"type": "text", "text": text}])

    def list(self):
        return self.store.get(self.key, [])

    def update(self, item, **changes):
        items = self.list()
        current = next((m for m in items if m["id"] == item["id"]), item)
        # A stop request can arrive during the network write.
        if current.get("status") == "cancelled" and changes.get("status") != "processed":
            return current
        current.update(changes, updated_at=time.time())
        items = [m for m in items if m["id"] != current["id"]] + [current]
        items.sort(key=lambda m: m["created_at"])
        self.store.set(self.key, items)
        return current

    def add(self, text, *, message_id=None):
        items = self.list()
        message_id = message_id or uuid.uuid4().hex
        existing = next((m for m in items if m["id"] == message_id), None)
        if existing:
            if existing["text"] != text:
                raise ValueError("消息 ID 已被其他内容使用")
            return existing
        if sum(m["status"] in {"queued", "sending", "accepted"} for m in items) >= 20:
            raise ValueError("待处理消息已达 20 条，请等待处理后再发送")
        item = dict(id=message_id, text=text, status="queued", created_at=time.time())
        self.store.set(self.key, [*items, item])
        return item

    def reconcile(self, events):
        by_id = {e["id"]: e for e in events}
        for item in self.list():
            event = by_id.get(item.get("event_id"))
            if event and event.get("processed_at") and item["status"] != "processed":
                self.update(item, status="processed")

    def pending(self):
        return any(m["status"] in {"queued", "sending", "accepted"} for m in self.list())

    def cancel(self, message_id=None):
        items = self.list()
        for item in items:
            if message_id and item["id"] != message_id:
                continue
            if message_id and item["status"] in {"sending", "accepted", "processed"}:
                raise ValueError("消息已提交，无法单独撤回")
            if message_id:
                item["dismissed"] = True
            if item["status"] in {"queued", "sending", "accepted"}:
                item.update(status="cancelled", updated_at=time.time())
        self.store.set(self.key, items)

    async def flush(self, ark, sid):
        items = [m for m in self.list() if m["status"] == "queued"]
        sent = False
        for item in items:
            if item.get("retry_after", 0) > time.time():
                break
            if next(m for m in self.list() if m["id"] == item["id"])["status"] != "queued":
                continue
            try:
                content = self.content(item["text"])
            except (ValueError, OSError) as exc:
                self.update(item, status="failed", error=safe_error(exc))
                continue  # Local validation failed; no network write occurred.
            self.update(item, status="sending", session_id=sid)
            try:
                responses = await ark.send(sid, [{"type": "user.message", "content": content}])
            except ArkHTTPError as exc:
                if exc.status_code in {409, 429} or (exc.status_code == 400 and "requires_action" in str(exc)):
                    attempts = item.get("attempts", 0) + 1
                    self.update(item, status="queued", attempts=attempts,
                                retry_after=time.time() + min(30, 2 ** min(attempts, 5)),
                                error="服务端繁忙，等待后重试")
                    break
                self.update(item, status="failed" if exc.status_code in {400, 401, 403, 404, 413, 415, 422} else "unknown", error=safe_error(exc))
                break
            except (Exception, asyncio.CancelledError) as exc:
                self.update(item, status="unknown", error="未能确认服务端是否收到消息，请查看会话记录后决定是否重发")
                raise
            remote = next((e for response in responses or [] for e in response.get("data", []) if e.get("type") == "user.message"), None)
            if remote is None:
                self.update(item, status="unknown", error="服务端未返回消息 ID，请核对会话记录")
                break
            self.store.event(sid, remote)
            self.update(item, status="processed" if remote.get("processed_at") else "accepted", event_id=remote["id"], error=None)
            self.reconcile(self.store.events(sid))
            sent = True
        return sent
