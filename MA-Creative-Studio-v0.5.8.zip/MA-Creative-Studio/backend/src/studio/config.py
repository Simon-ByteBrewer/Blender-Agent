from pathlib import Path
import os
from dotenv import dotenv_values, set_key
import hashlib

RESOURCES = Path(os.environ.get("STUDIO_RESOURCE_ROOT", Path(__file__).resolve().parents[3]))
ROOT = Path(os.environ.get("STUDIO_HOME", RESOURCES))
ROOT.mkdir(parents=True, exist_ok=True)
OUTPUT = ROOT / "data"
OUTPUT.mkdir(exist_ok=True)
STATE = ROOT / ".local"
STATE.mkdir(exist_ok=True)


# Ark-compatible MA deployments. API keys, model activation and MA resources
# are isolated per region, so each entry is one region of one platform.
PLATFORMS = {
    "volcengine": {
        "family": "volcengine", "name": "火山方舟", "region": "cn-beijing",
        "base_url": "https://ark.cn-beijing.volces.com/api/v3",
        "console_session_url": "https://console.volcengine.com/ark/region:cn-beijing/managed-agents/sessions/",
        "api_key_url": "https://console.volcengine.com/ark/region:cn-beijing/apiKey",
        "portrait_library_url": "https://ark.volcengine.com/region:cn-beijing/experience/vision?modelId=doubao-seedance-2-5-260628&tab=GenVideo",
        "key_env": "ARK_API_KEY",
        "agent_model": "doubao-seed-evolving-latest-version", "default_model": "doubao-seed-evolving",
        "seedance_model": "doubao-seedance-2-5-260628",
    },
    "byteplus-ap": {
        "family": "byteplus", "name": "BytePlus ModelArk", "region": "ap-southeast-1",
        "base_url": "https://ark.ap-southeast.bytepluses.com/api/v3",
        "console_session_url": "https://console.byteplus.com/ark/region:ap-southeast-1/managed-agents/sessions/",
        "api_key_url": "https://console.byteplus.com/ark/region:ap-southeast-1/apiKey",
        "portrait_library_url": "https://docs.byteplus.com/en/docs/modelark/seedance-portrait-asset-guide#preset-avatar",
        "key_env": "BYTEPLUS_API_KEY",
        "agent_model": "dola-seed-evolving", "default_model": "deepseek-v4-1-flash-261017",
        "seedance_model": "dreamina-seedance-2-5-260628",
    },
}
# Each platform keeps its own key, so switching back and forth needs no re-entry.
KEY_NAMES = {p["key_env"] for p in PLATFORMS.values()}
DEFAULT_PLATFORM = "volcengine"
# Signed Skill archive redirects may only point at the platforms' object storage.
STORAGE_SUFFIXES = (".volces.com", ".bytepluses.com")


def config():
    local = dotenv_values(ROOT / ".env")
    values = {**local, **os.environ}
    # The key saved in the UI takes effect immediately, including after restart.
    for name, value in local.items():
        if value and (name in KEY_NAMES or name == "ARK_PLATFORM" or name.startswith("BYOK_")):
            values[name] = value
    return values


def platform_id(values=None):
    value = (values if values is not None else config()).get("ARK_PLATFORM")
    return value if value in PLATFORMS else DEFAULT_PLATFORM


def platform(values=None):
    return {"id": platform_id(values), **PLATFORMS[platform_id(values)]}


def base_url(values=None):
    values = values if values is not None else config()
    # A process-level ARK_BASE_URL (e.g. a Worker's loopback gateway) always wins;
    # otherwise a platform chosen in the UI replaces a legacy .env base URL.
    if os.environ.get("ARK_BASE_URL") or not values.get("ARK_PLATFORM"):
        return values.get("ARK_BASE_URL", PLATFORMS[DEFAULT_PLATFORM]["base_url"]).rstrip("/")
    return PLATFORMS[platform_id(values)]["base_url"]


def key_name(values=None):
    # A Worker's loopback gateway authenticates with the token in ARK_API_KEY.
    if os.environ.get("ARK_BASE_URL"):
        return "ARK_API_KEY"
    return PLATFORMS[platform_id(values)]["key_env"]


def save_platform(value):
    if not isinstance(value, str) or value not in PLATFORMS:
        raise ValueError("不支持的服务平台")
    set_key(ROOT / ".env", "ARK_PLATFORM", value, quote_mode="always")


def save_api_key(value):
    if not isinstance(value, str) or not value.strip():
        raise ValueError("请输入 API Key")
    value = value.strip()
    if len(value) > 4096 or any(c.isspace() or not c.isprintable() for c in value):
        raise ValueError("API Key 不能包含空格、换行或控制字符，且长度不能超过 4096")
    # python-dotenv atomically replaces only this entry, preserving other settings.
    set_key(ROOT / ".env", key_name(), value, quote_mode="always")


def key():
    values = config()
    name = key_name(values)
    k = values.get(name)
    if not k:
        raise RuntimeError(f"未配置 {name}；请在左侧设置中填写 API Key")
    return k


def key_identity():
    """Separate cloud resources across credential changes without persisting a secret."""
    try:
        value = key()
    except RuntimeError:
        return "unconfigured"
    # Agents, environments and sessions are regional; Volcengine keeps its
    # original identity so existing projects stay bound to their sessions.
    if platform_id() != DEFAULT_PLATFORM:
        value += "\n" + platform_id()
    return hashlib.sha256(value.encode()).hexdigest()[:20]


def api_key_status():
    try:
        value = key()
    except RuntimeError:
        return {"api_key_configured": False, "api_key_masked": None}
    masked = value[:4] + "••••••••" + value[-4:] if len(value) > 8 else "••••••••"
    return {"api_key_configured": True, "api_key_masked": masked}


def platform_status():
    current = platform()
    return {"platform": {k: current[k] for k in (
        "id", "family", "name", "region", "console_session_url", "api_key_url", "portrait_library_url")},
        "platforms": [{"id": pid, "family": p["family"], "name": p["name"], "region": p["region"]}
                      for pid, p in PLATFORMS.items()]}


def redact_payload(payload):
    """Scrub upstream diagnostics before they reach events, logs or the browser."""
    from urllib.parse import quote
    secrets = [v for k, v in config().items() if v and any(
        marker in k.upper() for marker in ("KEY", "TOKEN", "SECRET", "PASSWORD"))]

    def redact(value):
        if isinstance(value, str):
            for secret in secrets:
                value = value.replace(secret, "[REDACTED]").replace(quote(secret, safe=""), "[REDACTED]")
        elif isinstance(value, list):
            value = [redact(item) for item in value]
        elif isinstance(value, dict):
            value = {k: redact(v) for k, v in value.items()}
        return value
    return redact(payload)


def safe_error(exc):
    message = str(exc).strip() or (type(exc).__name__ if isinstance(exc, BaseException) else "未知错误")
    return redact_payload(message)[:1500]


def output_path(value):
    p = (OUTPUT / value).resolve()
    if not p.is_relative_to(OUTPUT.resolve()):
        raise ValueError("Path must stay inside output directory")
    return p
