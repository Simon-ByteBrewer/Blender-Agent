"""Local BYOK profiles. Only public model snapshots go into MA / SQLite."""
import json
import uuid
from typing import Literal
from urllib.parse import urlsplit

from dotenv import set_key, unset_key
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator
from .config import ROOT, config, key_identity


class TokenLimits(BaseModel):
    model_config = ConfigDict(extra="forbid")
    context_window: int = Field(strict=True, gt=0)
    max_input_token_length: int = Field(strict=True, gt=0)
    max_output_token_length: int = Field(strict=True, gt=0)


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str = Field(min_length=1, max_length=200)
    provider: str = Field(min_length=1, max_length=100)
    base_url: str = Field(max_length=2048)
    protocol: Literal["openai_responses", "openai_chat_completions", "anthropic_messages"]
    token_limits: TokenLimits

    @field_validator("id", "provider")
    @classmethod
    def identifier(cls, value):
        if value != value.strip() or any(c.isspace() or not c.isprintable() for c in value):
            raise ValueError("模型 ID 和 Provider 不能包含空格或控制字符")
        if value.lower() == "ark":
            raise ValueError("BYOK 请使用非 Ark provider")
        return value

    @field_validator("base_url")
    @classmethod
    def endpoint(cls, value):
        url = urlsplit(value)
        if (url.scheme != "https" or not url.hostname or url.username or url.password
                or url.query or url.fragment or any(c.isspace() for c in value)):
            raise ValueError("请填写完整 HTTPS 模型接口地址，不包含密钥、查询参数或片段")
        return value


class ProfileInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1, max_length=100)
    model: Model
    auth_header: Literal["Ak", "Authorization", "x-api-key"] | None = None
    auth_scheme: Literal["raw", "bearer"] | None = None
    api_key: str = Field(default="", max_length=4096)

    @field_validator("api_key")
    @classmethod
    def secret(cls, value):
        value = value.strip()
        if any(c.isspace() or not c.isascii() or not c.isprintable() for c in value):
            raise ValueError("API Key 不能包含空格或控制字符")
        return value


def profiles():
    return json.loads(config().get("BYOK_MODELS") or "[]")


def find_profile(pid):
    return next((p for p in profiles() if p["id"] == pid), None)


def public_profile(profile):
    value = config().get(profile["key_env"]) or ""
    return {k: v for k, v in profile.items() if k != "key_env"} | {
        "api_key_configured": bool(value),
        "api_key_masked": value[:4] + "••••••••" + value[-4:] if len(value) > 8 else "••••••••",
    }


def resolve_auth(data, previous=None):
    # The UI omits transport details. Preserve existing credentials when editing;
    # for new profiles use the conventional authentication of the selected API.
    if data.auth_header is None:
        data.auth_header = previous["auth_header"] if previous else (
            "Ak" if data.model.provider.startswith("modelhub") else
            "x-api-key" if data.model.protocol == "anthropic_messages" else "Authorization")
    if data.auth_scheme is None:
        data.auth_scheme = previous["auth_scheme"] if previous and data.auth_header == previous["auth_header"] else (
            "bearer" if data.auth_header == "Authorization" else "raw")
    if data.model.provider.startswith("modelhub") and (data.auth_header != "Ak" or data.auth_scheme != "raw"):
        raise ValueError("ModelHub 必须使用 Ak / 原始 Key 鉴权")
    if data.auth_scheme == "bearer" and data.auth_header != "Authorization":
        raise ValueError("Bearer 仅适用于 Authorization 请求头")


def save_profile(body, pid=None):
    try:
        data = ProfileInput.model_validate(body)
    except (ValidationError, ValueError):
        # Never return Pydantic's input field: it may contain a credential.
        raise ValueError("配置无效：请检查必填字段、HTTPS 接口地址、协议和三个正整数 Token 上限；Key 不能包含空格或控制字符") from None
    records = profiles()
    previous = next((p for p in records if p["id"] == pid), None)
    if pid and previous is None:
        raise ValueError("BYOK 模型不存在，请刷新设置")
    if not previous and len(records) >= 50:
        raise ValueError("最多配置 50 个 BYOK 模型")
    resolve_auth(data, previous)
    pid = pid or "byok:" + uuid.uuid4().hex
    key_env = previous["key_env"] if previous else "BYOK_KEY_" + pid.split(":")[1].upper()
    if not data.api_key and not (previous and config().get(key_env)):
        raise ValueError("请输入模型 API Key")
    record = {"id": pid, **data.model_dump(exclude={"api_key"}), "key_env": key_env}
    if previous and any(record[k] != previous[k] for k in ("model", "auth_header", "auth_scheme")):
        raise ValueError("已有配置仅支持改名和更换 Key；更换接口或模型请新增配置，以保留旧会话的模型绑定")
    if data.api_key:
        set_key(ROOT / ".env", key_env, data.api_key, quote_mode="always")
    records = [record if p["id"] == pid else p for p in records] if previous else [*records, record]
    set_key(ROOT / ".env", "BYOK_MODELS", json.dumps(records, ensure_ascii=False), quote_mode="always")
    (ROOT / ".env").chmod(0o600)
    return public_profile(record)


def delete_profile(pid):
    records = profiles()
    profile = next((p for p in records if p["id"] == pid), None)
    if not profile:
        raise ValueError("BYOK 模型不存在")
    set_key(ROOT / ".env", "BYOK_MODELS", json.dumps([p for p in records if p["id"] != pid], ensure_ascii=False), quote_mode="always")
    unset_key(ROOT / ".env", profile["key_env"])


def catalog():
    return [{"id": p["id"], "name": p["name"], "model_id": p["model"]["id"], "byok": True,
             "provider": p["model"]["provider"], "contextWindow": p["model"]["token_limits"]["context_window"],
             "reasoning_effort_options": [], "reasoning_effort_default": None}
            for p in profiles() if config().get(p["key_env"])]


def bind_session(store, sid, pid, model):
    store.set("byok_session:" + sid, {"profile_id": pid, "model": model, "scope": key_identity()})


def event_headers(store, sid):
    snapshot = store.get("byok_session:" + sid) if store else None
    if not snapshot:
        return {}
    profile = find_profile(snapshot["profile_id"])
    if snapshot["scope"] != key_identity() or not profile or profile["model"] != snapshot["model"]:
        raise RuntimeError("此会话的 BYOK 配置已移除或变更，请重新配置并新建会话")
    secret = config().get(profile["key_env"])
    if not secret:
        raise RuntimeError("此会话缺少模型 API Key，请在设置中更新 BYOK 配置")
    value = "Bearer " + secret if profile["auth_scheme"] == "bearer" else secret
    return {"X-User-Model-Header-" + profile["auth_header"]: value}
