import asyncio, uuid, time, sys
from .config import ROOT, RESOURCES, safe_error, key_identity
from .video_names import reserve_video


class Jobs:
    def __init__(self, store):
        self.store = store
        self.tasks = {}
        self.render_slots = asyncio.Semaphore(2)

    def list(self):
        return self.store.get("jobs", [])

    def update(self, job):
        job['updated_at'] = time.time()
        jobs = [j for j in self.list() if j["id"] != job["id"]]
        jobs.append(job)
        self.store.set("jobs", jobs[-100:])

    def submit(self, kind, fn, project_id=None):
        job = {
            "id": uuid.uuid4().hex,
            "kind": kind,
            "project_id": project_id,
            "credential_scope": key_identity(),
            "status": "queued",
            "created_at": time.time(),
        }
        self.update(job)

        async def execute():
            job["status"] = "running"
            self.update(job)
            job["result"] = await fn()
            job["status"] = "succeeded"

        async def work():
            try:
                if kind == "render":
                    async with self.render_slots:
                        await execute()
                else:
                    await execute()
            except asyncio.CancelledError:
                job["status"] = "interrupted"
                raise
            except Exception as e:
                job["error"] = safe_error(e)
                job["status"] = "failed"
            finally:
                self.update(job)

        self.tasks[job["id"]] = asyncio.create_task(work())
        return job

    async def pipeline(self, action, project, projects):
        if action not in ["preview", "render", "encode", "validate", "all"]:
            raise ValueError("Unsupported pipeline action")
        out = projects.directory(project)
        movie = projects.get(project["id"])["reference"]
        creates_video = action in {"encode", "all"}
        reservation = None
        if creates_video:
            movie, reservation = reserve_video(out, project["id"])
        try:
            return await self._pipeline(action, project, projects, out, movie, creates_video)
        finally:
            if reservation is not None:
                reservation.unlink(missing_ok=True)

    async def _pipeline(self, action, project, projects, out, movie, creates_video):
        command = [
            sys.executable,
            str(RESOURCES / "blender_scripts/pipeline.py"),
            action,
            "--blend",
            str(projects.path(project, project["blend"])),
            "--output",
            str(out),
            "--scene",
            project["scene"],
            "--movie",
            movie,
        ]
        logpath = ROOT / f"logs/pipeline-{project['id']}-{time.time_ns()}.log"
        logpath.parent.mkdir(exist_ok=True)
        with logpath.open("w") as log:
            p = await asyncio.create_subprocess_exec(
                *command, stdout=log, stderr=log, start_new_session=True
            )
            try:
                code = await p.wait()
            except asyncio.CancelledError:
                import os, signal

                try:
                    os.killpg(p.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    await asyncio.wait_for(p.wait(), timeout=15)
                except asyncio.TimeoutError:
                    try:
                        os.killpg(p.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    await p.wait()
                if creates_video:
                    (out / movie).unlink(missing_ok=True)
                raise
            if code:
                if creates_video:
                    (out / movie).unlink(missing_ok=True)
                raise RuntimeError(
                    f"Pipeline {action} exited {code}; see {logpath.name}"
                )
        from .config import OUTPUT

        if action in {"preview", "render"}:
            folder = out / ("previews" if action == "preview" else "frames")
            candidates = sorted(folder.glob("frame_*.png"))
            if not candidates:
                raise RuntimeError("Renderer returned without producing any frames")
            artifact = candidates[0]
        else:
            artifact = out / movie
        if not artifact.is_file():
            raise RuntimeError("Pipeline returned without the expected artifact")
        if creates_video:
            if not artifact.stat().st_size:
                artifact.unlink()
                raise RuntimeError("Pipeline produced an empty video")
            current = projects.get(project["id"])
            current["reference"] = movie
            projects.put(current)
        return {
            "action": action,
            "artifact": "/artifacts/" + str(artifact.relative_to(OUTPUT)),
        }
