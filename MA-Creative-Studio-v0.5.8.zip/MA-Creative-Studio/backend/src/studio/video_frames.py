"""Bounded, read-only video sampling returned as MCP image blocks."""

import asyncio
import base64
import io
import json
import math
import re
from pathlib import PurePosixPath

from PIL import Image

from .media import video_metadata

MAX_FRAMES = 3
MAX_ENCODED_IMAGE = 120 * 1024


def is_frame_extraction(name, args):
    from ma_custom_tools.tool_names import LEGACY_PIPELINE, PREVIZ_RENDER
    return name in {PREVIZ_RENDER, LEGACY_PIPELINE} and args.get("action") == "extract_frames"


def validate_arguments(args):
    if set(args) - {"action", "artifact", "timestamps"}:
        raise ValueError("extract_frames 只接受 artifact 和可选 timestamps")
    name = args.get("artifact")
    if (not isinstance(name, str) or not name or len(name) > 1024
            or "\\" in name or "\0" in name
            or PurePosixPath(name).is_absolute()
            or any(part.startswith(".") for part in name.split("/"))
            or PurePosixPath(name).suffix.lower() != ".mp4"):
        raise ValueError("artifact 必须是当前项目 artifacts 返回的 MP4 相对名称")
    timestamps = args.get("timestamps")
    if timestamps is not None and (
        not isinstance(timestamps, list) or not 1 <= len(timestamps) <= MAX_FRAMES
        or any(type(t) not in (int, float) or not math.isfinite(t) or t < 0 for t in timestamps)
    ):
        raise ValueError("timestamps 必须包含 1–3 个非负有限秒数")
    return name, timestamps


def encode_image(raw):
    with Image.open(io.BytesIO(raw)) as source:
        image = source.convert("RGB")
    image.thumbnail((960, 960))
    for _ in range(10):
        output = io.BytesIO()
        image.save(output, format="JPEG", quality=80, optimize=True)
        encoded = base64.b64encode(output.getvalue()).decode("ascii")
        if len(encoded) <= MAX_ENCODED_IMAGE:
            return encoded
        image.thumbnail((max(1, int(image.width * .75)), max(1, int(image.height * .75))))
    raise ValueError("抽帧图片超过传输预算")


async def sample(path, timestamp):
    # copyts keeps source timestamps in showinfo; output is a single bounded PNG.
    process = await asyncio.create_subprocess_exec(
        "ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "info",
        "-ss", str(timestamp), "-copyts", "-i", str(path),
        "-map", "0:v:0", "-frames:v", "1", "-an", "-sn", "-dn",
        "-vf", "showinfo,scale=960:960:force_original_aspect_ratio=decrease",
        "-threads", "1", "-f", "image2pipe", "-c:v", "png", "pipe:1",
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
    )
    try:
        raw, diagnostics = await asyncio.wait_for(process.communicate(), timeout=20)
    except (TimeoutError, asyncio.CancelledError):
        if process.returncode is None:
            process.kill()
        await process.communicate()
        raise
    match = re.search(rb"\bn:\s*0\s+pts:.*?pts_time:([\d.eE+\-]+)", diagnostics)
    if process.returncode or not raw or not match:
        raise ValueError("视频抽帧失败或该时间点没有可解码画面，请检查视频或选择更早的时间点")
    actual = float(match[1])
    if not math.isfinite(actual):
        raise ValueError("无法读取实际帧时间")
    return await asyncio.to_thread(encode_image, raw), actual


async def extract_frames(projects, project, args):
    name, timestamps = validate_arguments(args)
    path = projects.path(project, name)
    artifacts = await asyncio.to_thread(projects.artifacts, project)
    if not path.is_file() or not any(a["name"] == name for a in artifacts):
        raise ValueError("视频不在当前项目的 artifacts 中")
    metadata = await asyncio.to_thread(video_metadata, path)
    if not metadata:
        raise ValueError("无法读取视频元数据")
    duration = metadata["duration"]
    timestamps = timestamps if timestamps is not None else [duration * f for f in (.1, .5, .9)]
    if any(t >= duration for t in timestamps):
        raise ValueError("timestamps 必须小于视频时长")
    revision = (path.stat().st_size, path.stat().st_mtime_ns)
    content, frames = [], []
    for timestamp in timestamps:
        encoded, actual = await sample(path, timestamp)
        frame = {"requested_timestamp": timestamp, "timestamp": actual}
        frames.append(frame)
        content.extend([
            {"type": "text", "text": json.dumps(frame, ensure_ascii=False)},
            {"type": "image", "mimeType": "image/jpeg", "data": encoded},
        ])
    if revision != (path.stat().st_size, path.stat().st_mtime_ns):
        raise ValueError("视频在抽帧期间发生变化，请待写入完成后重新读取")
    content.insert(0, {"type": "text", "text": json.dumps({
        "artifact": name, "video": metadata, "frames": frames,
        "message": "仅采样所列时间点；请结合用户要求检查画面，不能据此宣称整段视频通过验收。",
    }, ensure_ascii=False)})
    return {"content": content, "isError": False}
