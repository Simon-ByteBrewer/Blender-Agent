"""Public, content-free tool lifecycle snapshots for the current Session."""

import time


STATES = {"executing", "ready", "sending", "sent", "rejected"}


async def snapshot(store, sid, *, worker_active, remote_client=None):
    empty = {"session_id": sid or "", "available": False, "sampled_at": None,
             "worker_active": False, "calls": []}
    if not sid:
        return empty
    if remote_client is not None:
        data = await remote_client.tool_status.snapshot(sid)
        if data.get("session_id") != sid:
            return empty
        available = data.get("status") == "ok" and not data.get("stale", True)
        rows = [(call.get("call_id"), call.get("status")) for call in data.get("calls", [])
                if isinstance(call, dict)] if available else []
        sampled_at = data.get("sampled_at")
        truncated = bool(data.get("truncated"))
    else:
        with store.connect() as db:
            rows = db.execute("SELECT id,status FROM calls WHERE sid=?", (sid,)).fetchall()
        available, sampled_at, truncated = True, time.time(), False
    return {"session_id": sid, "available": available, "sampled_at": sampled_at,
            "worker_active": bool(worker_active),
            "truncated": truncated,
            "calls": [{"id": cid, "status": status if status in STATES else "unknown"}
                      for cid, status in rows if isinstance(cid, str)]}
