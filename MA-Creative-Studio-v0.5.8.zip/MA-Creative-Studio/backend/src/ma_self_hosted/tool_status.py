"""One persistent, read-only SSH journal sampler per configured server.

Create this alongside RemoteClient, call snapshot(sid) after checking ownership,
and close it with that client. sampled_at is observation time, never tool start
or completion time: the existing journal has no per-call timestamps.
"""

import asyncio
import json
import math
from pathlib import Path
import shlex
import sys
import time

from .collect_tool_status import MAX_CALLS, MAX_SESSIONS, STATUSES, identifier

FIRST_SAMPLE_WAIT_SECONDS = .8
STALE_SECONDS = 8
SAMPLE_TIMEOUT_SECONDS = 10
RETRY_SECONDS = 3
SUBSCRIPTION_IDLE_SECONDS = 60
PROCESS_STOP_TIMEOUT_SECONDS = 3


class ToolStatus:
    def __init__(self, server):
        self.server = server
        self.task = None
        self.lock = asyncio.Lock()
        self.changed = asyncio.Event()
        self.wanted = {}
        self.ready = {}
        self.latest = {}
        self.confirmed = set()
        self.connected = False
        self.retry_at = 0

    async def snapshot(self, sid):
        if not identifier(sid):
            raise ValueError("Invalid Session ID")
        async with self.lock:
            now = time.monotonic()
            expired = [item for item, seen in self.wanted.items()
                       if now - seen > SUBSCRIPTION_IDLE_SECONDS and item != sid]
            for item in expired:
                self.wanted.pop(item, None)
                self.latest.pop(item, None)
                self.confirmed.discard(item)
                self.ready.pop(item, None)
            if sid not in self.wanted and len(self.wanted) >= MAX_SESSIONS:
                return self.unknown(sid, "subscription_limit")
            new = sid not in self.wanted
            self.wanted[sid] = now
            ready = self.ready.setdefault(sid, asyncio.Event())
            if new or expired:
                self.changed.set()
            if (self.task is None or self.task.done()) and now >= self.retry_at:
                for event in self.ready.values():
                    event.clear()
                self.changed.set()
                self.task = asyncio.create_task(self.consume())
        if sid not in self.latest and self.task and not self.task.done():
            try:
                await asyncio.wait_for(ready.wait(), FIRST_SAMPLE_WAIT_SECONDS)
            except TimeoutError:
                pass
        cached = self.latest.get(sid)
        if cached is None:
            return self.unknown(sid, "loading" if self.task and not self.task.done() else "unavailable")
        value, received_at = cached
        age = max(0, time.monotonic() - received_at)
        stale = age > STALE_SECONDS
        available = self.connected and sid in self.confirmed and not stale and value["status"] == "ok"
        result = {**value, "session_id": sid, "source": "worker_journal",
                  "age_seconds": round(age, 3), "stale": stale,
                  "status": "ok" if available else "unknown"}
        if not available:
            result["reason"] = "stale" if stale else value.get("reason", "unavailable")
            result["calls"] = [{"call_id": call["call_id"], "status": "unknown",
                                "last_known_status": call["status"]} for call in value["calls"]]
        else:
            result["calls"] = [dict(call) for call in value["calls"]]
        return result

    @staticmethod
    def unknown(sid, reason):
        return {"session_id": sid, "source": "worker_journal", "status": "unknown",
                "sampled_at": None, "age_seconds": None, "stale": False,
                "calls": [], "reason": reason, "truncated": False}

    def accept(self, value):
        if not isinstance(value, dict) or not isinstance(value.get("sessions"), dict):
            return
        sampled_at = value.get("sampled_at")
        if isinstance(sampled_at, bool) or not isinstance(sampled_at, (int, float)) or not math.isfinite(sampled_at):
            return
        for sid, data in value["sessions"].items():
            if sid not in self.wanted or not isinstance(data, dict) or not isinstance(data.get("calls"), list):
                continue
            if not isinstance(data.get("status"), str) or data["status"] not in {"ok", "unknown"}:
                continue
            calls = {}
            for call in data["calls"][:MAX_CALLS]:
                if isinstance(call, dict) and identifier(call.get("call_id")):
                    status = call.get("status")
                    calls[call["call_id"]] = {"call_id": call["call_id"],
                                             "status": status if isinstance(status, str) and status in STATUSES else "unknown"}
            clean = {"sampled_at": sampled_at, "status": data["status"], "calls": list(calls.values()),
                     "truncated": bool(data.get("truncated")) or len(data["calls"]) > MAX_CALLS}
            if data["status"] != "ok":
                clean["reason"] = "journal_unavailable"
            self.latest[sid] = (clean, time.monotonic())
            self.confirmed.add(sid)
            self.ready[sid].set()

    async def consume(self):
        process, writer = None, None
        try:
            self.confirmed.clear()
            source = Path(__file__).with_name("collect_tool_status.py").read_text()
            command = "sudo -n -u elsa -H python3 -u -c " + shlex.quote(source)
            process = await asyncio.create_subprocess_exec(
                "/usr/bin/ssh" if sys.platform == "darwin" else "ssh", "-T", "-o", "BatchMode=yes",
                "-o", "ConnectTimeout=8", "-o", "ServerAliveInterval=15", "-o", "ServerAliveCountMax=3",
                "-o", "StrictHostKeyChecking=accept-new", self.server["ssh_target"], command,
                stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL, limit=16 * 1024 * 1024)
            self.connected = True

            async def subscriptions():
                while True:
                    await self.changed.wait()
                    self.changed.clear()
                    payload = json.dumps({"sessions": sorted(self.wanted)}).encode() + b"\n"
                    process.stdin.write(payload)
                    await process.stdin.drain()

            writer = asyncio.create_task(subscriptions())
            while line := await asyncio.wait_for(process.stdout.readline(), SAMPLE_TIMEOUT_SECONDS):
                if writer.done():
                    await writer
                try:
                    self.accept(json.loads(line))
                except (ValueError, UnicodeError):
                    continue
        except (OSError, TimeoutError, ValueError):
            pass
        finally:
            self.connected = False
            self.confirmed.clear()
            self.retry_at = time.monotonic() + RETRY_SECONDS
            if writer:
                writer.cancel()
                await asyncio.gather(writer, return_exceptions=True)
            try:
                if process and process.returncode is None:
                    try:
                        process.terminate()
                    except ProcessLookupError:
                        pass
                    try:
                        await asyncio.wait_for(process.wait(), PROCESS_STOP_TIMEOUT_SECONDS)
                    except TimeoutError:
                        try:
                            process.kill()
                        except ProcessLookupError:
                            pass
                        await process.wait()
            finally:
                for event in self.ready.values():
                    event.set()

    async def close(self):
        if self.task:
            self.task.cancel()
            await asyncio.gather(self.task, return_exceptions=True)
            self.task = None
        self.connected = False
        self.latest.clear()
        self.confirmed.clear()
        self.retry_at = 0
