"""Choose worker capacity from the server's CPU allocation and available memory."""

from dataclasses import asdict, dataclass
import os
from pathlib import Path

GIB = 1024 ** 3


@dataclass(frozen=True)
class Capacity:
    logical_cpus: int
    available_memory_bytes: int
    session_slots: int
    render_slots: int
    threads_per_render: int

    def as_dict(self):
        return asdict(self)


def calculate(logical_cpus, available_memory_bytes):
    # Keep a quarter of CPU/memory for the desktop, tool calls and other services.
    cpu_budget = max(1, int(logical_cpus * .75))
    memory_budget = max(0, int(available_memory_bytes * .75))
    threads = min(8, cpu_budget)
    renders = max(1, min(cpu_budget // threads, memory_budget // (4 * GIB)))
    sessions = max(1, min(renders * 2, memory_budget // (2 * GIB)))
    return Capacity(logical_cpus, available_memory_bytes, sessions, renders, threads)


def detect():
    cpus = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else (os.cpu_count() or 1)
    try:
        quota, period = Path("/sys/fs/cgroup/cpu.max").read_text().split()
        if quota != "max":
            cpus = min(cpus, max(1, int(quota) // int(period)))
    except (OSError, ValueError):
        pass
    memory = 8 * GIB
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemAvailable:"):
                memory = int(line.split()[1]) * 1024
                break
        maximum = Path("/sys/fs/cgroup/memory.max").read_text().strip()
        if maximum != "max":
            used = int(Path("/sys/fs/cgroup/memory.current").read_text())
            memory = min(memory, max(0, int(maximum) - used))
    except (OSError, ValueError):
        pass
    return calculate(cpus, memory)
