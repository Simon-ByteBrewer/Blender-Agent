"""One lightweight SSH sampler per server, shared by all its project views."""

import asyncio
import json
from pathlib import Path
import shlex
import sys
import time

SAMPLE_TIMEOUT_SECONDS = 90
PROCESS_STOP_TIMEOUT_SECONDS = 3


class Resources:
    def __init__(self, server):
        self.server = server
        self.task = None
        self.lock = asyncio.Lock()
        self.ready = asyncio.Event()
        self.latest = None
        self.received_at = 0

    async def snapshot(self):
        async with self.lock:
            if self.task is None or self.task.done():
                self.ready.clear()
                self.task = asyncio.create_task(self.consume())
        try:
            await asyncio.wait_for(self.ready.wait(), 15)
        except TimeoutError:
            raise RuntimeError("服务器资源信息暂时不可用") from None
        if self.latest is None or time.monotonic() - self.received_at > SAMPLE_TIMEOUT_SECONDS:
            raise RuntimeError("服务器资源信息暂时不可用")
        return self.latest

    async def consume(self):
        process = None
        try:
            source = Path(__file__).with_name("collect_resources.py").read_text()
            command = "sudo -n -u elsa -H python3 -u -c " + shlex.quote(source) + " /home/elsa/ma-creative-studio"
            process = await asyncio.create_subprocess_exec(
                "/usr/bin/ssh" if sys.platform == "darwin" else "ssh", "-o", "BatchMode=yes",
                "-o", "ConnectTimeout=12", "-o", "ServerAliveInterval=15", "-o", "ServerAliveCountMax=3",
                "-o", "StrictHostKeyChecking=accept-new", self.server["ssh_target"], command,
                stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
            while line := await asyncio.wait_for(process.stdout.readline(), SAMPLE_TIMEOUT_SECONDS):
                try:
                    value = json.loads(line)
                    if not isinstance(value, dict) or not {"cpu", "memory", "disk", "gpus"} <= value.keys():
                        continue
                except (ValueError, UnicodeError):
                    continue
                self.latest = value
                self.received_at = time.monotonic()
                self.ready.set()
        except (OSError, TimeoutError):
            pass
        finally:
            try:
                if process and process.returncode is None:
                    try:
                        process.terminate()
                    except ProcessLookupError:
                        pass
                    try:
                        await asyncio.wait_for(process.wait(), PROCESS_STOP_TIMEOUT_SECONDS)
                    except TimeoutError:
                        try:
                            process.kill()
                        except ProcessLookupError:
                            pass
                        await process.wait()
            finally:
                self.ready.set()

    async def close(self):
        if self.task:
            self.task.cancel()
            await asyncio.gather(self.task, return_exceptions=True)
            self.task = None
