"""Loopback-only remote executor. Start with ``python -m ma_self_hosted.server``."""

import asyncio
import contextlib
import hmac
import json
import os
import re
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request, HTTPException, UploadFile, File
from fastapi.responses import JSONResponse, FileResponse


def create_app(runtime, token, environment_id=None, *, work_queue=True):
    from .gateway import REMOTE_TOOLS
    from .capacity import detect
    capacity = detect()
    runtime.jobs.render_slots = asyncio.Semaphore(capacity.render_slots)
    os.environ["STUDIO_RENDER_POOL"] = str(runtime.ROOT / ".local" / "render-pool")
    os.environ["STUDIO_RENDER_WORKERS"] = str(capacity.render_slots)
    os.environ["STUDIO_RENDER_THREADS"] = str(capacity.threads_per_render)
    os.environ["LP_NUM_THREADS"] = str(capacity.threads_per_render)
    os.environ["OMP_NUM_THREADS"] = str(capacity.threads_per_render)
    workers = None
    if work_queue:
        if not environment_id:
            raise ValueError("Self-hosted Worker requires an Environment ID")
        from .worker import Workers
        workers = Workers(runtime, environment_id, concurrency=capacity.session_slots)

    worker_lock = asyncio.Lock()
    from . import desktops as desktop_module
    desktops = None
    if desktop_module.enabled():
        limit = int(os.environ.get("STUDIO_DESKTOP_LIMIT") or max(2, capacity.session_slots))
        desktops = desktop_module.ProjectDesktops(runtime.store, limit=limit, log_dir=runtime.ROOT / "logs")

        async def display_for(p):
            return ":%d" % (await desktops.ensure(p["id"]))["display"]

        def project_busy(pid):
            instance = runtime.blender_runtime.instances.get(pid)
            return (any(j.get("project_id") == pid and j["status"] in {"queued", "running"} for j in runtime.jobs.list())
                    or bool(workers and pid in workers.sessions)
                    or bool(instance and instance.operation_lock.locked()))

        runtime.blender_runtime.display_for = display_for
        desktops.busy = project_busy
        desktops.before_stop = lambda pid: close_blender(runtime.projects.get(pid))

    async def close_blender(p):
        await runtime.close_blender(p)

    async def enable_work_queue(target):
        nonlocal workers, environment_id
        if not isinstance(target, str) or not re.fullmatch(r"env-[A-Za-z0-9-]+", target):
            raise HTTPException(400, "Invalid Environment ID")
        async with worker_lock:
            if workers:
                if target != environment_id:
                    raise HTTPException(409, "Executor already serves another Work Queue")
                return
            from .worker import Workers
            created = Workers(runtime, target, concurrency=capacity.session_slots)
            await created.start()
            workers, environment_id = created, target

    @asynccontextmanager
    async def lifespan(app):
        (runtime.ROOT / "logs").mkdir(exist_ok=True)
        for job in runtime.jobs.list():
            if job["status"] in {"queued", "running"}:
                runtime.jobs.update({**job, "status": "interrupted"})
        if workers:
            await workers.start()
        reaper = asyncio.create_task(desktops.run_reaper()) if desktops else None
        yield
        if reaper:
            reaper.cancel()
            await asyncio.gather(reaper, return_exceptions=True)
        if workers:
            await workers.close()
        for task in runtime.jobs.tasks.values():
            task.cancel()
        await asyncio.gather(*runtime.jobs.tasks.values(), return_exceptions=True)

    app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
    app.state.enable_work_queue = enable_work_queue
    app.state.desktops = desktops

    @app.middleware("http")
    async def authorize(request, next):
        if request.headers.get("origin") or not hmac.compare_digest(
                request.headers.get("authorization", ""), "Bearer " + token):
            return JSONResponse({"detail": "Worker authentication required"}, 403)
        try:
            return await next(request)
        except Exception as exc:
            return JSONResponse({"detail": runtime.safe_error(exc).replace(token, "[REDACTED]")}, 500)

    def project(pid):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", pid):
            raise HTTPException(400, "Invalid project ID")
        try:
            return runtime.projects.get(pid)
        except KeyError:
            raise HTTPException(404, "Project not bound") from None

    @app.get("/health")
    async def health():
        return {"status": "ready", "environment_id": environment_id,
                # Lets the app update Self-hosted Agents only when this executor runs their tools.
                "tools_supported": sorted(REMOTE_TOOLS),
                "tool_protocol": "self_hosted" if workers else "custom_tools", "work_queue_enabled": workers is not None,
                "worker_slots": workers.concurrency if workers else 0, "active_sessions": len(workers.sessions) if workers else 0,
                "last_poll": workers.last_poll if workers else None, "worker_error": workers.last_error if workers else None,
                "capacity": capacity.as_dict()}

    @app.get("/tools")
    async def tools():
        return await runtime.bridge.discover()

    @app.post("/projects")
    async def bind(request: Request):
        body = await request.json()
        pid = body.get("id", "")
        allowed_environments = {environment_id} if work_queue else {None, environment_id}
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", pid) or body.get("environment_id") not in allowed_environments:
            raise HTTPException(400, "Invalid project binding")
        # Reuse the application's validation; reject path-like scene and file names.
        values = runtime.ProjectRequest(**{k: body.get(k, d) for k, d in
            (("title", pid), ("prompt", ""))}, **body.get("settings", {}))
        for name in ("blend", "reference"):
            value = body.get(name, "")
            if not value or Path(value).name != value or ".." in value:
                raise HTTPException(400, "Invalid project filename")
        if not isinstance(body.get("scene"), str) or not 1 <= len(body["scene"]) <= 120:
            raise HTTPException(400, "Invalid scene name")
        try:
            p = runtime.projects.get(pid)
        except KeyError:
            p = {"id": pid, "created_at": time.time(), "directory": "projects/" + pid,
                 "demo": False, "scene": body["scene"], "blend": body["blend"],
                 "reference": body["reference"], "settings": {
                     "duration": values.duration, "fps": values.fps, "resolution": values.resolution}}
        p.update(title=values.title, prompt=values.prompt)
        if body.get("session_id"):
            sid = body["session_id"]
            if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", sid):
                raise HTTPException(400, "Invalid Session ID")
            previous = runtime.store.get("worker_session:" + sid)
            if previous and previous != pid:
                raise HTTPException(409, "Session is already bound")
            p["session_id"] = sid
            runtime.store.set("worker_session:" + sid, pid)
        runtime.projects.directory(p).mkdir(parents=True, exist_ok=True)
        runtime.projects.put(p)
        return {"id": pid, "status": "bound"}

    @app.get("/projects/{pid}/state")
    async def state(pid: str):
        p = project(pid)
        path = runtime.projects.directory(p) / "render_progress.json"
        try:
            progress = json.loads(path.read_text())
        except (OSError, ValueError):
            progress = None
        return {"reference": p["reference"], "artifacts": runtime.projects.artifacts(p),
                "jobs": [j for j in runtime.jobs.list() if j.get("project_id") == pid],
                "render_progress": progress, "worker_active": bool(workers and pid in workers.sessions)}

    @app.get("/projects/{pid}/blender")
    async def blender(pid: str):
        return await runtime.instance(project(pid)).status()

    async def project_desktop(pid):
        try:
            return await desktops.ensure(pid)
        except desktop_module.DesktopLimit as exc:
            raise HTTPException(503, str(exc)) from None
        except RuntimeError as exc:
            raise HTTPException(502, str(exc)) from None

    @app.post("/projects/{pid}/desktop")
    async def desktop(pid: str, start: bool = True, activity: bool = True):
        """start: open the project's desktop (explicit user action). Otherwise only attach to a
        running one, so stale browser tabs reconnecting never revive an idle-closed desktop.
        activity: real input happened, which postpones the idle timeout."""
        project(pid)
        if not desktops:
            return {"isolated": False}
        if start:
            record = await project_desktop(pid)
        elif desktops.running(pid):
            if activity:
                desktops.touch(pid)
            record = desktops.records()[pid]
        else:
            raise HTTPException(409, "项目桌面已因空闲自动关闭")
        return {"isolated": True, "display": record["display"], "port": record["port"]}

    @app.get("/projects/{pid}/desktop")
    async def desktop_state(pid: str):
        project(pid)
        return {"isolated": bool(desktops), "running": not desktops or desktops.running(pid)}

    @app.post("/projects/{pid}/open")
    async def open_blender(pid: str):
        p = project(pid)
        if desktops:
            expected = ":%d" % (await project_desktop(pid))["display"]
            state = await runtime.instance(p).status()
            if state["running"] and state.get("display") and state["display"] != expected:
                # Blender launched before per-project desktops (on the shared :1) moves once.
                try:
                    await close_blender(p)
                except RuntimeError as exc:
                    raise HTTPException(409, "该项目的 Blender 仍在共享桌面上运行，且无法自动保存后迁移：" + str(exc)) from None
        async with runtime.blender_lock(p):
            await runtime.activate(p)
        await runtime.instance(p).open()
        return await runtime.instance(p).status()

    @app.post("/projects/{pid}/tools")
    async def tool(pid: str, request: Request):
        p = project(pid)
        if desktops:
            desktops.touch(pid)
        body = await request.json()
        if body.get("name") not in REMOTE_TOOLS:
            raise HTTPException(400, "Tool is not enabled on this server")
        context = runtime.active_project.set(p)
        try:
            return await runtime.dispatch(body["name"], body.get("arguments", {}))
        finally:
            runtime.active_project.reset(context)

    @app.post("/projects/{pid}/interrupt")
    async def interrupt(pid: str):
        project(pid)
        if workers:
            await workers.cancel(pid)
        return {"status": "interrupted"}

    @app.get("/projects/{pid}/files/{name:path}")
    async def download(pid: str, name: str):
        p = project(pid)
        if not any(a["name"] == name for a in runtime.projects.artifacts(p)):
            raise HTTPException(404, "Artifact not found")
        return FileResponse(runtime.projects.path(p, name))

    @app.put("/projects/{pid}/files/{name:path}")
    async def upload(pid: str, name: str, file: UploadFile = File(...)):
        p = project(pid)
        path = runtime.projects.path(p, name)
        if path.suffix.lower() not in {".png", ".jpg", ".jpeg", ".mp4"} or not name.startswith("uploads/"):
            raise HTTPException(400, "Only project uploads are accepted")
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".upload")
        count = 0
        try:
            with temporary.open("wb") as target:
                while chunk := await file.read(1024 * 1024):
                    count += len(chunk)
                    if count > 50 * 1024 * 1024:
                        raise HTTPException(413, "Upload exceeds 50 MB")
                    target.write(chunk)
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)
        return {"name": name, "bytes": count}

    return app


def main():
    import uvicorn
    config = json.loads(Path(os.environ["STUDIO_WORKER_CONFIG"]).read_text())
    # This token authorizes only the dedicated local gateway; no Ark business key
    # is installed on the server or inherited by Blender/MCP child processes.
    os.environ["ARK_API_KEY"] = config["token"]
    os.environ["ARK_BASE_URL"] = "http://127.0.0.1:17862/api/v3"
    from studio import app as runtime
    uvicorn.run(create_app(runtime, config["token"], config["environment_id"]),
                host="127.0.0.1", port=17861, access_log=False)


if __name__ == "__main__":
    main()
