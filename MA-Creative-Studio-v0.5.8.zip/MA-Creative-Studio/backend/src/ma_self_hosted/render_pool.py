"""Host-wide render leases and persistent Blender frame workers.

The existing job semaphore limits admitted jobs; these flock leases limit the
actual Blender/encoder processes across all admitted jobs. No server is needed.
"""

from collections import deque
from contextlib import contextmanager
import fcntl
import json
import math
import os
from pathlib import Path
import queue
import shutil
import signal
import subprocess
import tempfile
import threading
import time
import uuid

from studio.render_state import PROTOCOL, blend_hash, prepare_frames, valid_png, write_json


@contextmanager
def defer_interrupts():
    """Make spawn/registration and reaping atomic with respect to cancellation.

    Unlike pthread_sigmask, Python handlers are reset by exec, so children still
    receive SIGTERM normally. Threaded unit-test coordinators do not own signals.
    """
    if threading.current_thread() is not threading.main_thread():
        yield
        return
    previous = {number: signal.getsignal(number) for number in (signal.SIGINT, signal.SIGTERM)}
    pending = []

    def defer(number, frame):
        pending.append((number, frame))

    for number, handler in previous.items():
        if handler != signal.SIG_IGN:
            signal.signal(number, defer)
    try:
        yield
    finally:
        for number, handler in previous.items():
            signal.signal(number, handler)
        if pending:
            number, frame = pending[0]
            handler = previous[number]
            if callable(handler):
                handler(number, frame)
            else:
                raise KeyboardInterrupt("Renderer interrupted")


class RenderPool:
    def __init__(self, directory, slots, *, owner_fds=()):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.slots = max(1, int(slots))
        self.leases = []
        self.owner_fds = tuple(owner_fds)
        self.client = None
        self.client_path = self.directory / f"client-{time.time_ns():020d}-{uuid.uuid4().hex}"
        with self.guard():
            clients = self._clients()
            config = self.directory / "capacity.json"
            if clients:
                self.slots = int(json.loads(config.read_text())["slots"])
            else:
                write_json(config, {"slots": self.slots})
            self.client = self.client_path.open("a+")
            fcntl.flock(self.client, fcntl.LOCK_EX)

    @contextmanager
    def guard(self):
        with (self.directory / "registry.lock").open("a+") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            yield

    def _clients(self):
        clients = []
        for path in sorted(self.directory.glob("client-*")):
            if path == self.client_path and self.client is not None:
                clients.append(path)
                continue
            with path.open("a+") as lock:
                try:
                    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    clients.append(path)
                else:
                    path.unlink(missing_ok=True)
        return clients

    def fair_share(self):
        with self.guard():
            clients = self._clients()
            index = clients.index(self.client_path)
            base, extra = divmod(self.slots, len(clients))
            return base + (index < extra)

    def acquire(self):
        if len(self.leases) >= self.fair_share():
            return None
        for index in range(self.slots):
            lease = (self.directory / f"slot-{index:04d}.lock").open("a+")
            try:
                fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                lease.close()
                continue
            self.leases.append(lease)
            return lease
        return None

    def child_fds(self, lease):
        # Retain the project lock too: after SIGKILL a replacement coordinator
        # must not archive frames while an orphan Blender is still writing.
        return (lease.fileno(), self.client.fileno(), *self.owner_fds)

    def release(self, lease):
        self.leases.remove(lease)
        # Do not LOCK_UN: an inherited descriptor must retain the lease if the
        # coordinator dies before its child. Closing the last FD releases it.
        lease.close()

    @contextmanager
    def single_slot(self):
        lease = None
        try:
            while lease is None:
                lease = self.acquire()
                if lease is None:
                    time.sleep(.1)
            yield lease
        finally:
            if lease is not None:
                self.release(lease)

    def close(self):
        for lease in self.leases[:]:
            self.release(lease)
        if self.client is not None:
            with self.guard():
                self.client.close()
                self.client = None
                self.client_path.unlink(missing_ok=True)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


def stop_process(process, graceful=False):
    try:
        if process.poll() is None:
            if graceful:
                try:
                    process.stdin.write(json.dumps({"action": "stop"}) + "\n")
                    process.stdin.flush()
                except (OSError, ValueError):
                    process.terminate()
            else:
                process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
    finally:
        if process.stdin:
            process.stdin.close()


def run_leased(command, pool, *, capture_output=False):
    """Include serial rendering, encoding and validation in the same CPU budget."""
    command = [str(v) for v in command]
    with pool.single_slot() as lease:
        process = None
        try:
            with defer_interrupts():
                process = subprocess.Popen(command, text=True,
                    stdout=subprocess.PIPE if capture_output else None,
                    stderr=subprocess.PIPE if capture_output else None,
                    pass_fds=pool.child_fds(lease))
            stdout, stderr = process.communicate()
            if process.returncode:
                raise subprocess.CalledProcessError(process.returncode, command, stdout, stderr)
            return subprocess.CompletedProcess(command, process.returncode, stdout, stderr)
        finally:
            with defer_interrupts():
                if process is not None:
                    stop_process(process)



class FrameWorker:
    def __init__(self, command, pool, lease, events):
        self.pool, self.lease = pool, lease
        self.ready = False
        self.frames = None
        self.since = time.monotonic()
        try:
            self.process = subprocess.Popen([str(v) for v in command] + ["--worker"],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1, pass_fds=pool.child_fds(lease))
        except BaseException:
            pool.release(lease)
            raise

        def read():
            try:
                for line in self.process.stdout:
                    if line.startswith(PROTOCOL):
                        events.put((self, json.loads(line[len(PROTOCOL):])))
                    else:
                        print(f"[render:{self.process.pid}] {line.rstrip()}", flush=True)
            except Exception as error:
                events.put((self, {"event": "error", "message": str(error)}))
            finally:
                events.put((self, {"event": "exit"}))
                self.process.stdout.close()
        self.reader = threading.Thread(target=read, daemon=True)
        try:
            self.reader.start()
        except BaseException:
            stop_process(self.process)
            self.process.stdout.close()
            pool.release(lease)
            raise

    def assign(self, frames):
        self.frames = frames
        self.since = time.monotonic()
        self.process.stdin.write(json.dumps({"action": "render", "frames": frames}) + "\n")
        self.process.stdin.flush()

    def close(self, graceful=False):
        try:
            stop_process(self.process, graceful)
            self.reader.join(timeout=5)
        finally:
            self.pool.release(self.lease)


def render_parallel(command, out, pool, *, batch_size=8, startup_timeout=120, batch_timeout=1800):
    """Render independent frames; unsafe scenes fall back to one leased process."""
    out = Path(out)
    command = [str(v) for v in command]
    source_index = command.index("-b") + 1
    source = Path(command[source_index]).resolve()
    # Same directory preserves Blender's //relative texture and cache paths.
    # The backup extension is readable by Blender but excluded from artifacts.
    descriptor, snapshot_name = tempfile.mkstemp(prefix=".studio-render-", suffix=".blend1", dir=source.parent)
    os.close(descriptor)
    snapshot = Path(snapshot_name)
    workers = []
    events = queue.Queue()
    metadata = None
    completed = set()
    pending = deque()
    folder = out / "frames"
    started = time.monotonic()
    peak_workers = 0

    def progress(status, **extra):
        write_json(out / "render_progress.json", dict(status=status, mode="render",
            frame=max(completed, default=0), completed=len(completed),
            total=metadata["frames"] if metadata else 0, workers=len(workers),
            peak_workers=peak_workers, elapsed_seconds=round(time.monotonic() - started, 1), **extra))

    def spawn():
        nonlocal peak_workers
        lease = pool.acquire()
        if lease is None:
            return False
        with defer_interrupts():
            worker = FrameWorker(command, pool, lease, events)
            workers.append(worker)
            peak_workers = max(peak_workers, len(workers))
        return True

    def retire(worker, graceful=False):
        with defer_interrupts():
            worker.close(graceful)
            workers.remove(worker)

    try:
        shutil.copyfile(source, snapshot)
        digest = blend_hash(snapshot)
        command[source_index] = str(snapshot)
        command += ["--source-blend", str(source)]
        progress("waiting")
        while not workers:
            if not spawn():
                time.sleep(.1)
        while True:
            try:
                worker, event = events.get(timeout=.1)
            except queue.Empty:
                worker, event = None, None
            if worker in workers:
                if event["event"] == "ready":
                    if metadata is None:
                        reasons = event.get("sequential_reasons", [])
                        if reasons:
                            print("RENDER_SERIAL_FALLBACK " + json.dumps(reasons), flush=True)
                            retire(worker, graceful=True)
                            run_leased(command, pool)
                            return
                        metadata = event["metadata"]
                        folder = prepare_frames(out, metadata, "render", digest)
                        for frame in range(metadata["start"], metadata["end"] + 1):
                            if valid_png(folder / f"frame_{frame:06d}.png"):
                                completed.add(frame)
                            else:
                                pending.append(frame)
                        progress("running")
                    elif event["metadata"] != metadata or event.get("sequential_reasons"):
                        raise RuntimeError("Render workers loaded inconsistent scene settings")
                    worker.ready = True
                elif event["event"] == "done":
                    if worker.frames is None or event.get("frames") != worker.frames:
                        raise RuntimeError("Render worker acknowledged an unexpected frame batch")
                    for frame in worker.frames:
                        if not valid_png(folder / f"frame_{frame:06d}.png"):
                            raise RuntimeError(f"Render worker failed to publish frame {frame}")
                        completed.add(frame)
                    worker.frames = None
                    progress("running")
                else:
                    raise RuntimeError(f"Render worker {worker.process.pid} stopped unexpectedly: {event}")

            for current in workers:
                limit = batch_timeout if current.ready else startup_timeout
                if (not current.ready or current.frames is not None) and time.monotonic() - current.since > limit:
                    raise TimeoutError(f"Render worker {current.process.pid} exceeded {limit}s")
            if metadata is None:
                continue
            if not pending and all(worker.frames is None for worker in workers):
                break
            # A new project receives its fair share as current batches finish.
            # Only idle processes retire; completed frame files remain reusable.
            share = pool.fair_share()
            for current in workers[:]:
                if current.ready and current.frames is None:
                    if len(workers) > share:
                        retire(current, graceful=True)
                    elif pending:
                        current.assign([pending.popleft() for _ in range(min(batch_size, len(pending)))])
            outstanding = len(pending) + sum(len(w.frames or ()) for w in workers)
            desired = min(share, math.ceil(outstanding / batch_size))
            while len(workers) < desired:
                if not spawn():
                    break
        for worker in workers[:]:
            retire(worker, graceful=True)
        progress("completed")
        print("RENDER_COMPLETE " + json.dumps(metadata), flush=True)
    except BaseException as error:
        progress("interrupted" if isinstance(error, KeyboardInterrupt) else "failed", error=str(error))
        raise
    finally:
        with defer_interrupts():
            for worker in workers[:]:
                retire(worker)
            snapshot.unlink(missing_ok=True)
