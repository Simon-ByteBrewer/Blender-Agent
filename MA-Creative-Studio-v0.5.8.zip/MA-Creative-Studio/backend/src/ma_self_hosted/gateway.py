"""Environment-scoped MA access; the business API key stays on the desktop.

This is an application gateway, not an official Ark Environment Key. The worker
reaches it through reverse SSH forwarding and may only serve bound sessions.
"""

import asyncio
import hmac
import re
import socket
from contextlib import contextmanager

import httpx
import uvicorn
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import Response
from studio.config import base_url, config, key, key_identity

# Tools the Blender executor runs (current and earlier names); Seedance runs in the app.
REMOTE_TOOLS = {"execute_blender_code", "get_scene_info", "get_object_info",
                "get_viewport_screenshot", "blender_tools_list", "blender_tools_call",
                "blender_project", "previz_render", "local_pipeline"}


class GatewayServer(uvicorn.Server):
    @contextmanager
    def capture_signals(self):
        # The outer application owns process shutdown.
        yield


class WorkerGateway:
    def __init__(self, server, store, transport=None):
        self.server = server
        self.store = store
        self.scope = key_identity()
        self.transport = transport
        self.works_key = f"worker_gateway_works:{server['id']}:{self.scope}:{server['environment_id']}"
        self.works = self.known_works()
        self.calls = {}
        self.skills = {}
        self.task = None
        self.http = None
        self.port = None
        self.app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
        self.app.add_api_route("/api/v3/{path:path}", self.proxy, methods=["GET", "POST"])

    def known_works(self):
        recorded = self.store.get(self.works_key, {})
        if not isinstance(recorded, dict):
            return {}
        return {wid: sid for wid, sid in recorded.items()
                if isinstance(wid, str) and re.fullmatch(r"[A-Za-z0-9_-]+", wid)
                and isinstance(sid, str) and re.fullmatch(r"[A-Za-z0-9_-]+", sid)}

    def record_work(self, wid, sid=None):
        # Reload the persisted map so another gateway instance's updates are not
        # overwritten by this instance's older in-memory snapshot.
        recorded = self.known_works()
        if sid is None:
            recorded.pop(wid, None)
        else:
            recorded[wid] = sid
        self.store.set(self.works_key, recorded)
        self.works = recorded

    def owns_session(self, sid):
        return any(
            p.get("execution", {}).get("server_id") == self.server["id"]
            and self.store.get(f"project_session:{p['id']}:{self.scope}:self_hosted:{self.server['id']}") == sid
            for p in self.store.get("projects", [])
        )

    async def proxy(self, path: str, request: Request):
        supplied = request.headers.get("authorization", "")
        if not hmac.compare_digest(supplied, "Bearer " + self.server["token"]) or key_identity() != self.scope:
            raise HTTPException(403, "Worker access is unavailable")
        method = request.method
        body = await request.body()
        if len(body) > 6 * 1024 * 1024:
            raise HTTPException(413, "Tool result too large")
        env = re.escape(self.server["environment_id"])
        poll = method == "GET" and path == f"environments/{self.server['environment_id']}/work/poll"
        work = re.fullmatch(rf"environments/{env}/work/([A-Za-z0-9_-]+)/(ack|heartbeat|stop)", path)
        if work:
            self.works = self.known_works()
        session = re.fullmatch(r"sessions/([A-Za-z0-9_-]+)(/events)?", path)
        skill = re.fullmatch(r"skills/([A-Za-z0-9_-]+)(?:/versions/([A-Za-z0-9_-]+)/content)?", path)
        skill_download = bool(skill and skill[2])
        allowed = poll or (method == "POST" and work and work[1] in self.works
                           and self.owns_session(self.works[work[1]]))
        if method == "GET" and skill:
            allowed = any(self.owns_session(sid) and any(
                ref[0] == skill[1] and (not skill[2] or ref[1] == skill[2]) for ref in refs)
                for sid, refs in self.skills.items())
        if session and self.owns_session(session[1]):
            allowed = method == "GET"
            if method == "POST" and session[2] == "/events":
                try:
                    data = await request.json()
                    events = data["events"]
                    allowed = isinstance(events, list) and len(events) == 1 and all(
                        self.accepts_result(session[1], e) for e in events)
                except (ValueError, TypeError, KeyError):
                    allowed = False
        if not allowed:
            raise HTTPException(403, "Operation outside worker scope")
        if skill_download:
            # The ordinary API route returns a signed storage redirect. Resolve it
            # here without exposing it or sending the business key to storage.
            from studio.ark import Ark, ArkHTTPError
            try:
                content = await Ark(transport=self.transport).download(path)
            except ArkHTTPError as exc:
                raise HTTPException(exc.status_code, "Skill archive unavailable") from None
            except (RuntimeError, httpx.HTTPError):
                raise HTTPException(502, "Skill archive download unavailable") from None
            return Response(content, media_type="application/octet-stream", headers={"Cache-Control": "no-store"})
        headers = {"Authorization": "Bearer " + key(), "Content-Type": "application/json"}
        if method == "POST" and session and session[2] == "/events":
            from studio.byok import event_headers
            try:
                headers.update(event_headers(self.store, session[1]))
            except RuntimeError as exc:
                raise HTTPException(409, str(exc)) from None
        worker_id = request.headers.get("ark-worker-id")
        if worker_id:
            headers["Ark-Worker-ID"] = worker_id[:200]
        base = base_url(config())
        try:
            async with httpx.AsyncClient(transport=self.transport, timeout=45) as client:
                response = await client.request(method, base + "/" + path,
                    params=request.query_params, headers=headers, content=body)
        except httpx.HTTPError:
            raise HTTPException(502, "Ark connection unavailable; write outcome may be unknown") from None
        if response.is_success and method == "POST" and work and work[2] == "stop":
            self.record_work(work[1])
        if response.is_success and response.content:
            data = response.json()
            if poll and data.get("id"):
                sid = (data.get("data") or {}).get("id")
                if not self.owns_session(sid):
                    raise HTTPException(403, "Work is not bound to this desktop")
                self.record_work(data["id"], sid)
            if session and method == "GET" and session[2]:
                for e in data.get("data", data.get("events", [])):
                    if e.get("type") in {"agent.custom_tool_use", "agent.tool_use"}:
                        self.calls[(session[1], e["id"])] = e
                        self.store.event(session[1], e)
            elif session and method == "GET":
                refs = data.get("skills") or (data.get("agent") or {}).get("skills") or []
                self.skills[session[1]] = {(r.get("skill_id") or r.get("id"), str(r.get("version") or "")) for r in refs}
            if skill and not skill[2] and data.get("latest_version") is not None:
                for sid, refs in self.skills.items():
                    if (skill[1], "") in refs:
                        refs.add((skill[1], str(data["latest_version"])))
        # Never reflect credentials from an upstream diagnostic.
        content = response.content
        from urllib.parse import quote
        for name, value in config().items():
            if value and any(marker in name.upper() for marker in ("KEY", "TOKEN", "SECRET", "PASSWORD")):
                content = content.replace(value.encode(), b"[REDACTED]").replace(quote(value, safe="").encode(), b"[REDACTED]")
        return Response(content, response.status_code, media_type="application/json")

    def accepts_result(self, sid, event):
        if not isinstance(event, dict) or not self.owns_session(sid):
            return False
        builtin = event.get("type") == "user.tool_result"
        if not builtin and event.get("type") != "user.custom_tool_result":
            return False
        cid = event.get("tool_use_id" if builtin else "custom_tool_use_id")
        if not isinstance(cid, str) or not cid:
            return False
        call = self.calls.get((sid, cid))
        if call is None:
            call = next((e for e in self.store.events(sid)
                         if e.get("id") == cid and e.get("type") in {"agent.tool_use", "agent.custom_tool_use"}), None)
            if call is not None:
                self.calls[(sid, cid)] = call
        if not call or call.get("type") != ("agent.tool_use" if builtin else "agent.custom_tool_use"):
            return False
        if event.get("session_thread_id") != call.get("session_thread_id"):
            # Existing custom tools don't include a thread; built-ins correlate it.
            if builtin or event.get("session_thread_id"):
                return False
        return builtin or call.get("name") in REMOTE_TOOLS

    async def start(self):
        if self.task and not self.task.done():
            return self.port
        sock = socket.socket()
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("127.0.0.1", self.server.get("gateway_port", 0) if self.server.get("transport") == "loopback" else 0))
        sock.listen(128)
        self.port = sock.getsockname()[1]
        self.http = GatewayServer(uvicorn.Config(self.app, log_config=None, access_log=False))
        self.task = asyncio.create_task(self.http.serve(sockets=[sock]))
        for _ in range(100):
            if self.http.started:
                return self.port
            if self.task.done():
                await self.task
            await asyncio.sleep(.02)
        raise RuntimeError("无法启动 Worker 接入服务")

    async def close(self):
        if self.http:
            self.http.should_exit = True
        if self.task:
            await self.task
