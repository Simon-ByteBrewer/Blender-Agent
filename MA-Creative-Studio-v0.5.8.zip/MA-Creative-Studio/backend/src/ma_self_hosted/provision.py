"""Three-field SSH provisioning and an allowlisted deployment payload."""

import asyncio
import hashlib
import fcntl
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import shlex
import sys
import tarfile
import tempfile
import time

from studio.config import RESOURCES, STATE, key_identity, safe_error
from studio.ark import ArkHTTPError
from . import execution
from .download_proxy import DownloadProxy

UV_SHA256 = "b7e89798bd3df7dcc4b2b4ac4e2fc11d6b3ff4fe7d764aa3012d664c635e2922"
UV_URL = "https://files.pythonhosted.org/packages/38/16/a07593a040fe6403c36f3b0a99b309f295cbfe19a1074dbadb671d5d4ef7/uv-0.9.26-py3-none-manylinux_2_17_x86_64.manylinux2014_x86_64.whl"


def server_fields(body):
    if not isinstance(body, dict):
        raise ValueError("服务器配置无效")
    name = str(body.get("name", "")).strip()
    username = str(body.get("username", "")).strip()
    host = str(body.get("ip", "")).strip()
    if not name or len(name) > 80 or any(ord(c) < 32 for c in name):
        raise ValueError("服务器名称应为 1–80 个字符")
    if not re.fullmatch(r"[a-zA-Z_][a-zA-Z0-9_.-]{0,63}", username):
        raise ValueError("登录账号名称无效")
    try:
        ipaddress.IPv4Address(host)
    except ipaddress.AddressValueError:
        raise ValueError("请输入有效的 IPv4 地址") from None
    return {"name": name, "username": username, "ip": host, "ssh_target": username + "@" + host}


def bundle(destination):
    """Ship code and the reviewed built-in skill, never settings or project data."""
    from ma_custom_tools.skill_bundle import skill_files, SKILL_NAME
    with tarfile.open(destination, "w:gz") as archive:
        for name in ("pyproject.toml", "uv.lock", "backend/pyproject.toml"):
            archive.add(RESOURCES / name, arcname=name, recursive=False)
        for root in ("backend/src", "blender_scripts"):
            for path in sorted((RESOURCES / root).rglob("*")):
                if path.is_file() and path.suffix in {".py", ".sh"} and "__pycache__" not in path.parts:
                    archive.add(path, arcname=str(path.relative_to(RESOURCES)), recursive=False)
        for relative, data in skill_files(RESOURCES / "skills" / SKILL_NAME).items():
            import io
            info = tarfile.TarInfo(f"skills/{SKILL_NAME}/{relative}")
            info.size = len(data)
            archive.addfile(info, io.BytesIO(data))


class Provisioner:
    def __init__(self, runtime):
        self.runtime = runtime
        self.task = None
        self.status = self.runtime.store.get("worker_deployment", {"state": "idle", "message": "填写服务器信息后检查并部署"})
        self.file_lock = None

    def update(self, **values):
        self.status.update(values)
        self.runtime.store.set("worker_deployment", self.status)

    def start(self, body):
        if self.task and not self.task.done():
            raise ValueError("服务器配置正在进行，请等待当前操作完成")
        fields = server_fields(body)
        lock = (STATE / "self-hosted-deploy.lock").open("a")
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            lock.close()
            raise ValueError("已有服务器配置正在进行，请等待完成") from None
        self.file_lock = lock
        self.status = {"state": "running", "message": "正在检查 SSH 登录", "server": fields}
        self.update()
        self.task = asyncio.create_task(self.deploy(fields))
        return self.status

    async def command(self, args, input=None, timeout=1800, progress=False):
        process = await asyncio.create_subprocess_exec(*args, stdin=asyncio.subprocess.PIPE if input else asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
        async def collect():
            if not progress:
                output, _ = await process.communicate(input)
                return output
            lines = []
            async for line in process.stdout:
                text = line.decode(errors="replace").strip()
                lines.append(text)
                lines = lines[-100:]
                if text.startswith(("安装桌面", "安装 Chrome", "下载并校验", "安装 Worker", "配置远程桌面")):
                    self.update(message=text)
            await process.wait()
            return "\n".join(lines).encode()
        try:
            output = await asyncio.wait_for(collect(), timeout)
        except BaseException:
            process.terminate()
            await process.wait()
            raise
        if process.returncode:
            detail = "\n".join(output.decode(errors="replace").splitlines()[-8:])[-1200:]
            raise RuntimeError(detail or "远程安装命令未成功完成")
        return output.decode(errors="replace")

    async def deploy(self, fields):
        ssh = "/usr/bin/ssh" if sys.platform == "darwin" else "ssh"
        scp = "/usr/bin/scp" if sys.platform == "darwin" else "scp"
        options = ["-o", "BatchMode=yes", "-o", "ConnectTimeout=12", "-o", "StrictHostKeyChecking=accept-new"]
        target = fields["ssh_target"]
        identity = hashlib.sha256((target + ":" + key_identity()).encode()).hexdigest()[:20]
        statekey = "worker_provision:" + identity
        cfg = self.runtime.store.get(statekey, {})
        try:
            info = await self.command([ssh, *options, target,
                "sudo -n true && test \"$(dpkg --print-architecture)\" = amd64 && . /etc/os-release && test \"$ID:$VERSION_ID\" = debian:12"], timeout=30)
            self.update(message="SSH 已连接，正在配置方舟执行环境")
            if not cfg.get("environment_id"):
                if cfg.get("creating"):
                    raise RuntimeError("上次 Environment 创建结果不明确；请先检查方舟资源，避免重复创建")
                cfg["creating"] = True
                self.runtime.store.set(statekey, cfg)
                try:
                    env = await self.runtime.ark.request("POST", "environments", json={
                        "name": "ma-studio-" + identity, "config": {"type": "self_hosted"}})
                except ArkHTTPError as exc:
                    if exc.status_code in {400, 401, 403, 404, 422}:
                        cfg["creating"] = False
                        self.runtime.store.set(statekey, cfg)
                    raise
                cfg.update(environment_id=env["id"], creating=False)
                self.runtime.store.set(statekey, cfg)
            if not cfg.get("token"):
                cfg.update(token=secrets.token_urlsafe(48), desktop_password=secrets.token_urlsafe(24))
                self.runtime.store.set(statekey, cfg)
            self.update(message="正在安装桌面、Blender、Chrome 与 Worker，首次安装需要下载依赖")
            cache = STATE / "self-hosted-cache"
            cache.mkdir(exist_ok=True)
            uv = cache / "uv-linux.whl"
            if not uv.exists() or hashlib.sha256(uv.read_bytes()).hexdigest() != UV_SHA256:
                await self.command(["curl", "-4", "-fsSL", "--connect-timeout", "15", "--max-time", "180",
                    "-o", str(uv), UV_URL], timeout=190)
                if hashlib.sha256(uv.read_bytes()).hexdigest() != UV_SHA256:
                    raise RuntimeError("Worker 安装包校验失败")
            with tempfile.TemporaryDirectory(prefix="ma-worker-") as local:
                directory = Path(local)
                bundle(directory / "app.tar.gz")
                payload = directory / "worker.json"
                payload.write_text(json.dumps({k: cfg[k] for k in ("environment_id", "token", "desktop_password")}))
                payload.chmod(0o600)
                stage = (await self.command([ssh, *options, target, "mktemp -d /tmp/ma-studio-deploy.XXXXXXXX"])).strip()
                if not re.fullmatch(r"/tmp/ma-studio-deploy\.[A-Za-z0-9]+", stage):
                    raise RuntimeError("远程临时目录无效")
                try:
                    await self.command([scp, *options, str(directory / "app.tar.gz"), str(payload),
                        str(Path(__file__).parent / "deploy/install.sh"), target + ":" + stage + "/"])
                    await self.command([scp, *options, str(uv), target + ":" + stage + "/uv.whl"])
                    proxy = DownloadProxy()
                    port = await proxy.start()
                    try:
                        await self.command([ssh, *options, "-o", "ExitOnForwardFailure=yes",
                            "-R", f"127.0.0.1:17863:127.0.0.1:{port}", target,
                            "sudo -n env HTTPS_PROXY=http://127.0.0.1:17863 https_proxy=http://127.0.0.1:17863 NO_PROXY= no_proxy= bash "
                            + shlex.quote(stage + "/install.sh") + " " + shlex.quote(stage)], progress=True)
                    finally:
                        await proxy.close()
                finally:
                    await self.command([ssh, *options, target, "rm -f " + " ".join(shlex.quote(stage + "/" + n) for n in ("worker.json", "app.tar.gz", "install.sh", "uv.whl")) + " && rmdir " + shlex.quote(stage)], timeout=30)
            prior_mode = execution.settings(self.runtime.store)["mode"]
            result = execution.save_settings(self.runtime.store, {"mode": prior_mode, "server": {**fields, **cfg}})
            server = self.runtime.store.get("execution_server:" + result["server_id"])
            server.update(username=fields["username"], ip=fields["ip"], desktop_password=cfg["desktop_password"])
            self.runtime.store.set("execution_server:" + server["id"], server)
            self.update(message="正在检查 Worker 与原版 Blender MCP")
            client = self.runtime.remotes.for_project(self.runtime.store, {"execution": {"server_id": server["id"]}})
            for _ in range(20):
                try:
                    health = await client.request("GET", "/health")
                    break
                except Exception:
                    await asyncio.sleep(1)
            else:
                raise RuntimeError("Worker 已安装，但服务连接检查未通过")
            catalog = await client.discover()
            if not all(any(t["name"] == name for t in catalog) for name in ("get_scene_info", "execute_blender_code")):
                raise RuntimeError("Blender MCP 工具检查未通过")
            for _ in range(30):
                health = await client.request("GET", "/health")
                if health.get("last_poll", 0) and time.time() - health["last_poll"] < 10 and not health.get("worker_error"):
                    break
                await asyncio.sleep(1)
            else:
                raise RuntimeError("远程服务已安装，但方舟 Work Queue 尚未连接：" + str(health.get("worker_error") or "等待连接"))
            execution.save_settings(self.runtime.store, {"mode": "self_hosted"})
            self.update(state="ready", message="服务器已就绪，新建会话将使用 " + fields["name"], health=health)
        except Exception as exc:
            message = safe_error(exc)
            for name in ("token", "desktop_password"):
                if cfg.get(name):
                    message = message.replace(cfg[name], "[REDACTED]")
            self.update(state="failed", message=message)
        finally:
            if self.file_lock:
                self.file_lock.close()
                self.file_lock = None
