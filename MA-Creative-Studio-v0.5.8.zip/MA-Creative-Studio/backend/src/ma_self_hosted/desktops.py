"""One KasmVNC desktop per project on the Linux executor.

Enabled with STUDIO_PER_PROJECT_DESKTOP=1 (cloud executor). Each project gets its own X
display and websocket port, so Blender windows and keyboard/mouse input never mix between
projects. All desktops run as the executor's Unix user and share its files: this isolates
the UI and input, it is not a security sandbox.
"""

import asyncio
import contextlib
import logging
import os
import shlex
import signal
import socket
import time
from pathlib import Path

log = logging.getLogger(__name__)
KEY = "project_desktops"
# KasmVNC's vncserver passes -websocketPort/-interface/-geometry through to Xvnc. Override
# with STUDIO_DESKTOP_COMMAND (placeholders {display} {port} {xstartup}) if a host differs.
DEFAULT_COMMAND = ("vncserver :{display} -fg -websocketPort {port} -interface 127.0.0.1 "
                   "-geometry 1600x900 -xstartup {xstartup}")


def enabled():
    return os.environ.get("STUDIO_PER_PROJECT_DESKTOP") == "1"


class DesktopLimit(RuntimeError):
    pass


async def _launch(command, env, log_path):
    with open(log_path, "a") as output:
        return await asyncio.create_subprocess_exec(
            *command, env=env, stdin=asyncio.subprocess.DEVNULL, stdout=output, stderr=output,
            start_new_session=True)


async def _listening(port):
    try:
        _, writer = await asyncio.wait_for(asyncio.open_connection("127.0.0.1", port), 0.5)
    except (OSError, TimeoutError):
        return False
    writer.close()
    with contextlib.suppress(OSError):
        await writer.wait_closed()
    return True


def _port_free(port):
    try:
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", port))
        return True
    except OSError:
        return False


def _pid_alive(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


class ProjectDesktops:
    def __init__(self, store, *, limit, log_dir, idle_seconds=None, display_start=None,
                 port_start=None, x11_dir="/tmp/.X11-unix", lock_dir="/tmp",
                 launch=_launch, listening=_listening, port_free=_port_free):
        self.store = store
        self.limit = max(1, int(limit))
        self.log_dir = Path(log_dir)
        self.idle_seconds = idle_seconds if idle_seconds is not None else int(os.environ.get("STUDIO_DESKTOP_IDLE", "1800"))
        self.display_start = display_start or int(os.environ.get("STUDIO_DESKTOP_DISPLAY_START", "20"))
        self.port_start = port_start or int(os.environ.get("STUDIO_DESKTOP_PORT_START", "39000"))
        self.x11_dir, self.lock_dir = Path(x11_dir), Path(lock_dir)
        self.launch, self.listening, self.port_free = launch, listening, port_free
        self.processes = {}
        self.last_used = {}
        self.locks = {}
        self.global_lock = asyncio.Lock()
        # Set by the executor: busy(pid) -> bool and async before_stop(pid) (saves Blender).
        self.busy = lambda pid: False
        self.before_stop = None

    # Allocation -------------------------------------------------------------

    def records(self):
        return self.store.get(KEY, {})

    def _display_free(self, number, used):
        return (number not in used and not (self.x11_dir / f"X{number}").exists()
                and not (self.lock_dir / f".X{number}-lock").exists())

    def _allocate(self, pid, *, new_display=False, new_port=False):
        records = self.records()
        record = dict(records.get(pid) or {})
        others = [r for k, r in records.items() if k != pid]
        if new_display or "display" not in record:
            used = {r["display"] for r in others}
            record["display"] = next(n for n in range(self.display_start, self.display_start + 1000)
                                     if self._display_free(n, used))
        if new_port or "port" not in record:
            used = {r["port"] for r in others}
            for port in range(self.port_start, self.port_start + 1000):
                if port not in used and self.port_free(port):
                    record["port"] = port
                    break
            else:
                raise RuntimeError("没有可用的桌面端口")
        records[pid] = record
        self.store.set(KEY, records)
        return record

    def _clear_stale_lock(self, number):
        lock = self.lock_dir / f".X{number}-lock"
        try:
            owner = int(lock.read_text().strip())
        except (OSError, ValueError):
            return
        if not _pid_alive(owner):
            for path in (lock, self.x11_dir / f"X{number}"):
                with contextlib.suppress(OSError):
                    path.unlink()

    # Lifecycle --------------------------------------------------------------

    def running(self, pid):
        process = self.processes.get(pid)
        return bool(process and process.returncode is None)

    def display(self, pid):
        record = self.records().get(pid)
        return f":{record['display']}" if record and self.running(pid) else None

    def touch(self, pid):
        if self.running(pid):
            self.last_used[pid] = time.monotonic()

    async def ensure(self, pid):
        """Return {display, port} of this project's running desktop, starting it if needed."""
        async with self.locks.setdefault(pid, asyncio.Lock()):
            self.last_used[pid] = time.monotonic()
            if self.running(pid):
                record = self.records()[pid]
                await self._wait_ready(pid, record, timeout=30)
                return record
            async with self.global_lock:
                await self._make_room(pid)
                record = self._allocate(pid)
                self._clear_stale_lock(record["display"])
                if not self._display_free(record["display"], set()):
                    record = self._allocate(pid, new_display=True)
                if not self.port_free(record["port"]):
                    record = self._allocate(pid, new_port=True)
                xstartup = os.environ.get("STUDIO_DESKTOP_XSTARTUP", str(Path.home() / ".vnc/xstartup-project"))
                template = os.environ.get("STUDIO_DESKTOP_COMMAND", DEFAULT_COMMAND)
                command = [part.format(display=record["display"], port=record["port"], xstartup=xstartup)
                           for part in shlex.split(template)]
                env = {k: os.environ[k] for k in ("PATH", "HOME", "USER", "LANG", "TMPDIR", "XDG_RUNTIME_DIR") if k in os.environ}
                # All desktops share one Unix user. Chrome would hand a launch on this display to an
                # instance already running on another one (its profile singleton), so each project's
                # desktop gets its own Chrome profile and instance.
                profiles = Path(os.environ.get("STUDIO_DESKTOP_PROFILES", str(Path.home() / ".config/ma-studio-desktops")))
                (profiles / pid).mkdir(mode=0o700, parents=True, exist_ok=True)
                env["CHROME_CONFIG_HOME"] = str(profiles / pid)
                self.log_dir.mkdir(parents=True, exist_ok=True)
                self.processes[pid] = await self.launch(command, env, self.log_dir / f"desktop-{pid}.log")
            await self._wait_ready(pid, record, timeout=30)
            log.info("Desktop for %s on :%s port %s", pid, record["display"], record["port"])
            return record

    async def _wait_ready(self, pid, record, timeout):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if not self.running(pid):
                self.processes.pop(pid, None)
                raise RuntimeError("项目桌面启动失败，请查看执行器日志 " + f"logs/desktop-{pid}.log")
            if await self.listening(record["port"]):
                return
            await asyncio.sleep(0.2)
        await self.stop(pid)
        raise RuntimeError("项目桌面启动超时")

    async def _make_room(self, pid):
        active = [k for k in list(self.processes) if k != pid and self.running(k)]
        if len(active) < self.limit:
            return
        # Least recently used desktop that has no running work; saved before it closes.
        for candidate in sorted(active, key=lambda k: self.last_used.get(k, 0)):
            if not self.busy(candidate) and time.monotonic() - self.last_used.get(candidate, 0) > 120:
                if await self._save_and_stop(candidate):
                    return
        raise DesktopLimit(f"同时打开的项目桌面已达上限（{self.limit} 个），请稍后重试或关闭其他项目的桌面。")

    async def _save_and_stop(self, pid):
        if self.before_stop:
            try:
                await self.before_stop(pid)
            except Exception as exc:  # Never discard unsaved work to reclaim a desktop.
                log.warning("Desktop %s kept: saving before stop failed: %s", pid, exc)
                return False
        await self.stop(pid)
        return True

    async def stop(self, pid):
        process = self.processes.pop(pid, None)
        self.last_used.pop(pid, None)
        if process and process.returncode is None:
            with contextlib.suppress(ProcessLookupError):
                os.killpg(process.pid, signal.SIGTERM)
            try:
                await asyncio.wait_for(process.wait(), 8)
            except TimeoutError:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(process.pid, signal.SIGKILL)
                await process.wait()
        record = self.records().get(pid)
        if record:
            self._clear_stale_lock(record["display"])

    async def reap(self):
        """Close desktops idle past the timeout. Busy projects and viewers keep theirs."""
        now = time.monotonic()
        for pid in [k for k in list(self.processes) if self.running(k)]:
            if not self.busy(pid) and now - self.last_used.get(pid, now) > self.idle_seconds:
                async with self.locks.setdefault(pid, asyncio.Lock()):
                    if await self._save_and_stop(pid):
                        log.info("Desktop for %s closed after idle timeout", pid)
        for pid in [k for k, p in self.processes.items() if p.returncode is not None]:
            self.processes.pop(pid, None)

    async def run_reaper(self, interval=60):
        while True:
            await asyncio.sleep(interval)
            try:
                await self.reap()
            except Exception:
                log.exception("Desktop reaper failed")

    async def close(self):
        await asyncio.gather(*(self.stop(pid) for pid in list(self.processes)), return_exceptions=True)
