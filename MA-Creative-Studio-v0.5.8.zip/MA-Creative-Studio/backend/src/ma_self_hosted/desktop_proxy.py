"""Serve Kasm through the authenticated local application, including WebSockets."""

import asyncio
import contextlib
import logging
import time
from urllib.parse import quote, urlencode

import httpx
from fastapi import APIRouter, HTTPException, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import RedirectResponse

from . import execution
from .remote import DesktopStopped

log = logging.getLogger(__name__)
# RFB client messages that mean a person is using the desktop: key, pointer, clipboard.
# Frame update requests keep flowing from any open tab and do not count.
INPUT_MESSAGES = {4, 5, 6}


def desktop_url(project_id, root_path=""):
    prefix = root_path.rstrip("/") + "/api/self-hosted/desktop/" + quote(project_id, safe="") + "/"
    return prefix + "index.html?" + urlencode({"autoconnect": "1", "path": prefix.lstrip("/") + "websockify",
        "kasmvnc_mode_preference": "image", "resize": "scale", "enable_threading": "0",
        "reconnect": "1", "reconnect_delay": "3000"})


def valid_path(path):
    return not (path.startswith("/") or "\\" in path or any(ord(c) < 32 for c in path)
                or any(part in {".", ".."} for part in path.split("/")))


def authorized_socket(socket):
    # HTTP middleware does not run for WebSockets. Check the browser origin
    # before opening the SSH connection; CloudAccess handles cloud login.
    host = socket.headers.get("host", "")
    scheme = "https" if socket.url.scheme == "wss" else "http"
    origin = f"{scheme}://{host}"
    cloud_origin = getattr(socket.app.state, "cloud_origin", None)
    if cloud_origin:
        from ma_cloud.access import same_request_origin
        # The browser may use the server's domain or IP; match its actual URL.
        return same_request_origin(socket.headers, socket.url.scheme, require_origin=True)
    if socket.url.hostname not in {"127.0.0.1", "localhost", "testserver"}:
        return False
    return socket.headers.get("origin") == origin


def router(runtime, transport=None):
    api = APIRouter()

    async def remote(project_id, *, start, activity):
        """The server client and this project's desktop port (its own on the cloud executor)."""
        p = runtime.project(project_id)
        if not execution.is_remote(p):
            raise HTTPException(400, "此会话使用本机")
        client = runtime.remote(p)
        await client.connect()
        try:
            port = await client.desktop_port_for(p, start=start, activity=activity)
        except DesktopStopped as exc:
            raise HTTPException(409, str(exc)) from None
        except RuntimeError as exc:
            raise HTTPException(503, str(exc)) from None
        return client, port, p

    @api.api_route("/desktop/{project_id}/{path:path}", methods=["GET", "HEAD"])
    async def resource(project_id: str, path: str, request: Request):
        if not valid_path(path):
            raise HTTPException(400, "Invalid desktop path")
        if path in {"", "index.html", "vnc.html"} and "kasmvnc_mode_preference" not in request.query_params:
            return RedirectResponse(desktop_url(project_id, request.scope.get("root_path", "")), headers={"Cache-Control": "no-store"})
        # Loading the desktop page is an explicit open; its assets only attach.
        page = path in {"", "index.html", "vnc.html"}
        client, port, _ = await remote(project_id, start=page, activity=page)
        headers = {k: request.headers[k] for k in ("range", "if-none-match", "if-modified-since") if k in request.headers}
        async with httpx.AsyncClient(auth=("elsa", client.server["desktop_password"]),
                timeout=30, trust_env=False, transport=transport) as upstream:
            try:
                result = await upstream.request(request.method,
                    f"http://127.0.0.1:{port}/" + quote(path or "index.html", safe="/"),
                    params=request.query_params, headers=headers)
            except httpx.HTTPError:
                raise HTTPException(502, "远程桌面暂时无法连接，请稍后重试") from None
        if result.status_code in {401, 403}:
            raise HTTPException(502, "远程桌面认证失败，请在执行环境设置中重新检查服务器")
        # Kasm's standalone cross-origin isolation headers conflict with an
        # embedded view. Assets now share the app origin; credentials stay here.
        allowed = {"content-type", "content-range", "accept-ranges", "etag", "last-modified"}
        outgoing = {k: v for k, v in result.headers.items() if k in allowed}
        outgoing.update({"Cache-Control": "no-store", "Content-Security-Policy": "frame-ancestors 'self'",
                         "Cross-Origin-Resource-Policy": "same-origin", "Referrer-Policy": "no-referrer"})
        return Response(result.content, status_code=result.status_code, headers=outgoing)

    @api.websocket("/desktop/{project_id}/websockify")
    async def socket_proxy(socket: WebSocket, project_id: str):
        if not authorized_socket(socket):
            await socket.close(code=1008)
            return
        # Imported lazily: a remote executor itself does not serve desktop pages.
        from websockets.asyncio.client import connect
        from websockets.exceptions import WebSocketException
        tasks = []
        started = time.monotonic()
        try:
            # Reconnects from an open tab attach only; they never restart a closed desktop.
            client, port, p = await remote(project_id, start=False, activity=False)
            used = asyncio.Event()
            authorization = httpx.BasicAuth("elsa", client.server["desktop_password"])
            auth_request = next(authorization.auth_flow(httpx.Request("GET", "http://localhost")))
            async with connect(f"ws://127.0.0.1:{port}/websockify",
                    origin=f"http://127.0.0.1:{port}",
                    additional_headers={"Authorization": auth_request.headers["authorization"]},
                    subprotocols=socket.scope.get("subprotocols") or None,
                    # KasmVNC doesn't return matching Pong payloads. The default
                    # 20s interval + 20s timeout disconnected healthy desktops
                    # every 40s. SSH already monitors this loopback transport.
                    ping_interval=None,
                    compression=None, proxy=None, max_size=None, open_timeout=15, close_timeout=3) as upstream:
                await socket.accept(subprotocol=upstream.subprotocol)

                async def to_server():
                    while True:
                        message = await socket.receive()
                        if message["type"] == "websocket.disconnect":
                            return f"browser closed ({message.get('code', 1000)})"
                        data = message.get("bytes")
                        if data and data[0] in INPUT_MESSAGES:
                            used.set()
                        await upstream.send(data if data is not None else message["text"])

                async def to_browser():
                    async for message in upstream:
                        if isinstance(message, bytes):
                            await socket.send_bytes(message)
                        else:
                            await socket.send_text(message)
                    return "desktop closed"

                async def keep_alive():
                    # Only real input postpones the executor's idle timeout; an untouched
                    # tab lets the desktop close (after saving) like any idle project.
                    while True:
                        await asyncio.sleep(60)
                        if not used.is_set():
                            continue
                        used.clear()
                        try:
                            await client.desktop_port_for(p, start=False, activity=True)
                        except DesktopStopped:
                            return
                        except Exception:
                            pass

                tasks = [asyncio.create_task(to_server()), asyncio.create_task(to_browser())]
                keeper = asyncio.create_task(keep_alive())
                try:
                    finished, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                finally:
                    keeper.cancel()
                for task in finished:
                    reason = task.result()
                    log.info("Desktop %s disconnected after %.1fs: %s", project_id, time.monotonic() - started, reason)
        except (HTTPException, OSError, TimeoutError, WebSocketException, WebSocketDisconnect) as exc:
            log.info("Desktop %s disconnected after %.1fs: %s", project_id, time.monotonic() - started, type(exc).__name__)
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            with contextlib.suppress(RuntimeError, WebSocketDisconnect):
                await socket.close(code=1000 if tasks else 1011)

    return api
