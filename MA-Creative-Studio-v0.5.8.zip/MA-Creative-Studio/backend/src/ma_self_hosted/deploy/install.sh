#!/usr/bin/env bash
# Run as root on a dedicated Debian 12 amd64 worker. Inputs arrive as files,
# never interpolated shell code; no business credentials are included.
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
test "$(dpkg --print-architecture)" = amd64
. /etc/os-release
test "$ID:$VERSION_ID" = debian:12
base=/opt/ma-creative-studio
stage=$1
install -d -m 755 "$base" "$base/cache"
printf '%s\n' '安装桌面和渲染依赖'
apt-get update -qq
apt-get install -y --no-install-recommends xfce4 xfce4-terminal dbus-x11 xauth x11-utils xdotool \
  libgl1-mesa-dri libegl1 libxkbcommon0 libsm6 libxi6 libxrender1 libxxf86vm1 libxfixes3 \
  libxrandr2 libgomp1 libxcursor1 libxinerama1 ffmpeg curl ca-certificates xz-utils unzip \
  python3-venv python3-pip ssl-cert lsof
cd "$base/cache"
if ! dpkg-query -W kasmvncserver >/dev/null 2>&1; then
  curl -fL --retry 3 -o kasm.deb https://github.com/kasmtech/KasmVNC/releases/download/v1.5.0/kasmvncserver_bookworm_1.5.0_amd64.deb
  printf '%s\n' '770fd3df51510beecc89666879d82faf411276e68c6e11df612f736b891b5f71  kasm.deb' | sha256sum -c -
  apt-get install -y ./kasm.deb
fi
if ! command -v google-chrome >/dev/null; then
  printf '%s\n' '安装 Chrome'
  curl -fL --retry 3 -o chrome.deb https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
  apt-get install -y ./chrome.deb
fi
if ! test -x "$base/blender-5.2.1-linux-x64/blender"; then
  printf '%s\n' '下载并校验 Blender 5.2.1'
  curl -fL --retry 3 -o blender-5.2.1-linux-x64.tar.xz https://download.blender.org/release/Blender5.2/blender-5.2.1-linux-x64.tar.xz
  curl -fsSL -o blender.sha256 https://download.blender.org/release/Blender5.2/blender-5.2.1.sha256
  awk '/blender-5.2.1-linux-x64.tar.xz$/ {print}' blender.sha256 | sha256sum -c -
  tar -xJf blender-5.2.1-linux-x64.tar.xz -C "$base"
fi
printf '%s\n' '安装 Worker 与 Blender MCP'
if ! test -x "$base/bootstrap/bin/uv"; then
  python3 -m venv "$base/bootstrap"
  cp "$stage/uv.whl" uv-0.9.26-py3-none-manylinux_2_17_x86_64.manylinux2014_x86_64.whl
  printf '%s\n' 'b7e89798bd3df7dcc4b2b4ac4e2fc11d6b3ff4fe7d764aa3012d664c635e2922  uv-0.9.26-py3-none-manylinux_2_17_x86_64.manylinux2014_x86_64.whl' | sha256sum -c -
  "$base/bootstrap/bin/pip" install --no-index ./uv-0.9.26-py3-none-manylinux_2_17_x86_64.manylinux2014_x86_64.whl
fi
install -d "$base/app"
tar -xzf "$stage/app.tar.gz" -C "$base/app"
export UV_PYTHON_INSTALL_DIR="$base/python"
"$base/bootstrap/bin/uv" python install 3.12
cd "$base/app"
"$base/bootstrap/bin/uv" sync --python 3.12 --frozen --all-packages --no-dev
if ! getent passwd elsa >/dev/null; then
  useradd --create-home --shell /bin/bash elsa
fi
usermod -aG ssl-cert,video elsa
install -d -m 700 -o elsa -g elsa /home/elsa/.vnc /home/elsa/ma-creative-studio
install -d -m 755 -o elsa -g elsa /home/elsa/ma-creative-studio/logs
install -m 600 -o elsa -g elsa "$stage/worker.json" /home/elsa/ma-creative-studio/worker.json
install -d "$base/addons/addons"
"$base/app/.venv/bin/python" - "$base/addons/addons/blender_mcp.py" <<'PY'
import blender_mcp, pathlib, shutil, sys
shutil.copyfile(pathlib.Path(blender_mcp.__file__).parent / 'bundled/addon.py', sys.argv[1])
PY
python3 - "$stage/worker.json" <<'PY'
import json, subprocess, sys
password = json.load(open(sys.argv[1]))['desktop_password']
subprocess.run(['sudo', '-u', 'elsa', '-H', 'vncpasswd', '-u', 'elsa', '-w', '-o'],
    input=password + '\n' + password + '\n', text=True, check=True, stdout=subprocess.DEVNULL)
PY
cat > /home/elsa/.vnc/kasmvnc.yaml <<'YAML'
desktop:
  resolution:
    width: 1600
    height: 900
network:
  interface: 127.0.0.1
  websocket_port: 8444
  ssl:
    require_ssl: false
user_session:
  idle_timeout: never
command_line:
  prompt: false
YAML
cat > /home/elsa/.vnc/xstartup <<'SCRIPT'
#!/bin/sh
unset SESSION_MANAGER
unset DBUS_SESSION_BUS_ADDRESS
exec dbus-launch --exit-with-session startxfce4
SCRIPT
chmod 700 /home/elsa/.vnc/xstartup
chown -R elsa:elsa /home/elsa/.vnc
python3 "$base/app/backend/src/ma_self_hosted/deploy/desktop_launchers.py"
cat > /etc/systemd/system/ma-studio-desktop.service <<'UNIT'
[Unit]
Description=MA 导演 Agent desktop
After=network.target
[Service]
Type=simple
User=elsa
Group=elsa
Environment=HOME=/home/elsa
WorkingDirectory=/home/elsa
ExecStart=/usr/bin/vncserver :1 -fg
Restart=on-failure
RestartSec=5
[Install]
WantedBy=multi-user.target
UNIT
cat > /etc/systemd/system/ma-studio-worker.service <<'UNIT'
[Unit]
Description=MA 导演 Agent self-hosted worker
After=network.target ma-studio-desktop.service
Requires=ma-studio-desktop.service
[Service]
Type=simple
User=elsa
Group=elsa
Environment=HOME=/home/elsa
Environment=DISPLAY=:1
Environment=STUDIO_HOME=/home/elsa/ma-creative-studio
Environment=STUDIO_RESOURCE_ROOT=/opt/ma-creative-studio/app
Environment=STUDIO_WORKER_CONFIG=/home/elsa/ma-creative-studio/worker.json
Environment=STUDIO_BLENDER_SCRIPTS=/opt/ma-creative-studio/addons
Environment=BLENDER_BIN=/opt/ma-creative-studio/blender-5.2.1-linux-x64/blender
Environment=LIBGL_ALWAYS_SOFTWARE=1
Environment=LP_NUM_THREADS=8
Environment=OMP_NUM_THREADS=8
WorkingDirectory=/home/elsa/ma-creative-studio
ExecStart=/opt/ma-creative-studio/app/.venv/bin/python -m ma_self_hosted.server
Restart=on-failure
RestartSec=5
UMask=0077
NoNewPrivileges=true
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now ma-studio-desktop.service
for attempt in $(seq 1 30); do
  if pgrep -u elsa -x xfce4-panel >/dev/null; then
    python3 "$base/app/backend/src/ma_self_hosted/deploy/desktop_launchers.py"
    break
  fi
  sleep 1
done
systemctl enable ma-studio-worker.service
systemctl restart ma-studio-worker.service
printf '%s\n' 'MA_STUDIO_INSTALL_COMPLETE'
