"""Install recognizable Chrome and Blender launchers for the elsa desktop."""

from pathlib import Path
import os
import pwd
import re
import subprocess


def main():
    account = pwd.getpwnam("elsa")
    home = Path(account.pw_dir)
    desktop = home / "Desktop"
    desktop.mkdir(exist_ok=True)
    os.chown(desktop, account.pw_uid, account.pw_gid)

    def write(path, content, mode=0o644):
        path.write_text(content)
        path.chmod(mode)
        os.chown(path, account.pw_uid, account.pw_gid)

    chrome = Path("/usr/share/applications/google-chrome.desktop").read_text()
    write(desktop / "google-chrome.desktop", chrome, 0o755)
    # XFCE's default browser launcher uses a generic globe even when Chrome is
    # selected as the browser. Replace only that launcher, preserving panel order.
    for path in (home / ".config/xfce4/panel").glob("launcher-*/*.desktop"):
        old = path.read_text()
        if "exo-open --launch WebBrowser" in old or "Icon=org.xfce.webbrowser" in old:
            write(path, chrome.replace("[Desktop Entry]\n", "[Desktop Entry]\nX-XFCE-Source=file:///usr/share/applications/google-chrome.desktop\n", 1))

    base = Path("/opt/ma-creative-studio")
    blender = base / "blender-5.2.1-linux-x64"
    entry = ("[Desktop Entry]\nType=Application\nName=Blender\nComment=3D creation suite\n"
        f"Exec=env BLENDER_USER_SCRIPTS={base}/addons LIBGL_ALWAYS_SOFTWARE=1 LP_NUM_THREADS=8 {blender}/blender %f\n"
        f"Icon={blender}/blender.svg\nTerminal=false\nCategories=Graphics;3DGraphics;\n"
        "MimeType=application/x-blender;\n")
    write(desktop / "blender.desktop", entry, 0o755)
    applications = home / ".local/share/applications"
    for directory in (home / ".local", home / ".local/share", applications):
        if not directory.exists():
            directory.mkdir()
            os.chown(directory, account.pw_uid, account.pw_gid)
    write(applications / "ma-studio-blender.desktop", entry)
    place_in_panel(home, account, entry, write)
    print("Chrome and Blender desktop launchers installed")


def place_in_panel(home, account, blender, write):
    """Use XFCE's live settings API so a running panel updates without restarting."""
    found = subprocess.run(["pgrep", "-u", str(account.pw_uid), "-x", "xfce4-panel"], capture_output=True, text=True)
    if not found.stdout.strip():
        return
    pid = int(found.stdout.split()[0])
    values = Path(f"/proc/{pid}/environ").read_bytes().split(b"\0")
    bus = next((v.split(b"=", 1)[1].decode() for v in values if v.startswith(b"DBUS_SESSION_BUS_ADDRESS=")), None)
    if not bus:
        return
    command = ["sudo", "-u", account.pw_name, "-H", "env", "DISPLAY=:1", "DBUS_SESSION_BUS_ADDRESS=" + bus,
               "xfconf-query", "-c", "xfce4-panel"]

    def query(*args):
        return subprocess.check_output([*command, *args], text=True).strip()

    properties = query("-l").splitlines()
    chrome_id = None
    blender_id = None
    for path in (home / ".config/xfce4/panel").glob("launcher-*/*.desktop"):
        content = path.read_text()
        if "Icon=google-chrome" in content:
            chrome_id = int(path.parent.name.removeprefix("launcher-"))
        if "Name=Blender\n" in content:
            blender_id = int(path.parent.name.removeprefix("launcher-"))
    if chrome_id is None:
        return
    for panel in (p for p in properties if re.fullmatch(r"/panels/panel-\d+/plugin-ids", p)):
        order = [int(n) for n in query("-p", panel).splitlines() if n.isdigit()]
        if chrome_id not in order:
            continue
        if blender_id is None:
            blender_id = max(int(m.group(1)) for p in properties
                if (m := re.match(r"/plugins/plugin-(\d+)", p))) + 1
            directory = home / f".config/xfce4/panel/launcher-{blender_id}"
            directory.mkdir(exist_ok=True)
            os.chown(directory, account.pw_uid, account.pw_gid)
            write(directory / "blender.desktop", blender)
            query("-p", f"/plugins/plugin-{blender_id}", "-n", "-t", "string", "-s", "launcher")
            query("-p", f"/plugins/plugin-{blender_id}/items", "-n", "-a", "-t", "string", "-s", "blender.desktop")
        else:
            write(home / f".config/xfce4/panel/launcher-{blender_id}/blender.desktop", blender)
        order = [item for item in order if item != blender_id]
        order.insert(order.index(chrome_id) + 1, blender_id)
        args = ["-p", panel, "-a"]
        for item in order:
            args += ["-t", "int", "-s", str(item)]
        query(*args)
        print("Panel order: Chrome → Blender")
        break


if __name__ == "__main__":
    main()
