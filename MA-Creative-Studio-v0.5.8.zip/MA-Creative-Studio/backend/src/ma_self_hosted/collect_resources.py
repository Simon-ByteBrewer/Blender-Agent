"""Read-only Linux resource sampler; streamed over SSH using Python's stdlib."""

import csv
import io
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

MIB = 1024 ** 2


def cpu_ticks():
    # guest time is already included in user/nice; don't count it twice.
    values = [int(v) for v in Path("/proc/stat").read_text().splitlines()[0].split()[1:9]]
    return sum(values), values[3] + values[4]


def cpu_percent(previous, current):
    total, idle = current[0] - previous[0], current[1] - previous[1]
    return round(max(0, min(100, 100 * (1 - idle / total))), 1) if total > 0 else None


def memory_info(text):
    fields = {line.split(":", 1)[0]: int(line.split()[1]) * 1024
              for line in text.splitlines() if ":" in line and len(line.split()) >= 2}
    total = fields["MemTotal"]
    available = min(total, max(0, fields.get("MemAvailable", fields.get("MemFree", 0))))
    used = max(0, total - available)
    return {"total_bytes": total, "used_bytes": used, "available_bytes": available,
            "usage_percent": round(100 * used / total, 1) if total else 0}


def number(value):
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (ValueError, TypeError):
        return None


def nvidia_info(text):
    devices = []
    for row in csv.reader(io.StringIO(text), skipinitialspace=True):
        if len(row) != 5:
            continue
        index, name, usage, total, used = row
        total, used = number(total), number(used)
        devices.append({"id": "nvidia-" + index.strip(), "name": name.strip(),
            "usage_percent": number(usage), "memory_total_bytes": int(total * MIB) if total is not None else None,
            "memory_used_bytes": int(used * MIB) if used is not None else None})
    return devices


def gpu_info(drm_root=Path("/sys/class/drm")):
    devices = []
    if shutil.which("nvidia-smi"):
        try:
            result = subprocess.run(["nvidia-smi", "--query-gpu=index,name,utilization.gpu,memory.total,memory.used",
                "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=2)
            if result.returncode == 0:
                devices = nvidia_info(result.stdout)
        except (OSError, subprocess.TimeoutExpired):
            pass
    vendors = {"0x10de": "NVIDIA GPU", "0x1002": "AMD GPU", "0x8086": "Intel GPU"}
    nvidia_detected = bool(devices)
    for card in sorted(drm_root.glob("card*")):
        if not re.fullmatch(r"card\d+", card.name):
            continue
        device = card / "device"
        try:
            vendor = (device / "vendor").read_text().strip()
        except OSError:
            continue
        if vendor not in vendors or (vendor == "0x10de" and nvidia_detected):
            # Virtual display adapters aren't usable rendering GPUs.
            continue
        def read(name):
            try:
                return number((device / name).read_text().strip())
            except OSError:
                return None
        devices.append({"id": card.name, "name": vendors[vendor], "usage_percent": read("gpu_busy_percent"),
            "memory_total_bytes": read("mem_info_vram_total"), "memory_used_bytes": read("mem_info_vram_used")})
    return devices


class Sampler:
    def __init__(self, workspace):
        self.workspace = workspace
        self.previous = cpu_ticks()
        self.logical_cpus = os.cpu_count() or 1
        self.cpu_model = next((line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines()
                               if line.startswith("model name")), "CPU")

    def sample(self):
        current = cpu_ticks()
        cpu = {"usage_percent": cpu_percent(self.previous, current),
               "logical_cpus": self.logical_cpus, "model": self.cpu_model}
        self.previous = current
        disk = shutil.disk_usage(self.workspace)
        return {"sampled_at": time.time(), "cpu": cpu,
                "memory": memory_info(Path("/proc/meminfo").read_text()),
                "disk": {"total_bytes": disk.total, "used_bytes": disk.used, "available_bytes": disk.free,
                         "usage_percent": round(100 * disk.used / disk.total, 1) if disk.total else 0},
                "gpus": gpu_info()}


def main():
    sampler = Sampler(sys.argv[1])
    time.sleep(.3)
    try:
        while True:
            print(json.dumps(sampler.sample()), flush=True)
            time.sleep(30)
    except BrokenPipeError:
        pass


if __name__ == "__main__":
    main()
