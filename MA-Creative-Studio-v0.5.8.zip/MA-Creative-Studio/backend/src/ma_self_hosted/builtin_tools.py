"""Async/MCP adapter over the pinned official Ark self-hosted tool set.

The SDK owns execution of bash/write/edit/glob/grep, path checks and shell
cancellation. The sole tool override adapts read's byte/character offsets to
MA's line-based file_path/offset/limit requests. A workdir is not an OS sandbox.
"""

import asyncio
from collections.abc import Mapping
import contextlib
import json
import math
from pathlib import Path
import sys
import threading

from arkruntime.selfhosted.tools import (
    FunctionTool, ToolContext, _safe_path, default_toolset, error_result, text_result,
)


BUILTIN_TOOLS = frozenset({"read", "write", "edit", "glob", "grep", "bash"})
MAX_READ_BYTES = 8 * 1024 * 1024


def _read_lines(args, context):
    """Keep official path validation; only adapt MA's line-based read contract."""
    path = Path(_safe_path(context, str(args.get("path") or args.get("file") or "")))
    if not path.is_file() or path.stat().st_size > MAX_READ_BYTES:
        return error_result("read requires a regular text file no larger than 8 MiB")
    offset, limit = int(args.get("offset", 1)), int(args.get("limit", 2000))
    if offset < 1 or limit < 1:
        return error_result("offset is a 1-based line number; limit must be a positive line count")
    limit = min(limit, 10000)
    output, size = [], 0
    with path.open(encoding="utf-8", errors="replace") as stream:
        for number, line in enumerate(stream, 1):
            if context.cancel_event.is_set():
                return error_result("tool execution canceled")
            if "\0" in line:
                return error_result("binary files cannot be read as text; use an artifact or Blender tool")
            if number < offset:
                continue
            if number >= offset + limit or size >= 100000:
                output.append(f"… more content; continue with offset={number}.")
                break
            output.append(f"{number}\t{line.rstrip(chr(10)).rstrip(chr(13))}")
            size += len(output[-1].encode("utf-8"))
    return text_result("\n".join(output) or "(empty file or offset past end of file)")


class BuiltinTools:
    def __init__(self, workdir, *, timeout_seconds=120, max_output_bytes=100000):
        self.workdir = Path(workdir).resolve()
        self.workdir.mkdir(parents=True, exist_ok=True)
        self.timeout_seconds = float(timeout_seconds)
        self.max_output_bytes = int(max_output_bytes)
        if not math.isfinite(self.timeout_seconds) or self.timeout_seconds <= 0 or self.max_output_bytes < 1:
            raise ValueError("timeout and output limit must be positive and finite")
        self.tools = default_toolset()
        self.tools.add(FunctionTool("read", _read_lines))

    def _wire(self, result):
        blocks = [block.to_dict() for block in result.content]
        remaining = self.max_output_bytes
        for block in blocks:
            if block.get("type") != "text":
                continue
            data = block.get("text", "").encode("utf-8", errors="replace")
            if len(data) > remaining:
                marker = b"\n... truncated ..."
                data = data[:max(0, remaining - len(marker))] + marker[:remaining]
                block["text"] = data.decode("utf-8", errors="ignore")
            remaining = max(0, remaining - len(data))
        return {"content": blocks, "isError": result.is_error}

    async def dispatch(self, name, args):
        if not self.tools.has(name):
            return self._wire(error_result(
                f"Unsupported self-hosted tool: {name}. Available: {', '.join(sorted(BUILTIN_TOOLS))}. "
                "Use the registered blender_project, previz_render or Blender custom tools for Blender operations and renders."))
        task = None
        cancel = threading.Event()
        try:
            if isinstance(args, str):
                args = json.loads(args)
            if not isinstance(args, Mapping):
                raise ValueError("tool input must be an object")
            args = dict(args)
            if args.get("file_path"):
                args["path"] = args.pop("file_path")
            elif not args.get("path") and args.get("file"):
                args["path"] = args["file"]
            timeout = self.timeout_seconds
            if name == "bash" and args.get("timeout") is not None:
                milliseconds = float(args["timeout"])
                if not math.isfinite(milliseconds) or milliseconds <= 0:
                    raise ValueError("bash timeout must be positive milliseconds")
                timeout = min(timeout, milliseconds / 1000)
            if name == "edit" and args.get("replace_all"):
                raise ValueError("the official SDK edit replaces one occurrence; use individual edits or a reviewed bash command")
            if name == "grep" and any(key in args for key in (
                    "glob", "include", "head_limit", "output_mode", "ignore_case", "literal", "-i")):
                raise ValueError("the official SDK grep supports pattern and path; narrow path or use regex syntax for other filters")
            context = ToolContext(workdir=str(self.workdir), unrestricted_paths=False,
                tool_timeout_seconds=timeout, cancel_event=cancel, env={
                    "PATH": f"{Path(sys.executable).parent}:/usr/local/bin:/usr/bin:/bin",
                    "HOME": str(self.workdir), "TMPDIR": str(self.workdir),
                    "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
                })
            # Validate a supplied search root too: SDK glob only accepts pattern.
            if name == "glob" and args.get("path"):
                root = Path(_safe_path(context, str(args["path"])))
                args["pattern"] = str(root.relative_to(self.workdir) / str(args.get("pattern") or ""))
            if name == "glob":
                _safe_path(context, str(args.get("pattern") or ""))
            task = asyncio.create_task(asyncio.to_thread(self.tools.execute, name, args, context))
            result = await asyncio.wait_for(asyncio.shield(task), timeout + 1.5)
            return self._wire(result)
        except asyncio.CancelledError:
            cancel.set()
            if task is not None:
                with contextlib.suppress(Exception, asyncio.CancelledError):
                    await asyncio.wait_for(asyncio.shield(task), 2)
            raise
        except Exception as exc:
            cancel.set()
            if task is not None:
                with contextlib.suppress(Exception):
                    await asyncio.wait_for(asyncio.shield(task), 2)
            message = "tool execution timed out" if isinstance(exc, TimeoutError) else str(exc)
            return self._wire(error_result(f"{name} failed: {message}"))
