"""Concurrent MA Work consumers using the platform Poll/Ack/Heartbeat protocol.

Each Session retains a durable tool-result journal and a dedicated Blender
process/workspace. This provides project isolation, not a hostile-code sandbox.
"""

import asyncio
import contextlib
import logging
import time
import uuid

from ma_custom_tools.ma import MARunner
from ma_custom_tools.skills import guidance
from .gateway import REMOTE_TOOLS

log = logging.getLogger(__name__)


class Workers:
    def __init__(self, runtime, environment_id, concurrency=None):
        from .capacity import detect
        self.runtime = runtime
        self.environment_id = environment_id
        self.concurrency = concurrency or detect().session_slots
        self.slots = asyncio.Semaphore(self.concurrency)
        self.tasks = []
        self.sessions = {}
        self.last_error = None
        self.last_poll = None
        self.closing = False
        self.user_cancelled = set()

    async def start(self):
        # A single queue reader dispatches concurrent sessions, avoiding one idle
        # poller per potential session on large servers.
        self.tasks = [asyncio.create_task(self.consume())]

    async def close(self):
        self.closing = True
        for task in self.tasks:
            task.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)
        active = list(self.sessions.values())
        for task in active:
            task.cancel()
        await asyncio.gather(*active, return_exceptions=True)

    async def cancel(self, pid):
        current = self.sessions.get(pid)
        if current:
            self.user_cancelled.add(current)
            try:
                current.cancel()
                await asyncio.gather(current, return_exceptions=True)
            finally:
                self.user_cancelled.discard(current)
        tasks = [self.runtime.jobs.tasks[j["id"]] for j in self.runtime.jobs.list()
                 if j.get("project_id") == pid and j["id"] in self.runtime.jobs.tasks
                 and j["status"] in {"running", "queued"}]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    async def consume(self):
        worker_id = "studio-" + uuid.uuid4().hex
        prefix = f"environments/{self.environment_id}/work/"
        while True:
            await self.slots.acquire()
            dispatched = False
            try:
                work = await self.runtime.ark.request("GET", prefix + "poll",
                    headers={"Ark-Worker-ID": worker_id}, params={"block_ms": 999, "reclaim_older_than_ms": 60000})
                self.last_poll = time.time()
                self.last_error = None
                if not work or not work.get("id"):
                    await asyncio.sleep(1)
                    continue
                sid = (work.get("data") or {}).get("id")
                pid = self.runtime.store.get("worker_session:" + str(sid))
                if not pid or pid in self.sessions:
                    await asyncio.sleep(1)
                    continue
                await self.runtime.ark.request("POST", prefix + work["id"] + "/ack", headers={"Ark-Worker-ID": worker_id})
                task = asyncio.create_task(self.serve(work, pid))
                self.sessions[pid] = task
                dispatched = True
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.last_error = self.runtime.safe_error(exc)
                log.warning("Worker queue paused: %s", self.last_error)
                await asyncio.sleep(5)
            finally:
                if not dispatched:
                    self.slots.release()

    async def serve(self, work, pid):
        try:
            await self.handle(work, pid)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.last_error = self.runtime.safe_error(exc)
            log.warning("Session worker paused: %s", self.last_error)
        finally:
            self.sessions.pop(pid, None)
            self.slots.release()

    async def handle(self, work, pid):
        runtime = self.runtime
        p = runtime.projects.get(pid)
        sid = work["data"]["id"]
        prefix = f"environments/{self.environment_id}/work/{work['id']}"
        parent = asyncio.current_task()
        lease = {"owned": False, "last": work.get("latest_heartbeat_at") or "NO_HEARTBEAT"}

        async def heartbeat():
            while True:
                try:
                    result = await runtime.ark.request("POST", prefix + "/heartbeat", params={
                        "expected_last_heartbeat": lease["last"], "desired_ttl_seconds": 30})
                    if result.get("lease_extended") is False or result.get("state") in {"stopping", "stopped"}:
                        lease["owned"] = False
                        parent.cancel()
                        return
                    lease["owned"] = True
                    lease["last"] = result.get("last_heartbeat", lease["last"])
                except Exception:
                    # Stop dispatch immediately when ownership becomes uncertain.
                    lease["owned"] = False
                    parent.cancel()
                    return
                await asyncio.sleep(10)

        token = runtime.active_project.set(p)
        beat = asyncio.create_task(heartbeat())
        completed = False
        try:
            # Establish ownership before executing any Blender operation.
            for _ in range(600):
                if lease["owned"]:
                    break
                await asyncio.sleep(.05)
            else:
                raise RuntimeError("Worker heartbeat was not established")
            from .builtin_tools import BuiltinTools
            from .workspace_skills import prepare
            # Keep SDK files and Skill manifests out of user-facing artifacts.
            workdir = runtime.ROOT / ".local" / "worker-sessions" / pid / sid
            workdir.mkdir(parents=True, exist_ok=True)
            skill_error = None
            try:
                await prepare(runtime.ark, sid, workdir)
            except Exception as exc:
                skill_error = runtime.safe_error(exc)
                log.warning("Session %s Skill preparation failed: %s", sid, skill_error)
            builtins = BuiltinTools(workdir)

            async def dispatch_builtin(name, args):
                result = await builtins.dispatch(name, args)
                if skill_error and result.get("isError"):
                    result["content"].append({"type": "text", "text": "Session Skill 准备失败：" + skill_error
                        + '。'})
                return result

            tool_context = runtime.projects.context(p) + "\n" + guidance() + (
                f"\n执行环境为 Self-hosted 服务器。内置工具工作目录：{workdir}。"
                "当前 Session 绑定的 Skill 按版本安装在此目录的 skills 下，read 使用相对路径即可。"
                "Blender 工程、渲染与产物仍通过当前项目的 custom tools 操作。")
            from studio.video_frames import is_frame_extraction
            runner = MARunner(runtime.ark, runtime.store, runtime.dispatch, tool_context=tool_context,
                              owned_tools=REMOTE_TOOLS, builtin_dispatch=dispatch_builtin,
                              tool_filter=lambda name, args: not is_frame_extraction(name, args))
            # Blender starts on the first Blender tool call; a slow launch never blocks the Session.
            await runner.run(sid, timeout=3600)
            # Keep the lease while a render started by this work is still active.
            while any(j.get("project_id") == pid and j["status"] in {"queued", "running"}
                      for j in runtime.jobs.list()):
                await asyncio.sleep(1)
            completed = True
        finally:
            beat.cancel()
            await asyncio.gather(beat, return_exceptions=True)
            runtime.active_project.reset(token)
            if not completed:
                tasks = [runtime.jobs.tasks[j["id"]] for j in runtime.jobs.list()
                         if j.get("project_id") == pid and j["id"] in runtime.jobs.tasks
                         and j["status"] in {"queued", "running"}]
                for task in tasks:
                    task.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)
            # Transient failure/restart leaves work reclaimable. Ending it here
            # would strand a cloud Session still waiting for its tool result.
            if lease["owned"] and not self.closing and (completed or parent in self.user_cancelled):
                with contextlib.suppress(Exception):
                    await runtime.ark.request("POST", prefix + "/stop", json={"force": True})
