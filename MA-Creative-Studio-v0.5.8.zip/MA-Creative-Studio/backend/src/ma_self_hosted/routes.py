"""Small integration surface for the local application's settings and desktop."""

from fastapi import APIRouter, HTTPException, Request, Response
from . import execution
from .provision import Provisioner
from .desktop_proxy import desktop_url, router as desktop_router


def router(runtime):
    api = APIRouter(prefix="/api/self-hosted")
    api.include_router(desktop_router(runtime))
    provisioner = Provisioner(runtime)

    @api.get("/settings")
    async def settings():
        return {**execution.settings(runtime.store), "edition": getattr(runtime.app.state, "edition", "local"),
                "deployment": runtime.store.get("worker_deployment", provisioner.status)}

    @api.post("/settings")
    async def update(request: Request):
        if getattr(runtime.app.state, "edition", "local") == "cloud":
            from ma_cloud.settings import select
            try:
                return await select(runtime, await request.json())
            except ValueError as exc:
                raise HTTPException(400, str(exc)) from None
        body = await request.json()
        try:
            # The public UI exposes only mode switching; provisioning owns secrets.
            if set(body) - {"mode", "name"}:
                raise ValueError("无效的设置项")
            if body.get("name") is not None:
                current = execution.settings(runtime.store)
                server = runtime.store.get("execution_server:" + str(current.get("server_id")))
                name = str(body["name"]).strip()
                if not server or not name or len(name) > 80 or any(ord(c) < 32 for c in name):
                    raise ValueError("服务器名称无效")
                server["name"] = name
                runtime.store.set("execution_server:" + server["id"], server)
            return execution.save_settings(runtime.store, {"mode": body.get("mode", execution.settings(runtime.store)["mode"])})
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from None

    @api.post("/deploy")
    async def deploy(request: Request):
        if getattr(runtime.app.state, "edition", "local") == "cloud":
            raise HTTPException(409, "云版本已部署，无需远程安装 Worker。")
        try:
            return provisioner.start(await request.json())
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from None

    @api.get("/desktop")
    async def desktop(project_id: str, response: Response, request: Request):
        p = runtime.project(project_id)
        if not execution.is_remote(p):
            raise HTTPException(400, "此会话使用本机")
        client = runtime.remote(p)
        await client.connect()
        try:
            # Starts this project's own desktop on the cloud executor before the page loads.
            await client.desktop_port_for(p, start=True, activity=True)
        except RuntimeError as exc:
            raise HTTPException(503, str(exc)) from None
        response.headers["Cache-Control"] = "no-store"
        return {"url": desktop_url(project_id, request.scope.get("root_path", "")), "server_name": client.server["name"]}

    @api.get("/desktop-state")
    async def desktop_state(project_id: str, response: Response):
        p = runtime.project(project_id)
        if not execution.is_remote(p):
            raise HTTPException(400, "此会话使用本机")
        response.headers["Cache-Control"] = "no-store"
        try:
            return await runtime.remote(p).desktop_state(p)
        except RuntimeError as exc:
            raise HTTPException(503, str(exc)) from None

    @api.get("/resources")
    async def resources(project_id: str, response: Response):
        p = runtime.project(project_id)
        if not execution.is_remote(p):
            raise HTTPException(400, "此会话使用本机")
        response.headers["Cache-Control"] = "no-store"
        try:
            return await runtime.remote(p).resources.snapshot()
        except RuntimeError as exc:
            raise HTTPException(503, str(exc)) from None

    return api
