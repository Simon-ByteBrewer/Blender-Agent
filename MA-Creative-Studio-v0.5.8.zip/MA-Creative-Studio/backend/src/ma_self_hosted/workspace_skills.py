"""Prepare pinned cloud skills with the official ARK Self-hosted initializer.

Directory separation does not provide OS-level tenant isolation. No bundled skill
or unpinned alternative is substituted for a failed download.
"""

import asyncio
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import stat
import tempfile
from urllib.parse import quote

from arkruntime.selfhosted.envinit import Initializer, InitializerOptions, _replace_skill_dir
from arkruntime.selfhosted.types import Session, SkillContent, SkillRef

MAX_ARCHIVE_BYTES = 128 * 1024 * 1024
MAX_EXTRACTED_BYTES = 512 * 1024 * 1024
MAX_ARCHIVE_ENTRIES = 10000
MANIFEST_NAME = ".ma-skill-manifest.json"
_SAFE_COMPONENT = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")


class SkillPreparationError(RuntimeError):
    """A skill could not be prepared safely at its requested version."""


def _component(value, label):
    if not isinstance(value, str) or not _SAFE_COMPONENT.fullmatch(value):
        raise SkillPreparationError(f"无效的 {label}: {value!r}")
    return value


def _directory(path):
    if path.is_symlink() or (path.exists() and not path.is_dir()):
        raise SkillPreparationError(f"Skill 安装目录不是普通目录: {path}")
    path.mkdir(mode=0o700, parents=True, exist_ok=True)


def _file_hashes(root):
    files = {}
    for current, directories, names in os.walk(root, followlinks=False):
        for name in directories:
            if not stat.S_ISDIR((Path(current) / name).lstat().st_mode):
                raise SkillPreparationError("已安装 Skill 包含符号链接目录")
        for name in names:
            path = Path(current) / name
            if not stat.S_ISREG(path.lstat().st_mode):
                raise SkillPreparationError("已安装 Skill 包含符号链接或特殊文件")
            relative = path.relative_to(root).as_posix()
            if relative == MANIFEST_NAME:
                continue
            with path.open("rb") as source:
                files[relative] = hashlib.file_digest(source, "sha256").hexdigest()
    return files


def _cached(target, identity):
    if target.is_symlink():
        raise SkillPreparationError(f"Skill 安装目标不能是符号链接: {target}")
    manifest = target / MANIFEST_NAME
    if not target.is_dir() or manifest.is_symlink():
        return None
    try:
        if not manifest.is_file() or manifest.stat().st_size > 8 * 1024 * 1024:
            return None
        cached = json.loads(manifest.read_text())
        if (not isinstance(cached, dict) or any(cached.get(key) != value for key, value in identity.items())
                or not isinstance(cached.get("archive_sha256"), str)
                or not isinstance(cached.get("files"), dict) or "SKILL.md" not in cached["files"]):
            return None
        if _file_hashes(target) != cached["files"]:
            return None
        return {**identity, "archive_sha256": cached["archive_sha256"]}
    except (OSError, ValueError, SkillPreparationError):
        return None


class _PrefetchedSkill:
    """Bridge async authenticated downloads to the SDK's synchronous API."""

    def __init__(self, sid, reference, content):
        self.sid = sid
        self.reference = reference
        self.content = content

    def resolve_skill(self, reference):
        if reference.id_value() != self.reference.id_value() or reference.version != self.reference.version:
            raise SkillPreparationError("Skill 下载版本与 Session 引用不一致")
        return self.reference

    def open_skill(self, session_id, reference):
        if session_id != self.sid:
            raise SkillPreparationError("Skill 下载的 Session 不一致")
        self.resolve_skill(reference)
        return SkillContent(body=io.BytesIO(self.content), content_length=len(self.content))


def _install(content, target, identity):
    _directory(target.parent)
    if target.is_symlink() or (target.exists() and not target.is_dir()):
        raise SkillPreparationError(f"Skill 安装目标不是普通目录: {target}")
    reference = SkillRef(type="custom", skill_id=identity["skill_id"], name=identity["name"],
                         version=identity["version"])
    with tempfile.TemporaryDirectory(prefix=".ma-skill-", dir=target.parent) as temporary:
        initializer = Initializer(_PrefetchedSkill(identity["session_id"], reference, content),
            InitializerOptions(workdir=str(target.parent.parent), skills_dir=temporary,
                max_archive_bytes=MAX_ARCHIVE_BYTES, max_extracted_bytes=MAX_EXTRACTED_BYTES,
                max_archive_entries=MAX_ARCHIVE_ENTRIES))
        # setup() logs and skips failed skills; a worker must report the failure
        # instead of proceeding with absent or different instructions.
        initializer.install_skill(identity["session_id"], reference)
        source = Path(temporary) / identity["name"]
        if not (source / "SKILL.md").is_file():
            raise SkillPreparationError("Skill 归档根目录缺少 SKILL.md")
        if (source / MANIFEST_NAME).exists():
            raise SkillPreparationError("Skill 归档不能包含 Worker 的版本 manifest")
        summary = {**identity, "archive_sha256": hashlib.sha256(content).hexdigest()}
        manifest = {**summary, "files": _file_hashes(source)}
        (source / MANIFEST_NAME).write_text(json.dumps(manifest, ensure_ascii=False, sort_keys=True))
        (source / MANIFEST_NAME).chmod(0o600)
        # Reuse the SDK's swap/rollback so content and manifest become available
        # together, after validation is complete.
        backup = _replace_skill_dir(source, target)
        if backup is not None:
            shutil.rmtree(backup)
    return summary


async def prepare(ark, sid, workdir):
    """Return a manifest after all Session skills are ready, or raise explicitly."""
    try:
        _component(sid, "Session ID")
        raw = await ark.request("GET", "sessions/" + quote(sid, safe=""))
        if not isinstance(raw, dict):
            raise SkillPreparationError("Session 响应格式无效")
        agent = raw.get("agent") if isinstance(raw.get("agent"), dict) else {}
        refs = raw.get("skills") or agent.get("skills") or []
        if not isinstance(refs, list):
            raise SkillPreparationError("Session Skill 引用格式无效")
        for ref in refs:
            if not isinstance(ref, dict) or ref.get("type") != "custom":
                raise SkillPreparationError(f"不支持的 Skill 类型，仅支持 custom: {ref.get('type') if isinstance(ref, dict) else ref!r}")
        session = Session.from_mapping(raw)
        if session.id and session.id != sid:
            raise SkillPreparationError("返回的 Skill 配置不属于当前 Session")
        resolved = {}
        for ref in session.skill_refs():
            skill_id = _component(ref.id_value(), "Skill ID")
            metadata = await ark.request("GET", "skills/" + quote(skill_id, safe=""))
            if not isinstance(metadata, dict) or metadata.get("source", "custom") != "custom":
                raise SkillPreparationError(f"Skill {skill_id} 元数据无效或来源不是 custom")
            name = _component(metadata.get("name"), "Skill 名称")
            raw_version = ref.version or metadata.get("latest_version")
            version = _component(str(raw_version) if isinstance(raw_version, (str, int)) and not isinstance(raw_version, bool) else None, "Skill 版本")
            identity = {"session_id": sid, "skill_id": skill_id, "name": name, "version": version,
                        "path": "skills/" + name}
            previous = resolved.setdefault(name.casefold(), identity)
            if previous != identity:
                raise SkillPreparationError(f"多个 Skill 使用相同安装目录: {name}")
        root = Path(workdir).resolve()
        _directory(root)
        _directory(root / "skills")
        installed = []
        for identity in resolved.values():
            target = root / identity["path"]
            cached = await asyncio.to_thread(_cached, target, identity)
            if cached is None:
                path = "skills/{}/versions/{}/content".format(
                    quote(identity["skill_id"], safe=""), quote(identity["version"], safe=""))
                content = await ark.download(path, max_bytes=MAX_ARCHIVE_BYTES)
                cached = await asyncio.to_thread(_install, content, target, identity)
            installed.append(cached)
        return {"session_id": sid, "skills": installed}
    except SkillPreparationError:
        raise
    except Exception as exc:
        raise SkillPreparationError(f"准备 Session Skill 失败: {exc}") from exc
