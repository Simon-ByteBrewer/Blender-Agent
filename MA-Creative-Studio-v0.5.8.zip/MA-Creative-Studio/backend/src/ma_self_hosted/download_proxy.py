"""Temporary HTTPS CONNECT relay for official installation downloads over SSH.

TLS remains end-to-end. The relay neither decrypts requests nor accepts general
destinations, and is closed as soon as installation finishes.
"""

import asyncio
from contextlib import suppress


class DownloadProxy:
    def __init__(self):
        self.server = None
        self.connections = set()

    async def start(self):
        self.server = await asyncio.start_server(self.handle, "127.0.0.1", 0)
        return self.server.sockets[0].getsockname()[1]

    async def close(self):
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        for task in list(self.connections):
            task.cancel()
        await asyncio.gather(*self.connections, return_exceptions=True)

    async def handle(self, reader, writer):
        task = asyncio.current_task()
        self.connections.add(task)
        upstream = None
        try:
            header = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 10)
            method, target, _ = header.split(b"\r\n", 1)[0].decode("ascii").split()
            host, port = target.rsplit(":", 1)
            allowed = host in {"github.com", "codeload.github.com", "pypi.org", "files.pythonhosted.org", "download.blender.org", "dl.google.com"} or host.endswith(".githubusercontent.com")
            if method != "CONNECT" or port != "443" or not allowed:
                writer.write(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
                await writer.drain()
                return
            remote, upstream = await asyncio.wait_for(asyncio.open_connection(host, 443), 20)
            writer.write(b"HTTP/1.1 200 Connection established\r\n\r\n")
            await writer.drain()
            async def copy(source, target):
                while chunk := await source.read(65536):
                    target.write(chunk)
                    await target.drain()
            tasks = [asyncio.create_task(copy(reader, upstream)), asyncio.create_task(copy(remote, writer))]
            try:
                await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            finally:
                for item in tasks:
                    item.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)
        except (OSError, ValueError, TimeoutError, asyncio.IncompleteReadError, asyncio.LimitOverrunError):
            pass
        finally:
            self.connections.discard(task)
            for connection in (writer, upstream):
                if connection:
                    connection.close()
                    with suppress(OSError):
                        await connection.wait_closed()
