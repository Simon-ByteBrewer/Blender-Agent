"""Persist execution targets separately from projects; old projects always stay local."""

import hashlib
import re


def settings(store):
    value = store.get("execution_settings", {"mode": "local", "server_id": None})
    server = store.get("execution_server:" + str(value.get("server_id")), {})
    return {**value, "server": public_server(server) if server else None}


def public_server(server):
    return {k: server[k] for k in ("id", "name", "username", "ip", "ssh_target") if k in server}


def save_settings(store, body):
    if not isinstance(body, dict) or body.get("mode") not in {"local", "self_hosted"}:
        raise ValueError("请选择本机或 Self-hosted")
    current = settings(store)
    sid = current.get("server_id")
    if body.get("server") is not None:
        server = body["server"]
        if not isinstance(server, dict):
            raise ValueError("服务器配置无效")
        target = str(server.get("ssh_target", "")).strip()
        name = str(server.get("name", "")).strip()
        environment = str(server.get("environment_id", "")).strip()
        if not re.fullmatch(r"[a-zA-Z0-9_.-]+@[a-zA-Z0-9][a-zA-Z0-9.-]*", target):
            raise ValueError("SSH 地址应为 user@host")
        if not name or len(name) > 80 or any(ord(c) < 32 for c in name):
            raise ValueError("服务器名称应为 1–80 个字符")
        if not re.fullmatch(r"env-[a-zA-Z0-9-]+", environment):
            raise ValueError("请输入有效的 MA Environment ID")
        ports = {}
        for key, default in (("api_port", 17861), ("desktop_port", 8444)):
            value = server.get(key, default)
            if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 65535:
                raise ValueError("服务器端口应为 1–65535")
            ports[key] = value
        sid = hashlib.sha256(f"{target}:{ports['api_port']}:{environment}".encode()).hexdigest()[:20]
        old = store.get("execution_server:" + sid, {})
        token = server.get("token") or old.get("token", "")
        if not isinstance(token, str) or not 24 <= len(token) <= 4096 or any(c.isspace() or not c.isprintable() for c in token):
            raise ValueError("请填写服务器接入令牌（至少 24 个字符）")
        store.set("execution_server:" + sid, {"id": sid, "name": name, "ssh_target": target,
            "environment_id": environment, **ports, "token": token})
    if body["mode"] == "self_hosted" and not sid:
        raise ValueError("请先配置 Self-hosted 服务器")
    store.set("execution_settings", {"mode": body["mode"], "server_id": sid})
    return settings(store)


def binding(store):
    value = settings(store)
    return {"mode": value["mode"], "server_id": value["server_id"] if value["mode"] in {"self_hosted", "colocated"} else None}


def is_remote(project):
    """Whether Blender runs behind an executor HTTP endpoint."""
    return (project.get("execution") or {}).get("mode") in {"self_hosted", "colocated"}


def is_self_hosted(project):
    """Whether MA delegates tools through a Self-hosted Work Queue."""
    return (project.get("execution") or {}).get("mode") == "self_hosted"


def server_for(store, project):
    sid = (project.get("execution") or {}).get("server_id")
    server = store.get("execution_server:" + str(sid))
    if not server:
        raise ValueError("此会话的执行服务器配置不存在")
    return server


def describe(store, project):
    if not is_remote(project):
        return {"mode": "local"}
    server = server_for(store, project)
    result = {"mode": project["execution"]["mode"], "server_id": server["id"], "server_name": server["name"]}
    if is_self_hosted(project):
        result["environment_id"] = server["environment_id"]
    else:
        result["tool_protocol"] = "custom_tools"
    return result
