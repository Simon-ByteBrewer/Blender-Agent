"""Read-only journal metadata sampler, sent over SSH without installing files."""

from contextlib import closing
import json
from pathlib import Path
import re
import sqlite3
import sys
import threading
import time

JOURNAL = Path("/home/elsa/ma-creative-studio/.local/state.sqlite3")
INTERVAL_SECONDS = 2
MAX_SESSIONS = 64
MAX_CALLS = 2000
STATUSES = {"executing", "ready", "sending", "sent", "rejected", "unknown"}


def identifier(value):
    return isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9_-]{1,200}", value) is not None


def sample(session_ids, path=JOURNAL):
    """Never select tool input/result or open the worker database for writing."""
    session_ids = sorted({sid for sid in session_ids if identifier(sid)})[:MAX_SESSIONS]
    sessions = {sid: {"status": "unknown", "calls": [], "reason": "journal_unavailable"}
                for sid in session_ids}
    try:
        with closing(sqlite3.connect(Path(path).absolute().as_uri() + "?mode=ro", uri=True, timeout=.25)) as db:
            db.execute("PRAGMA query_only = ON")
            for sid in session_ids:
                rows = db.execute(
                    "SELECT id,status FROM calls WHERE sid=? ORDER BY rowid DESC LIMIT ?",
                    (sid, MAX_CALLS + 1),
                ).fetchall()
                calls = [{"call_id": cid, "status": status if status in STATUSES else "unknown"}
                         for cid, status in reversed(rows[:MAX_CALLS]) if identifier(cid)]
                sessions[sid] = {"status": "ok", "calls": calls, "truncated": len(rows) > MAX_CALLS}
    except (OSError, sqlite3.Error):
        # Do not print database paths, exception diagnostics, or row payloads.
        pass
    return {"sampled_at": time.time(), "sessions": sessions}


def main():
    lock, changed = threading.Lock(), threading.Event()
    state = {"sessions": [], "closed": False}

    def commands():
        try:
            for line in sys.stdin:
                if len(line) > 32 * 1024:
                    continue
                try:
                    value = json.loads(line)
                    ids = value.get("sessions") if isinstance(value, dict) else None
                    if not isinstance(ids, list):
                        continue
                except (ValueError, UnicodeError):
                    continue
                with lock:
                    state["sessions"] = sorted({sid for sid in ids if identifier(sid)})[:MAX_SESSIONS]
                changed.set()
        finally:
            with lock:
                state["closed"] = True
            changed.set()

    threading.Thread(target=commands, daemon=True).start()
    try:
        while True:
            with lock:
                ids, closed = list(state["sessions"]), state["closed"]
            if closed:
                return
            if not ids:
                changed.wait()
                changed.clear()
                continue
            print(json.dumps(sample(ids), separators=(",", ":")), flush=True)
            # Requests share the same two-second schedule, including new views.
            time.sleep(INTERVAL_SECONDS)
    except BrokenPipeError:
        pass


if __name__ == "__main__":
    main()
