"""Authenticated remote tools and files over a loopback-only SSH tunnel."""

import asyncio
import hashlib
import json
import os
import socket
import sys
import time
from pathlib import Path
from urllib.parse import quote

import httpx
from .execution import server_for
from .gateway import WorkerGateway
from .resources import Resources
from .tool_status import ToolStatus


class DesktopStopped(RuntimeError):
    """The project's desktop was closed (idle); only an explicit open restarts it."""


class RemoteClient:
    def __init__(self, server, store):
        self.server = server
        self.lock = asyncio.Lock()
        self.process = None
        self.port = None
        self.desktop_port = None
        self.bound = {}
        self.retry_at = 0
        self.connection_error = ""
        self.gateway = WorkerGateway(server, store)
        self.resources = Resources(server)
        self.tool_status = ToolStatus(server)

    async def connect(self):
        async with self.lock:
            if self.process and self.process.returncode is None:
                return
            if time.monotonic() < self.retry_at:
                raise RuntimeError(self.connection_error)
            gateway_port = await self.gateway.start()
            ports = []
            for _ in range(2):
                with socket.socket() as sock:
                    sock.bind(("127.0.0.1", 0))
                    ports.append(sock.getsockname()[1])
            self.port, self.desktop_port = ports
            ssh = "/usr/bin/ssh" if sys.platform == "darwin" else "ssh"
            self.process = await asyncio.create_subprocess_exec(
                ssh, "-N", "-o", "BatchMode=yes", "-o", "ConnectTimeout=12",
                "-o", "ExitOnForwardFailure=yes", "-o", "ServerAliveInterval=15",
                "-o", "ServerAliveCountMax=3", "-o", "StrictHostKeyChecking=accept-new",
                "-L", f"127.0.0.1:{self.port}:127.0.0.1:{self.server['api_port']}",
                "-L", f"127.0.0.1:{self.desktop_port}:127.0.0.1:{self.server['desktop_port']}",
                "-R", f"127.0.0.1:17862:127.0.0.1:{gateway_port}",
                self.server["ssh_target"], stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
            )
            for _ in range(150):
                if self.process.returncode is not None:
                    self.connection_error = "无法连接 Self-hosted 服务器，请确认 SSH 登录有效"
                    self.retry_at = time.monotonic() + 15
                    raise RuntimeError(self.connection_error)
                try:
                    _, writer = await asyncio.open_connection("127.0.0.1", self.port)
                    writer.close()
                    await writer.wait_closed()
                    self.bound.clear()
                    self.retry_at = 0
                    self.connection_error = ""
                    return
                except OSError:
                    await asyncio.sleep(.1)
            await self.close()
            self.connection_error = "Self-hosted SSH 连接超时"
            self.retry_at = time.monotonic() + 15
            raise RuntimeError(self.connection_error)

    async def close(self):
        await self.tool_status.close()
        await self.resources.close()
        if self.process and self.process.returncode is None:
            self.process.terminate()
            await self.process.wait()
        self.process = None
        await self.gateway.close()

    async def request(self, method, path, **kwargs):
        await self.connect()
        async with httpx.AsyncClient(base_url=f"http://127.0.0.1:{self.port}",
                headers={"Authorization": "Bearer " + self.server["token"]}, timeout=240) as client:
            response = await client.request(method, path, **kwargs)
            if response.is_error:
                try:
                    message = response.json().get("detail", "远程请求失败")
                except ValueError:
                    message = "远程请求失败"
                raise RuntimeError(f"{self.server['name']}: {message}")
            return response.json()

    async def bind(self, project):
        await self.connect()
        # Only project metadata crosses to the executor, never a business API Key.
        payload = {k: project[k] for k in ("id", "title", "prompt", "scene", "blend", "reference", "settings", "session_id") if k in project}
        payload["environment_id"] = self.server.get("environment_id")
        digest = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        if self.bound.get(project["id"]) != digest:
            await self.request("POST", "/projects", json=payload)
            self.bound[project["id"]] = digest

    async def project_request(self, project, method, suffix, **kwargs):
        await self.bind(project)
        return await self.request(method, f"/projects/{quote(project['id'], safe='')}/{suffix}", **kwargs)

    async def desktop_port_for(self, project, *, start=True, activity=True):
        """Over SSH every project shares the server's forwarded desktop."""
        await self.connect()
        return self.desktop_port

    async def desktop_state(self, project):
        return {"isolated": False, "running": True}

    async def tool(self, project, name, args):
        return await self.project_request(project, "POST", "tools", json={"name": name, "arguments": args})

    async def discover(self):
        return await self.request("GET", "/tools")

    async def download(self, project, name, destination):
        await self.bind(project)
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(destination.name + f".{time.time_ns()}.partial")
        try:
            async with httpx.AsyncClient(headers={"Authorization": "Bearer " + self.server["token"]}, timeout=240) as client:
                async with client.stream("GET", f"http://127.0.0.1:{self.port}/projects/{quote(project['id'], safe='')}/files/{quote(name, safe='/')}") as response:
                    response.raise_for_status()
                    with temporary.open("wb") as out:
                        async for chunk in response.aiter_bytes():
                            out.write(chunk)
            os.replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)

    async def upload(self, project, name, source):
        await self.bind(project)
        with Path(source).open("rb") as source_file:
            return await self.project_request(project, "PUT", "files/" + quote(name, safe="/"), files={"file": (Path(name).name, source_file)})


class Remotes:
    def __init__(self):
        self.clients = {}

    def for_project(self, store, project):
        server = server_for(store, project)
        client = self.clients.get(server["id"])
        if client is None:
            if server.get("transport") == "loopback":
                from ma_cloud.client import ColocatedClient
                client = ColocatedClient(server, store)
            else:
                client = RemoteClient(server, store)
            self.clients[server["id"]] = client
        client.server = server
        return client

    async def close(self):
        await asyncio.gather(*(client.close() for client in self.clients.values()))
