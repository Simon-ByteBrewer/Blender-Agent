"""Import a verified project download before switching its execution to this Mac."""

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import tempfile
import time

from studio.projects import Projects
from studio.conversation import history_key


def import_project(store, project_id, source, scope):
    source = Path(source).resolve()
    manifest = json.loads((source / 'migration-manifest.json').read_text())
    metadata = manifest['project']
    if metadata['id'] != project_id:
        raise ValueError('下载文件不属于当前项目')
    files = {}
    for entry in manifest['files']:
        name = entry['name']
        relative = PurePosixPath(name)
        path = (source / name).resolve()
        if relative.is_absolute() or '..' in relative.parts or not path.is_relative_to(source) or name in files:
            raise ValueError('下载清单包含无效路径')
        if (source / name).is_symlink() or not path.is_file():
            raise ValueError('下载文件缺失或不是普通文件：' + name)
        data = path.read_bytes()
        if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
            raise ValueError('下载文件校验失败：' + name)
        files[name] = path
    if metadata['blend'] not in files or metadata['reference'] not in files:
        raise ValueError('下载中缺少 Blender 工程或当前引用视频')

    projects = Projects(store)
    installed, backups = [], {}
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        def get(key, default=None):
            row = db.execute('SELECT value FROM kv WHERE key=?', (key,)).fetchone()
            return json.loads(row[0]) if row else default
        def put(key, value):
            db.execute('INSERT OR REPLACE INTO kv VALUES(?,?)', (key, json.dumps(value, ensure_ascii=False)))
        items = get('projects', [])
        project = next((p for p in items if p['id'] == project_id), None)
        if not project or (project.get('execution') or {}).get('mode') != 'self_hosted':
            raise ValueError('项目必须仍使用 Self-hosted 才能迁回本机')
        if any(j.get('project_id') == project_id and j.get('status') in {'running', 'queued'} for j in get('jobs', [])):
            raise ValueError('项目仍在执行任务，请完成后迁移')
        if any(m.get('status') in {'queued', 'sending', 'accepted'} for m in get(f'chat_outbox:{project_id}:{scope}', [])):
            raise ValueError('项目还有待处理消息，请先处理后迁移')
        root = projects.directory(project)
        destinations = {name: projects.path(project, name) for name in files}
        local_binding = f'project_session:{project_id}:{scope}'
        if get(local_binding):
            raise ValueError('此项目已有本机 Session，不能覆盖')
        old_execution = project['execution'].copy()
        old_binding = local_binding + ':self_hosted:' + old_execution['server_id']
        old_session = get(old_binding)
        stamp = time.time_ns()
        backup = Path(store.path).parent / 'migrations' / f'{project_id}-{stamp}'
        backup.mkdir(parents=True, mode=0o700)
        archive = history_key(project_id, scope)
        before = {key: get(key) for key in ('projects', local_binding, local_binding + ':model', local_binding + ':effort', archive)}
        snapshot = backup / 'before.json'
        snapshot.write_text(json.dumps(before, ensure_ascii=False, indent=2))
        snapshot.chmod(0o600)
        try:
            for name, src in files.items():
                dest = destinations[name]
                dest.parent.mkdir(parents=True, exist_ok=True)
                if dest.exists():
                    saved = backup / 'files' / name
                    saved.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dest, saved)
                    backups[dest] = saved
                with tempfile.NamedTemporaryFile(dir=dest.parent, prefix='.import-', delete=False) as out:
                    temporary = Path(out.name)
                try:
                    shutil.copy2(src, temporary)
                    os.replace(temporary, dest)
                finally:
                    temporary.unlink(missing_ok=True)
                installed.append(dest)
            project.update({k: metadata[k] for k in ('scene', 'blend', 'reference', 'settings')})
            project['execution_history'] = [*project.get('execution_history', []), {
                'execution': old_execution, 'session_id': old_session, 'migrated_at': time.time(),
            }]
            if old_session and old_session not in project.get('session_history', []):
                project['session_history'] = [*project.get('session_history', []), old_session]
            if old_session and old_session not in get(archive, []):
                put(archive, [*get(archive, []), old_session])
            project.update(execution={'mode': 'local', 'server_id': None}, session_id=None, updated_at=time.time())
            project.pop('execution_info', None)
            put('projects', items)
            put(local_binding, None)
            for suffix in (':model', ':effort'):
                value = get(old_binding + suffix)
                if value is not None:
                    put(local_binding + suffix, value)
            # Preserve the original remote Session binding and event history.
            db.commit()
        except BaseException:
            for dest in reversed(installed):
                if dest in backups:
                    shutil.copy2(backups[dest], dest)
                else:
                    dest.unlink(missing_ok=True)
            raise
    return {'project_id': project_id, 'directory': str(root), 'files': len(files),
            'reference': metadata['reference'], 'backup': str(backup), 'execution': 'local'}


if __name__ == '__main__':
    import argparse
    from studio.config import key_identity
    from studio.store import Store
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', required=True)
    parser.add_argument('--source', required=True)
    args = parser.parse_args()
    print(json.dumps(import_project(Store(), args.project, args.source, key_identity()), ensure_ascii=False))
