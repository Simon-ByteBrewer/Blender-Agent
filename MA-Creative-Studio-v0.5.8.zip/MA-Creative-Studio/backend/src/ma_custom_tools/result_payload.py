"""Bound MA tool-event payloads without changing Blender scene execution."""
import base64
import copy
import io
import json

from PIL import Image

# Conservative transport budgets; these are local defaults, not advertised API limits.
MAX_EVENT_BYTES = 512 * 1024
MAX_IMAGE_BYTES = 192 * 1024


def prepare_result(result):
    result = copy.deepcopy(result)
    for block in result.get("content", []):
        source = block.get("source", {})
        if block.get("type") != "image" or source.get("type") != "base64":
            continue
        encoded = source.get("data", "")
        if len(encoded) <= MAX_IMAGE_BYTES:
            continue
        raw = base64.b64decode(encoded, validate=True)
        with Image.open(io.BytesIO(raw)) as original:
            # Composite transparent screenshots against the light studio background.
            rgba = original.convert("RGBA")
            im = Image.new("RGB", rgba.size, "white")
            im.paste(rgba, mask=rgba.getchannel("A"))
        im.thumbnail((1280, 1280))
        for _ in range(8):
            out = io.BytesIO()
            im.save(out, format="JPEG", quality=82, optimize=True)
            encoded = base64.b64encode(out.getvalue()).decode("ascii")
            if len(encoded) <= MAX_IMAGE_BYTES:
                break
            im.thumbnail((max(1, int(im.width * .75)), max(1, int(im.height * .75))))
        block["source"] = {"type": "base64", "media_type": "image/jpeg", "data": encoded}
    if len(json.dumps({"events": [result]}, ensure_ascii=False).encode("utf-8")) > MAX_EVENT_BYTES:
        # Do not turn an untransmittable result into an endless delivery failure.
        # Keep its complete original in the durable call record before calling this function.
        correlation = {k: result[k] for k in ("type", "tool_use_id", "custom_tool_use_id", "session_thread_id") if k in result}
        return {
            **correlation,
            "is_error": True,
            "content": [{"type": "text", "text": "工具已执行，但返回内容超过平台传输预算，完整结果已保留在本地。不要重复执行建模或其他写操作；请改用只读查询，分段获取信息或获取更小的截图。"}],
        }
    return result
