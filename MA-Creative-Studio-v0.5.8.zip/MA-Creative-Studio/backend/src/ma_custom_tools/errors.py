"""Identify a model input failure that cannot be fixed by replaying its history."""

import json
import re


def blocked_reference_image(value):
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
    return (
        "Error while downloading" in text
        and "image_url" in text
        and re.search(r"status code:\s*403\b", text) is not None
    )


def needs_reference_recovery(events):
    for event in reversed(events):
        if event.get("type") in {"session.error", "session.status_idle"}:
            return event["type"] == "session.error" and blocked_reference_image(event)
    return False


def recovery_prompt(project, events):
    requests = [project["prompt"]] if project.get("prompt") else []
    for event in events:
        if event.get("type") == "user.message":
            text = "\n".join(
                block.get("text", "")
                for block in event.get("content", [])
                if block.get("type") == "text"
            )
            if text and text not in requests:
                requests.append(text)
    if not requests:
        raise ValueError("没有可恢复的创作要求，请输入提示词后重新开始")
    return (
        "上次会话因外部参考图片返回 HTTP 403 而中断。本次在新会话恢复创作，"
        "不带入失败的图片内容。不要调用 web_search、web_fetch 或 view_multimodal，"
        "不要访问外部参考图片。依据下列文字要求和当前项目场景完成建模。"
        "先检查当前场景，保留已有工作，分步保存工程并渲染视频。\n\n"
        + "\n\n".join(requests)
    )
