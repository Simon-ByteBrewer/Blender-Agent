"""Ship and reconcile the Studio-owned whitebox skill using the active account."""

from copy import deepcopy
import json
import hashlib
import io
import re
import zipfile

from studio.config import RESOURCES
from studio.ark import ArkHTTPError
from .skill_bundle import SKILL_NAME, skill_files as bundle_files

START = "[STUDIO_BUNDLED_WHITEBOX_SKILL]"
END = "[/STUDIO_BUNDLED_WHITEBOX_SKILL]"


def with_skill_reader(tools):
    """Older Agents also read an executor-side skill copy via local_pipeline action=skill.
    Current Agents read the mounted skill with the built-in read tool; nothing to add."""
    tools = deepcopy(tools)
    tool = next((t for t in tools if t.get("name") == "local_pipeline"), None)
    if tool is None:
        return tools
    schema = tool["input_schema"]
    encoded = isinstance(schema, str)
    schema = json.loads(schema) if encoded else schema
    props = schema.setdefault("properties", {})
    actions = props["action"]["enum"]
    if "skill" not in actions:
        actions.append("skill")
    props.setdefault("path", {"type": "string"})
    tool["input_schema"] = json.dumps(schema) if encoded else schema
    note = " Use action=skill with optional path (default SKILL.md) to read the bundled whitebox skill and local helper paths."
    if note not in tool.get("description", ""):
        tool["description"] = tool.get("description", "") + note
    return tools


def skill_root():
    return RESOURCES / "skills" / SKILL_NAME


def skill_files(root=None):
    return bundle_files(root if root is not None else skill_root())


def skill_package():
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(skill_files().items()):
            info = zipfile.ZipInfo(
                f"{SKILL_NAME}/{name}", date_time=(2020, 1, 1, 0, 0, 0)
            )
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, data)
    data = stream.getvalue()
    return data, hashlib.sha256(data).hexdigest()


def guidance():
    return f"""{START}
已挂载 {SKILL_NAME}。白模、运镜和预演任务先用内置 read 读取该技能的 SKILL.md，再按需读取 references：托管环境位于 /mnt/skills/{SKILL_NAME}/，Self-hosted 环境位于 Session 工作目录的 ./skills/{SKILL_NAME}/。
技能中的辅助脚本（wb_lib 等）由平台安装在 Blender 执行端并加入 Python 路径，不要按读取技能时的路径在 Blender 中导入或执行。
平台已选中项目场景并准备 wb_lib：在 execute_blender_code 中使用 import bpy, wb_lib as wb; scene=bpy.context.scene。不要运行 wb.new_scene 或示例 main() 创建另一个场景；当前场景已获得独立 wb_namespace。
根节点负责走位，台阶、下车和入座可增加最低限度的四肢姿态；Blender 5.2 曲线访问使用 action_slot/channelbag。
保存调用 blender_project save，渲染调用 previz_render preview/all/status，由平台登记版本；不要在云端或 MCP 主线程直接运行渲染 CLI。
较早创建的会话若只有 local_pipeline 工具，对应用法为 local_pipeline(action="save"/"all"/"status"/"blender_open" 等)，也可用 action="skill" 读取 Blender 执行端的技能副本；seedance 对应 seedance_video。
{END}"""


def with_guidance(system):
    text = re.sub(
        re.escape(START) + r".*?" + re.escape(END), "", system or "", flags=re.S
    ).rstrip()
    return text + "\n\n" + guidance()


def read_skill(path="SKILL.md"):
    files = skill_files()
    if path not in files:
        raise ValueError("只能读取内置白模技能中的文件")
    return {
        "name": SKILL_NAME,
        "path": path,
        "content": files[path].decode("utf-8"),
        "files": sorted(files),
        "local_scripts": str(skill_root() / "scripts"),
        "integration": guidance(),
    }


async def ensure_skill(ark, store, config_key, cfg):
    data, sha = skill_package()
    owned = cfg.setdefault("bundled_skills", {})
    cached = owned.get(SKILL_NAME, {})
    if cached.get("pending"):
        raise RuntimeError(
            "上次白模技能上传结果未知；请核对远端技能并恢复其 ID 后再重试，避免重复上传"
        )
    existing_id = None
    if cached.get("skill_id"):
        try:
            remote = await ark.request("GET", "skills/" + cached["skill_id"])
            existing_id = cached["skill_id"]
            if (
                cached.get("sha256") == sha
                and remote.get("display_title") == SKILL_NAME
            ):
                if not cached.get("version"):
                    cached["version"] = str(remote["latest_version"])
                    store.set(config_key, cfg)
                return {
                    "type": "custom",
                    "skill_id": existing_id,
                    "version": cached["version"],
                }
        except ArkHTTPError as exc:
            if exc.status_code != 404:
                raise
    # Persist ambiguity before a non-idempotent upload. Persist returned ID before binding.
    owned[SKILL_NAME] = {**cached, "pending": True, "pending_sha256": sha}
    store.set(config_key, cfg)
    try:
        result = await ark.request(
            "POST",
            "skills/" + existing_id + "/versions" if existing_id else "skills",
            files={"files": (SKILL_NAME + ".zip", data, "application/zip")},
            data={"display_title": SKILL_NAME},
        )
    except ArkHTTPError as exc:
        if exc.status_code in {400, 401, 403, 404, 413, 415, 422}:
            owned[SKILL_NAME] = cached
            store.set(config_key, cfg)
        raise
    skill_id = existing_id or result["id"]
    version = result.get("version") if existing_id else result.get("latest_version")
    if version is None:
        # The write may have succeeded: retain ambiguity instead of uploading again.
        owned[SKILL_NAME]["skill_id"] = skill_id
        store.set(config_key, cfg)
        raise RuntimeError("技能上传响应缺少版本号，请核对远端版本后恢复状态")
    previous = set(cached.get("previous_ids", []))
    if cached.get("skill_id"):
        previous.add(cached["skill_id"])
    version = str(version)
    owned[SKILL_NAME] = {
        "skill_id": skill_id,
        "version": version,
        "sha256": sha,
        "previous_ids": sorted(previous - {skill_id}),
    }
    store.set(config_key, cfg)
    return {"type": "custom", "skill_id": skill_id, "version": version}


async def sync_agent_skill(ark, store, config_key, cfg, reference=None):
    reference = reference or await ensure_skill(ark, store, config_key, cfg)
    agent = await ark.request("GET", "agents/" + cfg["agent_id"])
    owned = cfg["bundled_skills"][SKILL_NAME]
    ours = {reference["skill_id"], *owned.get("previous_ids", [])}
    # GET adds display_name; compare and write only the API's reference fields.
    current = [
        {k: s[k] for k in ("type", "skill_id", "version") if k in s}
        for s in agent.get("skills") or []
    ]
    skills = [s for s in current if s.get("skill_id") not in ours]
    skills.append(reference)
    if len(skills) > 20:
        raise RuntimeError("Agent 的技能已达 20 个上限，请先调整绑定")
    tools = with_skill_reader(list(agent.get("tools") or []))
    desired = {
        "skills": skills,
        "system": with_guidance(agent.get("system")),
        "tools": tools,
    }
    actual = {**agent, "skills": current}
    patch = {k: value for k, value in desired.items() if value != actual.get(k)}
    if patch:
        await ark.request(
            "POST", "agents/" + agent["id"], json={"version": agent["version"], **patch}
        )
        agent = await ark.request("GET", "agents/" + agent["id"])
    if not any(
        all(s.get(k) == v for k, v in reference.items())
        for s in agent.get("skills") or []
    ):
        raise RuntimeError("远端回读未确认白模技能绑定")
    cfg["bundled_skill_agent_version"] = agent["version"]
    store.set(config_key, cfg)
    return agent
