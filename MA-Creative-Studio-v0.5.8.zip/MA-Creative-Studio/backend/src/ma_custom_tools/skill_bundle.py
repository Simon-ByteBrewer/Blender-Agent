"""Standard-library-only resource manifest shared by runtime and desktop builds."""

from pathlib import Path

SKILL_NAME = "blender-whitebox-previz"


def skill_files(root):
    root = Path(root)
    paths = [root / "SKILL.md"]
    for folder in ("references", "scripts"):
        paths.extend(sorted((root / folder).rglob("*")))
    files = {}
    for path in paths:
        rel = path.relative_to(root)
        if any(part.startswith(".") or part == "__pycache__" for part in rel.parts):
            continue
        if path.is_symlink():
            raise ValueError(f"Bundled skill cannot contain symlinks: {rel}")
        if path.is_file() and path.suffix in {".md", ".py"}:
            files[rel.as_posix()] = path.read_bytes()
    if "SKILL.md" not in files or "scripts/wb_lib.py" not in files:
        raise RuntimeError("安装包缺少白模技能资源，请重新安装完整版本")
    return files
