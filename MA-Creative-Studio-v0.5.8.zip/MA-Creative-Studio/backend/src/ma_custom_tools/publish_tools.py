"""Explicitly update existing account-owned Agent tools and verify cloud read-back."""

import argparse
import asyncio
from copy import deepcopy
import json
import time

from studio.config import OUTPUT, key_identity, safe_error
from studio.ark import Ark
from studio.store import Store
from ma_mcp.mcp_bridge import MCPBridge
from .setup_ma import configured_tools, system_prompt, is_platform_prompt
from .skills import with_guidance
from .tool_names import LEGACY_TOOLS


def normalized(tool):
    result = {k: deepcopy(tool[k]) for k in ("type", "name", "description", "input_schema") if k in tool}
    if isinstance(result.get("input_schema"), str):
        result["input_schema"] = json.loads(result["input_schema"])
    # Ark may omit these two fields on read-back, and drops the schema's top-level title
    # (Blender MCP schemas carry e.g. "execute_blender_codeArguments").
    schema = result.get("input_schema")
    if isinstance(schema, dict):
        schema.setdefault("additionalProperties", False)
        schema.setdefault("required", [])
        schema.pop("title", None)
    return result


async def publish(ark, agent_id, definitions, backup_dir, system=None):
    """system: also refresh a platform-written system prompt (user-written prompts are kept)."""
    agent = await ark.request("GET", "agents/" + agent_id)
    current = agent.get("tools") or []
    names = [t.get("name") for t in current]
    if len(names) != len(set(names)):
        raise ValueError("Agent 的工具名称重复，不能自动替换")
    # Replace every Studio-owned tool (current and earlier names) with the configured set;
    # tools the user added to the Agent are kept unchanged.
    ours = {t["name"] for t in definitions} | set(LEGACY_TOOLS)
    desired = [deepcopy(t) for t in current if t.get("name") not in ours] + [deepcopy(t) for t in definitions]
    key = lambda tool: json.dumps(normalized(tool), ensure_ascii=False, sort_keys=True)
    patch = {}
    if sorted(map(key, current)) != sorted(map(key, desired)):
        patch["tools"] = desired
    desired_system = agent.get("system")
    if system and is_platform_prompt(agent.get("system")):
        desired_system = with_guidance(system)
        if desired_system != agent.get("system"):
            patch["system"] = desired_system
    changed = bool(patch)
    if changed:
        backup_dir.mkdir(parents=True, exist_ok=True)
        path = backup_dir / (agent_id + "-v" + str(agent["version"]) + ".json")
        # Keep the pre-update payload for review/recovery; never print its contents.
        if not path.exists():
            path.write_text(json.dumps(agent, ensure_ascii=False, indent=2), encoding="utf-8")
            path.chmod(0o600)
        await ark.request("POST", "agents/" + agent_id, json={"version": agent["version"], **patch})
        agent = await ark.request("GET", "agents/" + agent_id)
    actual = {t["name"]: normalized(t) for t in agent.get("tools") or []}
    if actual != {t["name"]: normalized(t) for t in desired}:
        raise RuntimeError("云端回读工具配置与本地不一致，请核对，不能宣称发布成功")
    if agent.get("system") != desired_system:
        raise RuntimeError("云端回读系统提示词与本地不一致，请核对，不能宣称发布成功")
    return {"agent_id": agent_id, "version": agent["version"], "updated": changed,
            "updated_fields": sorted(patch), "verified": True, "tool_count": len(actual),
            "platform_prompt": is_platform_prompt(agent.get("system"))}


async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--agent-id", action="append", required=True)
    parser.add_argument("--system-prompt", choices=["local", "remote"],
                        help="同时刷新平台写入的系统提示词：local=Mac 本地执行，remote=远程服务器执行")
    args = parser.parse_args()
    store = Store()
    with store.connect() as db:
        rows = db.execute("SELECT key,value FROM kv WHERE key LIKE 'platform_ma:%'").fetchall()
    prefix = "platform_ma:" + key_identity()
    owned = {json.loads(v).get("agent_id") for k, v in rows if k == prefix or k.startswith(prefix + ":")}
    if any(a not in owned for a in args.agent_id):
        raise ValueError("只能更新当前凭证在本地登记的 Agent")
    definitions = configured_tools(await MCPBridge().discover())
    backup_dir = OUTPUT / "config" / ("tool-publish-" + time.strftime("%Y%m%d-%H%M%S"))
    for agent_id in dict.fromkeys(args.agent_id):
        system = system_prompt(remote=args.system_prompt == "remote") if args.system_prompt else None
        print(json.dumps(await publish(Ark(), agent_id, definitions, backup_dir, system), ensure_ascii=False))


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as exc:
        print(safe_error(exc))
        raise SystemExit(1)
