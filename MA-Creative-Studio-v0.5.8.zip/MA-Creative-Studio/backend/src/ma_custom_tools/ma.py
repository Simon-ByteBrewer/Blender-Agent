"""Durable MA event runner: requires_action gate, call correlation, resumable cursor."""

import asyncio, time, json, hashlib
from ma_mcp.mcp_bridge import to_ma_result
from studio.config import safe_error
from studio.ark import ArkHTTPError
from .result_payload import prepare_result


class MARunner:
    def __init__(self, ark, store, dispatch, tool_context="", owned_tools=None, builtin_dispatch=None, tool_filter=None,
                 model_switch=None):
        self.ark = ark
        self.store = store
        self.dispatch = dispatch
        self.session_locks = {}
        self.tool_context = tool_context
        self.context_version = hashlib.sha256(tool_context.encode()).hexdigest()
        self.owned_tools = owned_tools
        self.builtin_dispatch = builtin_dispatch
        self.tool_filter = tool_filter
        # Optional: .pending(sid) / async .apply(sid) for a model chosen mid-Session.
        self.model_switch = model_switch

    def _pending(self, sid):
        return {e["id"]: e for e in self.store.events(sid)
                if e["type"] in {"agent.custom_tool_use", "agent.tool_use"}}

    async def _await_pending(self, sid, cid, attempts=5):
        """Ark can list requires_action before the tool_use it names (same timestamp,
        unstable order). Re-read the newest events briefly instead of abandoning the call."""
        for attempt in range(attempts):
            latest = await self.ark.request("GET", f"sessions/{sid}/events", params={"order": "desc", "limit": 100})
            for e in latest.get("data", []):
                self.store.event(sid, e)
            pending = self._pending(sid)
            if cid in pending or attempt == attempts - 1:
                return pending
            await asyncio.sleep(1)

    async def handle(self, sid, event):
        self.store.event(sid, event)
        if event["type"] == "user.tool_confirmation" and self.builtin_dispatch:
            # An ask permission gate can be confirmed without another idle event.
            cid = event.get("tool_use_id") or event.get("custom_tool_use_id")
            if cid:
                event = {"type": "session.status_idle", "stop_reason": {
                    "type": "requires_action", "event_ids": [cid]}}
        if event["type"] != "session.status_idle":
            if event["type"] in [
                "session.status_failed",
                "session.status_terminated",
                "session.error",
                "session.deleted",
            ]:
                self.store.set("cursor:" + sid, event["id"])
                self.store.set("processed:" + sid + ":" + event["id"], True)
                raise RuntimeError(json.dumps(event, ensure_ascii=False))
            return False
        reason = event.get("stop_reason") or {}
        if reason.get("type") != "requires_action":
            return True
        pending = self._pending(sid)
        ids = reason.get("event_ids", [])
        if not ids:
            raise RuntimeError("requires_action contains no event_ids")
        for cid in ids:
            # Self-hosted workers own remote tools. The desktop only handles
            # explicitly retained local services (Seedance) and observes the rest.
            prior = self.store.call(sid, cid)
            call = pending.get(cid)
            if not call and not (prior and prior[1]):
                pending = await self._await_pending(sid, cid)
                call = pending.get(cid)
            if not call and prior and prior[1] and self.owned_tools is None:
                # Older local journals can retain a prepared result after the
                # originating event was pruned. Delivery never reruns the tool.
                call = {"type": "agent.tool_use" if prior[1].get("type") == "user.tool_result"
                        else "agent.custom_tool_use"}
            if not call:
                raise RuntimeError("Missing pending tool event " + cid)
            builtin = call["type"] == "agent.tool_use"
            if builtin and self.builtin_dispatch is None:
                continue
            if not builtin and self.owned_tools is not None and call.get("name") not in self.owned_tools:
                continue
            if not builtin and self.tool_filter and not self.tool_filter(call.get("name"), call.get("input", {})):
                continue
            permission = call.get("evaluated_permission") or "allow"
            if permission == "ask":
                confirmation = next((e for e in reversed(self.store.events(sid))
                    if e["type"] == "user.tool_confirmation"
                    and (e.get("tool_use_id") or e.get("custom_tool_use_id")) == cid), None)
                if not confirmation:
                    continue
                permission = confirmation.get("result")
            if prior and prior[0] == "sent":
                continue
            if prior and prior[0] in ["executing", "sending"]:
                raise RuntimeError(
                    f"Tool {cid} has uncertain execution/delivery after interruption; inspect remote history before retrying"
                )
            if prior:
                result = prior[1]
            else:
                self.store.save_call(sid, cid, "executing")
                try:
                    if permission != "allow":
                        raise PermissionError(call.get("deny_message") or "Tool execution was not permitted")
                    dispatch = self.builtin_dispatch if builtin else self.dispatch
                    raw = await dispatch(call["name"], call.get("input", {}))
                    result = to_ma_result(cid, raw)
                except Exception as e:
                    result = to_ma_result(
                        cid,
                        {
                            "isError": True,
                            "content": [{"type": "text", "text": safe_error(e)}],
                        },
                    )
                if builtin:
                    result["type"] = "user.tool_result"
                    result["tool_use_id"] = result.pop("custom_tool_use_id")
                    if call.get("session_thread_id"):
                        result["session_thread_id"] = call["session_thread_id"]
                self.store.save_call(sid, cid, "ready", result)
            # Deliver updated platform direction at a tool boundary, including sessions
            # already running with an older cloud Agent configuration. Never rerun tools.
            context_key = "tool_context:" + sid
            context_pending = bool(self.tool_context) and self.store.get(context_key) != self.context_version
            if context_pending and not any(c.get("text") == self.tool_context for c in result.get("content", [])):
                result = {**result, "content": [*result.get("content", []),
                    {"type": "text", "text": self.tool_context}]}
            # Keep the original result for inspection, and only encode a transport copy.
            prepared = prepare_result(result)
            if prepared != result and self.store.get("call_output:" + sid + ":" + cid) is None:
                self.store.set("call_output:" + sid + ":" + cid, result)
            result = prepared
            # Mark ambiguous delivery durably before the network write.
            self.store.save_call(sid, cid, "sending", result)
            try:
                await self.ark.send(sid, [result])
            except ArkHTTPError as exc:
                if exc.status_code in {400, 401, 403, 404, 413, 415, 422}:
                    self.store.save_call(sid, cid, "rejected", result)
                raise
            self.store.save_call(sid, cid, "sent", result)
            if context_pending and any(c.get("text") == self.tool_context for c in result.get("content", [])):
                self.store.set(context_key, self.context_version)
        return False

    async def run(self, sid, message=None, timeout=900, inbox=None):
        if inbox is None or not callable(getattr(self.ark, "watch", None)):
            return await self._run(sid, message, timeout, inbox)
        wake, ready = asyncio.Event(), asyncio.Event()

        def observe(event):
            self.store.event(sid, event)
            inbox.reconcile([event])

        monitor = asyncio.create_task(self.ark.watch(sid, observe, wake, ready))
        try:
            # Subscribe before submitting input; polling fills gaps after reconnect.
            try:
                await asyncio.wait_for(ready.wait(), 3)
            except TimeoutError:
                pass
            return await self._run(sid, message, timeout, inbox, wake)
        finally:
            monitor.cancel()
            await asyncio.gather(monitor, return_exceptions=True)

    async def _run(self, sid, message=None, timeout=900, inbox=None, wake=None):
        async with self.session_locks.setdefault(sid, asyncio.Lock()):
            if message:
                # Upgrade before reading the cursor so the new turn starts on the new model.
                if self.model_switch and self.model_switch.pending(sid):
                    await self.model_switch.apply(sid)
                latest = await self.ark.request(
                    "GET",
                    f"sessions/{sid}/events",
                    params={"order": "desc", "limit": 100},
                )
                if latest.get("data"):
                    terminal = next((e for e in latest["data"] if e["type"] in {"session.status_idle", "session.error"}), None)
                    if terminal and (terminal.get("stop_reason") or {}).get("type") == "requires_action":
                        raise RuntimeError("MA 正在等待工具执行结果。请继续原任务，不要重新发送提示词。")
                await self.ark.send(
                    sid,
                    [
                        {
                            "type": "user.message",
                            "content": inbox.content(message) if inbox is not None else [{"type": "text", "text": message}],
                        }
                    ],
                )
                # A rejected send must leave the previous execution cursor intact.
                if latest.get("data"):
                    self.store.set("cursor:" + sid, latest["data"][0]["id"])
                    for old in reversed(latest["data"]):
                        self.store.event(sid, old)
                        self.store.set("processed:" + sid + ":" + old["id"], True)
            last_activity = time.monotonic()
            first_poll = True
            idle_boundary = False
            while time.monotonic() - last_activity < timeout:
                if wake:
                    wake.clear()
                cursor = self.store.get("cursor:" + sid)
                saved_cursor = cursor
                page = await self.ark.events(sid, cursor)
                events = page.get("data", [])
                # Record the whole page first: a requires_action may precede the
                # tool_use it names within the same page.
                for e in events:
                    self.store.event(sid, e)
                if inbox:
                    inbox.reconcile(events)
                for e in events:
                    if e["type"] in {"user.custom_tool_result", "user.tool_result"}:
                        cid = e.get("custom_tool_use_id") or e.get("tool_use_id")
                        if cid:
                            self.store.save_call(sid, cid, "sent", e)
                if first_poll and not message:
                    # The durable cache plus the tail is the complete known history.
                    # Reconcile old pending gates without downloading every image
                    # and tool result again on each resume.
                    events = self.store.events(sid)
                    # Older versions could advance the cursor before a rejected
                    # user.message. Reconcile pending gates from cloud history.
                    for e in events:
                        self.store.event(sid, e)
                    latest_state = next((e for e in reversed(events) if e["type"] in {
                        "session.status_running", "session.status_idle", "session.error",
                        "session.status_failed", "session.status_terminated",
                    }), None)
                    idle_boundary = bool(latest_state and latest_state["type"] == "session.status_idle"
                                         and (latest_state.get("stop_reason") or {}).get("type") != "requires_action")
                    start = next((i + 1 for i, e in enumerate(events) if e["id"] == saved_cursor), 0)
                    terminal = next((e for e in reversed(events) if e["type"] in {
                        "session.status_idle", "session.error", "session.status_failed",
                        "session.status_terminated", "session.deleted",
                    }), None)
                    reason = (terminal or {}).get("stop_reason") or {}
                    if reason.get("type") == "requires_action" and any(
                        not self.store.call(sid, cid) or self.store.call(sid, cid)[0] != "sent"
                        for cid in reason.get("event_ids", [])
                    ):
                        self.store.set("processed:" + sid + ":" + terminal["id"], False)
                        start = min(start, events.index(terminal))
                    events = events[start:]
                first_poll = False
                # Resume may consume the entire history up to the saved cursor.
                # No new events means keep observing, not that the running turn ended.
                turn_done = idle_boundary or (not message and not events and not cursor and not saved_cursor)
                for e in events:
                    if self.store.get("processed:" + sid + ":" + e["id"]):
                        continue
                    done = await self.handle(sid, e)
                    if e["type"] == "session.status_running" or (e["type"] == "session.status_idle" and not done):
                        turn_done = False
                    last_activity = time.monotonic()
                    self.store.set("cursor:" + sid, e["id"])
                    self.store.set("processed:" + sid + ":" + e["id"], True)
                    # Thread/telemetry events can follow the session's end_turn.
                    # Keep that boundary unless a later session state above
                    # resumes execution or requires a tool result.
                    if done:
                        turn_done = True
                if inbox:
                    # An accepted message can later acquire processed_at without a
                    # new event ID. Re-read history before declaring the turn done.
                    if turn_done and any(m["status"] == "accepted" for m in inbox.list()):
                        history = (await self.ark.events(sid)).get("data", [])
                        for event in history:
                            self.store.event(sid, event)
                        inbox.reconcile(history)
                        latest_state = next((e for e in reversed(history) if e["type"] in {"session.status_running", "session.status_idle"}), None)
                        if latest_state and (latest_state.get("stop_reason") or {}).get("type") == "requires_action":
                            idle_boundary = False
                            continue  # Handle the newly arrived tool gate before input.
                        if latest_state and latest_state["type"] == "session.status_running":
                            turn_done = False
                    switching = (self.model_switch and self.model_switch.pending(sid)
                                 and any(m["status"] == "queued" for m in inbox.list()))
                    if switching and turn_done:
                        await self.model_switch.apply(sid)
                    # Hold follow-ups while a switch waits for the turn to end, so they
                    # run on the newly chosen model rather than steering the old one.
                    sent = False if switching and not turn_done else await inbox.flush(self.ark, sid)
                    if sent:
                        last_activity = time.monotonic()
                        turn_done = False
                    if turn_done and not sent and not inbox.pending():
                        return {"status": "idle", "session_id": sid}
                elif turn_done:
                    return {"status": "idle", "session_id": sid}
                idle_boundary = turn_done
                if wake:
                    try:
                        await asyncio.wait_for(wake.wait(), 1)
                    except TimeoutError:
                        pass
                else:
                    await asyncio.sleep(1)
            raise TimeoutError(
                "MA 长时间没有新进展，已保存执行位置。请继续原任务，无需重新发送提示词。"
            )
