"""Managed Agent Custom Tool registration, execution, and result delivery."""
