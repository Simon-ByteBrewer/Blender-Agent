"""Studio custom tools, one per resource, and the mapping from the earlier tool names.

Sessions are pinned to the Agent version they were created with, so calls may still
arrive as ``local_pipeline`` / ``seedance``. Executors on other hosts may also predate
the split, so calls forwarded to them keep the original ``local_pipeline`` wire format.
"""

BLENDER_PROJECT = "blender_project"
PREVIZ_RENDER = "previz_render"
PREVIZ_SKILL = "previz_skill"
SEEDANCE_VIDEO = "seedance_video"
# Declared on the Agent. The whitebox skill is mounted on the Agent and read with the
# built-in read tool, so PREVIZ_SKILL only serves local_pipeline(action="skill") calls
# from sessions pinned to older Agent versions.
STUDIO_TOOLS = (BLENDER_PROJECT, PREVIZ_RENDER, SEEDANCE_VIDEO)

LEGACY_PIPELINE = "local_pipeline"
LEGACY_SEEDANCE = "seedance"
LEGACY_TOOLS = (LEGACY_PIPELINE, LEGACY_SEEDANCE)

BLENDER_ACTIONS = ("status", "open", "save", "close")
RENDER_ACTIONS = ("all", "preview", "render", "encode", "validate", "status", "artifacts", "extract_frames")
SEEDANCE_ACTIONS = ("portraits", "submit", "status", "download")


def canonical(name, args):
    """Translate a call made with an earlier tool name into the current tool."""
    args = dict(args or {})
    if name == LEGACY_SEEDANCE:
        return SEEDANCE_VIDEO, args
    if name != LEGACY_PIPELINE:
        return name, args
    action = args.get("action")
    if action == "skill":
        return PREVIZ_SKILL, {"path": args["path"]} if args.get("path") else {}
    if action == "save":
        return BLENDER_PROJECT, {"action": "save"}
    if isinstance(action, str) and action.startswith("blender_"):
        return BLENDER_PROJECT, {"action": action.removeprefix("blender_")}
    return PREVIZ_RENDER, args


def wire(name, args):
    """The form sent to a Blender executor: the original local_pipeline contract."""
    args = dict(args or {})
    if name == BLENDER_PROJECT:
        action = args.get("action")
        return LEGACY_PIPELINE, {"action": "save" if action == "save" else "blender_" + str(action)}
    if name == PREVIZ_RENDER:
        return LEGACY_PIPELINE, args
    if name == PREVIZ_SKILL:
        return LEGACY_PIPELINE, {"action": "skill", **({"path": args["path"]} if args.get("path") else {})}
    return name, args
