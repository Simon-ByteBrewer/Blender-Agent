"""Create only missing project-owned MA resources; persist every returned ID immediately."""

import asyncio, hashlib, json
from studio.config import ROOT, RESOURCES, OUTPUT, key_identity
from studio.models import agent_model
from ma_mcp.mcp_bridge import DIRECT
from studio.previs import PREVIS_POLICY
from .skills import ensure_skill, sync_agent_skill, with_guidance, with_skill_reader
from .tool_names import STUDIO_TOOLS, LEGACY_TOOLS, PREVIZ_SKILL

SYSTEM_PROMPT = RESOURCES / "backend/config/ma_system_prompt.md"
# Openings of every system prompt this platform has shipped (the product was renamed
# twice); a prompt without one was written by the user and is never replaced.
SIGNATURE = "MA 导演 Agent 的三维创作助手"
PLATFORM_PROMPTS = (SIGNATURE, "驱动 Seedance 导演 Agent 的三维创作助手", "MA Creative Studio 的三维创作助手", "火山MA-Seedance 导演 Agent 的三维创作助手")


def is_platform_prompt(system):
    head = (system or "")[:300]
    return any(marker in head for marker in PLATFORM_PROMPTS)


def system_prompt(remote=False):
    """The Agent system prompt: ma_system_prompt.md plus the shared previz policy."""
    text = SYSTEM_PROMPT.read_text(encoding="utf-8").strip().replace("{ROOT}", str(ROOT))
    text += "\n\n" + PREVIS_POLICY
    if remote:
        text = text.replace("用户 Mac", "配置的远程服务器").replace(
            f"工程根目录 {ROOT}。", "工程与资源位于远程服务器；从工具结果读取当前项目的实际路径。")
    return text


SYSTEM = system_prompt()


def configured_tools(catalog):
    """Load platform definitions while retaining the live Blender MCP contract."""
    path = RESOURCES / "backend/config/ma_custom_tools.json"
    tools = json.loads(path.read_text(encoding="utf-8"))
    expected = DIRECT | {"blender_tools_list", "blender_tools_call", *STUDIO_TOOLS}
    if (not isinstance(tools, list) or len(tools) != len(expected)
            or any(not isinstance(t, dict) for t in tools)
            or {t.get("name") for t in tools} != expected):
        raise ValueError(f"ma_custom_tools.json 必须声明当前实现的 {len(expected)} 个工具，且名称不能重复")
    discovered = {tool["name"]: tool for tool in catalog}
    for tool in tools:
        if (tool.get("type") != "custom" or not isinstance(tool.get("description"), str)
                or not tool["description"].strip()
                or not isinstance(tool.get("input_schema"), dict)):
            raise ValueError("Custom Tool 必须包含 type=custom、description 和 input_schema")
        if tool["name"] in DIRECT:
            original = discovered.get(tool["name"])
            if original is None:
                raise ValueError("Blender MCP 缺少工具：" + tool["name"])
            tool["input_schema"] = original["inputSchema"]
            tool["description"] += "\n\nBlender MCP 原始说明：\n" + original["description"]
    return with_skill_reader(tools)


def definitions_digest(defs):
    return hashlib.sha256(json.dumps(defs, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


async def sync_tool_definitions(ark, store, config_key, cfg, agent, defs):
    """Replace the Studio-owned tools (current and earlier names) on an existing Agent with
    the configured definitions; tools added by the user are kept. Updates only when the
    configured definitions changed, so repeated setups never create new Agent versions."""
    ours = {t["name"] for t in defs} | set(LEGACY_TOOLS) | {PREVIZ_SKILL}
    current = list(agent.get("tools") or [])
    names = {t.get("name") for t in current if t.get("name") in ours}
    digest = definitions_digest(defs)
    if names == {t["name"] for t in defs} and cfg.get("tool_definitions_digest") == digest:
        return agent
    tools = [t for t in current if t.get("name") not in ours] + defs
    await ark.request("POST", "agents/" + agent["id"], json={"version": agent["version"], "tools": tools})
    agent = await ark.request("GET", "agents/" + agent["id"])
    if {t.get("name") for t in agent.get("tools") or []} >= {t["name"] for t in defs}:
        cfg["tool_definitions_digest"] = digest
    cfg["bundled_skill_agent_version"] = agent["version"]
    store.set(config_key, cfg)
    return agent


async def executor_runs_studio_tools(bridge, environment_id):
    """Self-hosted Workers receive tool calls directly from MA, so an Agent may switch to
    the current tool names only when its Worker supports them. Other modes route through
    this app, which translates names for older executors."""
    if not environment_id:
        return True
    try:
        health = await bridge.request("GET", "/health")
    except Exception:
        return False
    return {"blender_project", "previz_render"} <= set(health.get("tools_supported") or [])


async def sync_system_prompt(ark, store, config_key, cfg, agent, system):
    """Keep a platform-written system prompt current; leave user-written prompts alone."""
    current = agent.get("system") or ""
    if not is_platform_prompt(current):
        return agent
    desired = with_guidance(system)
    if desired == current:
        return agent
    await ark.request("POST", "agents/" + agent["id"], json={"version": agent["version"], "system": desired})
    agent = await ark.request("GET", "agents/" + agent["id"])
    cfg["bundled_skill_agent_version"] = agent["version"]
    store.set(config_key, cfg)
    return agent


async def setup(ark, store, bridge, model=None, environment_id=None, remote_execution=False):
    model = model or agent_model()
    config_key = "platform_ma:" + key_identity()
    if environment_id:
        config_key += ":self_hosted:" + environment_id
    cfg = store.get(config_key, {})
    if environment_id:
        environment = await ark.request("GET", "environments/" + environment_id)
        if environment.get("config", {}).get("type") != "self_hosted":
            raise ValueError("配置的 Environment 不是 self_hosted 类型")
        cfg["environment_id"] = environment_id
    catalog = await bridge.discover()
    defs = configured_tools(catalog)
    (ROOT / "docs").mkdir(exist_ok=True)
    (ROOT / "docs/ma_tools.json").write_text(
        json.dumps(defs, ensure_ascii=False, indent=2)
    )
    reference = await ensure_skill(ark, store, config_key, cfg)
    system = system_prompt(remote=bool(environment_id or remote_execution))
    if not cfg.get("agent_id"):
        a = await ark.request(
            "POST",
            "agents",
            json={
                "name": "MA 导演 Agent",
                "model": {"id": model},
                "system": with_guidance(system),
                "tools": defs,
                "skills": [reference],
            },
        )
        cfg.update(agent_id=a["id"], model=model, tool_definitions_digest=definitions_digest(defs))
        store.set(config_key, cfg)
    a = await sync_agent_skill(ark, store, config_key, cfg, reference)
    if await executor_runs_studio_tools(bridge, environment_id):
        a = await sync_tool_definitions(ark, store, config_key, cfg, a, defs)
        a = await sync_system_prompt(ark, store, config_key, cfg, a, system)
    config_dir = OUTPUT / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    (config_dir / "platform_agent_verified.json").write_text(
        json.dumps(a, ensure_ascii=False, indent=2)
    )
    if not cfg.get("environment_id"):
        e = await ark.request(
            "POST",
            "environments",
            json={
                "name": ("studio-cloud-" if remote_execution else "studio-mac-") + cfg["agent_id"],
                "config": {"type": "cloud", "networking": {"type": "unrestricted"}},
            },
        )
        cfg["environment_id"] = e["id"]
        store.set(config_key, cfg)
    print(json.dumps(cfg, ensure_ascii=False))
    # Transient, authoritative snapshot for Session creation; do not persist it
    # as account configuration or reuse it after a later Agent update.
    return {**cfg, "session_base_agent": {k: a.get(k) for k in ("id", "version", "model")}}


if __name__ == "__main__":
    from studio.ark import Ark
    from studio.store import Store
    from ma_mcp.mcp_bridge import MCPBridge

    asyncio.run(setup(Ark(), Store(), MCPBridge()))
