"""Local favorites from the official Seedance virtual portrait library (and authorized real people).

Ark documents no API key endpoint for browsing the official library; it is searched in the
console Experience Center, and each portrait is passed to the model as asset://<asset ID>.

Only the asset reference and a display name are stored; the media stays in Ark.
"""

import re
import time
import uuid

KEY = "seedance:portraits"
ASSET_ID = re.compile(r"asset-\d{14}-[A-Za-z0-9]{3,40}")
KINDS = {"image", "video"}
MAX_PORTRAITS = 200


def normalize_asset(value):
    """Accept an ID, a URI, or text copied from the console (e.g. its API sample)."""
    match = ASSET_ID.search(value or "")
    if not match:
        raise ValueError("未找到素材 ID，格式应为 asset-xxxx 或 asset://asset-xxxx")
    return match[0]


class Portraits:
    def __init__(self, store):
        self.store = store

    def list(self):
        return self.store.get(KEY, [])

    def add(self, name, asset_id, kind="image", note=""):
        name = (name or "").strip()
        if not name or len(name) > 60:
            raise ValueError("请填写 1–60 字的人像名称")
        if kind not in KINDS:
            raise ValueError("素材类型只能是图片或视频")
        asset_id = normalize_asset(asset_id)
        items = self.list()
        if any(i["asset_id"] == asset_id for i in items):
            raise ValueError("该素材 ID 已在人像库中")
        if len(items) >= MAX_PORTRAITS:
            raise ValueError(f"人像库最多保存 {MAX_PORTRAITS} 个素材")
        item = {"id": uuid.uuid4().hex[:12], "name": name, "asset_id": asset_id, "kind": kind,
                "note": (note or "").strip()[:200], "created_at": time.time()}
        self.store.set(KEY, [*items, item])
        return item

    def remove(self, portrait_id):
        items = self.list()
        kept = [i for i in items if i["id"] != portrait_id]
        if len(kept) == len(items):
            raise KeyError(portrait_id)
        self.store.set(KEY, kept)
