"""Elapsed-time estimates, never a claim of provider-reported progress."""
import statistics
import time
from studio.config import key_identity

TERMINAL = {"succeeded", "failed", "expired", "cancelled"}


def timing_key(resolution):
    return f"seedance:timing:{key_identity()}:{resolution}"


def estimate(store, duration, resolution):
    samples = store.get(timing_key(resolution), [])
    # Initial heuristic only; replace with observed successful tasks as available.
    seconds_per_second = statistics.median(samples) if samples else (30 if resolution == "1080p" else 20)
    return max(60, round(duration * seconds_per_second)), "history" if samples else "initial"


def observe_completion(store, saved, result):
    if result.get("status") not in TERMINAL or saved.get("completed_at"):
        return
    saved["completed_at"] = time.time()
    if result["status"] == "succeeded" and saved.get("submitted_at"):
        elapsed = saved["completed_at"] - saved["submitted_at"]
        if 0 < elapsed < 86400:
            k = timing_key(saved.get("resolution", "720p"))
            samples = store.get(k, [])
            store.set(k, [*samples, elapsed / max(1, saved.get("duration", 8))][-20:])


def progress(saved, now=None):
    now = time.time() if now is None else now
    started = saved.get("submitted_at")
    elapsed = max(0, (saved.get("completed_at") or now) - started) if started else 0
    expected = saved.get("estimated_seconds", 0)
    status = saved.get("status", "queued")
    terminal = status in TERMINAL
    return {
        "status": status,
        "started_at": started,
        "elapsed_seconds": round(elapsed),
        "estimated_seconds": expected,
        "estimate_source": saved.get("estimate_source", "unknown"),
        "percent": 100 if status == "succeeded" else min(99, int(100 * elapsed / expected)) if expected else 0,
        "remaining_seconds": max(0, round(expected - elapsed)) if expected and not terminal else None,
        "finished": terminal,
    }
