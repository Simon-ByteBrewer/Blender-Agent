"""Local equivalent of the trace's ordered ComposeVideo step (no model call)."""

import asyncio
import json
from pathlib import Path
import uuid

from studio.config import output_path


def clip_paths(directory, clips):
    if not isinstance(clips, list) or not 1 <= len(clips) <= 50:
        raise ValueError("clips 需要 1–50 个按播放顺序排列的项目视频文件名")
    root = output_path(directory)
    paths = []
    for name in clips:
        if not isinstance(name, str):
            raise ValueError("clips 必须包含项目视频文件名字符串")
        path = (root / name).resolve()
        if not path.is_relative_to(root) or path.suffix.lower() not in {".mp4", ".mov"} or not path.is_file():
            raise ValueError(f"合成视频必须是当前项目内已有的 MP4/MOV：{name}")
        paths.append(path)
    return paths


async def command(*args, timeout=300):
    proc = await asyncio.create_subprocess_exec(*args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout)
    except BaseException:
        if proc.returncode is None:
            proc.kill()
        await proc.wait()
        raise
    if proc.returncode:
        raise ValueError("视频合成失败：" + stderr.decode(errors="replace")[-1500:])
    return stdout


async def compose(directory, clips, resolution="720p", ratio="16:9"):
    paths = clip_paths(directory, clips)
    if resolution not in {"480p", "720p", "1080p"} or ratio not in {"16:9", "9:16", "1:1", "4:3", "3:4", "21:9"}:
        raise ValueError("合成需要明确的分辨率和画面比例")
    height = int(resolution[:-1])
    x, y = map(int, ratio.split(":"))
    width = round(height * x / y / 2) * 2
    inputs, filters, streams = [], [], []
    total = 0
    for i, path in enumerate(paths):
        metadata = json.loads(await command("ffprobe", "-v", "error", "-show_entries",
                                            "stream=codec_type:format=duration", "-of", "json", str(path), timeout=10))
        duration = float(metadata["format"]["duration"])
        if not any(s.get("codec_type") == "video" for s in metadata["streams"]) or not 0 < duration <= 1200:
            raise ValueError(f"无法合成无效视频：{path.name}")
        total += duration
        if total > 1200:
            raise ValueError("单次合成总时长不能超过 20 分钟")
        inputs += ["-i", str(path)]
        filters.append(f"[{i}:v:0]scale={width}:{height}:force_original_aspect_ratio=decrease,"
                       f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=24,format=yuv420p,"
                       f"setpts=PTS-STARTPTS[v{i}]")
        if any(s.get("codec_type") == "audio" for s in metadata["streams"]):
            filters.append(f"[{i}:a:0]aresample=48000,aformat=channel_layouts=stereo,"
                           f"apad,atrim=duration={duration},asetpts=PTS-STARTPTS[a{i}]")
        else:
            filters.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={duration},asetpts=PTS-STARTPTS[a{i}]")
        streams.append(f"[v{i}][a{i}]")
    filters.append("".join(streams) + f"concat=n={len(paths)}:v=1:a=1[v][a]")
    name = "composed_" + uuid.uuid4().hex[:12] + ".mp4"
    dest = output_path(str(Path(directory) / name))
    temp = dest.with_suffix(".part.mp4")
    try:
        await command("ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y", *inputs,
                      "-filter_complex", ";".join(filters), "-map", "[v]", "-map", "[a]",
                      "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-c:a", "aac",
                      "-movflags", "+faststart", str(temp), timeout=max(300, total * 3))
        temp.replace(dest)
    finally:
        temp.unlink(missing_ok=True)
    return {"artifact": "/artifacts/" + str(Path(directory) / name), "clips": clips,
            "duration": round(total, 3), "resolution": resolution, "ratio": ratio}
