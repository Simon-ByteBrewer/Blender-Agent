"""Upload MA-session references through Ark's managed storage using its API Key."""

import asyncio
import hashlib
import re
import time
from urllib.parse import urlsplit

from studio.config import key_identity


class FilesUploader:
    def __init__(self, ark, store):
        self.ark, self.store = ark, store

    async def download_url(self, sid, fid):
        params = {"purpose": "agent", "scope_id": sid, "limit": 100}
        seen = set()
        for _ in range(100):
            result = await self.ark.request("GET", "files", params=params)
            for item in result.get("data", []):
                if item.get("id") == fid:
                    url = item.get("download_url") or ""
                    parsed = urlsplit(url)
                    if parsed.scheme == "https" and parsed.hostname and not parsed.username and not parsed.password:
                        return url
                    return None
            after = result.get("last_id")
            if not result.get("has_more") or not after or after in seen:
                return None
            seen.add(after)
            params["after"] = after
        raise RuntimeError("方舟文件列表分页超过限制")

    async def upload(self, path, sid):
        if not re.fullmatch(r"sesn-[A-Za-z0-9-]+", sid or ""):
            raise ValueError("自动上传需要当前项目的 MA Session；请先运行 MA 场景创作")

        def digest():
            value = hashlib.sha256()
            with path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    value.update(chunk)
            return value.hexdigest()

        cache_key = f"seedance_upload:{key_identity()}:{sid}:{await asyncio.to_thread(digest)}"
        cached = self.store.get(cache_key, {})
        fid = cached.get("file_id")
        if cached.get("expire_at", 0) <= time.time() + 3600:
            fid = None
        if not fid:
            # A session-scoped upload registers a managed file with a signed URL.
            # Ordinary Files uploads and resource-mounted copies don't expose one.
            with path.open("rb") as stream:
                result = await self.ark.request(
                    "POST", "files", headers={"Ark-Agent-Session-Id": sid},
                    data={"purpose": "agent"},
                    files={"file": (path.name, stream, "video/quicktime" if path.suffix.lower() == ".mov" else "video/mp4")},
                )
            fid = result["id"]
            self.store.set(cache_key, {"file_id": fid, "expire_at": result.get("expire_at", time.time() + 86400)})
        deadline = time.monotonic() + 120
        while True:
            url = await self.download_url(sid, fid)
            if url:
                return url
            detail = await self.ark.request("GET", "files/" + fid)
            if detail.get("status") == "failed":
                raise ValueError(f"方舟参考视频上传处理失败：{detail.get('error') or fid}")
            if time.monotonic() >= deadline:
                raise TimeoutError(f"方舟尚未返回参考视频下载地址（{fid}）；文件 ID 已保存，可重试当前上传")
            await asyncio.sleep(2)
