"""Shared Seedance submission module for the MA tool and HTTP/CLI callers."""

import base64, io, json, re, time, httpx
from pathlib import Path
from studio.config import output_path, OUTPUT, key_identity, platform
from studio.media import video_metadata, audio_metadata
from .files import FilesUploader
from .progress import estimate, observe_completion, progress

MODEL = "doubao-seedance-2-5-260628"


def model():
    """Seedance 2.5 is published under a different model ID on each platform."""
    return platform()["seedance_model"]
PROMPT = "参考视频是 Blender 轻量 3D 预演。遵循其空间结构、尺度、遮挡关系、人物数量与占位/走位、构图、相机运动、机位切换和剪辑节奏。灰模和简模人物只表示空间与动作，不是最终外观；根据场景内容描述补全真实材质、人物外观、建筑与环境细节和自然光照。保留指定的场景和视觉风格，保持时序稳定，不增加字幕或标题。"
RESOLUTIONS = {"480p", "720p", "1080p"}
RATIOS = {"16:9", "4:3", "1:1", "3:4", "9:16", "21:9", "adaptive"}
# Seedance 2.5 omni-reference limits.
MAX_IMAGES, MAX_VIDEOS, MAX_VIDEO_SECONDS = 30, 10, 30
MAX_AUDIOS = 10
MAX_VIDEO_BYTES = 200 * 1024 * 1024
ASSET = re.compile(r"asset://asset-[A-Za-z0-9-]{4,120}")
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp"}
VIDEO_SUFFIXES = {".mp4", ".mov"}
AUDIO_SUFFIXES = {".wav", ".mp3"}
MODES = {"auto", "reference", "extend", "edit"}


def generation_settings(prompt, duration, ratio, mode):
    """Translate GenVideo-style intent into the public Seedance 2.5 contract."""
    if mode not in MODES:
        raise ValueError("mode must be auto, reference, extend or edit")
    if ratio == "auto":
        ratio = "adaptive"  # MA GenVideo's spelling differs from the public API.
    if mode in {"extend", "edit"}:
        ratio = "adaptive"
    if mode == "extend":
        if duration == -1:
            raise ValueError("视频延长必须指定新增时长 4–30 秒")
        prompt = f"向后延长视频1，新增 {duration} 秒，从视频1的实际结尾自然延续画面、动作、镜头和声音。\n\n{prompt}"
    if mode == "edit":
        duration = -1
        prompt = f"编辑视频1，保持原视频时长和宽高比，按以下要求修改：\n\n{prompt}"
    return prompt, duration, ratio


def remote_source(kind, url):
    """True for sources Ark fetches itself; local project files need preparation."""
    if url.startswith("https://") or ASSET.fullmatch(url):
        return True
    if kind == "image" and url.startswith("data:image/"):
        return True
    if kind == "audio" and url.startswith(("data:audio/wav;base64,", "data:audio/mp3;base64,", "data:audio/mpeg;base64,")):
        return True
    if url.startswith(("http://", "asset://", "data:")):
        if kind == "audio":
            raise ValueError("参考音频仅支持 HTTPS、asset:// 或 MP3/WAV Base64")
        raise ValueError(
            "参考视频仅支持 HTTPS 地址、asset:// 或项目内视频（自动上传）；视频不支持 Base64"
            if kind == "video" else "参考图仅支持 HTTPS 地址、asset:// 素材或本项目图片"
        )
    return False


def payload(prompt=PROMPT, *, images=(), videos=(), audios=(), duration=12, resolution="720p",
            ratio="16:9", generate_audio=False, mode="auto"):
    prompt, duration, ratio = generation_settings(prompt, duration, ratio, mode)
    if isinstance(duration, bool) or not isinstance(duration, int) or (duration != -1 and not 4 <= duration <= 30):
        raise ValueError("duration must be -1 or 4–30 seconds")
    if resolution not in RESOLUTIONS:
        raise ValueError("resolution must be 480p, 720p or 1080p")
    if ratio not in RATIOS:
        raise ValueError("ratio is not supported by Seedance 2.5")
    if len(images) > MAX_IMAGES or len(videos) > MAX_VIDEOS or len(audios) > MAX_AUDIOS:
        raise ValueError(f"最多 {MAX_IMAGES} 张参考图、{MAX_VIDEOS} 个参考视频、{MAX_AUDIOS} 个参考音频")
    if mode in {"extend", "edit"} and not videos:
        raise ValueError("视频延长/编辑需要至少一个参考视频，视频1为待处理视频")
    for kind, urls in (("image", images), ("video", videos), ("audio", audios)):
        for url in urls:
            if not remote_source(kind, url):
                raise ValueError(
                    "Reference video must be an HTTPS URL or asset://; local paths and Base64 are unsupported"
                    if kind == "video" else "Reference image must be HTTPS, asset:// or a Base64 data URL"
                )
    content = [{"type": "text", "text": prompt}]
    content += [{"type": "image_url", "image_url": {"url": u}, "role": "reference_image"} for u in images]
    content += [{"type": "video_url", "video_url": {"url": u}, "role": "reference_video"} for u in videos]
    content += [{"type": "audio_url", "audio_url": {"url": u}, "role": "reference_audio"} for u in audios]
    return {
        "model": model(),
        "content": content,
        "duration": duration,
        "ratio": ratio,
        "resolution": resolution,
        "generate_audio": generate_audio,
        "watermark": False,
        **({"omni_reference_task_type": mode} if images or videos or audios else {}),
    }


def check_image(path):
    """Seedance requires 300–6000 px sides and a 0.4–2.5 aspect ratio; fail before submitting."""
    from PIL import Image
    if path.stat().st_size > 30 * 1024 * 1024:
        raise ValueError(f"参考图超过 30 MB：{path.name}")
    try:
        with Image.open(path) as image:
            width, height = image.size
    except OSError as exc:
        raise ValueError(f"无法读取参考图：{path.name}") from exc
    if not 0.4 <= width / height <= 2.5:
        raise ValueError(f"参考图宽高比需在 0.4–2.5 之间：{path.name}")
    if min(width, height) < 300:
        raise ValueError(f"参考图短边至少 300 像素（当前 {width}×{height}）：{path.name}")


def image_data_url(path):
    """Seedance accepts Base64 images, so local references never need object storage."""
    from PIL import Image, ImageOps
    with Image.open(path) as original:
        image = ImageOps.exif_transpose(original).convert("RGBA")
    background = Image.new("RGB", image.size, "white")
    background.paste(image, mask=image.getchannel("A"))
    background.thumbnail((2048, 2048))
    output = io.BytesIO()
    background.save(output, format="JPEG", quality=90, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(output.getvalue()).decode("ascii")


def legacy_references(reference, source):
    return [{"type": "video", "source": source or reference}]


class Seedance:
    def __init__(self, ark, store):
        self.ark = ark
        self.store = store
        self.files_uploader = FilesUploader(ark, store)

    def _local(self, kind, name, directory):
        p = output_path(str(Path(directory or "") / name))
        suffixes = {"image": IMAGE_SUFFIXES, "video": VIDEO_SUFFIXES, "audio": AUDIO_SUFFIXES}[kind]
        if p.suffix.lower() not in suffixes or not p.is_file():
            raise ValueError(f"参考{'图' if kind == 'image' else '音频' if kind == 'audio' else '视频'}不存在或格式不支持：{name}")
        if kind == "image":
            check_image(p)
        if kind == "audio" and not 0 < p.stat().st_size <= 15 * 1024 * 1024:
            raise ValueError(f"参考音频必须非空且不超过 15 MB：{name}")
        if kind == "video":
            if p.stat().st_size == 0 or p.stat().st_size > MAX_VIDEO_BYTES:
                raise ValueError(f"参考视频必须非空且不超过 200 MB：{name}")
        return p

    def resolve(self, references, directory=None, mode="auto"):
        """Validate every reference before any upload or billable request."""
        items, seconds = [], {"video": 0.0, "audio": 0.0}
        for ref in references:
            kind, source = ref.get("type"), (ref.get("source") or "").strip()
            if kind not in {"image", "video", "audio"} or not source:
                raise ValueError("参考素材需要 type=image|video|audio 和 source")
            if remote_source(kind, source):
                items.append((kind, source, None))
                continue
            p = self._local(kind, source, directory)
            if kind in {"video", "audio"}:
                meta = video_metadata(p) if kind == "video" else audio_metadata(p)
                if kind == "audio" and not meta:
                    raise ValueError(f"无法读取参考音频时长，请检查文件及 ffprobe：{source}")
                if meta:
                    minimum = 4 if kind == "video" and mode == "edit" else 2
                    if not minimum <= meta["duration"] <= MAX_VIDEO_SECONDS:
                        if kind == "audio":
                            raise ValueError(f"单个参考音频需为 2–30 秒：{source}")
                        if mode == "edit":
                            raise ValueError(f"编辑参考视频需为 4–30 秒：{source}")
                        raise ValueError(f"单个参考视频需为 2–30 秒：{source}（{meta['duration']:.1f} 秒）")
                    seconds[kind] += meta["duration"]
            items.append((kind, source, p))
        for kind, total in seconds.items():
            if total > MAX_VIDEO_SECONDS:
                raise ValueError(f"参考{'视频' if kind == 'video' else '音频'}总时长不能超过 30 秒（当前 {total:.1f} 秒）")
        images = [i for i in items if i[0] == "image"]
        videos = [i for i in items if i[0] == "video"]
        audios = [i for i in items if i[0] == "audio"]
        if len(images) > MAX_IMAGES or len(videos) > MAX_VIDEOS or len(audios) > MAX_AUDIOS:
            raise ValueError(f"最多 {MAX_IMAGES} 张参考图、{MAX_VIDEOS} 个参考视频、{MAX_AUDIOS} 个参考音频")
        if mode in {"extend", "edit"} and not videos:
            raise ValueError("视频延长/编辑需要至少一个参考视频，视频1为待处理视频")
        return images, videos, audios

    def validate(self, reference="reference.mp4", prompt=PROMPT, duration=12, source=None,
                 resolution="720p", ratio="16:9", generate_audio=False, references=None,
                 directory=None, mode="auto", upload_session_id=None):
        if not prompt.strip():
            raise ValueError("请填写视频提示词。")
        # Validate settings before touching files or uploading. Reference presence
        # is checked by resolve after the legacy reference has been expanded.
        effective_prompt, effective_duration, effective_ratio = generation_settings(prompt, duration, ratio, mode)
        payload(effective_prompt, duration=effective_duration, resolution=resolution,
                ratio=effective_ratio, generate_audio=generate_audio)
        if references is None:
            references = legacy_references(reference, source)
        resolved = self.resolve(references, directory, mode)
        if any(p for _, _, p in resolved[1]) and not upload_session_id:
            raise ValueError("本地参考视频通过当前项目的 MA Session 自动上传，只需现有 API Key。请先运行 MA 场景创作。")
        return resolved

    async def submit(self, reference="reference.mp4", prompt=PROMPT, duration=12, source=None,
                     project_id=None, resolution="720p", ratio="16:9", generate_audio=False,
                     references=None, directory=None, mode="auto", upload_session_id=None):
        source = (source or "").strip() or None
        images, videos, audios = self.validate(reference, prompt, duration, source, resolution, ratio,
                                               generate_audio, references, directory, mode, upload_session_id)
        image_urls = [image_data_url(p) if p else s for _, s, p in images]
        video_urls = [await self.files_uploader.upload(p, upload_session_id) if p else s
                      for _, s, p in videos]
        audio_urls = [f"data:audio/{p.suffix[1:].lower()};base64," + base64.b64encode(p.read_bytes()).decode("ascii")
                      if p else s for _, s, p in audios]
        body = payload(prompt, images=image_urls, videos=video_urls, audios=audio_urls, duration=duration,
                       resolution=resolution, ratio=ratio, generate_audio=generate_audio, mode=mode)
        if len(json.dumps(body).encode()) > 64 * 1024 * 1024:
            raise ValueError("参考素材请求体超过 64 MB，请减少素材或使用 HTTPS 地址")
        submitted_at = time.time()
        result = await self.ark.request("POST", "contents/generations/tasks", json=body)
        tid = result["id"]
        estimated_seconds, estimate_source = estimate(self.store, 12 if body["duration"] == -1 else body["duration"], resolution)
        self.store.set(
            "seedance:" + tid,
            {
                "id": tid,
                "reference": reference,
                "directory": directory,
                "references": [{"type": k, "source": s if p else ("[Base64]" if s.startswith("data:") else s[:200])} for k, s, p in images + videos + audios],
                "project_id": project_id,
                "credential_scope": key_identity(),
                "prompt": body["content"][0]["text"],
                "requested_prompt": prompt,
                "model": model(),
                "mode": mode,
                "status": "submitted",
                "duration": body["duration"],
                "resolution": resolution,
                "ratio": body["ratio"],
                "submitted_at": submitted_at,
                "estimated_seconds": estimated_seconds,
                "estimate_source": estimate_source,
            },
        )
        return {"id": tid, "status": "submitted"}

    async def status(self, tid):
        if not re.fullmatch(r"[A-Za-z0-9_-]+", tid):
            raise ValueError("Invalid task ID")
        result = await self.ark.request("GET", "contents/generations/tasks/" + tid)
        saved = self.store.get("seedance:" + tid, {})
        observe_completion(self.store, saved, result)
        saved.update(result)
        self.store.set("seedance:" + tid, saved)
        return {**result, "studio_progress": progress(saved)}

    async def download(self, tid):
        r = await self.status(tid)
        if r.get("status") != "succeeded":
            raise ValueError("Video task has not succeeded")
        url = r["content"]["video_url"]
        saved = self.store.get("seedance:" + tid, {})
        if saved.get("directory"):
            parent = Path(saved["directory"])
        else:
            reference = saved.get("reference", "reference.mp4")
            parent = Path(reference).parent if saved.get("project_id") else Path()
        dest = output_path(str(parent / ("seedance_" + tid + ".mp4")))
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_suffix(".part")
        async with httpx.AsyncClient(timeout=120, follow_redirects=True) as c:
            async with c.stream("GET", url) as resp:
                resp.raise_for_status()
                with tmp.open("wb") as f:
                    async for chunk in resp.aiter_bytes():
                        f.write(chunk)
        tmp.replace(dest)
        return {"artifact": "/artifacts/" + str(dest.relative_to(OUTPUT))}
