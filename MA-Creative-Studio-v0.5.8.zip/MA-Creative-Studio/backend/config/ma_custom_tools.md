# 1. MA Custom Tool 配置

[`ma_custom_tools.json`](ma_custom_tools.json) 是 MA Agent 的工具声明入口，[`ma_system_prompt.md`](ma_system_prompt.md) 是 Agent 的系统提示词。当前共 9 个工具：4 个 Blender MCP 原版工具、2 个 MCP 扩展入口，以及按资源划分的 3 个平台工具 `blender_project`、`previz_render`、`seedance_video`。白模技能 `blender-whitebox-previz` 以 Agent Skill 挂载，不需要单独的读取工具（见 3.3）。

MA 决定何时调用工具，业务后端或 Self-hosted Worker 执行操作，再将真实结果返回原 Session。项目、场景、凭证和输出目录由宿主绑定，模型不需要传入 API Key、项目 ID 或任意宿主路径。

## 1.1 配置格式与加载

文件顶层是工具数组，每项包含 `type: "custom"`、`name`、`description`、`input_schema`，对应 Agent 的 `tools` 字段。加载入口是 [`configured_tools()`](../src/ma_custom_tools/setup_ma.py)，要求这 9 个工具各出现一次。

- 4 个 Blender 专用工具：JSON 中保留输入 schema 快照供查阅；初始化时以 `bridge.discover()` 返回的实时 `inputSchema` 替换，并追加 MCP 原始说明，避免插件参数变化后调用失配。
- 其余 5 个工具使用 JSON 中的说明和 schema。
- 系统提示词：`setup_ma.system_prompt()` 读取 `ma_system_prompt.md`，替换 `{ROOT}`，追加 [`PREVIS_POLICY`](../src/studio/previs.py)，再附加技能指引块。远程执行环境会把「用户 Mac」和工程根目录替换为远程服务器的说法。`PREVIS_POLICY` 同时在工具返回边界下发给已有 Session。
- `docs/ma_tools.json` 是初始化生成的最终声明快照，不是配置源。
- 配置从 `STUDIO_RESOURCE_ROOT` 对应资源目录读取；`STUDIO_HOME` 控制用户状态和产物目录。

新增工具或 `action` 时必须同时实现执行路由；只增加声明不会产生执行能力。JSON Schema 描述模型调用契约，实际约束由执行器负责。

## 1.2 设计原则

按 [Managed Agents 工具最佳实践](https://platform.claude.com/docs/en/managed-agents/tools#best-practices-for-custom-tool-definitions) 组织：

- **按资源划分，只合并相关操作**：Blender 进程与工程、预演渲染与产物、Seedance 成片各一个工具。此前的 `local_pipeline` 混合了 4 类资源，部分参数只对个别 action 有效，容易选错动作或传错参数。
- **详细说明**：每个平台工具说明「做什么、何时用、何时不用」、参数含义、限制和后续步骤。
- **资源前缀命名**：`blender_*`、`previz_*`、`seedance_*`。
- **不重复平台能力**：已挂载的 Skill 由 MA 内置 `read` 读取，不再用自定义工具重复提供。
- **只返回高价值信息**：`previz_render status` 只返回运行状态、最近 5 个任务的精简字段和视频文件名；`artifacts` 只返回名称、大小和视频元数据；`seedance_video status` 只返回状态、进度和错误，不返回签名下载地址。

# 2. 工具列表

| 编号 | 工具 | 使用场景 | 主要参数 | 返回内容及判断方式 |
| --- | --- | --- | --- | --- |
| 1 | `get_scene_info` | 开始创作、恢复工程或修改前检查当前场景 | `user_prompt`：用户原话；必填项以实时 MCP schema 为准 | 实际场景信息；不表示完成建模 |
| 2 | `get_object_info` | 查看已有对象详情 | `object_name`；可选 `user_prompt` | 指定对象的信息；名称来自真实查询结果 |
| 3 | `execute_blender_code` | 建模、材质、灯光、相机及动画编辑 | `code`；可选 `user_prompt` | 代码执行输出；还需截图检查、保存和渲染 |
| 4 | `get_viewport_screenshot` | 检查构图与视觉效果 | 可选 `max_size`、`user_prompt` | 当前视口图像；不是成片视频 |
| 5 | `blender_tools_list` | 发现允许调用的扩展工具 | 无，传 `{}` | 工具名、说明和参数 schema |
| 6 | `blender_tools_call` | 调用资产搜索、下载、贴图等扩展能力 | `name`；可选 `arguments` | 原工具结果；遵循发现的 schema 和平台白名单 |
| 7 | `blender_project` | 本项目 Blender 进程与 .blend 工程 | `action`：`status` / `open` / `save` / `close` | Blender 与 MCP 状态，或保存结果 |
| 8 | `previz_render` | 预演渲染、任务查询、产物列表、视频抽帧 | `action`；`extract_frames` 需 `artifact`，可选 `timestamps` | 异步任务 ID、精简状态、产物列表或带时间戳图片 |
| 9 | `seedance_video` | Seedance 2.5 成片生成、查询、下载，人像库 | `action`；`submit` 的 `prompt`、`references`、`duration`、`resolution`、`ratio`、`generate_audio`；`status/download` 需 `task_id` | 任务 ID、精简进度或已下载产物路径 |

`user_prompt` 应保留用户原话，不用模型自己的子计划替换。原版 MCP 工具名保持不变，避免改变现有路由及历史工具事件的含义。

# 3. 平台工具用法

## 3.1 blender_project

每个项目有独立的 Blender 进程。首次调用任一 Blender 工具时平台自动启动、加载项目场景并连接 MCP（冷启动最多等待 90 秒），因此通常无需先调用本工具。启动失败作为工具错误返回 MA，由 MA 重试；用户发送消息不再等待 Blender。

| action | 作用 |
| --- | --- |
| `status` | 只读返回 `running`、`mcp_connected`、`launching` |
| `open` | 显式启动并等待连接；用于预热冷启动或连接超时后重试 |
| `save` | 保存项目场景到 .blend 并登记版本 |
| `close` | 先保存，再只结束本项目的 Blender 进程；无法保存（未连接）时报错并保留进程，不丢弃未保存的工作 |

若 MA 新建场景并删除了项目场景，激活和启动时会把文件中的场景接管为项目场景，而不是拒绝打开工程。

## 3.2 previz_render

| action | 作用 | 后续操作 |
| --- | --- | --- |
| `all` | 异步完成渲染、编码和校验（生成参考视频的默认选择） | 查 `status` |
| `preview` | 异步生成预览帧 | 查 `status`、`artifacts` |
| `render` / `encode` / `validate` | 分别渲染动画帧、编码已有帧、校验已有视频 | 查 `status` |
| `status` | `running`、最近 5 个渲染任务（`id`、`status`、`error`、`result`）、视频文件名 | 不用 MA Session 状态代替 |
| `artifacts` | 产物名称、大小、视频时长与分辨率 | 用真实文件名调用 `extract_frames` |
| `extract_frames` | 只读抽取已生成 MP4 的最多 3 帧 | 见下文 |

提交渲染前若有运行中的任务会报错，避免重复提交。`preview`、`render`、`all` 会先激活并保存工程。

### extract_frames 细节

用于 Blender 预演交付前检查运镜、构图、人物位置和遮挡。执行器负责提供真实画面，支持图像输入的 MA 模型结合用户要求判断；工具不自动给出质量分数。

执行链路为 `studio.app.dispatch` → `studio.video_frames.extract_frames` → FFmpeg 子进程，直接读取已生成的 MP4。视频在本机则由本机后端执行，在 Elsa 则转发至 Elsa 执行端；不调用 Blender/MCP，不打开 `.blend`，不触发渲染。元数据由 FFprobe 读取，图片压缩由 Pillow 完成。

```json
{"action": "extract_frames", "artifact": "example.mp4", "timestamps": [0.5, 3.0, 6.0]}
```

- `artifact`：必填，使用当前项目 `artifacts` 返回的 MP4 `name`；示例名称需替换为真实产物。不接受绝对路径、跨项目路径、隐藏路径。
- `timestamps`：可选，1–3 个非负有限秒数，且必须小于视频时长；省略时取时长的 10%、50%、90%。
- 返回 text 元数据及 image 内容块，含 `requested_timestamp` 和实际解码帧的 `timestamp`。帧落点可能因帧率略晚于请求时间。
- 单张图像最长边不超过 960 像素，编码后最多 120 KiB，最多 3 张，给整体 512 KiB 事件预算保留空间。
- 每帧 FFmpeg 操作最多 20 秒；超时或取消会清理子进程。抽帧期间视频发生变化则报错，避免将不同版本混为一组。
- 本地已有视频直接读取；远程项目中本地不存在的视频转发至对应执行端。Self-hosted 的抽帧事件由业务后端分发，Worker 跳过该 action，避免重复执行。
- 仅检查返回的采样画面，不表示连续运动、全部遮挡或整段视频通过验收；可继续对可疑片段补取时间点。


## 3.3 白模技能（无需工具）

`blender-whitebox-previz` 以 Agent Skill 挂载（`skills.ensure_skill()` 上传并绑定版本）。Session 中 MA 用内置 `read` 读取：托管环境位于 `/mnt/skills/blender-whitebox-previz/`，Self-hosted 由 Worker 安装在 Session 工作目录的 `./skills/blender-whitebox-previz/`。截至 2026-10-08，本机 22 个历史 Session 均使用过内置工具，读取技能的 61 次中有 33 次走内置 `read` / `bash`，与旧的 `local_pipeline(action="skill")` 重复，因此不再声明单独的技能读取工具。

技能中的辅助脚本（`wb_lib` 等）由平台安装在 Blender 执行端，激活项目时加入 Blender 的 Python 路径，`execute_blender_code` 中直接 `import wb_lib`，与 MA 读取文档的路径无关。

## 3.4 seedance_video

使用 `doubao-seedance-2-5-260628`，会产生按量费用，只在用户明确要求时 `submit`。

| action | 作用 |
| --- | --- |
| `portraits` | 列出本地人像库：`name`、`type`、`source`（`asset://…`） |
| `submit` | 提交生成，返回任务 ID |
| `status` | 精简状态与进度；成功时提示调用 `download` |
| `download` | 将成功的视频保存到项目 |
| `compose` | 按 clips 文件名列表顺序拼接项目内已下载的片段，保留原声；返回 job_id，用 status + job_id 查询 |

`submit` 参数：

- `references`：有序素材 `[{type: image|video|audio, source}]`。`source` 可为项目内文件名、`https://` 地址或 `asset://asset-…`。省略时使用当前项目最新的 Blender 预演视频作为视频1；空数组为纯文生视频。本地图片、音频以 Base64 提交；本地视频通过当前项目 MA Session 的 Files API 自动上传，无需 AK/SK。
- `prompt`：用「图片N」「视频N」「音频N」按同类素材顺序引用素材，不写素材 ID。
- `mode`：auto 默认判断；reference 参考生成；extend 从视频1实际结尾向后延长，duration 为新增4–30秒；edit 编辑视频1并保持原时长。延长/编辑自动使用 adaptive，编辑自动使用 duration=-1。
- `duration`：4–30 秒或 `-1`（模型自动）；`resolution`：480p / 720p / 1080p；`ratio`：默认 16:9；`generate_audio`：默认 false。
- 上限30张图、10个视频、10个音频，视频与音频各自合计≤30秒。本地音频支持MP3/WAV、单个2–30秒且≤15 MB；编辑的本地源视频需4–30秒。不接受未知 submit 参数。

连续分段时，先下载并检查上一段，再把它作为下一段的视频1；不要并行生成父子依赖片段。所有片段下载后使用 compose，明确 resolution 与 ratio（默认720p、16:9），输出24 fps的 H.264/AAC视频；不添加字幕或额外配乐。轨迹工具和公开 API 的差异见 [接入记录](../../docs/seedance-2.5-integration.md)。

```json
{"action": "submit", "prompt": "图片1中的人物沿视频1的运镜走向镜头", "references": [{"type": "image", "source": "asset://asset-20260401123823-6d4x2"}, {"type": "video", "source": "previz-xxx-3.mp4"}], "duration": -1, "resolution": "720p"}
```

# 4. 兼容与路由

[`tool_names.py`](../src/ma_custom_tools/tool_names.py) 集中定义工具名和新旧映射：

- **已有 Session**：Session 固定使用创建时的 Agent 版本，可能仍调用 `local_pipeline` / `seedance`。`canonical()` 把它们映射到新工具：`save` 与 `blender_*` → `blender_project`，`skill` 仍读取执行端的技能副本（内部处理，不再对新 Agent 声明），其余 action → `previz_render`，`seedance` → `seedance_video`。
- **远程执行端**：转发到 Elsa 执行器或 Self-hosted 服务器时，`wire()` 仍使用原 `local_pipeline` 格式，未升级的执行端也能执行；新执行端再映射回新工具。
- **Self-hosted**：服务器 Worker 执行 Blender 类工具（`REMOTE_TOOLS` 同时包含新旧名称）；业务后端执行 `seedance_video` 和本地已有视频的抽帧。

# 5. 结果、错误与恢复

- MCP 执行结果经 [`to_ma_result()`](../src/ma_mcp/mcp_bridge.py) 转换为 `user.custom_tool_result`，通过 `custom_tool_use_id` 关联原始调用事件，包含 `is_error` 与 `content`。平台业务对象通常编码在 text 内容块中；截图使用 image 内容块。
- [`MARunner`](../src/ma_custom_tools/ma.py) 等待 `requires_action.event_ids` 后才执行指定工具，持久化执行和回传状态。执行或回传结果未知时停止自动重试，避免重复建模、渲染或生成视频。
- [`result_payload.py`](../src/ma_custom_tools/result_payload.py) 会压缩大截图；整体内容仍超过本地传输预算时，返回明确错误说明并保存完整原结果。当前没有 Claude 文档中“自动落盘后让模型读取完整文件”的通用工具能力，不能假定 MA 能直接读取保留结果。
- 代码输出只打印影响下一步决策的信息，例如对象名、数量、关键属性和错误。不要一次输出完整场景数据或大量逐帧日志。
- `blender_tools_call` 仍受 MCP 白名单约束；Self-hosted 将 Blender 和渲染操作交给远端执行；抽帧由业务后端按产物实际位置分发。


# 6. 修改、校验与生效范围

修改 JSON 或系统提示词后运行：

```bash
.venv/bin/python -m pytest -q backend/tests/test_custom_tool_config.py backend/tests/test_bundled_skills.py backend/tests/test_publish_tools.py backend/tests/test_projects.py backend/tests/test_video_frames.py backend/tests/test_protocol.py
```

- **新建 Agent**：使用 JSON 工具声明和 `ma_system_prompt.md`。
- **已有 Agent**：`setup()` 每次初始化时调用 `sync_tool_definitions()`，把平台拥有的工具（含旧名称）替换为当前声明，保留用户自行添加的工具；只在声明内容的摘要变化时写入，重复初始化不产生新版本。`sync_system_prompt()` 只更新平台写入的系统提示词（以「MA 导演 Agent 的三维创作助手」及历史名称识别），用户自定义的提示词保持不变。
- **显式发布**：`python -m ma_custom_tools.publish_tools --agent-id <已登记的Agent-ID>` 备份原配置后替换平台工具并回读核验，不修改系统提示、模型和 Skill。
- 已有 Session 不会获得新声明；新建 Session 才使用更新后的工具和提示词。

# 8. 设计依据

- [Claude Managed Agents Tools](https://platform.claude.com/docs/en/managed-agents/tools#best-practices-for-custom-tool-definitions)，查阅日期：2026-10-08。参考详细说明、相关操作合并、清晰命名和高信息密度返回原则；该文档的内置工具与权限配置不直接视为方舟协议。
