# MA 导演 Agent 后端

`src/` 包含三个独立 Python 包：

- `studio/`：FastAPI 路由、项目目录、任务队列、配置与 SQLite 状态；`ark.py` 是两个云端模块共用的 HTTP 客户端。
- `ma_custom_tools/`：MA 自定义工具注册、Session 事件执行与结果回传。
- `ma_mcp/`：两种执行方式共用的原版 Blender MCP STDIO 客户端与多模态结果转换。
- `ma_self_hosted/`：Self-hosted Worker、Work Queue 与远程执行。
- `ma_cloud/`：Elsa 云版本部署、域名访问与 Custom Tool / Self-hosted 切换。
- `seedance/`：Seedance 2.5 请求、状态和下载，以及可选 TOS 视频上传。

从仓库根目录运行：

```bash
uv sync --frozen --all-packages
.venv/bin/python -m uvicorn studio.app:app --host 127.0.0.1 --port 7860
.venv/bin/python -m pytest -q
```

模型、会话、任务和项目使用 `.local/state.sqlite3` 持久化；凭证读取根目录 `.env`。前端只有本地 API 访问权限，不包含云端密钥。项目产物在 `data/projects/<id>/`。Blender 原版插件需要在本机开启 9876 端口。

输入框的模型菜单读取 `backend/config/ma_models.json`，使用与 mate-agent 相同的模型品牌 Logo 和上下文长度布局。`POST /api/ma/model` 保存新会话的模型选择（可指定 `project_id`）；创建 Session 时通过官方 SDK 支持的 `agent_with_overrides.model.id` 写入独立快照，适用于本机和 Self-hosted（GLM-5.3 已在云端 Session 回读确认）。已有 Session 也可切换模型（含生成过程中）：选择记为待切换（`:model_pending`，`/api/health` 的 `ma.pending`），由 Runner 在当前轮以 `end_turn` 结束、发送下一条消息前调用 [升级会话 API](https://ark.volcengine.com/region:cn-beijing/docs/ark/upgrade-session-api) `POST sessions/{id}/upgrades`（`agent.type=agent_with_upgrades`，`agent.model` 为新模型与推理档位），轮询至 `idle` 并回读核验后再发送；生成中排队的后续消息会等当前轮结束、切换完成后再投递。会话非空闲时 MA 返回 `OperationDenied.SessionNotIdle`，切换保持待生效；其他失败保留原模型并在发送前报错。火山与 BytePlus 已实测（含 Evolving 显式切换）。BYOK 凭据在建会话时绑定，需新建会话后切换。价格和上下文长度等展示字段不会作为请求参数发送。

推理强度滑杆使用清单中的 `reasoning_effort_options`，依据 [MA 模型支持的参数列表](https://console.volcengine.com/ark/region:cn-beijing/docs/82379/2662855?lang=zh)（核对于 2026-09-11）。GLM-5.3 的 Low/High/Max（模型默认 Max）依据 [GLM 官方文档](https://docs.z.ai/guides/llm/glm-5.3) 配置；已验证 MA Session 返回 GLM-5.3 / High，其他档位尚未逐一实测。用户选择通过同一接口的 `reasoning_effort` 保存；新建 Session 时明确传递所选模型 ID 和档位，并按档位配置 thinking。未手动调整或重置为 `null` 时，使用清单的 `reasoning_effort_default`，界面显示值与提交值一致，不再省略后继承基础 Agent 的不同档位。创建后核验云端返回的 `agent.model`，缺失时通过 GET 回读；模型或档位不符则报错并停止发送创作任务，重试使用已创建的 Session 重新核验。已有 Session 显示云端实际值，通过健康检查最多每 30 秒只读回查一次、5 秒超时，失败保留上次值，旧 Session 的迟到响应不覆盖新会话。未知的已有 Session 档位显示 Default，不用清单默认值猜测。旧单值 `reasoning_effort` 仍仅为展示资料。

输入框按“上下文圆环、模型、推理档位”展示，模型菜单中 Doubao 优先。圆环复用已有 Session 事件流，每次 `span.model_request_end` 后更新最近请求的 `input_tokens + output_tokens`，除以模型清单的 `contextWindow`，悬浮或聚焦显示估算百分比及 Token 数。它不是 Session 累计消耗，也不是 MA 精确保留的上下文或自动压缩阈值；输出可能含不会保留的推理 Token。[事件结构参考](https://ark.volcengine.com/region:cn-beijing/docs/82379/2559583?lang=zh) 将 `input_tokens` 定义为输入总数，因此不再加缓存计数；[事件流教程](https://ark.volcengine.com/region:cn-beijing/docs/82379/2553725?lang=zh) 对该字段的“未缓存输入”描述与之有差异，目前按 API 结构参考实现并明确标注估算（核对于 2026-09-11）。压缩事件清除旧估算，等待下一次请求用量；缺失数据不展示假零值。子线程用量不与主线程相加，无法判断主线程时显示暂无数据。全程只读已有事件，不额外发起模型调用。

后端无需公网部署。MA 由后端主动连接云端，工具调用在 Mac 上执行；React 由同一个 FastAPI 服务提供，开发时 Vite 使用 API 代理。
