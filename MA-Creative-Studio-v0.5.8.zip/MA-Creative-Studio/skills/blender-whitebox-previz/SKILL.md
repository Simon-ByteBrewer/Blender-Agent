---
name: blender-whitebox-previz
description: 使用 Blender MCP 或后台 Blender 搭建白模／彩色白模预演，规划人物走位、相机运动和镜头时序，交付可编辑 .blend 与参考视频。适用于白模、greybox、blockout、previz、animatic、一镜到底、分镜及 AI 视频生成的空间运动参考；不用于精细建模或直接提交云端视频生成。
---

# Blender 白模预演

白模的核心是可读的空间、动作、运镜和时序。用简单几何表达这些信息；只有当动作依赖关节时，才增加最低限度的四肢。支持灰色布景，也支持用纯色色块区分房间、角色和交互物。

## 宿主平台集成

若系统说明当前任务由宿主平台托管，使用宿主提供的工具读取技能文件；MCP 中直接使用已选中的 `bpy.context.scene` 与宿主准备的 `wb_lib`，不调用 `new_scene()` 或运行完整示例替换项目场景。技能文件与 Blender 可能位于不同执行环境，不跨环境复用绝对路径。保存、预览和长渲染遵循宿主提供的流程，由宿主登记工程与视频版本。具体工具名称以当前系统说明和可用工具为准。独立使用时遵循下方命令流程。

## 执行入口

- 有 Blender MCP 时，先用 `get_scene_info` 检查连接；首次执行代码前读 [MCP 操作](references/mcp-operations.md)。错误不一定代表插件未启动，应根据实际错误选择修复或后台执行。
- 长时间构建、完整渲染或没有 MCP 时，使用后台 Blender。先定位本机 Blender、`ffmpeg`、`ffprobe`，不要假定 `blender` 已加入 PATH。
- 构建器 `wb.new_scene()` 拒绝覆盖同名场景。对象、集合和材质在场景命名空间内隔离；保留既有工程，修订使用新文件名。

## 1. 先确定镜头与动作计划

记录时长、fps、画幅、镜头段落、人物动作、空间路线、镜头高度／焦距，以及需要重点观察的时间段。默认 24 fps、1280×720，但用户要求优先。

- **一镜到底**：使用一个活动相机，按动作段落设置普通事件标记；事件不是切镜。需要连续运镜、台阶、出入车门或入座时，读 [一镜到底与原生重定时](references/continuous-shot.md)。
- **多镜头**：写明每个镜头的起止帧、机位、主体动作，使用绑定相机的 timeline markers 切镜。

帧数为 `N = round(秒数 × fps)`，通常帧范围为 `1…N`；某帧的时间戳为 `(frame−1)/fps`。路线长度与目标时长冲突时，调整走位或说明速度取舍，不靠单帧跳跃补时长。

## 2. 搭建空间和动画

按“空间 → 人物 → 人物运动 → 相机 → 标记”搭建。使用 [wb_lib API](references/wb-lib-api.md) 中的辅助函数；复杂动作可扩展脚本。尺度、色块和简模选择见 [白模制作原则](references/whitebox-craft.md)。

```python
import sys
sys.path.insert(0, "<skill>/scripts")
import wb_lib as wb

scene = wb.new_scene("Whitebox_v01", fps=24, frame_end=168)
sets = wb.collection(scene, "01-set")
actors = wb.collection(scene, "02-subjects")
cams = wb.collection(scene, "03-cameras")
wb.ground(sets)
hero = wb.subject(actors, "hero", (0, 0, 0), height=1.75)
wb.path(hero, [(0, 0, 0), (3, -2, 0)], 1, 168, face_travel=True)
wb.at_frame(1)
cam = wb.camera(cams, "follow", (5, -8, 2), lens=35, look_at=(1, -1, 1))
scene.camera = cam
scene.timeline_markers.new("行走结束", frame=168)
wb.previz_render(scene)
wb.save(scene, "out/v01/scene.blend")
```

Blender 5.x 操作动画曲线前，读 [Action API 兼容与失败恢复](references/blender-actions.md)。使用 `object_fcurves()` 按对象 slot 取曲线；部分执行失败后，只清理负责重建的通道。

关键约定：

- 单位为米，Z 向上；人物局部 `−Y` 为正面。跨 MCP 调用用 `wb.find("SUB-hero")` 找角色。
- 读取动画对象的位置前调用 `wb.at_frame(frame)`；肩后机位显式传 `frame=`。
- `path()` 默认按弧长推进，摄像机使用四元数、人物航向角连续展开；自定义动画也保持这些约定。
- `path()` 默认替换该对象的位置／旋转关键帧。追加段落需 `append=True`，并自行保证边界位置、速度和朝向连续。长镜头优先用一条路线与整段时间—路程曲线。
- 角色仅平移时动画根节点；下车、踩台阶、入座时，根节点负责走位，子节点负责姿态。
- 相机和角色通过真实门洞。剖切墙面适合布局检查，不能代替长镜头需要的空间连通。

## 3. 预览与验收

交付前运行逐帧检查：

```bash
blender -b out/v01/scene.blend --python-exit-code 1 \
  --python <skill>/scripts/check_scene.py -- \
  --scene Whitebox_v01 --json out/v01/check.json
```

检查普通事件／切镜标记、每帧移动速度、支撑点和显式 BOX 碰撞代理。`wb.box()` 自动标记碰撞体；现有工程需显式标记角色与碰撞代理。详见 [验收范围](references/wb-lib-api.md#验收范围)。`--step 2` 等抽样仅用于预检，不能代替逐帧交付检查。检查失败时修正场景；有未覆盖网格时说明范围并补人工检查。

渲染快速检查帧：

```bash
# 长镜头：事件前一帧、事件帧、后一帧，加均匀采样
blender -b out/v01/scene.blend --python-exit-code 1 \
  --python <skill>/scripts/render_previz.py -- \
  --scene Whitebox_v01 --out out/v01 --events

# 多镜头：每个镜头首、中、尾帧
# 将上面的 --events 换为 --samples-per-cut
```

用可用的图片查看工具打开输出，检查遮挡、头部裁切、角色身份和相对位置，以及下楼、转弯、进座等过渡；观看动态片段判断速度、转向、步态是否自然。只有静帧或 gate 通过都不足以证明运动质量。

## 4. 完整渲染与版本保留

默认使用 Workbench 的纯色、简单明暗和深度线索。只有任务确实需要灯光或材质预演时才选择其他引擎；本技能的渲染器固定使用 Workbench。

```bash
blender -b out/v01/scene.blend --python-exit-code 1 \
  --python <skill>/scripts/render_previz.py -- \
  --scene Whitebox_v01 --out out/v01
```

渲染器将工程内容、外部依赖、脚本与参数的指纹写入 `out/v01/runs/<模式>-<指纹>/`。预览和正式渲染隔离；场景或参数变化产生新目录。只有指纹相同且文件哈希匹配的帧可续跑。输出 `reference.mp4`，限定帧数，检查帧率／尺寸／时长并完整解码；失败不会报告成功。仅交付帧时显式使用 `--no-video`。

保持每一版 `.blend`、视频、提示词、检查报告一致。重定时应在 Blender 中处理动画并重新渲染，不能通过抽视频帧替代。旧版本不覆盖；更短版本也需要重新验收速度和关键动作。

## 5. 交付

交付可编辑 `.blend`、视频或帧、镜头／动作计划、fps／帧数／时长、验收报告与未覆盖范围。AI 视频参考任务同时交付对应版本的提示词，按 [视频提示词](references/video-prompting.md) 写清色块身份、已有动作和镜头时序，再补服装、材质、灯光等信息。

生成参考文件不等于已经提交 Seedance 等云端任务。仅当用户要求提交时，再使用对应生成能力。

## 可复用资源

- [wb_lib.py](scripts/wb_lib.py)：场景隔离、几何、角色、弧长路径、相机、重定时、保存。
- [example_continuous.py](scripts/example_continuous.py)：下台阶 → 缓和转弯 → 固定座位入座；12 秒母版和 10 秒原生重定时版。
- [example_chase.py](scripts/example_chase.py)：三镜头追逐。
- [check_scene.py](scripts/check_scene.py)：逐帧 gate，明确碰撞覆盖边界。
- [render_previz.py](scripts/render_previz.py)：版本隔离、续跑、编码和媒体验证。
- [mcp_job.py](scripts/mcp_job.py)：交互 Blender 延后任务与状态文件。
- [test_regressions.py](scripts/test_regressions.py)：隔离场景中的行为回归测试。
