"""Run long Blender work through MCP without blocking the socket.

`execute_blender_code` runs on Blender's main thread and its socket times out
after ~15 s. Anything longer (a full set build, a render, a heavy boolean pass)
must be handed to `bpy.app.timers` and polled through a state file.

Use from the agent side: build the payload with `defer()`, send the returned
string as the `code` argument of execute_blender_code, then poll the state file
with the Read tool until status is succeeded/failed.

SCOPE: this pattern requires a running Blender event loop, i.e. an interactive
Blender with the MCP addon. It does NOT work under `blender -b --python`,
where no event loop runs and a registered timer never fires -- the state file
would sit at "queued" forever. Headless work needs no deferral anyway: call the
script directly with `blender -b --python script.py`.
"""

from __future__ import annotations

import json
import textwrap
import time
import uuid
from pathlib import Path


def defer(
    script_path: str, state_dir: str, job: str | None = None, reload_lib: bool = True
) -> tuple[str, str]:
    """Return (code_to_send, state_file). The script runs ~1 s later, off-socket."""
    job = job or uuid.uuid4().hex[:8]
    state = Path(state_dir).expanduser().resolve() / f"wb-{job}.json"
    state.parent.mkdir(parents=True, exist_ok=True)
    state.write_text(json.dumps({"status": "queued", "job": job}))
    script = str(Path(script_path).expanduser().resolve())
    lib_dir = str(Path(script).parent)
    reload_block = (
        textwrap.dedent("""
        import importlib
        if "wb_lib" in sys.modules:
            importlib.reload(sys.modules["wb_lib"])
    """)
        if reload_lib
        else ""
    )

    code = textwrap.dedent(f"""
        import bpy, json, sys, traceback
        from pathlib import Path
        sys.path.insert(0, {lib_dir!r})
        {textwrap.indent(reload_block, "        ").strip()}

        def _wb_job_{job}():
            state = Path({str(state)!r})
            state.write_text(json.dumps({{"status": "running", "job": {job!r}}}))
            try:
                ns = {{"__name__": "__main__", "__file__": {script!r}}}
                exec(compile(Path({script!r}).read_text(), {script!r}, "exec"), ns)
                state.write_text(json.dumps({{"status": "succeeded", "job": {job!r},
                                              "result": str(ns.get("WB_RESULT", ""))}}))
            except Exception as exc:
                state.write_text(json.dumps({{"status": "failed", "job": {job!r},
                                              "error": str(exc),
                                              "traceback": traceback.format_exc()[-3000:]}}))
            return None

        bpy.app.timers.register(_wb_job_{job}, first_interval=1.0)
        print("WB_JOB_QUEUED", {str(state)!r})
    """).strip()
    return code, str(state)


def wait(state_file: str, timeout: int = 1800, interval: float = 2.0) -> dict:
    """Local-side poll helper for non-MCP use (background Blender, tests)."""
    path = Path(state_file)
    deadline = time.monotonic() + timeout
    last = None
    while time.monotonic() < deadline:
        try:
            status = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError):
            time.sleep(interval)
            continue
        if status != last:
            print(json.dumps(status, ensure_ascii=False), flush=True)
            last = status
        if status.get("status") in {"succeeded", "failed"}:
            return status
        time.sleep(interval)
    raise TimeoutError(
        f"job still unresolved; inspect {path}. Do not queue a duplicate."
    )


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("script")
    p.add_argument("--state-dir", default="./.wb_jobs")
    a = p.parse_args()
    code, state = defer(a.script, a.state_dir)
    print(json.dumps({"state_file": state, "code": code}, ensure_ascii=False, indent=2))
