"""Whitebox previz helpers for Blender (4.x / 5.x). Units: metres, Z-up.

Deterministic building blocks for agent-driven whitebox (greybox) scenes:
subject proxies with facing tape, primitive-based sets, motion paths, camera
rigs with look-at targets, marker-bound cut sequences, and a Workbench previz
render profile.

Import inside Blender (execute_blender_code or `blender --python`):

    import sys; sys.path.insert(0, "<skill>/scripts")
    import wb_lib as wb                      # 每次 MCP 调用重新导入
    import importlib; importlib.reload(wb)   # after editing this file

Object constructors are idempotent within their scene namespace: calling it twice replaces the object
instead of leaving a duplicate. That matters because each execute_blender_code
call is a fresh Python namespace while bpy.data persists.
"""

from __future__ import annotations

import math
import bisect
import uuid
import hashlib

import bpy
from mathutils import Vector

# Whitebox palette. Neutral white for the set, saturated hues for subjects so
# a still frame or a downstream video model can tell actors apart.
GREY = (0.62, 0.62, 0.62)
TAPE = (0.05, 0.30, 0.85)
SUBJECT_COLORS = [
    (0.85, 0.16, 0.13),  # red
    (0.15, 0.45, 0.90),  # blue
    (0.95, 0.62, 0.10),  # amber
    (0.20, 0.70, 0.35),  # green
    (0.65, 0.25, 0.80),  # violet
    (0.90, 0.90, 0.90),  # white
]

# Head-body ratios from the whitebox asset convention: pick by character type.
HEAD_RATIOS = {2: "infant/chibi", 4: "child/anime", 6: "adult", 8: "heroic/mecha"}

_MAT_CACHE_TAG = "wb_material"


# --------------------------------------------------------------------------
# scene / collection / material plumbing
# --------------------------------------------------------------------------
def new_scene(name="Whitebox", fps=24, frame_end=120):
    """Create a dedicated scene; refuse an existing name to preserve revisions."""
    if bpy.data.scenes.get(name):
        raise ValueError(
            f"Scene {name!r} exists; use a new revision name or edit it explicitly"
        )
    scene = bpy.data.scenes.new(name)
    scene["wb_namespace"] = "WB" + uuid.uuid4().hex[:10]
    if bpy.context.window:
        bpy.context.window.scene = scene
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.scale_length = 1.0
    scene.frame_start, scene.frame_end = 1, frame_end
    scene.render.fps = fps
    return scene


def attach_scene(scene):
    """为平台已创建的当前项目场景分配命名空间；不清空或重建任何已有对象。"""
    namespace = scene.get("wb_namespace")
    if namespace and any(
        other != scene and other.get("wb_namespace") == namespace
        for other in bpy.data.scenes
    ):
        raise ValueError("场景命名空间被复制，请先明确共享数据归属")
    if not namespace:
        scene["wb_namespace"] = "WB" + uuid.uuid4().hex[:10]
    return scene


def _name(name, owner=None):
    owner = owner if owner is not None else bpy.context.scene
    ns = owner.get("wb_namespace")
    if not ns:
        raise ValueError("Use a wb.new_scene scene / wb.collection collection")
    if name.startswith(ns + "::"):
        return name
    # Keep stable names below Blender's byte limit, including non-ASCII labels.
    label = name.encode()[:36].decode(errors="ignore")
    return f"{ns}::{label}-{hashlib.sha256(name.encode()).hexdigest()[:8]}"


def find(name, scene=None):
    """Resolve a logical object name after a fresh MCP call."""
    scene = scene if scene is not None else bpy.context.scene
    return scene.objects[_name(name, scene)]


def collection(scene, name):
    """Get a scene-owned collection; refuse manually shared collections."""
    full = _name(name, scene)
    col = bpy.data.collections.get(full)
    if col is not None and any(
        col in list(s.collection.children_recursive)
        for s in bpy.data.scenes
        if s != scene
    ):
        raise ValueError(f"Collection {full} is shared; make it single-user first")
    if col is None:
        col = bpy.data.collections.new(full)
        col["wb_namespace"] = scene["wb_namespace"]
    if col.name not in scene.collection.children:
        scene.collection.children.link(col)
    return col


def _link(col, obj):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    col.objects.link(obj)
    return obj


def material(name, color, rough=0.75):
    """Flat viewport-visible material.

    Workbench previz reads `diffuse_color`, while Cycles/EEVEE reads the
    Principled node, so both are set to the same value.
    """
    name = _name(name)
    mat = bpy.data.materials.get(name)
    if mat and any(
        slot.material == mat
        for other in bpy.data.scenes
        if other != bpy.context.scene
        for obj in other.objects
        for slot in obj.material_slots
    ):
        raise ValueError(f"Material {name} is shared; make it single-user first")
    mat = mat or bpy.data.materials.new(name)
    mat[_MAT_CACHE_TAG] = True
    mat.diffuse_color = (*color, 1.0)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*color, 1.0)
        bsdf.inputs["Roughness"].default_value = rough
    return mat


def _replace(name):
    """Remove an existing object of this exact name so builds stay idempotent."""
    old = bpy.data.objects.get(name)
    if old:
        if any(
            old.name in scene.objects
            for scene in bpy.data.scenes
            if scene != bpy.context.scene
        ):
            raise ValueError(f"Object {name} is shared; make it single-user first")
        bpy.data.objects.remove(old, do_unlink=True)


def _mesh_obj(col, name, verts, faces, mat):
    if col.get("wb_namespace") != bpy.context.scene.get("wb_namespace"):
        raise ValueError("请先切换到集合所属场景")
    name = _name(name, col)
    _replace(name)
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.update()
    me.materials.append(mat)
    obj = bpy.data.objects.new(name, me)
    return _link(col, obj)


# --------------------------------------------------------------------------
# primitives (bpy.ops-free, so they work headless and in any context)
# --------------------------------------------------------------------------
def box(col, name, loc, size, mat):
    """Axis-aligned box centred on `loc`, `size` = full extents (x, y, z)."""
    sx, sy, sz = (s / 2 for s in size)
    verts = [
        (x * sx, y * sy, z * sz) for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)
    ]
    faces = [
        (0, 1, 3, 2),
        (4, 6, 7, 5),
        (0, 4, 5, 1),
        (2, 3, 7, 6),
        (0, 2, 6, 4),
        (1, 5, 7, 3),
    ]
    obj = _mesh_obj(col, name, verts, faces, mat)
    obj.location = loc
    obj["wb_collider"] = "BOX"
    return obj


def cylinder(col, name, loc, radius, height, mat, segments=16):
    """Z-aligned cylinder centred on `loc`."""
    ring = [
        (
            radius * math.cos(2 * math.pi * i / segments),
            radius * math.sin(2 * math.pi * i / segments),
        )
        for i in range(segments)
    ]
    verts = [(x, y, z * height / 2) for z in (-1, 1) for x, y in ring]
    n = segments
    faces = [tuple(range(n - 1, -1, -1)), tuple(range(n, 2 * n))]
    faces += [(i, (i + 1) % n, (i + 1) % n + n, i + n) for i in range(n)]
    obj = _mesh_obj(col, name, verts, faces, mat)
    obj.location = loc
    for poly in obj.data.polygons:
        poly.use_smooth = len(poly.vertices) == 4
    return obj


def sphere(col, name, loc, radius, mat, u=16, v=10):
    """UV sphere; pass a float radius or a per-axis (rx, ry, rz) tuple."""
    verts, faces = [], []
    for j in range(v + 1):
        theta = math.pi * j / v
        for i in range(u):
            phi = 2 * math.pi * i / u
            verts.append(
                (
                    math.sin(theta) * math.cos(phi),
                    math.sin(theta) * math.sin(phi),
                    math.cos(theta),
                )
            )
    for j in range(v):
        for i in range(u):
            a = j * u + i
            b = j * u + (i + 1) % u
            faces.append((a, b, b + u, a + u))
    obj = _mesh_obj(col, name, verts, faces, mat)
    obj.location = loc
    obj.scale = (radius, radius, radius) if isinstance(radius, (int, float)) else radius
    for poly in obj.data.polygons:
        poly.use_smooth = True
    return obj


# --------------------------------------------------------------------------
# subject proxies
# --------------------------------------------------------------------------
def subject(col, name, loc, height=1.75, head_ratio=6, color=None, facing=0.0):
    """带朝向标记的躯干与头部，返回根 Empty；默认没有可活动四肢。

    根节点负责走位；需要踩台阶、坐下时扩展子节点的局部姿态。
    """
    if col.get("wb_namespace") != bpy.context.scene.get("wb_namespace"):
        raise ValueError("请先切换到集合所属场景")
    color = color or SUBJECT_COLORS[0]
    mat = material(f"MAT-{name}", color)
    tape = material("MAT-facing-tape", TAPE, rough=0.4)

    head_h = height / head_ratio
    body_h = height - head_h
    width = max(0.16, height * 0.13)

    root_name = _name(f"SUB-{name}", col)
    _replace(root_name)
    root = bpy.data.objects.new(root_name, None)
    root.empty_display_type = "ARROWS"
    root.empty_display_size = 0.4
    _link(col, root)
    root.location = loc
    root.rotation_euler = (0, 0, facing)
    root["wb_role"] = "subject"
    root["wb_height_m"] = height
    root["wb_head_ratio"] = head_ratio

    body = cylinder(col, f"SUB-{name}-body", (0, 0, body_h / 2), width, body_h, mat, 12)
    head = sphere(col, f"SUB-{name}-head", (0, 0, body_h + head_h / 2), head_h / 2, mat)
    # -Y is forward, matching Blender camera convention for look-at maths.
    nose = box(
        col,
        f"SUB-{name}-facing",
        (0, -width * 0.95, body_h + head_h / 2),
        (head_h * 0.5, width * 0.5, head_h * 0.22),
        tape,
    )
    chest = box(
        col,
        f"SUB-{name}-chesttape",
        (0, -width * 0.98, body_h * 0.78),
        (width * 1.1, 0.02, body_h * 0.12),
        tape,
    )
    for child in (body, head, nose, chest):
        child.parent = root
    return root


def subject_row(col, base_name, count, start, spacing, **kw):
    """Row of proxies with cycling colours -- crowd scale without hand-placing."""
    out = []
    for i in range(count):
        loc = (start[0] + spacing[0] * i, start[1] + spacing[1] * i, start[2])
        out.append(
            subject(
                col,
                f"{base_name}{i + 1:02d}",
                loc,
                color=SUBJECT_COLORS[i % len(SUBJECT_COLORS)],
                **kw,
            )
        )
    return out


# --------------------------------------------------------------------------
# set pieces
# --------------------------------------------------------------------------
def ground(col, name="SET-ground", size=80.0, mat=None):
    return box(
        col, name, (0, 0, -0.05), (size, size, 0.1), mat or material("MAT-ground", GREY)
    )


def room(col, name, size, wall=0.15, height=3.0, open_sides=("+y",), mat=None):
    """Four walls + floor with named sides left open for camera access.

    `open_sides` uses "+x" / "-x" / "+y" / "-y"; opening the camera-side wall
    is usually better than flying the camera through geometry.
    """
    mat = mat or material("MAT-set", GREY)
    sx, sy = size
    parts = {
        "-y": ((0, -sy / 2, height / 2), (sx, wall, height)),
        "+y": ((0, sy / 2, height / 2), (sx, wall, height)),
        "-x": ((-sx / 2, 0, height / 2), (wall, sy, height)),
        "+x": ((sx / 2, 0, height / 2), (wall, sy, height)),
    }
    made = [box(col, f"{name}-floor", (0, 0, -0.05), (sx, sy, 0.1), mat)]
    for side, (loc, dim) in parts.items():
        if side in open_sides:
            continue
        made.append(box(col, f"{name}-wall{side}", loc, dim, mat))
    return made


def blocks(col, name, specs, mat=None):
    """Batch set dressing: specs = [(loc, size), ...]. One box per entry."""
    mat = mat or material("MAT-set", GREY)
    return [
        box(col, f"{name}{i + 1:02d}", loc, size, mat)
        for i, (loc, size) in enumerate(specs)
    ]


# --------------------------------------------------------------------------
# motion
# --------------------------------------------------------------------------
def ease(t, mode="inout"):
    """Normalised easing on t in [0, 1]."""
    if mode == "linear":
        return t
    if mode == "in":  # slow start, fast finish
        return t * t
    if mode == "out":  # fast start, slow finish
        return 1 - (1 - t) ** 2
    return t * t * (3 - 2 * t)  # smoothstep


def path(
    obj,
    points,
    start,
    end,
    easing="inout",
    face_travel=False,
    look_at=None,
    bob=0.0,
    append=False,
):
    """Bake a motion path onto `obj` as per-frame location keys.

    Baked keys instead of a follow-path constraint: the result survives .blend
    round-trips, background renders and MCP restarts, and reads identically in
    the dope sheet. `points` may be 2 or more control points (Catmull-Rom).
    """
    pts = [Vector(p) for p in points]
    if len(pts) < 2:
        raise ValueError("path() needs at least 2 points")
    if end <= start:
        raise ValueError("end must be greater than start")
    if not append:
        clear_keys(obj, ("location", "rotation_euler", "rotation_quaternion"))
    route = ArcPath(points)
    span = end - start
    # Tracking a moving object requires evaluating the scene each frame,
    # otherwise every key aims at wherever the target happened to be.
    track_obj = hasattr(look_at, "matrix_world")
    scene = bpy.context.scene

    for frame in range(start, end + 1):
        if track_obj:
            scene.frame_set(frame)
        s = ease((frame - start) / span, easing)
        pos = route.at(s * route.length)
        if bob:
            pos = pos.copy()
            pos.z += bob * math.sin(s * math.pi * 12) * math.sin(math.pi * s)
        obj.location = pos
        obj.keyframe_insert("location", frame=frame)
        target = None
        if look_at is not None:
            target = (
                look_at.matrix_world.translation.copy()
                if track_obj
                else Vector(look_at)
            )
        elif face_travel:
            target = pos + route.tangent(s * route.length)
        if target is not None:
            _aim(obj, pos, target)
            key_rotation(obj, frame)
    linear_keys(obj, ("location", "rotation_euler", "rotation_quaternion"))
    return obj


def _spline(pts, s):
    """Catmull-Rom through all control points; linear when only two exist."""
    if len(pts) == 2:
        return pts[0].lerp(pts[1], s)
    segs = len(pts) - 1
    f = min(s * segs, segs - 1e-9)
    i = int(f)
    t = f - i
    p0 = pts[max(0, i - 1)]
    p1, p2 = pts[i], pts[i + 1]
    p3 = pts[min(len(pts) - 1, i + 2)]
    return 0.5 * (
        2 * p1
        + (-p0 + p2) * t
        + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t
        + (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t
    )


def _aim(obj, pos, target):
    """Point an object's -Z at `target` with +Y up (camera convention).

    Subject proxies are built facing -Y, so they use a Z-rotation instead.
    """
    direction = Vector(target) - Vector(pos)
    if direction.length < 1e-6:
        return
    if obj.get("wb_role") == "subject":
        angle = math.atan2(direction.x, -direction.y)
        previous = obj.rotation_euler.z
        angle = previous + (angle - previous + math.pi) % (2 * math.pi) - math.pi
        obj.rotation_euler = (0, 0, angle)
    else:
        q = direction.to_track_quat("-Z", "Y")
        if obj.rotation_mode == "QUATERNION" and obj.rotation_quaternion.dot(q) < 0:
            q.negate()
        obj.rotation_mode = "QUATERNION"
        obj.rotation_quaternion = q


def face_target(obj, target, frame):
    """Key a single facing change (e.g. a chaser locking onto its target)."""
    at_frame(frame)
    pos = obj.matrix_world.translation.copy()
    tgt = (
        target.matrix_world.translation
        if hasattr(target, "matrix_world")
        else Vector(target)
    )
    _aim(obj, pos, tgt)
    key_rotation(obj, frame)
    return obj


# --------------------------------------------------------------------------
# cameras
# --------------------------------------------------------------------------
def camera(col, name, loc, lens=35.0, look_at=None, height=None, sensor=36.0):
    """Create a camera. `height` overrides loc.z -- use 1.6 for eye level."""
    if col.get("wb_namespace") != bpy.context.scene.get("wb_namespace"):
        raise ValueError("请先切换到集合所属场景")
    cam_name = _name(f"CAM-{name}", col)
    _replace(cam_name)
    data = bpy.data.cameras.new(cam_name)
    data.lens = lens
    data.sensor_width = sensor
    data.clip_start = 0.05
    data.clip_end = 2000
    obj = bpy.data.objects.new(cam_name, data)
    _link(col, obj)
    loc = list(loc)
    if height is not None:
        loc[2] = height
    obj.location = loc
    if look_at is not None:
        tgt = (
            look_at.matrix_world.translation
            if hasattr(look_at, "matrix_world")
            else Vector(look_at)
        )
        _aim(obj, Vector(loc), tgt)
    return obj


def orbit(
    cam,
    target,
    radius,
    start,
    end,
    height=None,
    turns=1.0,
    start_angle=0.0,
    easing="inout",
):
    """Orbit a camera around a target, always looking at it.

    Sample the target's position per frame, so orbiting a moving subject
    tracks it instead of circling where it used to be.
    """
    clear_keys(cam, ("location", "rotation_euler", "rotation_quaternion"))
    span = max(1, end - start)
    scene = bpy.context.scene
    for frame in range(start, end + 1):
        scene.frame_set(frame)
        s = ease((frame - start) / span, easing)
        centre = (
            target.matrix_world.translation.copy()
            if hasattr(target, "matrix_world")
            else Vector(target)
        )
        angle = start_angle + turns * 2 * math.pi * s
        pos = Vector(
            (
                centre.x + radius * math.cos(angle),
                centre.y + radius * math.sin(angle),
                centre.z + 1.2 if height is None else height,
            )
        )
        cam.location = pos
        _aim(cam, pos, centre)
        cam.keyframe_insert("location", frame=frame)
        key_rotation(cam, frame)
    linear_keys(cam, ("location", "rotation_euler", "rotation_quaternion"))
    return cam


def at_frame(frame):
    """Evaluate the scene at `frame` before reading any animated position.

    Baking a path leaves objects wherever the loop ended, so reading
    `actor.matrix_world` right after `path()` returns a stale position. Any
    placement derived from an animated object must set the frame first.
    """
    scene = bpy.context.scene
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    return frame


def over_shoulder(
    col, name, actor, target, frame, back=1.1, side=0.45, height=1.55, lens=40.0
):
    """Place an OTS camera behind `actor` looking at `target`, evaluated at `frame`.

    `frame` is mandatory on purpose: it must be the frame this camera cuts in
    on, otherwise the rig is built from an unrelated moment of the animation
    and the lens ends up buried in a wall.
    """
    at_frame(frame)
    a = actor.matrix_world.translation.copy()
    t = (
        target.matrix_world.translation.copy()
        if hasattr(target, "matrix_world")
        else Vector(target)
    )
    fwd = Vector((t.x - a.x, t.y - a.y, 0))
    fwd = fwd.normalized() if fwd.length > 1e-6 else Vector((0, -1, 0))
    right = Vector((-fwd.y, fwd.x, 0))
    pos = Vector((a.x, a.y, a.z)) - fwd * back + right * side
    pos.z = a.z + height
    return camera(
        col, name, pos, lens=lens, look_at=Vector((t.x, t.y, t.z + height * 0.65))
    )


def cut_sequence(scene, shots):
    """绑定切镜相机，保留普通动作事件标记。"""
    shots = sorted(shots, key=lambda shot: shot[0])
    if len({shot[0] for shot in shots}) != len(shots):
        raise ValueError("同一帧只能有一个切镜")
    if any(
        shot[1].type != "CAMERA" or shot[1].name not in scene.objects for shot in shots
    ):
        raise ValueError("切镜必须使用当前场景的相机")
    for marker in list(scene.timeline_markers):
        if marker.camera:
            scene.timeline_markers.remove(marker)
    shots = sorted(shots, key=lambda s: s[0])
    for i, shot in enumerate(shots):
        frame, cam = shot[0], shot[1]
        label = shot[2] if len(shot) > 2 else f"shot{i + 1:02d}"
        marker = scene.timeline_markers.new(label, frame=frame)
        marker.camera = cam
    if shots:
        scene.camera = shots[0][1]
    return scene.timeline_markers


# --------------------------------------------------------------------------
# render profile / output
# --------------------------------------------------------------------------
def previz_render(
    scene, resolution=(1280, 720), outline=True, cavity=True, color_type="MATERIAL"
):
    """Workbench 预演配置；MATERIAL 保留纯色色块，SINGLE 用于纯几何检查。"""
    scene.render.engine = "BLENDER_WORKBENCH"
    scene.render.resolution_x, scene.render.resolution_y = resolution
    scene.render.resolution_percentage = 100
    scene.render.film_transparent = False
    scene.render.use_compositing = False
    scene.render.use_sequencer = False
    scene.render.image_settings.file_format = "PNG"
    scene.display.render_aa = "8"
    shading = scene.display.shading
    shading.light = "STUDIO"
    shading.color_type = color_type
    shading.show_shadows = True
    shading.show_cavity = cavity
    shading.cavity_type = "WORLD"
    shading.show_object_outline = outline
    shading.show_specular_highlight = False
    shading.background_type = "VIEWPORT"
    shading.background_color = (0.14, 0.15, 0.18)
    scene.view_settings.view_transform = "Standard"
    scene.view_settings.exposure = 0
    scene.view_settings.gamma = 1
    # Node-based materials leave the Workbench colour at default grey unless
    # diffuse_color is synced from the Principled base colour.
    for obj in scene.objects:
        for slot in obj.material_slots:
            mat = slot.material
            if mat and mat.use_nodes and mat.node_tree:
                bsdf = next(
                    (n for n in mat.node_tree.nodes if n.type == "BSDF_PRINCIPLED"),
                    None,
                )
                if bsdf and not bsdf.inputs["Base Color"].is_linked:
                    mat.diffuse_color = bsdf.inputs["Base Color"].default_value
    return {"engine": scene.render.engine, "resolution": list(resolution)}


def save(scene, blend_path, overwrite=False):
    """Pack dependencies and save. Always hand the user a .blend, not just frames."""
    from pathlib import Path

    blend_path = Path(blend_path).expanduser().resolve()
    if blend_path.exists() and not overwrite:
        raise FileExistsError(f"Preserve the previous revision: {blend_path}")
    blend_path.parent.mkdir(parents=True, exist_ok=True)
    if bpy.context.window:
        bpy.context.window.scene = scene
    scene.frame_set(scene.frame_start)
    bpy.ops.file.pack_all()
    bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))
    return str(blend_path)


def report(scene):
    """Compact scene summary: cheaper and more readable than get_scene_info."""
    subs = [o for o in scene.objects if o.get("wb_role") == "subject"]
    cams = [o for o in scene.objects if o.type == "CAMERA"]
    return {
        "scene": scene.name,
        "objects": len(scene.objects),
        "subjects": [o.name for o in subs],
        "cameras": [o.name for o in cams],
        "active_camera": scene.camera.name if scene.camera else None,
        "markers": [
            (m.frame, m.name, m.camera.name if m.camera else None)
            for m in sorted(scene.timeline_markers, key=lambda m: m.frame)
        ],
        "frames": [scene.frame_start, scene.frame_end],
        "fps": scene.render.fps,
        "engine": scene.render.engine,
    }


# Arc-length route and monotone time-distance mapping.
# Geometry and timing stay separate.
class ArcPath:
    def __init__(self, points, samples_per_segment=100):
        pts = [Vector(p) for p in points]
        if len(pts) < 2:
            raise ValueError("At least two route points required")
        count = max(2, (len(pts) - 1) * samples_per_segment)
        self.points = [_spline(pts, i / count) for i in range(count + 1)]
        self.distances = [0.0]
        for a, b in zip(self.points, self.points[1:]):
            self.distances.append(self.distances[-1] + (b - a).length)
        self.length = self.distances[-1]
        if self.length < 1e-8:
            raise ValueError("Route has zero length")

    def at(self, distance):
        d = min(self.length, max(0.0, distance))
        i = min(
            len(self.points) - 2, max(0, bisect.bisect_right(self.distances, d) - 1)
        )
        width = self.distances[i + 1] - self.distances[i]
        return self.points[i].lerp(
            self.points[i + 1], (d - self.distances[i]) / width if width else 0
        )

    def tangent(self, distance, window=0.15):
        d = min(self.length, max(0.0, distance))
        v = self.at(d + window) - self.at(d - window)
        return v.normalized() if v.length > 1e-8 else Vector((0, -1, 0))


def travel_distance(keys, time):
    """Monotone Hermite time/distance keys. Starts/stops at rest, no stop at each waypoint."""
    if len(keys) < 2 or any(
        b[0] <= a[0] or b[1] < a[1] for a, b in zip(keys, keys[1:])
    ):
        raise ValueError("Times must increase and distances must not decrease")
    i = max(0, min(len(keys) - 2, bisect.bisect_right([k[0] for k in keys], time) - 1))
    ta, va = keys[i]
    tb, vb = keys[i + 1]
    h = tb - ta
    u = max(0, min(1, (time - ta) / h))
    slopes = [(b[1] - a[1]) / (b[0] - a[0]) for a, b in zip(keys, keys[1:])]

    def slope(j):
        if j == 0 or j == len(keys) - 1:
            return 0.0
        a, b = slopes[j - 1 : j + 1]
        if a * b <= 0:
            return 0.0
        h0 = keys[j][0] - keys[j - 1][0]
        h1 = keys[j + 1][0] - keys[j][0]
        w0 = 2 * h1 + h0
        w1 = h1 + 2 * h0
        return (w0 + w1) / (w0 / a + w1 / b)

    return (
        (2 * u**3 - 3 * u * u + 1) * va
        + (u**3 - 2 * u * u + u) * h * slope(i)
        + (-2 * u**3 + 3 * u * u) * vb
        + (u**3 - u * u) * h * slope(i + 1)
    )


def fcurves(action):
    """Support legacy and layered Blender actions without traversing an action twice."""
    if hasattr(action, "layers") and len(action.layers):
        for layer in action.layers:
            for strip in layer.strips:
                for bag in getattr(strip, "channelbags", []):
                    yield from bag.fcurves
    elif hasattr(action, "fcurves"):
        yield from action.fcurves


def linear_keys(obj, data_paths=None):
    for curve in object_fcurves(obj):
        if data_paths is None or curve.data_path in data_paths:
            for key in curve.keyframe_points:
                key.interpolation = "LINEAR"


def key_rotation(obj, frame):
    obj.keyframe_insert(
        "rotation_quaternion"
        if obj.rotation_mode == "QUATERNION"
        else "rotation_euler",
        frame=frame,
    )


def retime(scene, frame_end):
    """Retime an isolated baked scene natively; save the result under a new filename.

    Refuses drivers, NLA and actions used outside this scene. Does not retime
    simulations, audio or external caches. See continuous-shot.md.
    """
    if frame_end <= scene.frame_start or scene.frame_end <= scene.frame_start:
        raise ValueError("Need at least two frames")
    owners = [scene]
    for obj in scene.objects:
        owners.extend([obj, obj.data] if obj.data else [obj])
    owners = list({o.as_pointer(): o for o in owners}.values())
    actions = {}
    for owner in owners:
        ad = owner.animation_data
        if not ad:
            continue
        if ad.drivers or ad.nla_tracks:
            raise ValueError("Bake drivers/NLA before retiming")
        if ad.action:
            actions[ad.action.as_pointer()] = ad.action
    # user_map also catches shared data and action users outside the object list.
    allowed = {o.as_pointer() for o in owners}
    user_map = bpy.data.user_map(subset=set(actions.values()))
    for action in actions.values():
        if any(o.as_pointer() not in allowed for o in user_map.get(action, set())):
            raise ValueError("Action has users outside this scene")
    for other in bpy.data.scenes:
        if other == scene:
            continue
        for obj in other.objects:
            if obj.as_pointer() in allowed or (
                obj.data and obj.data.as_pointer() in allowed
            ):
                raise ValueError("Scene shares animated owners with another scene")
    ratio = (frame_end - scene.frame_start) / (scene.frame_end - scene.frame_start)

    def remap(x):
        return scene.frame_start + (x - scene.frame_start) * ratio

    for action in actions.values():
        for curve in fcurves(action):
            for k in curve.keyframe_points:
                k.co.x = remap(k.co.x)
                k.handle_left.x = remap(k.handle_left.x)
                k.handle_right.x = remap(k.handle_right.x)
            curve.update()
    for marker in scene.timeline_markers:
        marker.frame = round(remap(marker.frame))
    scene.frame_end = frame_end
    scene.frame_set(scene.frame_start)


def object_fcurves(obj):
    """遍历对象绑定 slot 的曲线；不会误取其他角色的第一个 channelbag。"""
    ad = obj.animation_data
    if not ad or not ad.action:
        return
    action = ad.action
    if hasattr(action, "layers") and len(action.layers):
        slot = getattr(ad, "action_slot", None)
        if slot is None:
            raise ValueError(
                "分层 Action 未绑定 action_slot，不能猜测第一个 channelbag"
            )
        for layer in action.layers:
            for strip in layer.strips:
                if getattr(strip, "type", None) != "KEYFRAME":
                    continue
                bag = strip.channelbag(slot)
                if bag is not None:
                    yield from bag.fcurves
    elif hasattr(action, "fcurves"):
        yield from action.fcurves


def clear_keys(obj, data_paths, frame_range=None):
    """重建前只清理指定通道／帧区间。共享 Action 先复制，保留其他对象及通道。"""
    paths = set(data_paths)
    if not paths:
        raise ValueError("必须明确指定待重建通道")
    if frame_range and frame_range[1] < frame_range[0]:
        raise ValueError("无效帧范围")
    ad = obj.animation_data
    if not ad or not ad.action:
        return
    if ad.drivers or ad.nla_tracks:
        raise ValueError("对象含 drivers/NLA，请先明确动画归属并烘焙")
    # Resolve first so a missing slot fails before changing the action assignment.
    list(object_fcurves(obj))
    if ad.action.users > 1:
        slot_id = (
            ad.action_slot.identifier if getattr(ad, "action_slot", None) else None
        )
        ad.action = ad.action.copy()
        if slot_id:
            ad.action_slot = next(
                slot for slot in ad.action.slots if slot.identifier == slot_id
            )
    for curve in object_fcurves(obj):
        if curve.data_path not in paths:
            continue
        if frame_range is None:
            curve.keyframe_points.clear()
        else:
            lo, hi = frame_range
            for key in list(curve.keyframe_points)[::-1]:
                if lo <= key.co.x <= hi:
                    curve.keyframe_points.remove(key, fast=True)
        curve.update()
