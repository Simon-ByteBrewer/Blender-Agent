"""一镜到底小案例：四级台阶 → 缓和右转 → 固定座位入座。

示范将 12 秒母版原生重定时为 10 秒，保留走位与动作曲线。
blender -b --python-exit-code 1 --python example_continuous.py -- --out /tmp/wb-continuous
输出为独立目录（必须不存在），含两个 .blend、事件计划及各自验收报告。
"""

import argparse
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bpy
from mathutils import Vector
import wb_lib as wb
from check_scene import validate


def floor_z(y):
    if y <= 0:
        return 0.0
    if y >= 1.8:
        return -0.64
    return -0.16 * (int(y / 0.45) + 1)


def main(out):
    out.mkdir(parents=True, exist_ok=False)
    scene = wb.new_scene("Continuous", frame_end=288)
    sets = wb.collection(scene, "01-set")
    actors = wb.collection(scene, "02-subjects")
    cams = wb.collection(scene, "03-cameras")
    green = wb.material("stairs", (0.30, 0.50, 0.40))
    gold = wb.material("landing", (0.62, 0.54, 0.36))
    wb.box(sets, "lower-floor", (1, 1, -0.70), (16, 18, 0.12), gold)
    wb.box(sets, "upper-floor", (0, -3, -0.06), (6, 6, 0.12), green)
    for i in range(4):
        top = -0.16 * (i + 1)
        wb.box(
            sets,
            f"step-{i}",
            (0, (i + 0.5) * 0.45, (top - 0.7) / 2),
            (2.4, 0.45, top + 0.7),
            green,
        )
    # Colored walls retain spatial cues without placing a wall across the actual route.
    wb.box(sets, "stair-wall", (-1.3, 0.9, 0.5), (0.15, 2.1, 2.3), green)
    wb.box(sets, "landing-wall", (2, 4, 0.6), (6, 0.15, 2.5), gold)
    hero = wb.subject(actors, "hero", (0, -1.3, 0), color=(0.88, 0.88, 0.88))
    hero["wb_collision_bottom_m"] = 0.60  # torso capsule; feet checked separately
    body = wb.find("SUB-hero-body")
    head = wb.find("SUB-hero-head")
    chest = wb.find("SUB-hero-chesttape")
    nose = wb.find("SUB-hero-facing")
    # Shape the torso while keeping the subject root at the support reference height.
    body.scale = (1, 1, 0.46)
    mat = wb.material("limbs", (0.88, 0.88, 0.88))
    parts = {}
    for side in ("L", "R"):
        for part in ("thigh", "shin", "foot", "arm"):
            obj = wb.box(actors, f"{side}-{part}", (0, 0, 0), (1, 1, 1), mat)
            obj.parent = hero
            parts[side, part] = obj
            if part == "foot":
                obj["wb_role"] = "foot"
    route = wb.ArcPath(
        [(0, -1.3, 0), (0, 1.8, 0), (0, 2.35, 0), (0.65, 3, 0), (3.2, 3, 0)]
    )
    keys = [(0, 0), (3.8, 3.1), (6.0, 4.4), (9.5, route.length), (12, route.length)]
    wb.box(sets, "seat", (3.2, 3, -0.64 + 0.43), (0.70, 0.70, 0.12), gold)
    # The seat is intentional body contact; the collision capsule checks the torso above it.
    cam = wb.camera(cams, "follow", (0, -4.5, 1.7), lens=24, look_at=(0, -1.3, 1.2))
    scene.camera = cam
    events = [
        (1, "开始行走"),
        (49, "进入楼梯"),
        (92, "下楼结束"),
        (145, "缓和转弯"),
        (229, "固定座位入座"),
        (265, "稳定收尾"),
    ]
    for f, label in events:
        scene.timeline_markers.new(label, frame=f)
    for frame in range(1, 289):
        t = (frame - 1) / 24
        d = wb.travel_distance(keys, t)
        pos = route.at(d)
        pos.z = -0.64 * max(0, min(1, pos.y / 1.8))
        forward = route.tangent(d)
        forward.z = 0
        forward.normalize()
        sit = wb.ease(max(0, min(1, (t - 9.5) / 1.5)))
        hero.location = pos
        wb._aim(hero, pos, pos + forward)
        hero.keyframe_insert("location", frame=frame)
        wb.key_rotation(hero, frame)
        # Shortening the upper body collision volume allows intended seat contact.
        hero["wb_collision_height_m"] = 1.75 - 0.28 * sit
        hero.keyframe_insert('["wb_collision_height_m"]', frame=frame)
        body.location = (0, 0, 1.02 - 0.28 * sit)
        head.location = (0, 0, 1.60 - 0.28 * sit)
        chest.location = (0, -0.225, 1.16 - 0.28 * sit)
        nose.location = (0, -0.215, 1.60 - 0.28 * sit)
        for obj in (body, head, chest, nose):
            obj.keyframe_insert("location", frame=frame)
        bpy.context.view_layer.update()
        inv = hero.matrix_world.inverted()

        def limb(obj, a, b, width):
            obj.location = inv @ ((a + b) / 2)
            q = (inv.to_3x3() @ (b - a)).to_track_quat("Z", "Y")
            if obj.rotation_mode == "QUATERNION" and obj.rotation_quaternion.dot(q) < 0:
                q.negate()
            obj.rotation_mode = "QUATERNION"
            obj.rotation_quaternion = q
            obj.scale = (width, width, (b - a).length)

        right = Vector((-forward.y, forward.x, 0))
        for j, side in enumerate(("L", "R")):
            sign = -1 if j == 0 else 1
            # Phase is driven by distance: planted foot stays fixed while the body advances.
            stride = 0.45
            cycle = d / (2 * stride) + j * 0.5
            count = math.floor(cycle)
            u = cycle - count
            anchor = count * 2 * stride - j * stride
            swing = max(0, min(1, (u - 0.6) / 0.4))
            fd = anchor + 2 * stride * wb.ease(swing)
            footpos = route.at(fd)
            ft = route.tangent(fd)
            fr = Vector((-ft.y, ft.x, 0))
            footpos += fr * (sign * 0.13)
            z0 = floor_z(route.at(anchor).y)
            z1 = floor_z(route.at(anchor + 2 * stride).y)
            footpos.z = (
                z0 + (z1 - z0) * wb.ease(swing) + 0.18 * math.sin(math.pi * swing)
            )
            # Stable final foot placement while hips lower into the fixed seat.
            final = pos + right * (sign * 0.13) + forward * 0.35
            final.z = -0.64
            settle = wb.ease(max(0, min(1, (t - 8.8) / 0.7)))
            footpos = footpos.lerp(final, settle)
            foot = parts[side, "foot"]
            foot.location = inv @ (footpos + Vector((0, 0, 0.045)))
            foot.scale = (0.15, 0.27, 0.09)
            foot["wb_contact"] = float(u <= 0.6 or settle >= 0.999)
            foot.keyframe_insert('["wb_contact"]', frame=frame)
            hip = pos + right * (sign * 0.13) + Vector((0, 0, 0.82 - 0.28 * sit))
            ankle = footpos + Vector((0, 0, 0.09))
            knee = (hip + ankle) / 2 + forward * (0.13 + 0.22 * sit)
            limb(parts[side, "thigh"], hip, knee, 0.13)
            limb(parts[side, "shin"], knee, ankle, 0.11)
            shoulder = pos + right * (sign * 0.29) + Vector((0, 0, 1.25 - 0.28 * sit))
            hand = (
                pos
                + right * (sign * 0.29)
                + forward
                * (0.16 * math.sin(cycle * 2 * math.pi) * (1 - sit) + 0.25 * sit)
                + Vector((0, 0, 0.80 - 0.15 * sit))
            )
            limb(parts[side, "arm"], shoulder, hand, 0.10)
            for part in ("thigh", "shin", "foot", "arm"):
                obj = parts[side, part]
                obj.keyframe_insert("location", frame=frame)
                obj.keyframe_insert("scale", frame=frame)
                wb.key_rotation(obj, frame)
        cp = route.at(max(0, d - 3.2))
        if d < 3.2:
            cp += route.tangent(0) * (d - 3.2)
        cp.z = -0.64 * max(0, min(1, cp.y / 1.8)) + 1.70 + 0.20 * sit
        cp += right * (0.65 * sit)
        cam.location = cp
        wb._aim(cam, cp, pos + Vector((0, 0, 0.78 - 0.10 * sit)))
        # _aim enforces quaternion hemisphere continuity, including through the turn.
        cam.keyframe_insert("location", frame=frame)
        wb.key_rotation(cam, frame)
    for obj in scene.objects:
        wb.linear_keys(obj)
    # Contact is a discrete state; native retiming must not interpolate it as a blend.
    for obj in parts.values():
        if obj.get("wb_role") == "foot":
            for curve in wb.fcurves(obj.animation_data.action):
                if curve.data_path == '["wb_contact"]':
                    for k in curve.keyframe_points:
                        k.interpolation = "CONSTANT"
    wb.previz_render(scene)
    master = out / "continuous_12s.blend"
    wb.save(scene, master)
    report = validate(scene)
    (out / "check_12s.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2)
    )
    wb.retime(scene, 240)
    wb.save(scene, out / "continuous_10s.blend")
    report2 = validate(scene)
    (out / "check_10s.json").write_text(
        json.dumps(report2, ensure_ascii=False, indent=2)
    )
    (out / "shot_plan.json").write_text(
        json.dumps(
            {
                "master_seconds": 12,
                "retimed_seconds": 10,
                "fps": 24,
                "camera": "one continuous take",
                "events_master": events,
                "route_points": [list(p) for p in route.points[::100]],
                "time_distance": keys,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    if report["status"] != "passed" or report2["status"] != "passed":
        raise RuntimeError("示例验收失败，请查看 check JSON")
    print("WB_CONTINUOUS_SAVED", out, flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--out", required=True)
    a = p.parse_args(sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else [])
    main(Path(a.out).resolve())
