"""按工程指纹隔离白模渲染版本，恢复有效帧，编码并完整解码验证视频。

blender -b scene.blend --python-exit-code 1 --python render_previz.py -- --scene Whitebox --out out
预览、事件采样和正式帧放入不同 run；修改工程或参数会创建新 run。
"""

from __future__ import annotations
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import time
import uuid
from fractions import Fraction
from pathlib import Path


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path, value):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2))
    tmp.replace(path)


def prepare_run(out, meta):
    key = hashlib.sha256(json.dumps(meta, sort_keys=True).encode()).hexdigest()
    run = Path(out) / "runs" / f"{meta['mode']}-{key[:20]}"
    run.mkdir(parents=True, exist_ok=True)
    manifest = run / "render_metadata.json"
    if manifest.exists() and json.loads(manifest.read_text()) != meta:
        raise RuntimeError("渲染指纹冲突，请使用新的输出目录")
    # Each run lock protects both frame hashes and encoding. Do not auto-steal stale locks.
    lock = run / ".render.lock"
    try:
        lock.mkdir()
    except FileExistsError:
        raise RuntimeError(f"渲染目录已锁定；确认旧进程结束后才可移除 {lock}")
    try:
        atomic_json(manifest, meta)
    except BaseException:
        lock.rmdir()
        raise
    return run, lock


def validate_video(video, meta):
    proc = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-count_frames",
            "-show_streams",
            "-show_format",
            "-of",
            "json",
            str(video),
        ],
        capture_output=True,
        text=True,
        check=True,
    )
    data = json.loads(proc.stdout)
    v = next(x for x in data["streams"] if x["codec_type"] == "video")
    expected = len(meta["todo"])
    fps = float(Fraction(meta["fps"]))
    checks = {
        "frames": int(v["nb_read_frames"]) == expected,
        "fps": abs(float(Fraction(v["avg_frame_rate"])) - fps) < 1e-4,
        "resolution": [int(v["width"]), int(v["height"])]
        == [x + (x % 2) for x in meta["size"]],
        "duration": abs(float(data["format"]["duration"]) - expected / fps)
        < max(0.03, 1 / fps),
    }
    if not all(checks.values()):
        raise RuntimeError(f"视频参数不匹配：{checks}")
    subprocess.run(
        ["ffmpeg", "-v", "error", "-xerror", "-i", str(video), "-f", "null", "-"],
        check=True,
        capture_output=True,
    )
    return {"checks": checks, "full_decode": "passed", "sha256": digest(video)}


def encode(run, meta):
    if not all(shutil.which(tool) for tool in ("ffmpeg", "ffprobe")):
        raise RuntimeError("需要 ffmpeg 和 ffprobe；仅交付帧时显式传 --no-video")
    video = run / "reference.mp4"
    if video.exists():
        return video, validate_video(video, meta)
    temp = run / f"encoding-{uuid.uuid4().hex}.mp4"
    try:
        subprocess.run(
            [
                "ffmpeg",
                "-v",
                "error",
                "-n",
                "-framerate",
                meta["fps"],
                "-start_number",
                str(meta["todo"][0]),
                "-i",
                str(run / "frames/frame_%06d.png"),
                "-frames:v",
                str(len(meta["todo"])),
                "-c:v",
                "libx264",
                "-crf",
                "18",
                "-pix_fmt",
                "yuv420p",
                "-vf",
                "pad=ceil(iw/2)*2:ceil(ih/2)*2",
                "-movflags",
                "+faststart",
                str(temp),
            ],
            check=True,
        )
        report = validate_video(temp, meta)
        # Exclusive publication. An existing accepted video is never replaced.
        import os

        os.link(temp, video)
        return video, report
    finally:
        if temp.exists():
            temp.unlink()


def main():
    import bpy

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import wb_lib as wb

    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--scene", required=True)
    p.add_argument("--out", required=True)
    modes = p.add_mutually_exclusive_group()
    modes.add_argument("--preview", action="store_true", help="半分辨率首中尾帧")
    modes.add_argument(
        "--samples-per-cut", action="store_true", help="每个切镜首中尾帧"
    )
    modes.add_argument(
        "--events", action="store_true", help="事件前后帧＋均匀采样，适合一镜到底"
    )
    p.add_argument("--scale", type=int, default=100)
    p.add_argument("--no-video", action="store_true")
    a = p.parse_args(sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else [])
    if not 1 <= a.scale <= 100:
        raise ValueError("scale 必须在 1–100 之间")
    if not bpy.data.filepath or bpy.data.is_dirty:
        raise ValueError("请先保存工程，再在新后台进程中渲染，以保证指纹对应真实场景")
    scene = bpy.data.scenes[a.scene]
    bpy.context.window.scene = scene
    if not scene.camera:
        raise ValueError("场景未设置活动相机")
    wb.previz_render(
        scene, resolution=(scene.render.resolution_x, scene.render.resolution_y)
    )
    scale = 50 if a.preview else a.scale
    scene.render.resolution_percentage = scale
    start, end = scene.frame_start, scene.frame_end
    cuts = sorted(
        {
            m.frame
            for m in scene.timeline_markers
            if m.camera and start <= m.frame <= end
        }
        | {start}
    )
    if a.preview:
        todo = sorted({start, (start + end) // 2, end})
        mode = "preview"
    elif a.samples_per_cut:
        todo = sorted(
            {
                f
                for x, y in zip(cuts, cuts[1:] + [end + 1])
                for f in (x, (x + y - 1) // 2, y - 1)
            }
        )
        mode = "cuts"
    elif a.events:
        todo = sorted(
            {start, end}
            | {round(start + (end - start) * i / 12) for i in range(13)}
            | {
                f
                for m in scene.timeline_markers
                for f in (m.frame - 1, m.frame, m.frame + 1)
                if start <= f <= end
            }
        )
        mode = "events"
    else:
        todo = list(range(start, end + 1))
        mode = "full"
    # Packed whitebox files normally have no external dependencies. Hash any unpacked files too.
    dependencies = {}
    for item in bpy.utils.blend_paths(absolute=True, packed=False):
        path = Path(item)
        if not path.is_file():
            raise ValueError(f"外部依赖无法建立指纹，请先打包或烘焙：{item}")
        dependencies[str(path)] = digest(path)
    meta = {
        "mode": mode,
        "blend_sha256": digest(bpy.data.filepath),
        "scene": scene.name,
        "scripts": {x.name: digest(x) for x in (Path(__file__), Path(wb.__file__))},
        "dependencies": dependencies,
        "todo": todo,
        "fps": str(Fraction(scene.render.fps) / Fraction(str(scene.render.fps_base))),
        "size": [
            scene.render.resolution_x * scale // 100,
            scene.render.resolution_y * scale // 100,
        ],
        "engine": scene.render.engine,
        "scale": scale,
    }
    run, lock = prepare_run(a.out, meta)
    t0 = time.monotonic()
    try:
        frames = run / "frames"
        frames.mkdir(exist_ok=True)
        hashfile = run / "frame_hashes.json"
        hashes = json.loads(hashfile.read_text()) if hashfile.exists() else {}
        for i, frame in enumerate(todo, 1):
            path = frames / f"frame_{frame:06d}.png"
            valid = path.is_file() and hashes.get(str(frame)) == digest(path)
            if not valid:
                if path.exists():
                    path.rename(
                        path.with_suffix(f".invalid-{uuid.uuid4().hex[:8]}.png")
                    )
                scene.frame_set(frame)
                temp = frames / f".render-{frame}.png"
                scene.render.filepath = str(temp)
                bpy.ops.render.render(write_still=True, scene=scene.name)
                temp.replace(path)
                hashes[str(frame)] = digest(path)
                atomic_json(hashfile, hashes)
            atomic_json(
                run / "render_progress.json",
                {"status": "running", "done": i, "total": len(todo), "frame": frame},
            )
        video = None
        if mode == "full" and not a.no_video:
            video, report = encode(run, meta)
            atomic_json(run / "video_validation.json", report)
        result = {
            "status": "completed",
            "run": str(run),
            "frames": len(todo),
            "video": str(video) if video else None,
            "elapsed_s": round(time.monotonic() - t0, 1),
        }
        atomic_json(run / "render_progress.json", result)
        print("WB_RENDER_COMPLETE", json.dumps(result), flush=True)
    except BaseException as exc:
        atomic_json(
            run / "render_progress.json", {"status": "failed", "error": str(exc)}
        )
        raise
    finally:
        lock.rmdir()


if __name__ == "__main__":
    main()
