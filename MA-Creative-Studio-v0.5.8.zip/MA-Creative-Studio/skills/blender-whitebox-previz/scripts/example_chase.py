"""三镜头屋顶追逐：双角色、168 帧、24 fps。

blender -b --python-exit-code 1 --python example_chase.py -- --out /tmp/wb-chase-v01
输出目录必须不存在；构建后运行 check_scene.py --fast-subjects 1。
示例仅表达追逐和环绕收尾，没有扑倒动作。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import wb_lib as wb  # noqa: E402

FPS = 24
# 42 m of roofline over 168 frames = 7 s = ~7 m/s peak, a believable sprint.
# Compress this to 96 frames and check_scene.py rejects it at >9 m/s.
END = 168


def main(out_dir: Path):
    scene = wb.new_scene("Whitebox_Chase", fps=FPS, frame_end=END)
    sets = wb.collection(scene, "01-set")
    actors = wb.collection(scene, "02-subjects")
    cams = wb.collection(scene, "03-cameras")

    # --- set: rooftops as boxes; nothing here needs to be pretty -----------
    wb.ground(sets, size=120)
    # Contiguous roofline: 10 m boxes on 10 m centres, spanning x -25..25.
    # Leaving gaps, or starting an actor past the last box, makes proxies walk
    # on air; check_scene.py reports that as a ground error.
    roof_x = (-20, -10, 0, 10, 20)
    wb.blocks(sets, "SET-roof", [((x, 0, 6.0), (10, 14, 12)) for x in roof_x])
    wb.blocks(sets, "SET-parapet", [((x, -7.2, 12.5), (10, 0.4, 1.0)) for x in roof_x])
    # Stacks are placed away from the -y camera side so an OTS lens can travel
    # the roofline without clipping them; check_scene.py flags it if they move in.
    wb.blocks(
        sets,
        "SET-stack",
        [((-11, 5.2, 13.6), (1.2, 1.2, 3.2)), ((17, 5.6, 13.2), (1.6, 1.6, 2.4))],
    )

    # --- subjects: red thief chased by blue guard, both on the roofline ----
    thief = wb.subject(
        actors, "thief", (-18, 0, 12.0), height=1.75, color=wb.SUBJECT_COLORS[0]
    )
    guard = wb.subject(
        actors, "guard", (-24, 0, 12.0), height=1.82, color=wb.SUBJECT_COLORS[1]
    )
    thief_path = [(-18, 0, 12.0), (-6, 1.5, 12.0), (8, -1.0, 12.0), (24, 0.5, 12.0)]
    guard_path = [(-24, 0, 12.0), (-10, 1.0, 12.0), (5, -0.8, 12.0), (21, 0.4, 12.0)]
    wb.path(thief, thief_path, 1, END, easing="linear", face_travel=True, bob=0.05)
    wb.path(guard, guard_path, 1, END, easing="linear", look_at=thief, bob=0.05)

    # --- cameras: wide establish, OTS on the guard, low finish ------------
    # Subject paths are baked first, so every camera derived from an actor
    # position must name the frame it cuts in on.
    wide = wb.camera(cams, "01-wide", (-34, -38, 20), lens=28, look_at=(-6, 0, 13))
    ots = wb.over_shoulder(
        cams, "02-ots", guard, thief, frame=57, back=4.5, side=1.1, height=2.1, lens=32
    )
    low = wb.camera(cams, "03-low", (27, -9, 13.2), lens=24, look_at=(21, 0, 13.0))

    # follow moves so the cameras are not static during their cuts
    wb.path(wide, [(-34, -38, 20), (-20, -33, 19)], 1, 56, look_at=(-6, 0, 13))
    wb.at_frame(57)
    ots_start = ots.location.copy()
    wb.path(
        ots, [ots_start, ots_start + wb.Vector((13, 0.6, 0))], 57, 112, look_at=thief
    )
    wb.orbit(low, thief, radius=7.5, start=113, end=END, height=13.4, turns=0.28)

    wb.cut_sequence(
        scene,
        [
            (1, wide, "01 establish"),
            (57, ots, "02 over shoulder"),
            (113, low, "03 orbit finish"),
        ],
    )
    wb.previz_render(scene, resolution=(1280, 720))

    blend = out_dir / "whitebox_chase.blend"
    wb.save(scene, blend)
    report = wb.report(scene)
    (out_dir / "scene_report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False)
    )
    print("WB_BUILD", json.dumps(report, ensure_ascii=False), flush=True)
    globals()["WB_RESULT"] = str(blend)
    return report


if __name__ == "__main__":
    argv = sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="/tmp/wb_demo")
    a = p.parse_args(argv)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=False)
    main(out)
