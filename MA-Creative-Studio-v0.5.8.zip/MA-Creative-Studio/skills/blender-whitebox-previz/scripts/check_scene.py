"""白模逐帧验收：事件标记、运动、落地及显式 BOX 碰撞体。

blender -b scene.blend --python-exit-code 1 --python check_scene.py -- --scene Whitebox --json check.json
BOX 检查为保守的包围体测试，不等于通用网格/肢体穿插检测；报告列出未覆盖网格。
"""

from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
import bpy
from mathutils import Vector


def _args():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--scene", required=True)
    p.add_argument("--json")
    p.add_argument("--step", type=int, default=1, help="默认逐帧；大于 1 仅用于预检")
    p.add_argument("--fast-subjects", type=int, choices=[0, 1], default=0)
    return p.parse_args(
        sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    )


def capsule_box(a, b, radius, obj):
    """Conservative capsule vs oriented box, including points inside solid geometry.

    Transform centre segment to box coordinates; expand box by world radius.
    At box corners this overestimates overlap. Sheared colliders require manual review.
    """
    matrix = obj.matrix_world
    inverse = matrix.inverted_safe()
    a = inverse @ a
    b = inverse @ b
    delta = b - a
    corners = [Vector(v) for v in obj.bound_box]
    # Row norms convert a world-space sphere into local-axis extents.
    pad = [radius * inverse.to_3x3().row[i].length for i in range(3)]
    lo = [min(v[i] for v in corners) - pad[i] for i in range(3)]
    hi = [max(v[i] for v in corners) + pad[i] for i in range(3)]
    enter, leave = 0.0, 1.0
    for i in range(3):
        if abs(delta[i]) < 1e-9:
            if a[i] < lo[i] or a[i] > hi[i]:
                return False
        else:
            t0 = (lo[i] - a[i]) / delta[i]
            t1 = (hi[i] - a[i]) / delta[i]
            enter = max(enter, min(t0, t1))
            leave = min(leave, max(t0, t1))
            if enter > leave:
                return False
    return True


def validate(scene, step=1, fast=False):
    if step < 1:
        raise ValueError("step 必须 >= 1")
    bpy.context.window.scene = scene
    errors = []
    warnings = []
    tracks = {}
    previous = {}
    subs = [o for o in scene.objects if o.get("wb_role") == "subject"]
    parts = {p for o in subs for p in [o, *o.children_recursive]}
    cuts = sorted(
        (m for m in scene.timeline_markers if m.camera), key=lambda m: m.frame
    )
    if scene.camera is None or scene.camera.name not in scene.objects:
        errors.append("活动相机未设置或不属于当前场景")
    if scene.frame_end < scene.frame_start:
        errors.append("空帧范围")
    if len({m.frame for m in cuts}) != len(cuts):
        errors.append("同帧存在多个切镜标记")
    if any(m.camera.name not in scene.objects for m in cuts):
        errors.append("切镜相机不属于当前场景")
    if step > 1:
        warnings.append("抽样预检不能排除单帧跳变；交付前使用 --step 1")
    if not subs:
        warnings.append("没有 wb_role=subject，未验证人物；请显式标记现有角色")
    colliders = [
        o
        for o in scene.objects
        if o not in parts
        and o.type == "MESH"
        and o.get("wb_collider") == "BOX"
        and not o.hide_render
    ]
    unsupported = [
        o.name
        for o in scene.objects
        if o.type == "MESH"
        and o not in parts
        and not o.hide_render
        and o.get("wb_collider") != "BOX"
    ]
    if unsupported:
        warnings.append("部分网格没有 BOX 碰撞代理，体积碰撞覆盖不完整")
    fps = scene.render.fps / scene.render.fps_base
    frames = sorted(
        set(range(scene.frame_start, scene.frame_end + 1, step))
        | {scene.frame_end}
        | {m.frame for m in cuts if scene.frame_start <= m.frame <= scene.frame_end}
    )
    hidden = [(o, o.hide_get()) for o in parts if o.type == "MESH"]
    original_frame = scene.frame_current
    initial_camera = scene.camera
    for obj, _ in hidden:
        obj.hide_set(True)
    try:
        for frame in frames:
            scene.frame_set(frame)
            deps = bpy.context.evaluated_depsgraph_get()
            active = initial_camera
            for marker in cuts:
                if marker.frame <= frame:
                    active = marker.camera
            watched = [*subs] + ([active] if active else [])
            for obj in watched:
                pos = obj.matrix_world.translation.copy()
                subject = obj in subs
                record = tracks.setdefault(
                    obj.name, {"max_speed": 0.0, "max_angular_speed_deg": 0.0}
                )
                quat = obj.matrix_world.to_quaternion()
                if obj.name in previous:
                    pf, pp, pq = previous[obj.name]
                    # Skip camera motion across inactive shots, retain every actor frame.
                    if subject or pf == frame - step:
                        dt = (frame - pf) / fps
                        speed = (pos - pp).length / dt
                        record["max_speed"] = max(record["max_speed"], speed)
                        dot = min(1.0, abs(quat.dot(pq)))
                        import math

                        angular = math.degrees(2 * math.acos(dot)) / dt
                        record["max_angular_speed_deg"] = max(
                            record["max_angular_speed_deg"], angular
                        )
                        cap = float(
                            obj.get(
                                "wb_speed_max",
                                9 if fast and subject else 3 if subject else 25,
                            )
                        )
                        if speed > cap:
                            errors.append(
                                f"{obj.name} 第 {frame} 帧速度 {speed:.2f} > {cap} m/s"
                            )
                previous[obj.name] = (frame, pos, quat)
                radius = float(obj.get("wb_radius_m", 0.18 if subject else 0.12))
                if subject:
                    height = float(
                        obj.get("wb_collision_height_m", obj.get("wb_height_m", 1.75))
                    )
                    # Keep the lower sphere above the support surface; bob up to 5cm is allowed.
                    bottom = float(obj.get("wb_collision_bottom_m", 0.08))
                    a = pos + Vector((0, 0, radius + bottom))
                    b = pos + Vector((0, 0, max(radius + bottom, height - radius)))
                else:
                    a = b = pos
                for collider in colliders:
                    evaluated = collider.evaluated_get(deps)
                    if capsule_box(a, b, radius, evaluated):
                        errors.append(
                            f"{obj.name} 第 {frame} 帧包围体与 {collider.name} 相交"
                        )
                if subject:
                    feet = [
                        p for p in obj.children_recursive if p.get("wb_role") == "foot"
                    ]
                    probes = []
                    if feet:
                        for foot in feet:
                            if foot.get("wb_contact", 0) >= 0.5:
                                z = min(
                                    (foot.matrix_world @ Vector(v)).z
                                    for v in foot.bound_box
                                )
                                point = foot.matrix_world.translation.copy()
                                point.z = z
                                probes.append(point)
                        if not probes:
                            errors.append(
                                f"{obj.name} 第 {frame} 帧无支撑脚；腾空动作需单独验收"
                            )
                    else:
                        probes = [pos]
                    for point in probes:
                        hit, loc, *_ = scene.ray_cast(
                            deps,
                            point + Vector((0, 0, 0.3)),
                            Vector((0, 0, -1)),
                            distance=80,
                        )
                        tol = float(obj.get("wb_ground_tolerance", 0.06))
                        if not hit or abs(point.z - loc.z) > tol:
                            errors.append(f"{obj.name} 第 {frame} 帧支撑点未贴地")
    finally:
        for obj, hide in hidden:
            obj.hide_set(hide)
        scene.frame_set(original_frame)
        scene.camera = initial_camera
    return {
        "status": "failed" if errors else "passed",
        "scene": scene.name,
        "frames": [scene.frame_start, scene.frame_end],
        "step": step,
        "fps": fps,
        "collision_method": "conservative capsule vs explicit BOX; support ray casts",
        "unsupported_meshes": unsupported,
        "motion": tracks,
        "error_count": len(errors),
        "errors": errors[:80],
        "warnings": warnings,
        "events": [(m.frame, m.name) for m in scene.timeline_markers if not m.camera],
        "cuts": [(m.frame, m.camera.name) for m in cuts],
    }


def main():
    a = _args()
    scene = bpy.data.scenes.get(a.scene)
    if not scene:
        raise ValueError(f"场景不存在：{a.scene}")
    report = validate(scene, a.step, bool(a.fast_subjects))
    if a.json:
        path = Path(a.json)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print("WB_CHECK", json.dumps(report, ensure_ascii=False), flush=True)
    if report["status"] == "failed":
        raise RuntimeError("白模验收失败，见报告")


if __name__ == "__main__":
    main()
