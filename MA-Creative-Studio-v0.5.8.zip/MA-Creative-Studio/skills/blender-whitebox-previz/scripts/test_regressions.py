"""有意义的行为回归；仅在独立 Blender 后台进程运行，输出写入临时目录。
blender -b --python-exit-code 1 --python test_regressions.py
"""

import math
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bpy
from mathutils import Vector
import wb_lib as wb
from check_scene import validate
from render_previz import prepare_run


def main():
    out = Path(tempfile.mkdtemp(prefix="wb-regression-"))
    host_scene = bpy.data.scenes.new("HostProject")
    existing = bpy.data.objects.new("ExistingObject", None)
    host_scene.collection.objects.link(existing)
    wb.attach_scene(host_scene)
    namespace = host_scene["wb_namespace"]
    wb.attach_scene(host_scene)
    assert (
        host_scene["wb_namespace"] == namespace and existing.name in host_scene.objects
    )
    s = wb.new_scene("Regression", frame_end=5)
    col = wb.collection(s, "actors")
    sets = wb.collection(s, "set")
    cams = wb.collection(s, "cameras")
    wb.ground(sets)
    hero = wb.subject(col, "hero", (0, 0, 0))
    wb.path(hero, [(0, 0, 0), (1, 0, 0)], 1, 25, easing="linear", face_travel=True)
    wb.at_frame(5)
    assert (hero.matrix_world.to_quaternion() @ Vector((0, -1, 0))).dot(
        Vector((1, 0, 0))
    ) > 0.999
    old_loc = hero.location.copy()
    mat = hero.children[0].data.materials[0]
    old_color = tuple(mat.diffuse_color)
    s2 = wb.new_scene("Regression2", frame_end=5)
    col2 = wb.collection(s2, "actors")
    hero2 = wb.subject(col2, "hero", (5, 0, 0), color=(0, 1, 0))
    assert col != col2 and hero != hero2 and (hero.location - old_loc).length < 1e-8
    assert (
        tuple(mat.diffuse_color) == old_color
        and hero.name in s.objects
        and hero2.name not in s.objects
    )
    try:
        wb.new_scene("Regression")
    except ValueError:
        pass
    else:
        raise AssertionError("Existing scene reset silently")
    bpy.context.window.scene = s
    cam = wb.camera(cams, "camera", (0, -5, 2), look_at=(0, 0, 1))
    s.camera = cam
    s.timeline_markers.new("Walk", frame=1)
    wb.previz_render(s)
    assert validate(s)["status"] == "passed"
    solid = wb.box(sets, "solid", (0, -5, 2), (4, 4, 4), wb.material("grey", wb.GREY))
    assert validate(s)["status"] == "failed"  # lens 2m inside box, no close forward hit
    bpy.data.objects.remove(solid, do_unlink=True)
    # A one-frame excursion must be seen by the default check.
    hero.animation_data_clear()
    for f, x in [(1, 0), (2, 3), (3, 0), (4, 0), (5, 0)]:
        hero.location = (x, 0, 0)
        hero.keyframe_insert("location", frame=f)
    assert validate(s)["status"] == "failed"
    # Arc-length sampling removes control-point spacing from travel speed.
    route = wb.ArcPath([(0, 0, 0), (0.1, 0, 0), (10, 0, 0), (11, 1, 0)])
    distances = [
        (
            route.at((i + 1) * route.length / 100) - route.at(i * route.length / 100)
        ).length
        for i in range(100)
    ]
    assert max(distances) - min(distances) < 0.015
    keys = [(0, 0), (2, 1), (5, 6), (7, 6)]
    values = [wb.travel_distance(keys, i / 100) for i in range(701)]
    assert all(b >= a - 1e-8 for a, b in zip(values, values[1:]))
    assert abs(values[-1] - 6) < 1e-8
    # Camera rotation across the angle branch stays in one quaternion hemisphere.
    quats = []
    for angle in [math.pi - 0.1, math.pi, math.pi + 0.1]:
        wb._aim(cam, Vector((0, 0, 0)), Vector((math.cos(angle), math.sin(angle), 0.1)))
        quats.append(cam.rotation_quaternion.copy())
    assert all(a.dot(b) > 0 for a, b in zip(quats, quats[1:]))
    hero.animation_data_clear()
    wb.path(hero, [(0, 0, 0), (1, 0, 0)], 1, 25, easing="linear")
    s.frame_end = 25
    s.timeline_markers.new("End", frame=25)
    wb.retime(s, 13)
    wb.at_frame(13)
    assert abs(hero.location.x - 1) < 1e-6 and s.timeline_markers["End"].frame == 13
    wb.at_frame(7)
    assert abs(hero.location.x - 0.5) < 1e-5
    # Blender 5.x multi-slot Action: per-object edits must not touch another slot.
    helper = wb.subject(col, "helper", (2, 0, 0))
    shared = bpy.data.actions.new("MultiSlot")
    for obj in (hero, helper):
        obj.animation_data_clear()
        ad = obj.animation_data_create()
        ad.action = shared
        ad.action_slot = shared.slots.new(id_type="OBJECT", name=obj.name)
        for frame in (1, 25):
            obj.location.x = frame / 25
            obj.keyframe_insert("location", frame=frame)
            obj.keyframe_insert("scale", frame=frame)
    assert len(list(wb.object_fcurves(hero))) == 6
    assert len(list(wb.fcurves(shared))) == 12
    wb.linear_keys(hero, {"location"})
    assert all(
        k.interpolation == "BEZIER"
        for fc in wb.object_fcurves(helper)
        for k in fc.keyframe_points
    )
    wb.clear_keys(hero, {"location"})
    assert hero.animation_data.action != helper.animation_data.action
    assert all(len(fc.keyframe_points) == 2 for fc in wb.object_fcurves(helper))
    assert all(
        len(fc.keyframe_points) == 2
        for fc in wb.object_fcurves(hero)
        if fc.data_path == "scale"
    )
    for _ in range(2):
        wb.clear_keys(hero, {"location"})
        for frame in (1, 25):
            hero.location.x = frame / 25
            hero.keyframe_insert("location", frame=frame)
    assert all(len(fc.keyframe_points) == 2 for fc in wb.object_fcurves(hero))
    wb.clear_keys(hero, {"location"}, frame_range=(1, 1))
    assert all(
        [k.co.x for k in fc.keyframe_points] == [25]
        for fc in wb.object_fcurves(hero)
        if fc.data_path == "location"
    )
    # Rebind the two owners to a shared Action; retime every channelbag exactly once.
    ad = hero.animation_data
    ad.action = shared
    ad.action_slot = shared.slots[0]  # controlled test fixture, not production lookup
    s.frame_end = 25
    wb.retime(s, 13)
    assert all(fc.keyframe_points[-1].co.x == 13 for fc in wb.fcurves(shared))
    # Store a small valid scene for actual render/encode smoke tests.
    s.frame_end = 4
    s.render.resolution_x = 160
    s.render.resolution_y = 90
    wb._aim(cam, cam.location, Vector((0, 0, 1)))
    wb.save(s, out / "smoke.blend")
    try:
        wb.save(s, out / "smoke.blend")
    except FileExistsError:
        pass
    else:
        raise AssertionError("save overwrote existing revision")
    meta = {
        "mode": "full",
        "blend_sha256": "a",
        "todo": [1, 2, 3, 4],
        "size": [160, 90],
    }
    run, lock = prepare_run(out, meta)
    lock.rmdir()
    same, lock = prepare_run(out, meta)
    lock.rmdir()
    assert same == run
    other, lock = prepare_run(out, {**meta, "blend_sha256": "b"})
    lock.rmdir()
    assert other != run
    preview, lock = prepare_run(out, {**meta, "mode": "preview"})
    lock.rmdir()
    assert preview != run
    print("WB_REGRESSIONS_PASSED", out, flush=True)


if __name__ == "__main__":
    main()
