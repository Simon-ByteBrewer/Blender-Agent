# Blender MCP 操作

## 连接与执行方式

先调用 `get_scene_info` 判断工具能否连接当前 Blender。失败时按实际错误处理：连接拒绝可能是插件未监听，超时也可能是上一个任务仍在运行。不要把任意错误都判断为未启动，更不要重复发送构建任务。

常见工具包括 `execute_blender_code`、`get_scene_info`、`get_object_info` 和 `get_viewport_screenshot`。不同插件版本的工具、端口及超时不同，以当前可用能力为准。优先用 `bpy.data` 构造几何，减少对窗口上下文的依赖。

## 跨调用状态

Python 局部变量可能不会在调用间保留，`bpy.data` 会保留。每次重新导入库并取回当前场景及对象：

```python
import bpy, sys
sys.path.insert(0, "<skill>/scripts")
import wb_lib as wb
scene = bpy.data.scenes["Whitebox_v01"]
bpy.context.window.scene = scene
hero = wb.find("SUB-hero", scene)
wb.at_frame(57)
pos = hero.matrix_world.translation.copy()
```

修改库后需 `importlib.reload(wb)`。集合和对象的实际名称有场景命名空间；不要使用旧版无命名空间的全局名称查找。

## 长任务与超时

通常插件在 Blender 主线程执行代码，构建或渲染会阻塞 UI。超时不代表任务取消；先查状态文件和 Blender 进程再决定后续动作，不盲目重试。

短交互按空间、人物、运动、相机分阶段，每阶段输出简短摘要。完整渲染优先保存工程后启动独立后台进程。

需要在当前交互 Blender 中执行长任务时，可用 `scripts/mcp_job.py`：

```python
from mcp_job import defer
code, state_file = defer("/absolute/build.py", state_dir="/absolute/jobs")
# 将 code 传给 execute_blender_code，随后从本地文件读取 state_file。
```

包装器用 `bpy.app.timers` 延后执行，先让 MCP 请求返回；它不会把 Blender 工作转成后台线程，执行时仍会阻塞 UI。状态为 `queued → running → succeeded / failed`，结果路径可通过脚本的 `WB_RESULT` 返回。

这个方式依赖交互 Blender 的事件循环，不适用于 `blender -b --python`。后台模式直接运行脚本即可。超过预期时间但状态未终结时，检查进程和日志，不自动提交重复任务。

## 场景与保存

操作用户正在编辑的文件前先保存到新版本路径。`wb.new_scene()` 不覆盖已有同名场景；命名空间能避免正常构建的同名冲突，但 `.blend` 仍包含文件中的所有场景。

旧工程不一定有 `wb_role` 或 BOX 代理；不能只运行 gate 得到“没有角色”的 warning 就视为完整验收。显式标记要检查的对象，并核对哪些网格需要额外验证。

不要在用户现有文件中调用清空全局数据的操作。要交付精简的独立工程，可以在新后台进程中构建。

## 后台命令

```bash
# macOS 常见位置；以本机实际安装为准
BL=/Applications/Blender.app/Contents/MacOS/Blender
"$BL" -b --python-exit-code 1 --python build.py
"$BL" -b scene.blend --python-exit-code 1 --python <skill>/scripts/check_scene.py -- \
  --scene Whitebox_v01 --json check.json
"$BL" -b scene.blend --python-exit-code 1 --python <skill>/scripts/render_previz.py -- \
  --scene Whitebox_v01 --out out/v01
```

`--python-exit-code 1` 让脚本异常变成进程失败，供流水线识别。后台代码不要依赖 `bpy.context.screen`。修改或重定时后的工程先保存，再从新进程读取渲染，确保输出指纹对应磁盘工程。

渲染器按 run 建锁；进程异常退出可能留下 `.render.lock`。只有确认原进程已结束后才移除对应锁，不自动抢锁或并发写同一 run。
