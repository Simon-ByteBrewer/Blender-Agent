#!/bin/zsh
set -euo pipefail
TASK_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$TASK_ROOT"
export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/.local/bin:$PATH"
mkdir -p logs .local data
# The macOS app shell sets STUDIO_NO_BROWSER=1 and shows the page itself.
open_page() { [[ -n "${STUDIO_NO_BROWSER:-}" ]] || open http://127.0.0.1:7860; }
if curl -fsS http://127.0.0.1:7860/api/health >/dev/null 2>&1; then
  open_page
  echo '工作室已运行：http://127.0.0.1:7860'
  exit 0
fi
command -v uv >/dev/null || { echo '请先安装 uv'; exit 1; }
command -v ffmpeg >/dev/null || { echo '请先安装 ffmpeg'; exit 1; }
STUDIO_BLENDER_BIN=/Applications/Blender.app/Contents/MacOS/Blender
[[ -x "$STUDIO_BLENDER_BIN" ]] || { echo '请将 Blender.app 安装到 /Applications（应用程序）'; exit 1; }
uv sync --frozen --all-packages
STUDIO_BLENDER_VERSION=$("$STUDIO_BLENDER_BIN" --version | awk 'NR == 1 {split($2, v, "."); print v[1] "." v[2]}')
[[ "$STUDIO_BLENDER_VERSION" == <->.<-> ]] || { echo '无法识别 Blender 版本'; exit 1; }
STUDIO_ADDONS_DIR="$HOME/Library/Application Support/Blender/$STUDIO_BLENDER_VERSION/scripts/addons"
if [[ ! -f "$STUDIO_ADDONS_DIR/blender_mcp.py" ]]; then
  echo '首次启动：安装 Blender MCP 插件…'
  .venv/bin/blender-mcp install-addon --addons-dir "$STUDIO_ADDONS_DIR"
fi
if [[ ! -f frontend/dist/index.html ]]; then
  command -v npm >/dev/null || { echo '缺少预编译页面，请安装 Node.js 后重试'; exit 1; }
  (cd frontend && npm ci && npm run build)
fi
# Open the page only after the API is ready.
(
  for attempt in {1..60}; do
    if curl -fsS http://127.0.0.1:7860/api/health >/dev/null 2>&1; then
      open_page
      exit 0
    fi
    sleep 1
  done
  echo '页面尚未就绪，请查看终端报错。'
) &
echo '启动工作室：http://127.0.0.1:7860（按 Ctrl+C 停止服务）'
PYTHONPATH="$TASK_ROOT/backend/src" exec .venv/bin/python -m uvicorn studio.app:app --host 127.0.0.1 --port 7860 --timeout-graceful-shutdown 5
