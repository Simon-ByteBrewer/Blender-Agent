"""Scene-independent render/encode/validate CLI. Demo pipeline is demo_pipeline.py."""

import argparse
import fcntl
import json
import os
import subprocess
import sys
from contextlib import ExitStack
from contextvars import ContextVar
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend/src"))
from studio.video_names import reserve_video

active_pool = ContextVar("render_pool", default=None)


def run(command):
    pool = active_pool.get()
    if pool is not None:
        from ma_self_hosted.render_pool import run_leased
        run_leased(command, pool)
    else:
        subprocess.run([str(v) for v in command], check=True)


def encode(out, movie):
    m = json.loads((out / "render_metadata.json").read_text())
    for frame in range(m["start"], m["end"] + 1):
        if not (out / f"frames/frame_{frame:06d}.png").is_file():
            raise RuntimeError(f"Missing frame {frame}")
    run(
        [
            "ffmpeg",
            "-v",
            "error",
            "-n",
            "-framerate",
            m["fps"],
            "-start_number",
            m["start"],
            "-i",
            out / "frames/frame_%06d.png",
            "-frames:v",
            m["frames"],
            "-c:v",
            "libx264",
            *(["-threads", os.environ["STUDIO_RENDER_THREADS"]] if os.environ.get("STUDIO_RENDER_THREADS") else []),
            "-crf",
            18,
            "-pix_fmt",
            "yuv420p",
            "-vf",
            "pad=ceil(iw/2)*2:ceil(ih/2)*2",
            "-movflags",
            "+faststart",
            movie,
        ]
    )


def validate(out, movie):
    expected = json.loads((out / "render_metadata.json").read_text())
    probe_command = [
            "ffprobe",
            "-v",
            "error",
            *(["-threads", os.environ["STUDIO_RENDER_THREADS"]] if os.environ.get("STUDIO_RENDER_THREADS") else []),
            "-count_frames",
            "-show_streams",
            "-show_format",
            "-of",
            "json",
            str(movie),
        ]
    pool = active_pool.get()
    if pool is not None:
        from ma_self_hosted.render_pool import run_leased
        result = run_leased(probe_command, pool, capture_output=True)
    else:
        result = subprocess.run(probe_command, check=True, capture_output=True, text=True)
    data = json.loads(result.stdout)
    stream = next(s for s in data["streams"] if s["codec_type"] == "video")
    assert int(stream["nb_read_frames"]) == expected["frames"], "Frame count mismatch"
    numerator, denominator = map(int, stream["avg_frame_rate"].split("/"))
    assert abs(numerator / denominator - expected["fps"]) < 0.001, "FPS mismatch"
    assert (
        abs(float(data["format"]["duration"]) - expected["frames"] / expected["fps"])
        < 0.1
    )
    assert (
        stream["width"] == (expected["width"] + 1) // 2 * 2
        and stream["height"] == (expected["height"] + 1) // 2 * 2
    )
    run(["ffmpeg", "-v", "error", "-xerror",
         *(["-threads", os.environ["STUDIO_RENDER_THREADS"]] if os.environ.get("STUDIO_RENDER_THREADS") else []),
         "-i", movie, "-f", "null", "-"])
    report = dict(
        **expected,
        video=str(movie),
        duration_seconds=float(data["format"]["duration"]),
        full_decode="passed",
    )
    (out / "video_validation.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("action", choices=["preview", "render", "encode", "validate", "all"])
    p.add_argument("--blend", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--scene", required=True)
    p.add_argument("--movie", help="Explicit output filename; existing videos are never overwritten")
    p.add_argument("--project-id", help="Defaults to the output directory name")
    p.add_argument("--samples", type=int, default=16)
    p.add_argument("--profile", choices=["previs", "scene"], default="previs")
    args = p.parse_args()
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)
    if args.movie and (Path(args.movie).name != args.movie or not args.movie.endswith(".mp4")):
        raise ValueError("Movie must be an MP4 filename")
    if not Path(args.blend).is_file():
        raise ValueError("Save the Blender project before rendering")
    with (out / ".pipeline.lock").open("w") as lock, ExitStack() as cleanup:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("This project already has an active renderer")
        pool_directory = os.environ.get("STUDIO_RENDER_POOL")
        workers = int(os.environ.get("STUDIO_RENDER_WORKERS", "1"))
        if not pool_directory and os.environ.get("STUDIO_WORKER_CONFIG"):
            # Existing workers pick up this subprocess code on their next job;
            # enabling the pool does not require restarting Blender/the desktop.
            from ma_self_hosted.capacity import detect
            capacity = detect()
            home = Path(os.environ.get("STUDIO_HOME") or Path(os.environ["STUDIO_WORKER_CONFIG"]).parent)
            pool_directory = str(home / ".local" / "render-pool")
            workers = capacity.render_slots
            for name in ("STUDIO_RENDER_THREADS", "LP_NUM_THREADS", "OMP_NUM_THREADS"):
                os.environ.setdefault(name, str(capacity.threads_per_render))
        if pool_directory:
            from ma_self_hosted.render_pool import RenderPool
            pool = cleanup.enter_context(RenderPool(pool_directory, workers, owner_fds=(lock.fileno(),)))
            token = active_pool.set(pool)
            cleanup.callback(active_pool.reset, token)
        project_id = args.project_id or out.name
        if Path(project_id).name != project_id or project_id in {".", ".."}:
            raise ValueError("Invalid project ID")
        movie = out / args.movie if args.movie else None
        if args.action in ["encode", "all"]:
            if movie is None:
                name, reservation = reserve_video(out, project_id)
                movie = out / name
                cleanup.callback(reservation.unlink, missing_ok=True)
            if movie.exists():
                raise FileExistsError(f"Video already exists; choose a new filename: {movie.name}")
        elif args.action == "validate" and movie is None:
            candidates = [f for f in out.glob("*.mp4") if f.name.startswith(("previz-" + project_id + "-", project_id + "-", "render_")) or f.name == "reference.mp4"]
            if not candidates:
                raise FileNotFoundError("No rendered video to validate; specify --movie")
            movie = max(candidates, key=lambda f: f.stat().st_mtime_ns)
        if args.action in ["preview", "render", "all"]:
            command = [
                os.getenv(
                    "BLENDER_BIN",
                    "/Applications/Blender.app/Contents/MacOS/Blender",
                ),
                "-b",
                args.blend,
                *(["--threads", os.environ["STUDIO_RENDER_THREADS"]] if os.environ.get("STUDIO_RENDER_THREADS") else []),
                "--python-exit-code",
                1,
                "-P",
                ROOT / "blender_scripts/render.py",
                "--",
                "--output",
                out,
                "--scene",
                args.scene,
                "--samples",
                args.samples,
                "--profile",
                args.profile,
                "--mode",
                "preview" if args.action == "preview" else "render",
            ]
            pool = active_pool.get()
            if pool is not None and pool.slots > 1 and args.action != "preview" and args.profile == "previs":
                from ma_self_hosted.render_pool import render_parallel
                render_parallel(command, out, pool)
            else:
                run(command)
        if args.action in ["encode", "all"]:
            encode(out, movie)
        if args.action in ["validate", "all"]:
            validate(out, movie)


if __name__ == "__main__":
    import signal

    def interrupted(signum, frame):
        raise KeyboardInterrupt("Pipeline interrupted")

    signal.signal(signal.SIGTERM, interrupted)
    main()
