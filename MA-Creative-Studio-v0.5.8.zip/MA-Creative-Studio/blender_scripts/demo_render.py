"""Background render worker; called by pipeline.py, never inside an MCP timeout."""

import bpy, sys, json, time, hashlib, shutil
from pathlib import Path

args = sys.argv[sys.argv.index("--") + 1 :]
mode = args[0] if args else "preview"
root = Path(__file__).resolve().parents[1]
s = bpy.data.scenes["Tiananmen_Tourist"]
bpy.context.window.scene = s
s.render.engine = "CYCLES"
prefs = bpy.context.preferences.addons["cycles"].preferences
try:
    prefs.compute_device_type = "METAL"
    prefs.get_devices()
    for d in prefs.devices:
        d.use = d.type == "METAL"
    s.cycles.device = "GPU"
except Exception:
    s.cycles.device = "CPU"
s.cycles.samples = 24 if mode == "preview" else 16
s.cycles.use_denoising = True
s.cycles.use_light_tree = True
s.render.use_persistent_data = True
s.render.resolution_percentage = 75 if mode == "preview" else 100
s.render.image_settings.file_format = "PNG"
frames = [1, 96, 97, 192, 193, 288] if mode == "preview" else list(range(1, 289))
if len(args) > 1:
    frames = [int(v) for v in args[1].split(",")]
folder = root / "data" / ("previews" if mode == "preview" else "frames")
folder.mkdir(exist_ok=True)
signature = (
    hashlib.sha256(Path(bpy.data.filepath).read_bytes()).hexdigest()
    + f":{s.cycles.samples}:{s.render.resolution_percentage}:v1"
)
manifest = folder / "manifest.json"
if mode != "preview":
    previous = (
        json.loads(manifest.read_text()).get("signature") if manifest.exists() else None
    )
    if previous != signature and any(folder.glob("frame_*.png")):
        archive = root / "data/archive" / str(time.time_ns())
        archive.parent.mkdir(exist_ok=True)
        shutil.move(str(folder), str(archive))
        folder.mkdir()
    manifest.write_text(
        json.dumps({"signature": signature, "blend": bpy.data.filepath})
    )
started = time.time()
for f in frames:
    path = folder / f"frame_{f:04d}.png"
    if mode != "preview" and path.exists():
        continue
    s.frame_set(f)
    s.render.filepath = str(path)
    bpy.ops.render.render(write_still=True, scene=s.name)
    (root / "data/render_progress.json").write_text(
        json.dumps(
            dict(
                mode=mode,
                status="running",
                frame=f,
                total=288,
                elapsed_seconds=round(time.time() - started, 1),
            )
        )
    )
(root / "data/render_progress.json").write_text(
    json.dumps(
        dict(
            mode=mode,
            status="completed",
            frame=frames[-1],
            total=288,
            elapsed_seconds=round(time.time() - started, 1),
        )
    )
)
print("RENDER_COMPLETE", mode, flush=True)
