"""Shared CLI: PYTHONPATH=backend/src .venv/bin/python blender_scripts/seedance_cli.py submit --source HTTPS_URL"""

import argparse, asyncio, json, time
from studio.ark import Ark
from studio.store import Store
from seedance.client import Seedance, PROMPT, RATIOS
from seedance.compose import compose


async def main():
    p = argparse.ArgumentParser()
    p.add_argument("action", choices=["submit", "status", "wait", "download", "compose"])
    p.add_argument("--source")
    p.add_argument("--reference", default="reference.mp4")
    p.add_argument("--prompt", default=PROMPT)
    p.add_argument("--duration", type=int, default=12)
    p.add_argument("--resolution", choices=["480p", "720p", "1080p"], default="720p")
    p.add_argument("--mode", choices=["auto", "reference", "extend", "edit"], default="auto")
    p.add_argument("--ratio", choices=sorted(RATIOS | {"auto"}), default="16:9")
    p.add_argument("--image", action="append", default=[], help="Repeat for ordered image references")
    p.add_argument("--video", action="append", default=[], help="Repeat; first video is the extend/edit source")
    p.add_argument("--audio", action="append", default=[], help="Repeat for MP3/WAV audio references")
    p.add_argument("--text-only", action="store_true", help="Generate without the default reference video")
    p.add_argument("--directory", help="Reference/output directory relative to project data/")
    p.add_argument("--session-id", help="Current MA Session for automatic managed upload without TOS AK/SK")
    p.add_argument("--generate-audio", action="store_true")
    p.add_argument("--clip", action="append", default=[], help="compose: repeat in playback order")
    p.add_argument("--task-id")
    p.add_argument("--timeout", type=int, default=1200)
    a = p.parse_args()
    client = Seedance(Ark(), Store())
    if a.action == "compose":
        if not a.directory or not a.clip:
            p.error("compose requires --directory and --clip")
        r = await compose(a.directory, a.clip, a.resolution, a.ratio)
    elif a.action == "submit":
        refs = [{"type": kind, "source": source}
                for kind, sources in (("image", a.image), ("video", a.video), ("audio", a.audio))
                for source in sources]
        if a.text_only and refs:
            p.error("--text-only cannot be combined with reference flags")
        if a.source and (refs or a.text_only):
            p.error("--source cannot be combined with --image/--video/--audio/--text-only")
        r = await client.submit(a.reference, a.prompt, a.duration, a.source, resolution=a.resolution,
                                mode=a.mode, ratio=a.ratio, generate_audio=a.generate_audio,
                                references=refs if refs or a.text_only else None, directory=a.directory,
                                upload_session_id=a.session_id)
    else:
        if not a.task_id:
            p.error("--task-id is required")
        if a.action == "status":
            r = await client.status(a.task_id)
        elif a.action == "download":
            r = await client.download(a.task_id)
        else:
            start = time.monotonic()
            while True:
                r = await client.status(a.task_id)
                if r["status"] == "succeeded":
                    r = await client.download(a.task_id)
                    break
                if r["status"] in ["failed", "expired", "cancelled"]:
                    raise RuntimeError(json.dumps(r, ensure_ascii=False))
                if time.monotonic() - start > a.timeout:
                    raise TimeoutError(
                        "Task still running; resume with the same task ID"
                    )
                await asyncio.sleep(10)
    print(json.dumps(r, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
