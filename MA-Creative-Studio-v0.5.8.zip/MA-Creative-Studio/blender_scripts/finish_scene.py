import bpy, math, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
scene = bpy.context.scene
COL = scene.collection.children["10 Daylight"]


def collection(name):
    pass


collection("10 Daylight")
world = bpy.data.worlds.new("Beijing clear late afternoon")
scene.world = world
world.use_nodes = True
n = world.node_tree.nodes
l = world.node_tree.links
sky = n.new("ShaderNodeTexSky")
sky.sky_type = "MULTIPLE_SCATTERING"
sky.sun_elevation = math.radians(32)
sky.sun_rotation = math.radians(220)
sky.air_density = 1.1
l.new(sky.outputs[0], n.get("Background").inputs[0])
n.get("Background").inputs[1].default_value = 0.38
ld = bpy.data.lights.new("Warm afternoon sun", "SUN")
lo = bpy.data.objects.new("Warm afternoon sun", ld)
COL.objects.link(lo)
lo.rotation_euler = (math.radians(28), math.radians(-25), math.radians(-28))
ld.energy = 2.2
ld.angle = math.radians(2)
scene.render.engine = "CYCLES"
scene.cycles.samples = 32
scene.cycles.use_denoising = True
scene.render.resolution_x = 1280
scene.render.resolution_y = 720
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = "PNG"
scene.render.film_transparent = False
scene.view_settings.view_transform = "AgX"
scene.view_settings.look = "AgX - Medium High Contrast"
scene.view_settings.exposure = 0.3
scene.render.filepath = str(ROOT / "data/frames/frame_")
scene["reference_only"] = (
    "Approximate procedural reconstruction; not a surveyed digital twin or final photoreal Seedance film."
)
scene["source"] = (
    "Jakub Hałun / Wikimedia Commons, 20090528 Beijing Tiananmen 7628.jpg, CC BY-SA 4.0; portrait texture crop"
)
scene.frame_set(1)
for area in bpy.context.screen.areas:
    if area.type == "VIEW_3D":
        area.spaces.active.region_3d.view_perspective = "CAMERA"
        area.spaces.active.shading.type = "MATERIAL"
# Pack image and font dependencies into the editable project.
bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT / "data/tiananmen_tourist.blend"))

print(
    json.dumps(
        {
            "status": "built",
            "scene": scene.name,
            "objects": len(scene.objects),
            "frames": 288,
            "blend": str(ROOT / "data/tiananmen_tourist.blend"),
        }
    )
)
