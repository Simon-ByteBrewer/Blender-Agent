"""Start the installed, original Blender MCP addon in a dedicated Blender window."""

import argparse
import importlib.util
import json
import shutil
from pathlib import Path
import sys

import bpy
import addon_utils

# Scripts may run from a signed, read-only app bundle; never write __pycache__ beside them.
sys.dont_write_bytecode = True


def start_project():
    parser = argparse.ArgumentParser()
    parser.add_argument('--studio-config', required=True)
    parser.add_argument('--studio-project', required=True)
    parser.add_argument('--studio-token', required=True)
    args = parser.parse_args(sys.argv[sys.argv.index('--') + 1:])
    config = json.loads(Path(args.studio_config).read_text())
    project = config['project']
    assert project['id'] == args.studio_project and config['token'] == args.studio_token
    path = Path(config['blend_path'])
    if path.exists():
        # Import a copy: Blender refuses to save over a currently used library.
        # This also upgrades legacy scene-only exports without losing the window
        # context during startup. The native main file is saved below.
        source_path = path.parent / 'archive' / 'startup-source.blend'
        source_path.parent.mkdir(exist_ok=True)
        shutil.copy2(path, source_path)
        with bpy.data.libraries.load(str(source_path), link=False) as (source, target):
            if not source.scenes:
                raise RuntimeError('Saved project contains no scene')
            # The project file belongs to this project only. If its scene was replaced or
            # renamed, adopt the saved scene instead of refusing to open the user's work.
            target.scenes = [project['scene'] if project['scene'] in source.scenes else source.scenes[0]]
        scene = target.scenes[0]
        if scene.name != project['scene']:
            print('PROJECT_SCENE_ADOPTED', scene.name, '->', project['scene'], flush=True)
            scene.name = project['scene']
    else:
        scene = bpy.data.scenes.new(project['scene'])
        scene.render.engine = 'BLENDER_WORKBENCH'
        scene.render.resolution_x, scene.render.resolution_y = {'720p': (1280, 720), '1080p': (1920, 1080)}[project['settings']['resolution']]
        scene.render.fps = project['settings']['fps']
        scene.frame_end = scene.render.fps * project['settings']['duration']
    bpy.context.window.scene = scene
    # This is a newly launched, owned process. Remove factory defaults, never
    # data from an existing user's Blender window.
    for other in list(bpy.data.scenes):
        if other != scene:
            bpy.data.scenes.remove(other)
    for obj in list(bpy.data.objects):
        if not obj.users_scene:
            bpy.data.objects.remove(obj)
    # The original addon's register() auto-starts by default. Configure its
    # persisted properties before registration so it cannot claim port 9876.
    scene['blendermcp_port'] = config['port']
    scene['blendermcp_auto_start_server'] = False
    addon_utils.enable('blender_mcp', default_set=False, persistent=False)
    scene.blendermcp_port = config['port']
    existing = getattr(bpy.types, 'blendermcp_server', None)
    if existing and existing.port != config['port']:
        existing.stop()
        del bpy.types.blendermcp_server
    spec = importlib.util.spec_from_file_location('ma_studio_autosave', Path(__file__).with_name('autosave.py'))
    autosave = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(autosave)
    sys.modules['ma_studio_autosave'] = autosave
    autosave.register_scene(scene, str(path), native=True)
    autosave.save_scene(scene, str(path))
    bpy.ops.blendermcp.start_server()
    assert bpy.types.blendermcp_server.running
    print('MA_CREATIVE_STUDIO_MCP_READY', project['id'], config['port'], flush=True)


if '--studio-config' in sys.argv:
    start_project()
else:
    addon_utils.enable('blender_mcp', default_set=False, persistent=False)
    bpy.ops.blendermcp.start_server()
    print('MA_CREATIVE_STUDIO_MCP_READY', flush=True)
