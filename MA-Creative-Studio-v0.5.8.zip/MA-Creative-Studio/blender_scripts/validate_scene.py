import bpy, json
from pathlib import Path
from mathutils import Vector

root = Path(__file__).resolve().parents[1]
s = bpy.data.scenes["Tiananmen_Tourist"]
bpy.context.window.scene = s
shots = json.loads((root / "data/shots.json").read_text())
report = {
    "scene": s.name,
    "object_count": len(s.objects),
    "camera_count": len(shots),
    "cameras": [],
    "packed_images": [],
    "fonts": [],
}
assert s.frame_start == 1 and s.frame_end == 288 and s.render.fps == 24
for shot in shots:
    o = bpy.data.objects[shot["id"]]
    heights = []
    speeds = []
    prev = None
    minclear = 999
    for f in range(shot["start"], shot["end"] + 1):
        s.frame_set(f)
        p = o.matrix_world.translation.copy()
        deps = bpy.context.evaluated_depsgraph_get()
        hit, loc, normal, index, object, matrix = s.ray_cast(
            deps, p, Vector((0, 0, -1)), distance=5
        )
        assert hit, f"No walkable ground at {f}"
        height = p.z - loc.z
        heights.append(height)
        assert 1.60 < height < 1.70, (f, height)
        if prev:
            speeds.append((p - prev).length * 24)
        prev = p
        forward = o.matrix_world.to_quaternion() @ Vector((0, 0, -1))
        hit, loc, *_ = s.ray_cast(deps, p, forward, distance=300)
        if hit:
            minclear = min(minclear, (p - loc).length)
    assert max(speeds) < 1.5
    assert minclear > 0.5
    report["cameras"].append(
        {
            "name": o.name,
            "lens_mm": o.data.lens,
            "eye_height_min": min(heights),
            "eye_height_max": max(heights),
            "max_speed_m_s": max(speeds),
            "min_front_clearance_m": minclear,
            "frames": [shot["start"], shot["end"]],
        }
    )
for im in bpy.data.images:
    if im.source == "FILE":
        report["packed_images"].append(
            {"name": im.name, "packed": bool(im.packed_file)}
        )
for font in bpy.data.fonts:
    report["fonts"].append({"name": font.name, "packed": bool(font.packed_file)})
assert all(x["packed"] for x in report["packed_images"])
report["status"] = "passed"
(root / "data/scene_validation.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report))
