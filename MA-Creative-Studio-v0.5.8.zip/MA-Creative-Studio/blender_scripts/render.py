"""Blender renderer: serial CLI or persistent frame worker for the coordinator."""

import argparse
import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend/src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from studio.render_state import (PROTOCOL, blend_hash, prepare_frames,
                                 sequential_reasons, valid_png, write_json)


def main():
    import bpy
    from previs import configure_previs

    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--scene", required=True)
    parser.add_argument("--mode", choices=["preview", "render"], default="render")
    parser.add_argument("--samples", type=int, default=16)
    parser.add_argument("--profile", choices=["previs", "scene"], default="previs")
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--source-blend")
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    scene = bpy.data.scenes.get(args.scene)
    if not scene or not scene.camera:
        raise RuntimeError("Scene must exist and have an active camera before rendering")
    bpy.context.window.scene = scene
    if args.profile == "previs":
        configure_previs(scene)
    elif scene.render.engine == "CYCLES":
        scene.cycles.samples = args.samples
        scene.cycles.use_denoising = True
    scene.render.image_settings.file_format = "PNG"
    scene.render.use_file_extension = False
    scene.render.resolution_percentage = 50 if args.mode == "preview" else 100
    start, end = scene.frame_start, scene.frame_end
    if start > end or end - start > 14400:
        raise ValueError("Invalid or excessive frame range")
    metadata = dict(scene=scene.name, start=start, end=end, frames=end - start + 1,
                    fps=scene.render.fps / scene.render.fps_base,
                    width=scene.render.resolution_x, height=scene.render.resolution_y,
                    blend=args.source_blend or bpy.data.filepath,
                    samples=8 if args.profile == "previs" else args.samples,
                    profile=args.profile, engine=scene.render.engine,
                    render_scale=scene.render.resolution_percentage)
    reasons = sequential_reasons(scene, [*bpy.app.handlers.frame_change_pre,
                                         *bpy.app.handlers.frame_change_post])
    folder = out / ("previews" if args.mode == "preview" else "frames")

    def render_frame(frame):
        if not start <= frame <= end:
            raise ValueError("Worker frame outside scene timeline")
        scene.frame_set(frame)
        path = folder / f"frame_{frame:06d}.png"
        temporary = folder / f".frame_{frame:06d}.{os.getpid()}.tmp"
        scene.render.filepath = str(temporary)
        try:
            bpy.ops.render.render(write_still=True, scene=scene.name)
            if not valid_png(temporary):
                raise RuntimeError(f"Renderer produced an invalid PNG for frame {frame}")
            temporary.replace(path)
        finally:
            temporary.unlink(missing_ok=True)

    def emit(value):
        print(PROTOCOL + json.dumps(value), flush=True)

    if args.worker:
        emit({"event": "ready", "metadata": metadata, "sequential_reasons": reasons})
        # Each process loads the scene once. The coordinator exclusively owns
        # manifests/progress and never sends stateful scenes to this protocol.
        for line in sys.stdin:
            request = json.loads(line)
            if request["action"] == "stop":
                break
            if request["action"] != "render" or reasons:
                raise RuntimeError("Scene requires ordered serial rendering")
            frames = request["frames"]
            for frame in frames:
                render_frame(frame)
            emit({"event": "done", "frames": frames})
        return

    folder = prepare_frames(out, metadata, args.mode, blend_hash(bpy.data.filepath))
    frames = sorted({start, (start + end) // 2, end}) if args.mode == "preview" else list(range(start, end + 1))
    started = time.monotonic()
    previous = start - 1
    for completed, frame in enumerate(frames, 1):
        if reasons:
            # Simulations must evaluate intervening frames even on resume or
            # a three-frame preview. They never enter the parallel worker pool.
            for step in range(previous + 1, frame + 1):
                scene.frame_set(step)
            previous = frame
        if not valid_png(folder / f"frame_{frame:06d}.png"):
            render_frame(frame)
        progress = dict(status="running", mode=args.mode, frame=frame,
                        completed=completed, total=len(frames), workers=1,
                        sequential_reasons=reasons,
                        elapsed_seconds=round(time.monotonic() - started, 1))
        write_json(out / "render_progress.json", progress)
    progress["status"] = "completed"
    write_json(out / "render_progress.json", progress)
    print("RENDER_COMPLETE", json.dumps(metadata), flush=True)


if __name__ == "__main__":
    main()
