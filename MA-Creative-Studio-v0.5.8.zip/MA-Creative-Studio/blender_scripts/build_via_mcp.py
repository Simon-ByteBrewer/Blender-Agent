"""Schedule the reproducible builder through original Blender MCP without holding a tool call."""

import asyncio, json, time, uuid, fcntl
from ma_mcp.mcp_bridge import MCPBridge, to_ma_result
from studio.config import ROOT, STATE


async def main():
    (ROOT / "logs").mkdir(exist_ok=True)
    job = uuid.uuid4().hex
    state = STATE / f"build-{job}.json"
    state.write_text(json.dumps({"status": "queued"}))
    script = ROOT / "blender_scripts/build_scene.py"
    code = f"""import bpy
import json
from pathlib import Path
def tiananmen_build_job():
    state=Path({str(state)!r})
    state.write_text(json.dumps({{"status":"running"}}))
    try:
        ns={{"__name__":"__main__", "__file__":{str(script)!r}}}
        exec(compile(Path({str(script)!r}).read_text(),{str(script)!r},"exec"),ns)
        state.write_text(json.dumps({{"status":"succeeded","artifact":"data/tiananmen_tourist.blend"}}))
    except Exception as exc:
        state.write_text(json.dumps({{"status":"failed","error":str(exc)}}))
    return None
bpy.app.timers.register(tiananmen_build_job,first_interval=1.0)
print("BUILD_QUEUED")
"""
    with (STATE / "build.lock").open("w") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("A scene build is already active")
        r = await MCPBridge().call(
            "execute_blender_code",
            {
                "code": code,
                "user_prompt": "使用Blender MCP创建一个北京天安门的3D场景，然后以游客视角渲染为视频",
            },
        )
        if to_ma_result("build", r)["is_error"]:
            raise RuntimeError(str(r))
        start = time.monotonic()
        last = None
        while time.monotonic() - start < 1200:
            try:
                status = json.loads(state.read_text())
            except json.JSONDecodeError:
                await asyncio.sleep(1)
                continue
            if status != last:
                print(json.dumps(status, ensure_ascii=False), flush=True)
                last = status
            if status["status"] == "succeeded":
                return
            if status["status"] == "failed":
                raise RuntimeError(status["error"])
            await asyncio.sleep(2)
        raise TimeoutError(
            f"Build still unresolved; inspect {state}. Do not submit a duplicate build."
        )


if __name__ == "__main__":
    asyncio.run(main())
