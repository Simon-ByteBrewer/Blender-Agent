import bpy, math, json, bmesh
from pathlib import Path
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
s = bpy.data.scenes["Tiananmen_Tourist"]
bpy.context.window.scene = s
s.world.node_tree.nodes.get("Background").inputs[1].default_value = 0.035
s.view_settings.exposure = -0.5
# Repair solid orientation on arch cutters, and rebuild the platform alone.
wall = bpy.data.objects.get("Tiananmen vermilion platform")
bpy.data.objects.remove(wall, do_unlink=True)
bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 1, 5))
wall = bpy.context.object
wall.name = "Tiananmen vermilion platform"
[
    setattr(v, "co", Vector((v.co.x * 120, v.co.y * 32, v.co.z * 10)))
    for v in wall.data.vertices
]
wall.data.materials.append(bpy.data.materials["Weathered vermilion lime plaster"])
for c in list(wall.users_collection):
    c.objects.unlink(wall)
s.collection.children["02 Gate platform • five arched passages"].objects.link(wall)
for x, r in [(-28, 1.9), (-14, 2), (0, 2.65), (14, 2), (28, 1.9)]:
    spring = 3.0 if x == 0 else 2.35
    contour = [(-r, -1), (r, -1), (r, spring)] + [
        (r * math.cos(i * math.pi / 24), spring + r * math.sin(i * math.pi / 24))
        for i in range(1, 25)
    ]
    verts = [(x + xx, y, zz) for y in [-17, 19] for xx, zz in contour]
    N = len(contour)
    faces = [tuple(range(N - 1, -1, -1)), tuple(range(N, 2 * N))] + [
        (i, (i + 1) % N, (i + 1) % N + N, i + N) for i in range(N)
    ]
    d = bpy.data.meshes.new("Arch cutter")
    d.from_pydata(verts, [], faces)
    d.update()
    bm = bmesh.new()
    bm.from_mesh(d)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(d)
    bm.free()
    o = bpy.data.objects.new("Arch cutter", d)
    s.collection.objects.link(o)
    bpy.context.view_layer.objects.active = wall
    m = wall.modifiers.new("True arched passage", "BOOLEAN")
    m.object = o
    m.operation = "DIFFERENCE"
    bpy.ops.object.modifier_apply(modifier=m.name)
    bpy.data.objects.remove(o, do_unlink=True)
SHOTS = [
    dict(
        id="01_square",
        label="广场远望 · 缓步前行",
        start=1,
        end=96,
        lens=37,
        p0=[-11, -121, 1.65],
        p1=[-9, -118, 1.65],
        t0=[0, 0, 15],
        t1=[0, 0, 15.5],
    ),
    dict(
        id="02_bridge",
        label="金水桥旁 · 侧行转头",
        start=97,
        end=192,
        lens=23,
        p0=[-23, -61, 1.65],
        p1=[-19.8, -60, 1.65],
        t0=[-4, 0, 14.4],
        t1=[0, 0, 15.5],
    ),
    dict(
        id="03_look_up",
        label="桥前驻足 · 缓缓仰望",
        start=193,
        end=288,
        lens=24,
        p0=[19, -48, 1.65],
        p1=[19.5, -47.2, 1.65],
        t0=[0, -3, 13],
        t1=[0, 0, 20],
    ),
]
for shot in SHOTS:
    o = bpy.data.objects[shot["id"]]
    o.animation_data_clear()
    o.data.lens = shot["lens"]
    for f in range(shot["start"], shot["end"] + 1):
        t = (f - shot["start"]) / (shot["end"] - shot["start"])
        u = t * t * (3 - 2 * t)
        pos = Vector(shot["p0"]).lerp(Vector(shot["p1"]), u)
        pos.z += 0.007 * math.sin(t * math.pi * 12) * math.sin(math.pi * t)
        target = Vector(shot["t0"]).lerp(Vector(shot["t1"]), u)
        o.location = pos
        o.rotation_euler = (target - pos).to_track_quat("-Z", "Y").to_euler()
        o.keyframe_insert("location", frame=f)
        o.keyframe_insert("rotation_euler", frame=f)
s.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT / "data/tiananmen_tourist.blend"))
(ROOT / "data/shots.json").write_text(json.dumps(SHOTS, ensure_ascii=False, indent=2))
print("Refined light, five real passages, and visitor compositions")
