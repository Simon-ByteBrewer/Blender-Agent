"""Deterministic editable Tiananmen cinematography reference, Blender 5.2.
Run via original Blender MCP execute_blender_code, or background Blender.
Geometry is an approximate reconstruction; units are metres.
"""

import bpy, math, random, json, os, bmesh
from pathlib import Path
from mathutils import Vector

ROOT = Path(os.environ.get("TIANANMEN_ROOT", Path(__file__).resolve().parents[1]))
random.seed(20260907)
# Dedicated scene only: don't delete other scenes or their datablocks.
old = bpy.data.scenes.get("Tiananmen_Tourist")
if old:
    for obj in list(old.objects):
        if not any(
            obj.name in other.objects for other in bpy.data.scenes if other != old
        ):
            bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.scenes.remove(old)
scene = bpy.data.scenes.new("Tiananmen_Tourist")
bpy.context.window.scene = scene
scene.unit_settings.system = "METRIC"
COL = None


def collection(name):
    global COL
    COL = bpy.data.collections.new(name)
    scene.collection.children.link(COL)
    print("BUILD_STAGE", name, flush=True)


def link(obj):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    COL.objects.link(obj)
    return obj


def material(name, color, rough=0.6, noise=0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    n = m.node_tree.nodes
    p = n.get("Principled BSDF")
    p.inputs["Base Color"].default_value = (*color, 1)
    p.inputs["Roughness"].default_value = rough
    if noise:
        tc = n.new("ShaderNodeTexCoord")
        tex = n.new("ShaderNodeTexNoise")
        tex.inputs["Scale"].default_value = 3.5
        tex.inputs["Detail"].default_value = 3
        m.node_tree.links.new(tc.outputs["Object"], tex.inputs["Vector"])
        ramp = n.new("ShaderNodeValToRGB")
        ramp.color_ramp.elements[0].color = (*(c * 0.68 for c in color), 1)
        ramp.color_ramp.elements[1].color = (*(min(c * 1.2, 1) for c in color), 1)
        m.node_tree.links.new(tex.outputs["Fac"], ramp.inputs[0])
        m.node_tree.links.new(ramp.outputs[0], p.inputs["Base Color"])
        bump = n.new("ShaderNodeBump")
        bump.inputs["Strength"].default_value = 0.22
        bump.inputs["Distance"].default_value = noise
        m.node_tree.links.new(tex.outputs["Fac"], bump.inputs["Height"])
        m.node_tree.links.new(bump.outputs[0], p.inputs["Normal"])
    return m


red = material("Weathered vermilion lime plaster", (0.40, 0.037, 0.022), 0.84, 0.045)
wood = material("Dark red painted timber", (0.19, 0.024, 0.014), 0.55, 0.02)
gold = material("Ochre glazed imperial tiles", (0.63, 0.28, 0.037), 0.29, 0.012)
gold2 = material("Glazed tile raised ribs", (0.74, 0.37, 0.065), 0.27)
marble = material("Warm white carved marble", (0.67, 0.66, 0.59), 0.7, 0.035)
dark = material("Deep portal shadow", (0.012, 0.008, 0.005), 0.95)
teal = material("Qing painted blue green", (0.024, 0.12, 0.11), 0.6)
blue = material("Painted indigo", (0.026, 0.061, 0.14), 0.55)
trim = material("Gold painted ornament", (0.6, 0.35, 0.09), 0.42)
stone = material("Granite paving", (0.43, 0.42, 0.38), 0.82, 0.012)
asphalt = material("Chang an avenue asphalt", (0.07, 0.079, 0.086), 0.95, 0.04)
foliage = [
    material("Foliage " + str(i), c, 0.92)
    for i, c in enumerate(
        [(0.055, 0.12, 0.032), (0.09, 0.17, 0.044), (0.12, 0.20, 0.061)]
    )
]
trunk = material("Tree bark", (0.12, 0.07, 0.037), 0.9, 0.05)
flagmat = material("Flag red textile", (0.64, 0.012, 0.018), 0.8)
metal = material("Patinated bronze", (0.12, 0.14, 0.105), 0.35)


def cube(name, loc, scale, mat, bevel=0):
    verts = [
        (x * scale[0] / 2, y * scale[1] / 2, z * scale[2] / 2)
        for x, y, z in [
            (-1, -1, -1),
            (-1, -1, 1),
            (-1, 1, -1),
            (-1, 1, 1),
            (1, -1, -1),
            (1, -1, 1),
            (1, 1, -1),
            (1, 1, 1),
        ]
    ]
    faces = [
        (0, 4, 6, 2),
        (1, 3, 7, 5),
        (0, 1, 5, 4),
        (2, 6, 7, 3),
        (0, 2, 3, 1),
        (4, 5, 7, 6),
    ]
    o = mesh(name, verts, faces, mat)
    o.location = loc
    if bevel:
        mod = o.modifiers.new("Soft architectural edges", "BEVEL")
        mod.width = bevel
        mod.segments = 2
        o.modifiers.new("Weighted normals", "WEIGHTED_NORMAL")
    return o


def mesh(name, verts, faces, mat):
    d = bpy.data.meshes.new(name)
    d.from_pydata(verts, [], faces)
    d.update()
    o = bpy.data.objects.new(name, d)
    COL.objects.link(o)
    d.materials.append(mat)
    return o


def curve(name, pts, radius, mat):
    d = bpy.data.curves.new(name, "CURVE")
    d.dimensions = "3D"
    d.resolution_u = 1
    d.bevel_depth = radius
    d.bevel_resolution = 1
    s = d.splines.new("POLY")
    s.points.add(len(pts) - 1)
    for p, co in zip(s.points, pts):
        p.co = (*co, 1)
    o = bpy.data.objects.new(name, d)
    COL.objects.link(o)
    d.materials.append(mat)
    return o


SHAPES = {}


def cylinder(name, loc, r, depth, mat, vertices=16):
    key = ("cylinder", vertices, mat.name)
    if key not in SHAPES:
        bm = bmesh.new()
        bmesh.ops.create_cone(
            bm,
            cap_ends=True,
            cap_tris=False,
            segments=vertices,
            radius1=1,
            radius2=1,
            depth=1,
        )
        d = bpy.data.meshes.new(name)
        bm.to_mesh(d)
        bm.free()
        d.materials.append(mat)
        for p in d.polygons:
            p.use_smooth = len(p.vertices) == 4
        SHAPES[key] = d
    o = bpy.data.objects.new(name, SHAPES[key])
    COL.objects.link(o)
    o.location = loc
    o.scale = (r, r, depth)
    return o


def sphere(name, loc, scale, mat):
    key = ("sphere", mat.name)
    if key not in SHAPES:
        bm = bmesh.new()
        bmesh.ops.create_uvsphere(bm, u_segments=12, v_segments=8, radius=1)
        d = bpy.data.meshes.new(name)
        bm.to_mesh(d)
        bm.free()
        d.materials.append(mat)
        for p in d.polygons:
            p.use_smooth = True
        SHAPES[key] = d
    o = bpy.data.objects.new(name, SHAPES[key])
    COL.objects.link(o)
    o.location = loc
    o.scale = scale
    return o


collection("01 Site • paving river avenue")
# Granite uses real world brick joints to give foreground motion/parallax cues.
p = stone.node_tree.nodes.get("Principled BSDF")
n = stone.node_tree.nodes
l = stone.node_tree.links
tex = n.new("ShaderNodeTexBrick")
tex.inputs["Scale"].default_value = 1
tex.inputs["Mortar Size"].default_value = 0.009
tex.inputs["Brick Width"].default_value = 1.2
tex.inputs["Row Height"].default_value = 0.75
tex.inputs["Color1"].default_value = (0.38, 0.37, 0.34, 1)
tex.inputs["Color2"].default_value = (0.52, 0.50, 0.46, 1)
tex.inputs["Mortar"].default_value = (0.20, 0.19, 0.18, 1)
tc = n.new("ShaderNodeTexCoord")
l.new(tc.outputs["Object"], tex.inputs["Vector"])
l.new(tex.outputs["Color"], p.inputs["Base Color"])
bump = n.new("ShaderNodeBump")
bump.inputs["Distance"].default_value = 0.016
bump.inputs["Strength"].default_value = 0.5
l.new(tex.outputs["Fac"], bump.inputs["Height"])
l.new(bump.outputs[0], p.inputs["Normal"])
cube("South square stone paving", (0, -132, -0.25), (420, 155, 0.5), stone)
cube("North visitor esplanade", (0, -49, -0.25), (310, 32, 0.5), stone)
cube("Gate forecourt", (0, -24, -0.25), (240, 16, 0.5), stone)
cube("Avenue", (0, -77, -0.10), (440, 22, 0.2), asphalt)
for y in [-87, -67]:
    cube("Road kerb", (0, y, 0.09), (400, 0.30, 0.18), marble, 0.025)
for x in range(-180, 181, 9):
    for y in [-73, -80]:
        cube("Lane marking", (x, y, 0.015), (4, 0.12, 0.012), marble)
water = material("Jinshui river water", (0.024, 0.13, 0.12), 0.18, 0.04)
water.node_tree.nodes.get("Principled BSDF").inputs["Metallic"].default_value = 0.45
cube("Jinshui water", (0, -34, -1.25), (205, 12, 0.12), water)
for y in [-40, -28]:
    cube("River retaining wall", (0, y, -0.8), (210, 0.8, 2.2), marble, 0.08)

collection("02 Gate platform • five arched passages")
wall = cube("Tiananmen vermilion platform", (0, 1, 5), (120, 32, 10), red)
# Actual arch cuts through the platform, not black decals.
for x, r in [(-28, 1.9), (-14, 2), (0, 2.65), (14, 2), (28, 1.9)]:
    spring = 3.0 if x == 0 else 2.35
    contour = [(-r, 0), (r, 0), (r, spring)] + [
        (r * math.cos(i * math.pi / 24), spring + r * math.sin(i * math.pi / 24))
        for i in range(1, 25)
    ]
    verts = [(x + xx, y, zz - 0.08) for y in [-16, 18] for xx, zz in contour]
    N = len(contour)
    faces = [tuple(range(N - 1, -1, -1)), tuple(range(N, 2 * N))] + [
        (i, (i + 1) % N, (i + 1) % N + N, i + N) for i in range(N)
    ]
    cutter = mesh("temporary arch cutter", verts, faces, dark)
    bm = bmesh.new()
    bm.from_mesh(cutter.data)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(cutter.data)
    bm.free()
    bpy.context.view_layer.update()
    bpy.context.view_layer.objects.active = wall
    mod = wall.modifiers.new("Passage", "BOOLEAN")
    mod.object = cutter
    mod.operation = "DIFFERENCE"
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(cutter, do_unlink=True)
    cube("Portal inner darkness", (x, 13, 2.7), (r * 1.95, 0.2, 5.4), dark)
    pts = [
        (
            x + r * math.cos(i * math.pi / 40),
            -15.035,
            spring + r * math.sin(i * math.pi / 40),
        )
        for i in range(41)
    ]
    curve("Arch voussoir edge", pts, 0.10, wood)
for z in [0.2, 9.9, 10.3]:
    cube("Platform stone cornice", (0, 1, z), (121, 33, 0.23), marble, 0.04)
for x in [-115, 115]:
    cube("Flanking imperial wall", (x, 4, 3), (110, 3, 6), red)
    cube("Wall coping", (x, 4, 6.1), (111, 3.5, 0.35), gold)
# Portrait mapped from licensed reference photograph; no generated likeness.
pm = material("Historical portrait • photo texture", (0.5, 0.4, 0.25), 0.85)
im = pm.node_tree.nodes.new("ShaderNodeTexImage")
im.image = bpy.data.images.load(str(ROOT / "assets/tiananmen_reference.jpg"))
im.image.pack()
pm.node_tree.links.new(
    im.outputs["Color"], pm.node_tree.nodes.get("Principled BSDF").inputs["Base Color"]
)
# Crop coordinates based on the original 2493x1781 photograph.
x0, x1, y0, y1 = 1238 / 2493, 1319 / 2493, 1127 / 1781, 1234 / 1781
portrait = mesh(
    "Mao portrait",
    [(-1.7, -15.12, 5.6), (1.7, -15.12, 5.6), (1.7, -15.12, 9.5), (-1.7, -15.12, 9.5)],
    [(0, 1, 2, 3)],
    pm,
)
uv = portrait.data.uv_layers.new()
coords = [(x0, 1 - y1), (x1, 1 - y1), (x1, 1 - y0), (x0, 1 - y0)]
for i, p in enumerate(coords):
    uv.data[i].uv = p
for x in [-1.85, 1.85]:
    cube("Portrait gilt frame", (x, -15.18, 7.55), (0.19, 0.19, 4.2), trim, 0.03)
for z in [5.48, 9.62]:
    cube("Portrait gilt frame", (0, -15.18, z), (3.9, 0.19, 0.18), trim, 0.03)
font = bpy.data.fonts.load("/System/Library/Fonts/STHeiti Medium.ttc")
for x, txt in [(-23, "中华人民共和国万岁"), (23, "世界人民大团结万岁")]:
    cube("Slogan gilt border", (x, -15.11, 7.8), (27.6, 0.25, 2.3), marble, 0.04)
    cube("Slogan red panel", (x, -15.27, 7.8), (27.2, 0.12, 1.98), red)
    d = bpy.data.curves.new(txt, "FONT")
    d.body = txt
    d.font = font
    d.align_x = "CENTER"
    d.align_y = "CENTER"
    d.size = 1.65
    d.space_character = 1.4
    d.extrude = 0.008
    o = bpy.data.objects.new(txt, d)
    COL.objects.link(o)
    o.location = (x, -15.35, 7.8)
    o.rotation_euler = (math.pi / 2, 0, 0)
    d.materials.append(marble)

collection("03 Timber hall • painted beams and columns")
cube("Upper hall shadow", (0, 1, 15.2), (59, 24, 9.5), wood)
for x in range(-28, 29, 7):
    for y in [-12, 14]:
        cylinder("Red structural column", (x, y, 14.4), 0.48, 8, wood)
        cylinder("Column marble foot", (x, y, 10.55), 0.65, 0.45, marble)
    for dx in [-2.7, -1.5, 0, 1.5, 2.7]:
        cube("Lattice door muntin", (x + dx, -11.16, 14), (0.10, 0.12, 5.2), trim)
    for z in [12, 13, 14, 15, 16]:
        cube("Door lattice rail", (x, -11.22, z), (5.8, 0.10, 0.07), teal)
for z in [17.3, 18.2, 22.0, 23.0]:
    cube("Painted beam", (0, -12.6, z), (64, 0.7, 0.65), teal, 0.06)
    cube("Gold beam line", (0, -13.0, z + 0.26), (64, 0.06, 0.065), trim)
    for x in range(-30, 31, 2):
        cube("Painted coffer blue", (x, -13.01, z), (1.65, 0.05, 0.42), blue)
        o = cube("Gold coffer diamond", (x, -13.06, z), (0.27, 0.06, 0.27), trim)
        o.rotation_euler.y = math.pi / 4
for x in range(-31, 32, 2):
    for y in [-13, 15]:
        for i in range(3):
            cube(
                "Dougong bracket",
                (x, y - i * 0.26, 18.7 + i * 0.32),
                (1.4 - i * 0.23, 1.2, 0.20),
                teal,
                0.03,
            )

collection("04 Double hip roof • glazed ribs and ornaments")


def roof(name, hx, hy, ridge, z, rise):
    # Front/back curved surfaces and triangular hip ends.
    def point(u, t, side):
        w = ridge + (hx - ridge) * t
        return (
            u * w,
            1 + side * hy * t,
            z + rise * (1 - t) ** 1.7 + 1.0 * (abs(u) ** 12) * (t**5),
        )

    for side in [-1, 1]:
        verts = [
            point(-1 + 2 * i / 96, j / 24, side) for j in range(25) for i in range(97)
        ]
        faces = [
            (j * 97 + i, j * 97 + i + 1, (j + 1) * 97 + i + 1, (j + 1) * 97 + i)
            for j in range(24)
            for i in range(96)
        ]
        o = mesh(name + " glazed slope", verts, faces, gold)
        for p in o.data.polygons:
            p.use_smooth = True
        for i in range(193):
            u = -1 + 2 * i / 192
            curve(
                "Raised tile roll",
                [
                    tuple(
                        v + (0.045 if k == 2 else 0)
                        for k, v in enumerate(point(u, j / 24, side))
                    )
                    for j in range(25)
                ],
                0.065,
                gold2,
            )
        curve(
            "Sweeping eave",
            [point(-1 + 2 * i / 96, 1, side) for i in range(97)],
            0.19,
            gold2,
        )
        for j in range(1, 24, 2):
            curve(
                "Tile course",
                [point(-1 + 2 * i / 48, j / 24, side) for i in range(49)],
                0.022,
                gold2,
            )
    for sign in [-1, 1]:
        verts = []
        for j in range(25):
            t = j / 24
            for i in range(25):
                u = -1 + 2 * i / 24
                verts.append(
                    (
                        sign * (ridge + (hx - ridge) * t),
                        1 + u * hy * t,
                        z + rise * (1 - t) ** 1.7 + abs(u) ** 12 * t**5,
                    )
                )
        mesh(
            name + " hipped end",
            verts,
            [
                (j * 25 + i, j * 25 + i + 1, (j + 1) * 25 + i + 1, (j + 1) * 25 + i)
                for j in range(24)
                for i in range(24)
            ],
            gold,
        )
        for side in [-1, 1]:
            curve(
                "Hip ridge", [point(sign, j / 24, side) for j in range(25)], 0.20, gold2
            )
        for ysign in [-1, 1]:
            for i in range(7):
                t = 1 - i * 0.045
                pos = point(sign, t, ysign)
                sphere(
                    "Ridge guardian ornament",
                    (pos[0], pos[1], pos[2] + 0.34),
                    (0.15, 0.23, 0.35),
                    gold2,
                )
        curve(
            "Chiwen ridge end",
            [
                (sign * (ridge - 0.3), 1, z + rise),
                (sign * (ridge + 0.5), 1, z + rise + 0.7),
                (sign * (ridge + 0.2), 1, z + rise + 1.7),
                (sign * (ridge - 0.3), 1, z + rise + 1.5),
            ],
            0.32,
            gold2,
        )
    curve(
        "Main ridge",
        [(-ridge, 1, z + rise + 0.15), (ridge, 1, z + rise + 0.15)],
        0.26,
        gold2,
    )


roof("Lower roof", 35, 17, 25, 18.9, 4.0)
roof("Upper roof", 31, 13.0, 25, 23.5, 7.4)
# red upper frieze and national-emblem proxy, kept small at reference distances.
cube("Upper storey", (0, 1, 22.1), (55, 21, 4.5), wood)
cylinder_obj = cylinder(
    "National emblem base", (0, -12.9, 22.2), 0.9, 0.12, flagmat, 32
)
cylinder_obj.rotation_euler.x = math.pi / 2
for a in range(12):
    ang = a * 2 * math.pi / 12
    sphere(
        "Emblem gilt wreath",
        (0.70 * math.sin(ang), -13.01, 22.2 + 0.70 * math.cos(ang)),
        (0.10, 0.05, 0.10),
        trim,
    )

collection("05 White marble bridges and balustrades")


def balustrade(x1, y1, x2, y2, z=0.0):
    length = math.hypot(x2 - x1, y2 - y1)
    count = max(1, round(length / 1.65))
    for i in range(count + 1):
        t = i / count
        x = x1 + (x2 - x1) * t
        y = y1 + (y2 - y1) * t
        cube("Marble baluster foot", (x, y, z + 0.15), (0.55, 0.55, 0.3), marble, 0.04)
        cylinder("Carved baluster", (x, y, z + 0.75), 0.17, 1.0, marble, 8)
        sphere("Lotus finial", (x, y, z + 1.36), (0.24, 0.24, 0.24), marble)
    for zz in [0.45, 1.12]:
        curve("Marble railing", [(x1, y1, z + zz), (x2, y2, z + zz)], 0.13, marble)


for x in [-28, -14, 0, 14, 28]:
    w = 7 if x == 0 else 5.1
    # walkable gently humped decks, modelled in longitudinal strips.
    for j in range(24):
        y = -42 + j * 16 / 24
        z = 0.12 + 0.55 * math.sin(math.pi * j / 24)
        cube(
            "Jinshui bridge deck",
            (x, y, z - 0.19),
            (w, 16 / 24 + 0.025, 0.35),
            marble,
            0.025,
        )
    for side in [-1, 1]:
        for j in range(8):
            ya = -42 + j * 2
            yb = ya + 2
            zz = 0.12 + 0.55 * math.sin(math.pi * (j + 0.5) / 8)
            balustrade(x + side * w / 2, ya, x + side * w / 2, yb, zz)
for xa, xb in [(-100, -31), (-25, -17), (-11, -4.2), (4.2, 11), (17, 25), (31, 100)]:
    for y in [-40.5, -27.5]:
        balustrade(xa, y, xb, y)
for xa, xb in [(-60, -33), (33, 60)]:
    balustrade(xa, -15, xb, -15, 10.4)


def huabiao(x, y):
    for z, w, h in [(0.2, 2.7, 0.4), (0.55, 2.2, 0.3), (0.85, 1.7, 0.3)]:
        cube("Huabiao pedestal", (x, y, z), (w, w, h), marble, 0.08)
    cylinder("Huabiao carved shaft", (x, y, 4.7), 0.50, 7.2, marble, 24)
    for phase in [0, math.pi]:
        curve(
            "Spiral dragon relief",
            [
                (
                    x + 0.52 * math.cos(t * 0.15 + phase),
                    y + 0.52 * math.sin(t * 0.15 + phase),
                    1.2 + t * 0.09,
                )
                for t in range(77)
            ],
            0.075,
            marble,
        )
    cube("Cloud tablet", (x, y, 7.6), (3.6, 0.35, 0.42), marble, 0.16)
    for s in [-1, 1]:
        sphere("Cloud curl", (x + s * 1.4, y, 7.84), (0.6, 0.26, 0.37), marble)
    cylinder("Huabiao crown", (x, y, 8.5), 0.78, 0.32, marble)
    sphere("Hou guardian body", (x, y, 9.02), (0.35, 0.52, 0.38), marble)
    sphere("Hou guardian head", (x, y - 0.3, 9.35), (0.26, 0.28, 0.31), marble)


for x in [-43, 43]:
    huabiao(x, -23)

collection("06 Flags • animated breeze")
for x in [-55, -46, -37, 37, 46, 55]:
    cylinder("Flagstaff", (x, -10, 14.1), 0.045, 8, metal)
    sphere("Flagstaff finial", (x, -10, 18.2), (0.11, 0.11, 0.11), trim)
    verts = [
        (x + u * 2.5, -10 + 0.18 * math.sin(u * 7 + v * 3) * u, 17.9 - v * 1.6)
        for v in [j / 8 for j in range(9)]
        for u in [i / 20 for i in range(21)]
    ]
    o = mesh(
        "Wind driven red banner",
        verts,
        [
            (j * 21 + i, j * 21 + i + 1, (j + 1) * 21 + i + 1, (j + 1) * 21 + i)
            for j in range(8)
            for i in range(20)
        ],
        flagmat,
    )
    o.shape_key_add(name="Basis")
    key = o.shape_key_add(name="Gust")
    for p in key.data:
        p.co.y = -10 + (p.co.x - x) / 2.5 * 0.30 * math.sin((p.co.x - x) * 4 + 1.7)
    for f in range(1, 290, 24):
        key.value = 0.5 + 0.5 * math.sin(f * 0.09 + x)
        key.keyframe_insert("value", frame=f)

collection("07 Trees and ornamental street lamps")
for side in [-1, 1]:
    for j in range(22):
        x = side * (69 + j * 3.8)
        y = random.choice([-5, 10, 20])
        h = random.uniform(8, 13)
        cylinder("Plane tree trunk", (x, y, h * 0.37), 0.35, h * 0.74, trunk)
        for k in range(5):
            sphere(
                "Tree foliage",
                (
                    x + random.uniform(-2, 2),
                    y + random.uniform(-2, 2),
                    h + random.uniform(-1.5, 1),
                ),
                (random.uniform(2, 3.5), 2.6, 2.4),
                random.choice(foliage),
            )
for x in [-52, 52, -94, 94]:
    y = -57
    cube("Lamp pedestal", (x, y, 0.5), (1, 1, 1), marble, 0.08)
    cylinder("Ornamental lamp post", (x, y, 5.3), 0.15, 9.8, metal)
    for a in range(6):
        ang = a * math.pi / 3
        xx = x + 1.25 * math.cos(ang)
        yy = y + 1.25 * math.sin(ang)
        curve("Lamp arm", [(x, y, 8), (xx, yy, 9)], 0.08, metal)
        sphere("Opal lamp globe", (xx, yy, 9.35), (0.35, 0.35, 0.46), marble)
    sphere("Lamp crown", (x, y, 10), (0.44, 0.44, 0.55), marble)

collection("08 Visitors • distant scale and parallax")
skin = material("Visitor skin", (0.48, 0.29, 0.18), 0.85)
hair = material("Visitor hair", (0.025, 0.018, 0.013), 0.93)
cloth = [
    material("Visitor clothing " + str(i), c, 0.9)
    for i, c in enumerate(
        [
            (0.08, 0.14, 0.23),
            (0.65, 0.60, 0.49),
            (0.35, 0.08, 0.055),
            (0.15, 0.20, 0.16),
            (0.65, 0.65, 0.62),
            (0.075, 0.075, 0.09),
        ]
    )
]
# Keep simplified people away from camera foreground; no conspicuous proxy near lens.
for i in range(65):
    x = random.uniform(-57, 57)
    y = random.choice([random.uniform(-25, -18), random.uniform(-60, -48)])
    if abs(x) < 5 or (x < -16 and -60 < y < -48):
        continue
    h = random.uniform(1.55, 1.83)
    m = random.choice(cloth)
    sphere("Visitor torso", (x, y, h * 0.65), (0.22, 0.14, 0.35), m)
    sphere("Visitor head", (x, y, h - 0.13), (0.12, 0.115, 0.15), skin)
    sphere("Visitor hair", (x, y + 0.025, h - 0.06), (0.123, 0.108, 0.095), hair)
    for side in [-1, 1]:
        curve(
            "Visitor leg",
            [
                (x + side * 0.10, y, 0.82),
                (x + side * 0.13, y + side * 0.07, 0.43),
                (x + side * 0.13, y + side * 0.13, 0.09),
            ],
            0.075,
            random.choice(cloth),
        )
        sphere(
            "Visitor shoe",
            (x + side * 0.13, y + side * 0.13 - 0.06, 0.06),
            (0.09, 0.15, 0.06),
            hair,
        )
        curve(
            "Visitor arm",
            [
                (x + side * 0.22, y, h * 0.77),
                (x + side * 0.29, y - 0.02, h * 0.56),
                (x + side * 0.29, y - 0.06, h * 0.43),
            ],
            0.055,
            m,
        )

collection("09 Cameras • eye level visitor itinerary")
SHOTS = [
    dict(
        id="01_square",
        label="广场远望 · 缓步前行",
        start=1,
        end=96,
        lens=37,
        p0=[-11, -121, 1.65],
        p1=[-9, -118, 1.65],
        t0=[0, 0, 15],
        t1=[0, 0, 15.5],
    ),
    dict(
        id="02_bridge",
        label="金水桥旁 · 侧行转头",
        start=97,
        end=192,
        lens=23,
        p0=[-23, -61, 1.65],
        p1=[-19.8, -60, 1.65],
        t0=[-4, 0, 14.4],
        t1=[0, 0, 15.5],
    ),
    dict(
        id="03_look_up",
        label="桥前驻足 · 缓缓仰望",
        start=193,
        end=288,
        lens=24,
        p0=[19, -48, 1.65],
        p1=[19.5, -47.2, 1.65],
        t0=[0, -3, 13],
        t1=[0, 0, 20],
    ),
]
for shot in SHOTS:
    d = bpy.data.cameras.new(shot["id"])
    o = bpy.data.objects.new(shot["id"], d)
    COL.objects.link(o)
    d.lens = shot["lens"]
    d.clip_end = 1000
    d.clip_start = 0.15
    d.sensor_width = 36
    o["eye_height_m"] = 1.65
    o["shot_description"] = shot["label"]
    for f in range(shot["start"], shot["end"] + 1):
        t = (f - shot["start"]) / (shot["end"] - shot["start"])
        s = t * t * (3 - 2 * t)
        pos = Vector(shot["p0"]).lerp(Vector(shot["p1"]), s)
        # Sub-centimetre stabilized footfall; horizon stays level.
        pos.z += 0.007 * math.sin(t * math.pi * 12) * math.sin(math.pi * t)
        target = Vector(shot["t0"]).lerp(Vector(shot["t1"]), s)
        o.location = pos
        o.rotation_euler = (target - pos).to_track_quat("-Z", "Y").to_euler()
        o.keyframe_insert("location", frame=f)
        o.keyframe_insert("rotation_euler", frame=f)
    mark = scene.timeline_markers.new(shot["label"], frame=shot["start"])
    mark.camera = o
scene.camera = bpy.data.objects["01_square"]
scene.frame_start = 1
scene.frame_end = 288
scene.render.fps = 24

collection("10 Daylight")
world = bpy.data.worlds.new("Beijing clear late afternoon")
scene.world = world
world.use_nodes = True
n = world.node_tree.nodes
l = world.node_tree.links
sky = n.new("ShaderNodeTexSky")
sky.sky_type = "MULTIPLE_SCATTERING"
sky.sun_elevation = math.radians(32)
sky.sun_rotation = math.radians(220)
sky.air_density = 1.1
l.new(sky.outputs[0], n.get("Background").inputs[0])
n.get("Background").inputs[1].default_value = 0.035
ld = bpy.data.lights.new("Warm afternoon sun", "SUN")
lo = bpy.data.objects.new("Warm afternoon sun", ld)
COL.objects.link(lo)
lo.rotation_euler = (math.radians(28), math.radians(-25), math.radians(-28))
ld.energy = 2.2
ld.angle = math.radians(2)
scene.render.engine = "CYCLES"
scene.cycles.samples = 32
scene.cycles.use_denoising = True
scene.render.resolution_x = 1280
scene.render.resolution_y = 720
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = "PNG"
scene.render.film_transparent = False
scene.view_settings.view_transform = "AgX"
scene.view_settings.look = "AgX - Medium High Contrast"
scene.view_settings.exposure = -0.5
scene.render.filepath = str(ROOT / "data/frames/frame_")
scene["reference_only"] = (
    "Approximate procedural reconstruction; not a surveyed digital twin or final photoreal Seedance film."
)
scene["source"] = (
    "Jakub Hałun / Wikimedia Commons, 20090528 Beijing Tiananmen 7628.jpg, CC BY-SA 4.0; portrait texture crop"
)
scene.frame_set(1)
for area in bpy.context.screen.areas:
    if area.type == "VIEW_3D":
        area.spaces.active.region_3d.view_perspective = "CAMERA"
        area.spaces.active.shading.type = "MATERIAL"
# Pack image and font dependencies into the editable project.
bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT / "data/tiananmen_tourist.blend"))
(ROOT / "data/shots.json").write_text(json.dumps(SHOTS, ensure_ascii=False, indent=2))
print(
    json.dumps(
        {
            "status": "built",
            "scene": scene.name,
            "objects": len(scene.objects),
            "frames": 288,
            "blend": str(ROOT / "data/tiananmen_tourist.blend"),
        }
    )
)
