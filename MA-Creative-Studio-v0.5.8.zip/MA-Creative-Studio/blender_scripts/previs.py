"""Temporary render-only settings: preserve source geometry, camera and timeline."""


def configure_previs(scene):
    scene.render.engine = "BLENDER_WORKBENCH"
    scene.render.use_simplify = True
    scene.render.simplify_subdivision_render = 0
    scene.render.simplify_child_particles_render = 0
    scene.render.film_transparent = False
    scene.render.use_compositing = False
    scene.render.use_sequencer = False
    scene.display.render_aa = "8"
    shading = scene.display.shading
    shading.light = "STUDIO"
    shading.color_type = "MATERIAL"
    shading.show_shadows = True
    shading.show_cavity = True
    shading.cavity_type = "WORLD"
    shading.show_specular_highlight = False
    shading.show_object_outline = True
    shading.show_xray = False
    shading.use_dof = False
    shading.background_type = "VIEWPORT"
    shading.background_color = (0.12, 0.14, 0.18)
    scene.view_settings.view_transform = "Standard"
    scene.view_settings.exposure = 0
    scene.view_settings.gamma = 1
    # Node materials often leave the viewport color at its default grey.
    # Copy simple base colors only; do not evaluate textures or modify node trees.
    for obj in scene.objects:
        for slot in obj.material_slots:
            material = slot.material
            if material and material.use_nodes and material.node_tree:
                shader = next((n for n in material.node_tree.nodes if n.type == "BSDF_PRINCIPLED"), None)
                if shader and not shader.inputs["Base Color"].is_linked:
                    material.diffuse_color = shader.inputs["Base Color"].default_value
    return {"profile": "previs", "engine": scene.render.engine, "render_aa": scene.display.render_aa}
