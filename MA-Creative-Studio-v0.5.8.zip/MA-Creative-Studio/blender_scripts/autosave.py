"""Project-scoped checkpoints for MCP operations and edits in the Blender UI."""

import os
from pathlib import Path
import shutil
import time
import uuid

import bpy

_paths = {}
_dirty = {}
_saving = False
_native = set()


def save_scene(scene, path=None):
    global _saving
    path = Path(path or _paths[scene.name])
    path.parent.mkdir(parents=True, exist_ok=True)
    archive = path.parent / "archive"
    archive.mkdir(exist_ok=True)
    pending = archive / (uuid.uuid4().hex + ".blend")
    backup_pending = archive / (uuid.uuid4().hex + ".backup")
    _saving = True
    try:
        if scene.name in _native:
            bpy.context.window.scene = scene
            if bpy.data.filepath != str(path):
                if path.exists():
                    shutil.copyfile(path, backup_pending)
                    os.replace(backup_pending, archive / (path.stem + '-previous.blend'))
                # Establish the real main-file name once. Later checkpoints use
                # copy=True so the window keeps the project title, not temp names.
                result = bpy.ops.wm.save_as_mainfile(filepath=str(path), check_existing=False, compress=True)
                if 'FINISHED' not in result:
                    raise RuntimeError('Blender could not initialize the main project file')
                _dirty.pop(scene.name, None)
                return
            result = bpy.ops.wm.save_as_mainfile(filepath=str(pending), check_existing=False, compress=True, copy=True)
            if 'FINISHED' not in result:
                raise RuntimeError('Blender could not save the main project file')
        else:
            bpy.data.libraries.write(str(pending), {scene}, path_remap="ABSOLUTE", fake_user=True, compress=True)
        if not pending.is_file() or pending.stat().st_size == 0:
            raise RuntimeError("Blender did not write the project checkpoint")
        if path.exists():
            shutil.copyfile(path, backup_pending)
            os.replace(backup_pending, archive / (path.stem + "-previous.blend"))
        os.replace(pending, path)
        _dirty.pop(scene.name, None)
    finally:
        _saving = False
        pending.unlink(missing_ok=True)
        backup_pending.unlink(missing_ok=True)


def _changed(scene, depsgraph):
    if not _saving and scene.name in _paths:
        now = time.monotonic()
        first, _ = _dirty.get(scene.name, (now, now))
        _dirty[scene.name] = (first, now)


def _flush():
    now = time.monotonic()
    for name, (first, last) in list(_dirty.items()):
        if now - last < 2 and now - first < 15:
            continue
        scene = bpy.data.scenes.get(name)
        if scene is None:
            _dirty.pop(name, None)
            continue
        try:
            save_scene(scene)
        except Exception as exc:
            print("MA_STUDIO_AUTOSAVE_FAILED", name, str(exc), flush=True)
            _dirty[name] = (now, now)
    return 1.0


def register_scene(scene, path, native=False):
    _paths[scene.name] = str(path)
    if native:
        _native.add(scene.name)
    if _changed not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_changed)
    if not bpy.app.timers.is_registered(_flush):
        bpy.app.timers.register(_flush, first_interval=1.0)
