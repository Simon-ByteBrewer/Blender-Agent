"""Local reproducible render/encode/validation entry point. No cloud credentials needed."""

import argparse, json, subprocess, os, fcntl
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BLENDER = os.getenv("BLENDER_BIN", "/Applications/Blender.app/Contents/MacOS/Blender")


def run(cmd):
    subprocess.run([str(x) for x in cmd], cwd=ROOT, check=True)


def encode():
    frames = ROOT / "data/frames"
    missing = [i for i in range(1, 289) if not (frames / f"frame_{i:04d}.png").exists()]
    if missing:
        raise RuntimeError(
            f"Missing {len(missing)} rendered frames, first: {missing[:5]}"
        )
    run(
        [
            "ffmpeg",
            "-y",
            "-framerate",
            "24",
            "-start_number",
            "1",
            "-i",
            frames / "frame_%04d.png",
            "-frames:v",
            "288",
            "-c:v",
            "libx264",
            "-preset",
            "slow",
            "-crf",
            "18",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
            ROOT / "data/tiananmen_reference.mp4",
        ]
    )
    for i, name in enumerate(["01_square", "02_bridge", "03_look_up"]):
        run(
            [
                "ffmpeg",
                "-y",
                "-i",
                ROOT / "data/tiananmen_reference.mp4",
                "-ss",
                str(i * 4),
                "-t",
                "4",
                "-an",
                "-c:v",
                "libx264",
                "-crf",
                "18",
                "-pix_fmt",
                "yuv420p",
                "-movflags",
                "+faststart",
                ROOT / f"data/{name}.mp4",
            ]
        )


def validate():
    movie = ROOT / "data/tiananmen_reference.mp4"
    p = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-count_frames",
            "-show_streams",
            "-show_format",
            "-of",
            "json",
            str(movie),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    data = json.loads(p.stdout)
    s = next(s for s in data["streams"] if s["codec_type"] == "video")
    assert (s["width"], s["height"]) == (1280, 720)
    assert s["r_frame_rate"] == "24/1" and int(s["nb_read_frames"]) == 288
    assert abs(float(data["format"]["duration"]) - 12) < 0.05
    assert s["pix_fmt"] == "yuv420p" and s["codec_name"] == "h264"
    # Decode every frame, treating corrupt frame errors as failures.
    run(["ffmpeg", "-v", "error", "-xerror", "-i", movie, "-f", "null", "-"])
    report = {
        "video": str(movie.relative_to(ROOT)),
        "width": 1280,
        "height": 720,
        "fps": 24,
        "frames": 288,
        "duration_seconds": 12,
        "full_decode": "passed",
        "blend_exists": (ROOT / "data/tiananmen_tourist.blend").is_file(),
    }
    assert report["blend_exists"]
    (ROOT / "data/video_validation.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("action", choices=["preview", "render", "encode", "validate", "all"])
    a = p.parse_args().action
    (ROOT / ".local").mkdir(exist_ok=True)
    with (ROOT / ".local/pipeline.lock").open("w") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("Another local render/encode pipeline is active")
        if a in ["preview", "render", "all"]:
            run(
                [
                    BLENDER,
                    "-b",
                    ROOT / "data/tiananmen_tourist.blend",
                    "-P",
                    ROOT / "blender_scripts/demo_render.py",
                    "--",
                    "preview" if a == "preview" else "render",
                ]
            )
        if a in ["encode", "all"]:
            encode()
        if a in ["validate", "all"]:
            validate()


if __name__ == "__main__":
    main()
