import asyncio, json, base64
from ma_mcp.mcp_bridge import MCPBridge, to_ma_result
from studio.config import OUTPUT


async def main():
    b = MCPBridge()
    tools = await b.discover()
    info = await b.call(
        "get_scene_info",
        {
            "user_prompt": "使用Blender MCP创建一个北京天安门的3D场景，然后以游客视角渲染为视频"
        },
    )
    assert not to_ma_result("info", info)["is_error"]
    execution = await b.call(
        "execute_blender_code",
        {
            "code": "import bpy; bpy.context.scene['adapter_verified']=True; print('ADAPTER_EXECUTION_VERIFIED')"
        },
    )
    executed = not to_ma_result("exec", execution)[
        "is_error"
    ] and "ADAPTER_EXECUTION_VERIFIED" in str(execution)
    assert executed
    shot = await b.call("get_viewport_screenshot", {"max_size": 1200})
    converted = to_ma_result("shot", shot)
    for c in shot["content"]:
        if c["type"] == "image":
            (OUTPUT / "mcp_viewport.png").write_bytes(base64.b64decode(c["data"]))
    images = sum(c["type"] == "image" for c in converted["content"])
    assert images > 0
    report = {
        "tool_count": len(tools),
        "scene_query": "passed",
        "execute_passed": executed,
        "ma_image_blocks": images,
        "status": "passed",
    }
    (OUTPUT / "mcp_validation.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report))


if __name__ == "__main__":
    asyncio.run(main())
