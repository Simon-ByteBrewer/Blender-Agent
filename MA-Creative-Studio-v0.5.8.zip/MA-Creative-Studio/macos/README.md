# Mac 原生应用外壳

同一份 `StudioShell.swift` 有两种用法：`build_dmg.py` 构建带内置程序的安装版（见根目录 README「Mac 安装版」，内置程序由 `start_bundled.sh` 从只读目录启动，数据写入 `~/Library/Application Support/MA Creative Studio`）；`build_app.sh` 构建指向项目目录的开发版（下文）。

`StudioShell.swift` 是单文件 AppKit + WKWebView 程序，只负责窗口：

- 启动时检查 `http://127.0.0.1:7860/api/health`。服务已运行则直接显示；否则在项目目录运行 `blender_scripts/start.sh`（设置 `STUDIO_NO_BROWSER=1`，不再弹出浏览器），输出写入 `logs/mac-app.log`，就绪后加载页面。
- 退出应用时只停止由它启动的服务，不关闭 Blender 窗口；终端或其他方式启动的服务保持运行。
- 外部链接和新窗口交给默认浏览器；下载保存到“下载”文件夹并在 Finder 中显示；支持文件选择、复制粘贴、缩放和全屏。
- 菜单「文件」可在浏览器中打开、打开应用目录或日志、重新选择项目目录。

业务代码、页面和依赖都在项目目录中，更新项目（git pull 或替换解压目录）后重启应用即可，无需重新构建。只有修改本目录的 Swift 代码时才需要重新构建。

## 构建

只需 Xcode Command Line Tools（`swiftc`、`sips`、`iconutil`、`codesign`），不需要 Xcode 工程、Rust、Node 或 Electron。

```bash
zsh macos/build_app.sh            # 生成 macos/build/MA Creative Studio.app
zsh macos/build_app.sh --install  # 同时安装到 ~/Applications，并记住当前项目目录
```

项目目录按以下顺序确定：已保存的选择（`defaults read com.macreative.studio.shell projectRoot`）→ 应用所在目录向上查找 `blender_scripts/start.sh` → 首次启动弹窗选择。

构建产物使用 ad-hoc 签名，适合本机使用。分发给他人时，可将脚本中的 `codesign --sign -` 换成 Developer ID 证书并公证；或让对方在自己的机器上运行构建脚本。
