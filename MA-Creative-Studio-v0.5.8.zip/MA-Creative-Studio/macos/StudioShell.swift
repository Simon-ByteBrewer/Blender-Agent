// Native macOS shell: a WKWebView window around the local Studio service.
// It holds no business logic and shows http://127.0.0.1:7860.
// - Installed app (DMG): runs the read-only payload in Contents/Resources/payload with all
//   writable data in ~/Library/Application Support/MA Creative Studio.
// - Developer build: starts (or reuses) blender_scripts/start.sh in a project folder, so
//   updating the project never requires rebuilding the app.
import AppKit
import WebKit

let studioURL = URL(string: "http://127.0.0.1:7860/")!
let healthURL = URL(string: "http://127.0.0.1:7860/api/health")!
let rootKey = "projectRoot"

func isProjectRoot(_ url: URL) -> Bool {
    FileManager.default.fileExists(atPath: url.appendingPathComponent("blender_scripts/start.sh").path)
}

/// Saved choice first, then the folders containing the app (macos/build/X.app or X.app in the project).
func locateProjectRoot() -> URL? {
    if let saved = UserDefaults.standard.string(forKey: rootKey) {
        let url = URL(fileURLWithPath: saved)
        if isProjectRoot(url) { return url }
    }
    var dir = Bundle.main.bundleURL.deletingLastPathComponent()
    for _ in 0..<4 {
        if isProjectRoot(dir) { return dir }
        dir = dir.deletingLastPathComponent()
    }
    return nil
}

/// The installed app's bundled program, if this build carries one.
func bundledPayload() -> URL? {
    guard let url = Bundle.main.resourceURL?.appendingPathComponent("payload") else { return nil }
    return FileManager.default.fileExists(atPath: url.appendingPathComponent("macos/start_bundled.sh").path) ? url : nil
}

func appDataHome() -> URL {
    FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("MA Creative Studio")
}

func escapeHTML(_ text: String) -> String {
    text.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;")
        .replacingOccurrences(of: ">", with: "&gt;")
}

final class AppDelegate: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
    var window: NSWindow!
    var webView: WKWebView!
    var server: Process?
    var root: URL?
    var dataHome: URL?  // Set in bundled mode; the project folder is the data folder otherwise.
    var logURL: URL?
    var startedAt = Date()
    var pollTimer: Timer?
    var downloads: [ObjectIdentifier: URL] = [:]
    var titleObservation: NSKeyValueObservation?

    func applicationDidFinishLaunching(_ notification: Notification) {
        buildMenu()
        let config = WKWebViewConfiguration()
        config.preferences.setValue(true, forKey: "developerExtrasEnabled")
        if #available(macOS 12.3, *) { config.preferences.isElementFullscreenEnabled = true }
        config.mediaTypesRequiringUserActionForPlayback = []
        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = false
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1440, height: 900),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        window.title = "MA 导演 Agent"
        // The page localizes its title (e.g. "MA Director Studio" in English); mirror it.
        titleObservation = webView.observe(\.title, options: [.new]) { [weak self] view, _ in
            if let title = view.title, !title.isEmpty { self?.window.title = title }
        }
        window.contentView = webView
        window.minSize = NSSize(width: 900, height: 600)
        window.center()
        window.setFrameAutosaveName("StudioMainWindow")
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        start()
    }

    // MARK: Service lifecycle

    func start() {
        if let payload = bundledPayload() {
            root = payload
            dataHome = appDataHome()
            showStatus("正在启动创作环境…", detail: "首次启动需联网安装 Python 依赖，可能需要几分钟。")
            startedAt = Date()
            checkHealth { [weak self] alive in
                guard let self else { return }
                if !alive { self.launchServer(payload) }
                self.pollUntilReady()
            }
            return
        }
        guard let root = locateProjectRoot() ?? chooseProjectRoot() else {
            showStatus("未选择项目目录", detail: "请通过菜单「文件 → 选择项目目录…」选择包含 start.command 的应用目录。", failed: true)
            return
        }
        self.root = root
        showStatus("正在启动创作环境…", detail: "首次启动需联网安装依赖，可能需要几分钟。")
        startedAt = Date()
        checkHealth { [weak self] alive in
            guard let self else { return }
            if !alive { self.launchServer(root) }
            self.pollUntilReady()
        }
    }

    func launchServer(_ root: URL) {
        let logs = (dataHome ?? root).appendingPathComponent("logs")
        try? FileManager.default.createDirectory(at: logs, withIntermediateDirectories: true)
        let logURL = logs.appendingPathComponent("mac-app.log")
        FileManager.default.createFile(atPath: logURL.path, contents: nil)
        self.logURL = logURL
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/bin/zsh")
        var env = ProcessInfo.processInfo.environment
        for key in ["PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV", "UV_PROJECT_ENVIRONMENT"] { env.removeValue(forKey: key) }
        env["STUDIO_NO_BROWSER"] = "1"
        if let home = dataHome {
            try? FileManager.default.createDirectory(at: home, withIntermediateDirectories: true)
            process.arguments = [root.appendingPathComponent("macos/start_bundled.sh").path]
            process.currentDirectoryURL = home
            env["STUDIO_HOME"] = home.path
        } else {
            process.arguments = [root.appendingPathComponent("blender_scripts/start.sh").path]
            process.currentDirectoryURL = root
        }
        process.environment = env
        if let handle = try? FileHandle(forWritingTo: logURL) {
            process.standardOutput = handle
            process.standardError = handle
        }
        process.terminationHandler = { [weak self] p in
            DispatchQueue.main.async {
                guard let self, self.server === p else { return }
                self.server = nil
                // start.sh exits 0 when it found an already running service.
                if p.terminationStatus != 0 { self.serverFailed("服务已停止（退出码 \(p.terminationStatus)）") }
            }
        }
        do {
            try process.run()
            server = process
        } catch {
            serverFailed("无法启动服务：\(error.localizedDescription)")
        }
    }

    func pollUntilReady() {
        pollTimer?.invalidate()
        pollTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] timer in
            guard let self else { return timer.invalidate() }
            self.checkHealth { alive in
                if alive {
                    timer.invalidate()
                    self.webView.load(URLRequest(url: studioURL))
                } else if Date().timeIntervalSince(self.startedAt) > 900 {
                    timer.invalidate()
                    self.serverFailed("等待服务超时")
                } else {
                    let seconds = Int(Date().timeIntervalSince(self.startedAt))
                    self.updateStatus("已等待 \(seconds) 秒" + (self.lastLogLine().map { " · " + $0 } ?? ""))
                }
            }
        }
    }

    func checkHealth(_ done: @escaping (Bool) -> Void) {
        var request = URLRequest(url: healthURL, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 2)
        request.httpMethod = "GET"
        URLSession.shared.dataTask(with: request) { _, response, _ in
            let ok = (response as? HTTPURLResponse)?.statusCode == 200
            DispatchQueue.main.async { done(ok) }
        }.resume()
    }

    func serverFailed(_ reason: String) {
        pollTimer?.invalidate()
        let tail = logTail(lines: 25)
        showStatus(reason, detail: tail.isEmpty ? "请检查 logs/mac-app.log。" : tail, failed: true)
    }

    /// Stops only a service this app started; the user's Blender windows stay open.
    func stopServer(then done: @escaping () -> Void = {}) {
        guard let process = server, process.isRunning else { return done() }
        server = nil
        // Leave the page first so its event streams do not hold up a graceful shutdown.
        webView.stopLoading()
        webView.loadHTMLString("", baseURL: nil)
        process.terminate()
        let deadline = Date().addingTimeInterval(10)
        let timer = Timer(timeInterval: 0.1, repeats: true) { timer in
            guard process.isRunning else { timer.invalidate(); return done() }
            if Date() > deadline {
                timer.invalidate()
                kill(process.processIdentifier, SIGKILL)
                done()
            }
        }
        // Common modes: during terminateLater the run loop is in the modal panel mode.
        RunLoop.main.add(timer, forMode: .common)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard server?.isRunning == true else { return .terminateNow }
        stopServer { sender.reply(toApplicationShouldTerminate: true) }
        return .terminateLater
    }

    // MARK: Status page (shown until the service is ready)

    func showStatus(_ title: String, detail: String, failed: Bool = false) {
        let choose = bundledPayload() == nil ? " · <a href=\"studio-shell://choose\">选择项目目录</a>" : ""
        let actions = failed ? "<p><a href=\"studio-shell://retry\">重试</a> · <a href=\"studio-shell://logs\">打开日志</a>\(choose)</p>" : ""
        let html = """
        <!doctype html><meta charset="utf-8"><style>
        body{font:14px -apple-system,system-ui;margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:#f5f6f8;color:#2d333b}
        main{max-width:680px;padding:32px}h1{font-size:20px;font-weight:600}#s{color:#6b7686;min-height:1.4em}
        pre{white-space:pre-wrap;background:#fff;border:1px solid #e1e5eb;border-radius:8px;padding:12px;font-size:12px;max-height:50vh;overflow:auto}
        a{color:#006dcc;text-decoration:none}</style><main><h1>\(escapeHTML(title))</h1>
        \(failed ? "<pre>\(escapeHTML(detail))</pre>" : "<p>\(escapeHTML(detail))</p><p id=\"s\"></p>")\(actions)</main>
        """
        webView.loadHTMLString(html, baseURL: nil)
    }

    func updateStatus(_ text: String) {
        guard let data = try? JSONSerialization.data(withJSONObject: [text]),
              let literal = String(data: data, encoding: .utf8) else { return }
        webView.evaluateJavaScript("var s=document.getElementById('s'); if (s) s.textContent=\(literal)[0];")
    }

    func logTail(lines: Int) -> String {
        guard let url = logURL, let text = try? String(contentsOf: url, encoding: .utf8) else { return "" }
        return text.split(separator: "\n", omittingEmptySubsequences: true).suffix(lines).joined(separator: "\n")
    }

    func lastLogLine() -> String? {
        let line = logTail(lines: 1)
        return line.isEmpty ? nil : String(line.prefix(120))
    }

    // MARK: Navigation, new windows, downloads

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { return decisionHandler(.cancel) }
        if url.scheme == "studio-shell" {
            decisionHandler(.cancel)
            switch url.host {
            case "retry": start()
            case "logs": if let logURL { NSWorkspace.shared.open(logURL) }
            case "choose": chooseFolder()
            default: break
            }
            return
        }
        if action.shouldPerformDownload { return decisionHandler(.download) }
        if url.scheme == "about" || url.scheme == "data" || isStudio(url) { return decisionHandler(.allow) }
        // Everything outside the local service opens in the default browser.
        if action.navigationType == .linkActivated || action.targetFrame?.isMainFrame == true {
            NSWorkspace.shared.open(url)
            return decisionHandler(.cancel)
        }
        decisionHandler(.allow)  // Subresources and iframes (e.g. the remote desktop).
    }

    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        let disposition = (response.response as? HTTPURLResponse)?.value(forHTTPHeaderField: "Content-Disposition") ?? ""
        if disposition.lowercased().hasPrefix("attachment") || (response.isForMainFrame && !response.canShowMIMEType) {
            return decisionHandler(.download)
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = self
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
                  suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let folder = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask)[0]
        let base = (suggestedFilename as NSString).deletingPathExtension
        let ext = (suggestedFilename as NSString).pathExtension
        var dest = folder.appendingPathComponent(suggestedFilename)
        var n = 1
        while FileManager.default.fileExists(atPath: dest.path) {
            dest = folder.appendingPathComponent(ext.isEmpty ? "\(base) \(n)" : "\(base) \(n).\(ext)")
            n += 1
        }
        downloads[ObjectIdentifier(download)] = dest
        completionHandler(dest)
    }

    func downloadDidFinish(_ download: WKDownload) {
        if let dest = downloads.removeValue(forKey: ObjectIdentifier(download)) {
            NSWorkspace.shared.activateFileViewerSelecting([dest])
        }
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        downloads.removeValue(forKey: ObjectIdentifier(download))
        alert("下载失败", error.localizedDescription)
    }

    /// target=_blank / window.open: local pages and external links open in the default browser.
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = action.request.url { NSWorkspace.shared.open(url) }
        return nil
    }

    func isStudio(_ url: URL) -> Bool {
        url.host == studioURL.host && url.port == studioURL.port
    }

    // MARK: JavaScript dialogs and file inputs

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        alert(message, "")
        completionHandler()
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = NSAlert()
        a.messageText = message
        a.addButton(withTitle: "确定")
        a.addButton(withTitle: "取消")
        completionHandler(a.runModal() == .alertFirstButtonReturn)
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        let a = NSAlert()
        a.messageText = prompt
        let field = NSTextField(frame: NSRect(x: 0, y: 0, width: 320, height: 24))
        field.stringValue = defaultText ?? ""
        a.accessoryView = field
        a.addButton(withTitle: "确定")
        a.addButton(withTitle: "取消")
        completionHandler(a.runModal() == .alertFirstButtonReturn ? field.stringValue : nil)
    }

    func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = parameters.allowsMultipleSelection
        panel.canChooseDirectories = parameters.allowsDirectories
        panel.canChooseFiles = true
        panel.beginSheetModal(for: window) { completionHandler($0 == .OK ? panel.urls : nil) }
    }

    func alert(_ title: String, _ text: String) {
        let a = NSAlert()
        a.messageText = title
        a.informativeText = text
        a.runModal()
    }

    // MARK: Menu

    func chooseProjectRoot() -> URL? {
        let panel = NSOpenPanel()
        panel.message = "选择应用目录（包含 start.command 和 blender_scripts）"
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        while panel.runModal() == .OK, let url = panel.url {
            if isProjectRoot(url) {
                UserDefaults.standard.set(url.path, forKey: rootKey)
                return url
            }
            alert("不是应用目录", "所选目录中没有 blender_scripts/start.sh。")
        }
        return nil
    }

    @objc func reloadPage() {
        if let url = webView.url, isStudio(url) { webView.reload() } else { start() }
    }
    @objc func openInBrowser() { NSWorkspace.shared.open(studioURL) }
    @objc func openProjectFolder() { if let folder = dataHome ?? root { NSWorkspace.shared.open(folder) } }
    @objc func openLogs() { if let folder = dataHome ?? root { NSWorkspace.shared.open(folder.appendingPathComponent("logs")) } }
    @objc func chooseFolder() {
        if bundledPayload() != nil {
            return alert("安装版使用内置程序", "数据保存在 ~/Library/Application Support/MA Creative Studio。开发者可用 macos/build_app.sh 构建指向项目目录的版本。")
        }
        if chooseProjectRoot() != nil { stopServer { self.start() } }
    }
    @objc func zoomIn() { webView.pageZoom = min(2, webView.pageZoom + 0.1) }
    @objc func zoomOut() { webView.pageZoom = max(0.5, webView.pageZoom - 0.1) }
    @objc func zoomReset() { webView.pageZoom = 1 }

    func buildMenu() {
        let main = NSMenu()
        func submenu(_ title: String, _ items: [NSMenuItem]) {
            let item = NSMenuItem(title: title, action: nil, keyEquivalent: "")
            let menu = NSMenu(title: title)
            items.forEach(menu.addItem)
            item.submenu = menu
            main.addItem(item)
        }
        func entry(_ title: String, _ action: Selector?, _ key: String = "", _ mods: NSEvent.ModifierFlags = .command) -> NSMenuItem {
            let item = NSMenuItem(title: title, action: action, keyEquivalent: key)
            item.keyEquivalentModifierMask = mods
            return item
        }
        let name = "MA Creative Studio"
        submenu(name, [
            entry("关于 \(name)", #selector(NSApplication.orderFrontStandardAboutPanel(_:))),
            .separator(),
            entry("隐藏 \(name)", #selector(NSApplication.hide(_:)), "h"),
            entry("隐藏其他", #selector(NSApplication.hideOtherApplications(_:)), "h", [.command, .option]),
            .separator(),
            entry("退出 \(name)", #selector(NSApplication.terminate(_:)), "q"),
        ])
        submenu("文件", [
            entry("在浏览器中打开", #selector(openInBrowser), "o", [.command, .shift]),
            entry(bundledPayload() == nil ? "打开应用目录" : "打开数据目录", #selector(openProjectFolder)),
            entry("打开日志目录", #selector(openLogs)),
            .separator(),
            entry("选择项目目录…", #selector(chooseFolder)),
            .separator(),
            entry("关闭窗口", #selector(NSWindow.performClose(_:)), "w"),
        ])
        // WKWebView text fields need these responder actions for copy and paste shortcuts.
        submenu("编辑", [
            entry("撤销", Selector(("undo:")), "z"),
            entry("重做", Selector(("redo:")), "z", [.command, .shift]),
            .separator(),
            entry("剪切", #selector(NSText.cut(_:)), "x"),
            entry("拷贝", #selector(NSText.copy(_:)), "c"),
            entry("粘贴", #selector(NSText.paste(_:)), "v"),
            entry("全选", #selector(NSText.selectAll(_:)), "a"),
        ])
        submenu("显示", [
            entry("重新载入", #selector(reloadPage), "r"),
            .separator(),
            entry("放大", #selector(zoomIn), "+"),
            entry("缩小", #selector(zoomOut), "-"),
            entry("实际大小", #selector(zoomReset), "0"),
            .separator(),
            entry("进入全屏", #selector(NSWindow.toggleFullScreen(_:)), "f", [.command, .control]),
        ])
        submenu("窗口", [
            entry("最小化", #selector(NSWindow.performMiniaturize(_:)), "m"),
            entry("缩放", #selector(NSWindow.performZoom(_:))),
        ])
        NSApp.mainMenu = main
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
