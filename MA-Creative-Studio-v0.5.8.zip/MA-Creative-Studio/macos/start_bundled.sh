#!/bin/zsh
# Start the studio from the read-only payload inside the macOS app bundle.
# Every writable file (Python environment, .env, projects, logs) lives in STUDIO_HOME,
# so the signed bundle is never modified.
set -euo pipefail
RESOURCES="$(cd "$(dirname "$0")/.." && pwd)"
: "${STUDIO_HOME:?STUDIO_HOME is required}"
export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/.local/bin:$PATH"
export PYTHONDONTWRITEBYTECODE=1
mkdir -p "$STUDIO_HOME/logs" "$STUDIO_HOME/.local" "$STUDIO_HOME/data"
cd "$STUDIO_HOME"
command -v uv >/dev/null || { echo '缺少 uv：请先安装 Homebrew 后运行 brew install uv ffmpeg'; exit 1; }
command -v ffmpeg >/dev/null || { echo '缺少 FFmpeg：请运行 brew install ffmpeg'; exit 1; }
BLENDER_BIN=/Applications/Blender.app/Contents/MacOS/Blender
[[ -x "$BLENDER_BIN" ]] || { echo '请将 Blender.app 安装到 /Applications（应用程序）并正常打开一次'; exit 1; }

export UV_PROJECT_ENVIRONMENT="$STUDIO_HOME/runtime/venv"
# Dependencies only: the backend runs from the payload through PYTHONPATH, so nothing is
# built or written inside the bundle.
uv sync --frozen --all-packages --no-dev --no-install-workspace --project "$RESOURCES"
VENV="$UV_PROJECT_ENVIRONMENT"

BLENDER_VERSION=$("$BLENDER_BIN" --version | awk 'NR == 1 {split($2, v, "."); print v[1] "." v[2]}')
[[ "$BLENDER_VERSION" == <->.<-> ]] || { echo '无法识别 Blender 版本'; exit 1; }
ADDONS_DIR="$HOME/Library/Application Support/Blender/$BLENDER_VERSION/scripts/addons"
if [[ ! -f "$ADDONS_DIR/blender_mcp.py" ]]; then
  echo '首次启动：安装 Blender MCP 插件…'
  "$VENV/bin/blender-mcp" install-addon --addons-dir "$ADDONS_DIR"
fi

echo "启动工作室：http://127.0.0.1:7860（数据目录 $STUDIO_HOME）"
export STUDIO_RESOURCE_ROOT="$RESOURCES" PYTHONPATH="$RESOURCES/backend/src"
exec "$VENV/bin/python" -m uvicorn studio.app:app --host 127.0.0.1 --port 7860 --timeout-graceful-shutdown 5
