#!/bin/zsh
# Build the native macOS shell with the Command Line Tools Swift compiler only.
#   zsh macos/build_app.sh            -> macos/build/MA Creative Studio.app
#   zsh macos/build_app.sh --install  -> also copy to ~/Applications and remember this project folder
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NAME="MA Creative Studio"
BUNDLE_ID="com.macreative.studio.shell"
BUILD="$ROOT/macos/build"
APP="$BUILD/$NAME.app"
VERSION="$(tr -d '[:space:]' < "$ROOT/VERSION")"
command -v swiftc >/dev/null || { echo "缺少 swiftc，请先运行 xcode-select --install"; exit 1; }

rm -rf "$APP" "$BUILD/AppIcon.iconset"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
swiftc -O -swift-version 5 -target "$(uname -m)-apple-macos12.0" \
  -framework AppKit -framework WebKit \
  "$ROOT/macos/StudioShell.swift" -o "$APP/Contents/MacOS/StudioShell"

ICON="$ROOT/frontend/public/app-icon.png"
if [[ -f "$ICON" ]]; then
  ICONSET="$BUILD/AppIcon.iconset"
  mkdir -p "$ICONSET"
  for size in 16 32 128 256 512; do
    sips -z $size $size "$ICON" --out "$ICONSET/icon_${size}x${size}.png" >/dev/null
    sips -z $((size * 2)) $((size * 2)) "$ICON" --out "$ICONSET/icon_${size}x${size}@2x.png" >/dev/null
  done
  iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/AppIcon.icns"
  rm -rf "$ICONSET"
fi

cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>$NAME</string>
  <key>CFBundleDisplayName</key><string>$NAME</string>
  <key>CFBundleIdentifier</key><string>$BUNDLE_ID</string>
  <key>CFBundleExecutable</key><string>StudioShell</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>$VERSION</string>
  <key>CFBundleVersion</key><string>$VERSION</string>
  <key>LSMinimumSystemVersion</key><string>12.0</string>
  <key>LSApplicationCategoryType</key><string>public.app-category.graphics-design</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSAppTransportSecurity</key><dict><key>NSAllowsLocalNetworking</key><true/></dict>
</dict></plist>
PLIST
# Ad-hoc signature; use a Developer ID identity here for distribution outside this Mac.
codesign --force --sign - "$APP" >/dev/null
echo "已生成：$APP"

if [[ "${1:-}" == "--install" ]]; then
  mkdir -p "$HOME/Applications"
  rm -rf "$HOME/Applications/$NAME.app"
  cp -R "$APP" "$HOME/Applications/"
  defaults write "$BUNDLE_ID" projectRoot "$ROOT"
  echo "已安装到：$HOME/Applications/$NAME.app（项目目录：$ROOT）"
fi
