#!/usr/bin/env python3
"""Build the installable macOS app and DMG, audit it for credentials, sign and notarize.

    .venv/bin/python macos/build_dmg.py              # signed DMG, file name says unnotarized
    .venv/bin/python macos/build_dmg.py --notarize   # also notarize and staple

The app carries the audited release payload (scripts/package_release.py) read-only in
Contents/Resources/payload; at runtime all writable data lives in
~/Library/Application Support/MA Creative Studio.

Notarization code, credential config and docs live in .local/notarization/ (git-ignored,
never packaged); see its README.md. APPLE_SIGNING_IDENTITY overrides the signing identity.
"""
import argparse
import hashlib
import os
from pathlib import Path
import plistlib
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from release_audit import Auditor  # noqa: E402

NAME = "MA Creative Studio"
BUNDLE_ID = "com.macreative.studio"


def run(*command, **kwargs):
    return subprocess.run(command, check=True, **kwargs)


def signing_identity():
    if os.environ.get("APPLE_SIGNING_IDENTITY"):
        return os.environ["APPLE_SIGNING_IDENTITY"]
    listing = subprocess.check_output(["security", "find-identity", "-v", "-p", "codesigning"], text=True)
    match = re.search(r'"(Developer ID Application: [^"]+)"', listing)
    if not match:
        raise SystemExit("未找到 Developer ID Application 签名证书")
    return match[1]


def build_payload(version):
    archive = ROOT / "release" / f"MA-Creative-Studio-v{version}.zip"
    command = [sys.executable, str(ROOT / "scripts/package_release.py")]
    if archive.exists():
        command.append("--force")
    run(*command, cwd=ROOT)  # Whitelist, frontend build and credential audit.
    return archive


def build_binary(out):
    with tempfile.TemporaryDirectory() as tmp:
        slices = []
        for arch in ("arm64", "x86_64"):
            target = Path(tmp) / arch
            # Map the source path so no local directory is embedded in the binary.
            run("swiftc", "-O", "-swift-version", "5", "-target", f"{arch}-apple-macos12.0",
                "-file-prefix-map", f"{ROOT}=.", "-framework", "AppKit", "-framework", "WebKit",
                str(ROOT / "macos/StudioShell.swift"), "-o", str(target))
            slices.append(str(target))
        run("lipo", "-create", *slices, "-output", str(out))


def build_icon(resources, work):
    iconset = work / "AppIcon.iconset"
    iconset.mkdir()
    source = ROOT / "frontend/public/app-icon.png"
    for size in (16, 32, 128, 256, 512):
        for scale in (1, 2):
            name = f"icon_{size}x{size}{'@2x' if scale == 2 else ''}.png"
            run("sips", "-z", str(size * scale), str(size * scale), str(source), "--out", str(iconset / name),
                stdout=subprocess.DEVNULL)
    run("iconutil", "-c", "icns", str(iconset), "-o", str(resources / "AppIcon.icns"))


def build_app(version, archive, work):
    app = work / f"{NAME}.app"
    contents = app / "Contents"
    (contents / "MacOS").mkdir(parents=True)
    resources = contents / "Resources"
    resources.mkdir()
    build_binary(contents / "MacOS/StudioShell")
    build_icon(resources, work)
    payload = resources / "payload"
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            name = info.filename.split("/", 1)[1] if "/" in info.filename else ""
            if not name or info.is_dir():
                continue
            dest = payload / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(z.read(info))
            dest.chmod(0o755 if (info.external_attr >> 16) & 0o111 else 0o644)
    with (contents / "Info.plist").open("wb") as f:
        plistlib.dump({
            "CFBundleName": NAME, "CFBundleDisplayName": NAME, "CFBundleIdentifier": BUNDLE_ID,
            "CFBundleExecutable": "StudioShell", "CFBundleIconFile": "AppIcon", "CFBundlePackageType": "APPL",
            "CFBundleShortVersionString": version, "CFBundleVersion": version,
            "LSMinimumSystemVersion": "12.0", "LSApplicationCategoryType": "public.app-category.graphics-design",
            "NSHighResolutionCapable": True, "NSHumanReadableCopyright": "MA 导演 Agent",
            "NSAppTransportSecurity": {"NSAllowsLocalNetworking": True},
        }, f)
    return app


def audit_tree(auditor, folder, label):
    count = 0
    for path in sorted(Path(folder).rglob("*")):
        if path.is_file() and not path.is_symlink():
            auditor.check(f"{label}/{path.relative_to(folder)}", path.read_bytes())
            count += 1
    return count


def background(path):
    """A plain arrow from the app to Applications; 1320x800 at 144 dpi for Retina."""
    from PIL import Image, ImageDraw
    image = Image.new("RGB", (1320, 800), "#f5f6f8")
    draw = ImageDraw.Draw(image)
    draw.line([(560, 370), (760, 370)], fill="#007aff", width=10)
    draw.polygon([(790, 370), (750, 340), (750, 400)], fill="#007aff")
    image.save(path, dpi=(144, 144))


def build_dmg(app, out, work):
    bg = work / "background.png"
    background(bg)
    settings = work / "dmg_settings.py"
    settings.write_text(f'''
files = [{str(app)!r}]
symlinks = {{"Applications": "/Applications"}}
hide_extension = [{app.name!r}]
format = "UDBZ"
background = {str(bg)!r}
window_rect = ((200, 120), (660, 400))
default_view = "icon-view"
icon_size = 128
text_size = 13
icon_locations = {{{app.name!r}: (165, 185), "Applications": (495, 185)}}
show_status_bar = False
show_tab_view = False
show_toolbar = False
show_pathbar = False
show_sidebar = False
''')
    out.unlink(missing_ok=True)
    run("uvx", "--from", "dmgbuild==1.6.7", "dmgbuild", "-s", str(settings), NAME, str(out))


def audit_dmg(auditor, dmg):
    with tempfile.TemporaryDirectory() as mount:
        run("hdiutil", "attach", "-readonly", "-nobrowse", "-mountpoint", mount, str(dmg), stdout=subprocess.DEVNULL)
        try:
            return audit_tree(auditor, mount, "dmg")
        finally:
            run("hdiutil", "detach", mount, "-quiet")


def load_notarizer():
    """The local-only notarization module; fail before building if it is missing."""
    module = ROOT / ".local/notarization/notarize.py"
    if not module.is_file():
        raise SystemExit(f"缺少 {module}；公证配置只保存在本机，可去掉 --notarize 生成未公证 DMG")
    import importlib.util
    spec = importlib.util.spec_from_file_location("local_notarize", module)
    notarizer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(notarizer)
    notarizer.credentials()  # Validate credentials up front, not after a long build.
    return notarizer.notarize


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--notarize", action="store_true")
    args = parser.parse_args()
    version = (ROOT / "VERSION").read_text().strip()
    notarize = load_notarizer() if args.notarize else None
    identity = signing_identity()
    archive = build_payload(version)
    auditor = Auditor(ROOT)
    release = ROOT / "release"
    with tempfile.TemporaryDirectory(prefix="studio-dmg-") as tmp:
        work = Path(tmp)
        app = build_app(version, archive, work)
        files = audit_tree(auditor, app, app.name)
        print(f"app audit: {files} files, no credentials or personal identifiers")
        run("codesign", "--force", "--options", "runtime", "--timestamp", "--sign", identity, str(app))
        run("codesign", "--verify", "--deep", "--strict", "--verbose=2", str(app))
        staged = work / f"MA-Creative-Studio-v{version}-macOS.dmg"
        build_dmg(app, staged, work)
        run("codesign", "--force", "--timestamp", "--sign", identity, str(staged))
        print(f"dmg audit: {audit_dmg(auditor, staged)} files, no credentials or personal identifiers")
        if notarize:
            notarize(staged)
            final = release / staged.name
        else:
            final = release / staged.name.replace("-macOS.dmg", "-macOS-unnotarized.dmg")
        shutil.copyfile(staged, final)
    digest = hashlib.sha256(final.read_bytes()).hexdigest()
    final.with_name(final.name + ".sha256").write_text(f"{digest}  {final.name}\n")
    print(f"{final} ({final.stat().st_size // 1024} KB, sha256 {digest})")


if __name__ == "__main__":
    main()
