import type { CSSProperties } from "react";
import "@vscode/codicons/dist/codicon.css";
type Props = { size?: number; className?: string; style?: CSSProperties };
const icon =
  (name: string) =>
  ({ size = 16, className = "", style }: Props) => (
    <span
      aria-hidden="true"
      className={`codicon codicon-${name} ${className}`}
      style={{ fontSize: size, ...style }}
    />
  );
export const ArrowUp = icon("arrow-up"),
  Camera = icon("device-camera"),
  Check = icon("check"),
  ChevronDown = icon("chevron-down"),
  ChevronRight = icon("chevron-right"),
  CircleAlert = icon("warning"),
  Download = icon("cloud-download"),
  Pencil = icon("edit"),
  FileBox = icon("file"),
  FileVideo = icon("device-camera-video"),
  Audio = icon("unmute"),
  Folder = icon("folder"),
  Image = icon("file-media"),
  Layers = icon("layers"),
  LoaderCircle = icon("loading"),
  MessageSquare = icon("comment-discussion"),
  PanelLeftClose = icon("layout-sidebar-left"),
  PanelRightClose = icon("layout-sidebar-right"),
  Play = icon("play"),
  Plus = icon("add"),
  RefreshCw = icon("refresh"),
  Send = icon("send"),
  Settings = icon("settings-gear"),
  Sparkles = icon("sparkle"),
  Square = icon("debug-stop"),
  Terminal = icon("terminal"),
  Upload = icon("cloud-upload"),
  X = icon("close"),
  Files = icon("files"),
  Window = icon("open-preview"),
  ExternalLink = icon("link-external"),
  LinkIcon = icon("link"),
  Person = icon("person"),
  Trash = icon("trash");

export function SquareFilled({ size = 16, className = "", style }: Props) {
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className}
      style={style}
    >
      <rect x="5" y="5" width="14" height="14" rx="1.5" />
    </svg>
  );
}

export function CreativeMark({ size = 24 }: Props) {
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
    >
      <path
        d="M12 5H7a3 3 0 0 0-3 3v9a3 3 0 0 0 3 3h9a3 3 0 0 0 3-3v-4"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
      <path
        d="m17 2 1.6 4.4L23 8l-4.4 1.6L17 14l-1.6-4.4L11 8l4.4-1.6L17 2Z"
        fill="currentColor"
      />
      <path
        d="m8 13 .8 2.2L11 16l-2.2.8L8 19l-.8-2.2L5 16l2.2-.8L8 13Z"
        fill="currentColor"
        opacity=".65"
      />
    </svg>
  );
}

export function Box({ size = 16, className = "", style }: Props) {
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={style}
    >
      <path d="M12 3 3.5 7.8v8.4L12 21l8.5-4.8V7.8L12 3Z" />
      <path d="m3.5 7.8 8.5 4.8 8.5-4.8M12 12.6V21M7.8 5.4l8.4 4.8" />
    </svg>
  );
}
export function SidebarIcon({
  side,
  open,
}: {
  side: "left" | "right";
  open: boolean;
}) {
  return (
    <svg
      aria-hidden="true"
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect
        x="3"
        y="3"
        width="18"
        height="18"
        rx="5.5"
      />
      {open && (
        <path
          d={
            side === "left"
              ? "M9 4H8a4 4 0 0 0-4 4v8a4 4 0 0 0 4 4h1Z"
              : "M15 4h1a4 4 0 0 1 4 4v8a4 4 0 0 1-4 4h-1Z"
          }
          fill="currentColor"
          stroke="none"
        />
      )}
      <path
        d={side === "left" ? "M9 3.5v17" : "M15 3.5v17"}
      />
    </svg>
  );
}
