import { appFetch } from "../appUrl";
import { useEffect, useRef, useState } from "react";
import { Check, LoaderCircle } from "../icons";
import { startPolling } from "../polling";
import { t } from "../i18n";
import "./styles.css";

type ExecutionMode = "local" | "self_hosted" | "colocated";

async function request(path: string, body?: object, signal?: AbortSignal) {
  let response: Response | undefined;
  try {
    response = await appFetch("/api/self-hosted/" + path, body ? {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal,
    } : { signal });
  } catch (exc) {
    if (signal?.aborted) throw exc;
    throw new Error(t("无法连接工作室服务，请确认服务正在运行后重试"));
  }
  // A restarting service can answer without a usable response or JSON body.
  if (!response) throw new Error(t("无法连接工作室服务，请确认服务正在运行后重试"));
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : t("请求失败"));
  return data;
}

export function SelfHostedSettings() {
  const [settings, setSettings] = useState<any>(null);
  const [selectedMode, setSelectedMode] = useState<ExecutionMode | null>(null);
  // No preset server: the form shows only what the user configured.
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [ip, setIp] = useState("");
  const [error, setError] = useState("");
  const [loadError, setLoadError] = useState("");
  const [retry, setRetry] = useState(0);
  const [saving, setSaving] = useState(false);
  const initial = useRef(true);
  const submitting = useRef(false);
  const running = saving || settings?.deployment?.state === "running";

  useEffect(() => {
    let cancelled = false;
    async function refresh(signal: AbortSignal) {
      try {
        const data = await request("settings", undefined, signal);
        if (cancelled || signal.aborted) return;
        setSettings(data);
        setLoadError("");
        // Keep an unconfigured Self-hosted selection open while the user fills it in.
        setSelectedMode((current) => current ?? (data.mode === "self_hosted" ? "self_hosted" : "local"));
        if (initial.current && data.server) {
          setName(data.server.name || "");
          setUsername(data.server.username || "");
          setIp(data.server.ip || "");
        }
        initial.current = false;
      } catch (exc) {
        if (!cancelled) setLoadError(exc instanceof Error ? exc.message : t("无法读取服务器设置"));
      }
    }
    const stop = startPolling(refresh, 2000, () => {}, 10000);
    return () => { cancelled = true; stop(); };
  }, [retry]);

  async function update(path: string, body: object) {
    if (submitting.current) return false;
    submitting.current = true;
    setSaving(true); setError("");
    try {
      await request(path, body);
      setSettings(await request("settings"));
      return true;
    } catch (exc) {
      setError(exc instanceof Error ? exc.message : t("保存失败"));
      return false;
    }
    finally { submitting.current = false; setSaving(false); }
  }

  async function selectMode(mode: ExecutionMode) {
    if (running || submitting.current || !settings) return;
    setSelectedMode(mode);
    setError("");
    if (mode === settings.mode) return;
    // Provisioning enables the saved default only after the server is ready.
    if (mode === "self_hosted" && (!settings.server || settings.deployment?.state === "failed")) return;
    if (!await update("settings", { mode })) {
      setSelectedMode(settings.mode === "self_hosted" ? "self_hosted" : "local");
    }
  }

  if (settings?.edition === "cloud") return <section className="settings-panel self-hosted-settings" aria-labelledby="execution-settings-title">
    <div className="settings-panel-heading"><h3 id="execution-settings-title">{t("执行环境")}</h3></div>
    <p className="settings-section-description">{t("选择新建会话的工具执行方式，两种方式都在 Elsa 运行。")}</p>
    <div className="execution-options" role="group" aria-label={t("云端工具执行方式")}>
      <button type="button" aria-pressed={settings.mode === "colocated"} disabled={running}
        onClick={() => void update("settings", { mode: "colocated" })}><span>Custom Tool</span>
        {settings.mode === "colocated" && <Check size={16} />}</button>
      <button type="button" aria-pressed={settings.mode === "self_hosted"} disabled={running}
        onClick={() => void update("settings", { mode: "self_hosted" })}><span>Self-hosted</span>
        {settings.mode === "self_hosted" && <Check size={16} />}</button>
    </div>
    <p className="execution-selection"><Check size={16} /><span>{t("当前选择")}</span><strong>{settings.mode === "self_hosted" ? "Self-hosted" : "Custom Tool"} · {settings.server?.name || "Elsa"}</strong></p>
    <p className="execution-hint">{settings.mode === "self_hosted" ? t("Worker 通过方舟任务队列执行工具。") : t("推荐方式：云版后端直接处理工具请求。")} {t("切换仅影响新建会话，已有会话保持原来的方式。")}</p>
    {error && <p className="execution-error" role="alert">{error}</p>}
    {loadError && <p className="execution-error" role="alert">{loadError} <button type="button" onClick={() => setRetry((value) => value + 1)}>{t("重试")}</button></p>}
  </section>;

  return <section className="settings-panel self-hosted-settings" aria-labelledby="execution-settings-title">
    <div className="settings-panel-heading"><h3 id="execution-settings-title">{t("执行环境")}</h3></div>
    <p className="settings-section-description">{t("选择新建会话运行的位置。")}</p>
    <div className="execution-options" role="group" aria-label={t("新建会话的执行环境")}>
      <button type="button" aria-pressed={selectedMode === "local"} disabled={running || !settings}
        onClick={() => void selectMode("local")}><span>{t("本机 Mac")}</span>
        {selectedMode === "local" && <Check size={16} />}</button>
      <button type="button" aria-pressed={selectedMode === "self_hosted"} disabled={running || !settings}
        onClick={() => void selectMode("self_hosted")}><span>Self-hosted</span>
        {selectedMode === "self_hosted" && <Check size={16} />}</button>
    </div>
    <p className="execution-selection" role="status">
      {!settings ? (loadError ? t("执行环境读取失败") : t("正在读取执行环境…")) : <>
        <span>{t("当前选择")}</span>
        <strong>{selectedMode === "self_hosted"
          ? `Self-hosted${settings.mode === "self_hosted" && settings.server?.name ? ` · ${settings.server.name}` : ""}`
          : t("本机 Mac")}</strong>
        {saving ? <span className="execution-selection-pending">{t("保存中…")}</span>
          : selectedMode !== settings.mode && <span className="execution-selection-pending">
            {settings.deployment?.state === "running" ? t("配置中…") : t("待配置")}</span>}
      </>}
    </p>
    <p className="execution-hint">{selectedMode === "self_hosted" && settings?.mode !== "self_hosted"
      ? t("配置完成后生效，目前新建会话仍使用本机 Mac。")
      : t("仅影响新建会话，已有会话保持不变。")}</p>
    <div hidden={selectedMode !== "self_hosted"}>
    <form className="self-hosted-server-form" onSubmit={(event) => {
      event.preventDefault();
      void update("deploy", { name: name.trim(), username: username.trim(), ip: ip.trim() });
    }}>
      <h4>{t("Self-hosted 服务器")}</h4>
      <div className="self-hosted-server-fields">
      <label className="server-name-field">{t("服务器名称")}<input value={name} maxLength={80} required disabled={running}
        onChange={(e) => setName(e.target.value)} placeholder={t("便于识别的名称，如 渲染服务器")} /></label>
      <label>{t("登录账号名称")}<input value={username} maxLength={64} required disabled={running}
        onChange={(e) => setUsername(e.target.value)} placeholder={t("SSH 登录用户名")} autoCapitalize="none" spellCheck={false} /></label>
      <label>{t("IP 地址")}<input value={ip} required disabled={running} autoCapitalize="none" spellCheck={false}
        onChange={(e) => setIp(e.target.value)} placeholder={t("服务器 IP 地址")} /></label>
      </div>
      <p className="execution-hint">{t("支持 Debian 12，使用本机 SSH 登录。首次配置自动安装 Blender、Worker 和远程桌面。")}</p>
      <div className="execution-actions">
        <button type="submit" className="primary" disabled={running || !settings || !name.trim() || !username.trim() || !ip.trim()}>
          {running && <LoaderCircle size={15} className="spin" />}
          {running ? t("配置中…") : t("检查并配置服务器")}</button>
        {settings?.server && <button type="button" disabled={running || !name.trim()}
          onClick={() => void update("settings", { name: name.trim() })}>{t("保存名称")}</button>}
      </div>
    </form>
    {settings?.deployment?.message && <p role="status" className={`execution-deployment-status ${settings.deployment.state === "failed" ? "inline-error" : "execution-hint"}`}>
      {settings.deployment.message}</p>}
    </div>
    {error && <p role="alert" className="inline-error">{error}</p>}
    {loadError && <p role="alert" className="inline-error">{loadError} <button type="button" onClick={() => setRetry((value) => value + 1)}>{t("重试")}</button></p>}
  </section>;
}
