import { appFetch, appUrl } from "../appUrl";
import { useEffect, useState } from "react";
import { ExternalLink } from "../icons";
import { ServerResources } from "./Resources";
import { t } from "../i18n";
import "./styles.css";

export type ExecutionInfo = { mode: "local" | "self_hosted" | "colocated"; server_name?: string };

export function ExecutionBadge({ info }: { info?: ExecutionInfo }) {
  return info && info.mode !== "local" ? <span className="execution-badge">{info.mode === "self_hosted" ? "Self-hosted" : "Custom Tool"} · {info.server_name}</span> : null;
}

export function RemoteDesktop({ projectId, info }: { projectId: string; info?: ExecutionInfo }) {
  const [desktop, setDesktop] = useState<{ url: string } | null>(null);
  const [error, setError] = useState("");
  const [open, setOpen] = useState(true);
  const [loading, setLoading] = useState(false);
  // The executor closes a project's desktop (after saving) when nobody uses it.
  const [sleeping, setSleeping] = useState(false);
  const prefix = appUrl("/api/self-hosted/desktop/" + encodeURIComponent(projectId) + "/");
  const desktopUrl = prefix + "index.html?" + new URLSearchParams({ autoconnect: "1", path: prefix.slice(1) + "websockify",
    kasmvnc_mode_preference: "image", resize: "scale", enable_threading: "0", reconnect: "1", reconnect_delay: "3000" });
  useEffect(() => {
    const controller = new AbortController();
    setOpen(true); setDesktop(null); setError(""); setSleeping(false);
    if (info && info.mode !== "local") void connect(controller.signal);
    return () => controller.abort();
  }, [projectId, info?.mode]);
  useEffect(() => {
    if (!desktop) return;
    const timer = setInterval(async () => {
      try {
        const response = await appFetch("/api/self-hosted/desktop-state?project_id=" + encodeURIComponent(projectId));
        const state = await response.json();
        if (response.ok && state.isolated && !state.running) { setDesktop(null); setSleeping(true); }
      } catch { /* The next poll retries; the desktop view stays as it is. */ }
    }, 30000);
    return () => clearInterval(timer);
  }, [desktop, projectId]);
  async function connect(signal?: AbortSignal) {
    setLoading(true); setError(""); setSleeping(false);
    try {
      const response = await appFetch("/api/self-hosted/desktop?project_id=" + encodeURIComponent(projectId), { signal });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || t("远程桌面连接失败"));
      if (!signal?.aborted) setDesktop(data);
    } catch (exc) { if (!signal?.aborted) setError(exc instanceof Error ? exc.message : t("远程桌面连接失败")); }
    finally { if (!signal?.aborted) setLoading(false); }
  }
  if (!info || info.mode === "local") return null;
  return <section className="remote-desktop">
    <div className="preview-toolbar"><h3 className="preview-section-title">{t("远程桌面")} <span className="remote-desktop-server">· {info.server_name}</span></h3>
      <div className="remote-desktop-actions">
      <a className="remote-desktop-link" href={desktopUrl} target="_blank" rel="noopener noreferrer"
        aria-label={t("在新标签页打开远程桌面")}><ExternalLink size={14} />{t("新窗口打开")}</a>
      <button type="button" onClick={() => setOpen(!open)}>
        {open ? t("收起") : t("展开")}</button></div></div>
    {open && <div className="remote-desktop-body">
      {loading && <div className="remote-desktop-placeholder" role="status">{t("正在启动项目桌面…")}</div>}
      {desktop && <iframe src={desktop.url} title={t("{server} 远程桌面", { server: info.server_name || "" })} allow="clipboard-read; clipboard-write; fullscreen" />}
      {sleeping && <div className="remote-desktop-placeholder remote-desktop-sleeping" role="status">
        <span>{t("桌面长时间无操作，已自动保存工程并关闭，释放服务器资源。")}</span>
        <button type="button" onClick={() => void connect()}>{t("重新打开桌面")}</button>
      </div>}
      {error && <p role="alert" className="inline-error">{error} <button type="button" onClick={() => void connect()}>{t("重试")}</button></p>}
    </div>}
    <ServerResources projectId={projectId} />
  </section>;
}
