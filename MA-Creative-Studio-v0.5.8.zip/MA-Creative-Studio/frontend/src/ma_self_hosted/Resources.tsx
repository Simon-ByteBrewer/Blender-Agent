import { appFetch } from "../appUrl";
import { useEffect, useState } from "react";
import { getLanguage, t } from "../i18n";

const locale = () => getLanguage() === "zh" ? "zh-CN" : "en-US";

type Usage = { total_bytes: number; used_bytes: number; available_bytes: number; usage_percent: number };
type GPU = { id: string; name: string; usage_percent: number | null; memory_total_bytes: number | null; memory_used_bytes: number | null };
type Resources = {
  sampled_at: number;
  cpu: { usage_percent: number | null; logical_cpus: number; model: string };
  memory: Usage;
  disk: Usage;
  gpus: GPU[];
};

function bytes(value: number) {
  const unit = value >= 1024 ** 4 ? "TiB" : "GiB";
  const size = value / (unit === "TiB" ? 1024 ** 4 : 1024 ** 3);
  return `${size.toLocaleString(locale(), { maximumFractionDigits: 1 })} ${unit}`;
}

function capacity(used: number, total: number) {
  const unit = total >= 1024 ** 4 ? "TiB" : "GiB";
  const divisor = unit === "TiB" ? 1024 ** 4 : 1024 ** 3;
  const format = (value: number) => (value / divisor).toLocaleString(locale(), { maximumFractionDigits: unit === "TiB" ? 2 : 1 });
  return `${format(used)} / ${format(total)} ${unit}`;
}

export function ServerResources({ projectId }: { projectId: string }) {
  const [resources, setResources] = useState<Resources | null>(null);
  const [error, setError] = useState(false);
  useEffect(() => {
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout>;
    setResources(null); setError(false);
    async function refresh() {
      try {
        const response = await appFetch("/api/self-hosted/resources?project_id=" + encodeURIComponent(projectId), { signal: controller.signal });
        if (!response.ok) throw new Error("Resource information unavailable");
        const data: Resources = await response.json();
        if (!controller.signal.aborted) { setResources(data); setError(false); }
      } catch {
        if (!controller.signal.aborted) setError(true);
      } finally {
        if (!controller.signal.aborted) timer = setTimeout(refresh, 30000);
      }
    }
    void refresh();
    return () => { controller.abort(); clearTimeout(timer); };
  }, [projectId]);
  if (!resources) return <div className="server-resources server-resource-message" role="status">
    {error ? t("服务器状态暂不可用") : t("读取服务器状态…")}
  </div>;
  const { cpu, memory, disk, gpus } = resources;
  return <div className={"server-resources" + (error ? " is-stale" : "")} aria-label={t("服务器资源使用情况，每 30 秒更新")}>
    <span className="server-resource-item" title={t("{model} · {count} 逻辑核", { model: cpu.model, count: cpu.logical_cpus })}>
      <span>CPU</span><b>{cpu.usage_percent == null ? "—" : `${cpu.usage_percent.toFixed(1)}%`}</b><span> / {cpu.logical_cpus} vCPU</span>
    </span>
    <span className="server-resource-item" title={t("已用 {used}% · 可用 {available}", { used: memory.usage_percent, available: bytes(memory.available_bytes) })}>
      <span>{t("内存")}</span><b>{capacity(memory.used_bytes, memory.total_bytes)}</b>
    </span>
    <span className="server-resource-item" title={t("项目所在磁盘 · 已用 {used}% · 可用 {available}", { used: disk.usage_percent, available: bytes(disk.available_bytes) })}>
      <span>{t("磁盘")}</span><b>{capacity(disk.used_bytes, disk.total_bytes)}</b>
    </span>
    {gpus.map((gpu, index) => <span key={gpu.id} className="server-resource-item" title={gpu.name + (
      gpu.memory_total_bytes != null && gpu.memory_used_bytes != null
        ? t(" · 显存 {usage}", { usage: capacity(gpu.memory_used_bytes, gpu.memory_total_bytes) }) : t(" · 显存监测不可用"))}>
      <span>{gpus.length > 1 ? `GPU ${index + 1}` : "GPU"}</span><b>{gpu.usage_percent == null ? "—" : `${gpu.usage_percent.toFixed(1)}%`}</b><span>{gpu.name}</span>
    </span>)}
    {gpus.length === 0 && <span className="server-resource-item"><span>GPU</span><b>{t("未检测到")}</b></span>}
    {error && <span className="server-resource-message" role="status">{t("更新暂停")}</span>}
  </div>;
}
