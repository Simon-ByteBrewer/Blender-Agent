import { useCallback, useImperativeHandle, useLayoutEffect, useRef, useState, type Ref, type SetStateAction } from "react";
import { t } from "./i18n";

export type ComposerInputHandle = {
  getText: () => string;
  setText: (value: SetStateAction<string>) => void;
  focus: () => void;
};

// Keep keystrokes local: the workspace only needs to know whether a draft exists.
export function ComposerInput({ ref, placeholder, canSend, enterToSend = true, onHasTextChange }: {
  ref: Ref<ComposerInputHandle>;
  placeholder: string;
  canSend: boolean;
  enterToSend?: boolean;
  onHasTextChange: (hasText: boolean) => void;
}) {
  const [text, setText] = useState("");
  const draft = useRef("");
  const input = useRef<HTMLTextAreaElement>(null);
  const updateText = useCallback((value: SetStateAction<string>) => {
    const next = typeof value === "function" ? value(draft.current) : value;
    const hadText = !!draft.current.trim();
    draft.current = next;
    setText(next);
    if (hadText !== !!next.trim()) onHasTextChange(!!next.trim());
  }, [onHasTextChange]);

  useImperativeHandle(ref, () => ({
    getText: () => draft.current,
    setText: updateText,
    focus: () => input.current?.focus(),
  }), [updateText]);

  const resize = useCallback(() => {
    const element = input.current;
    if (!element) return;
    const maxHeight = parseFloat(getComputedStyle(element).maxHeight) || Infinity;
    element.style.height = "0px";
    element.style.height = `${Math.min(element.scrollHeight, maxHeight)}px`;
  }, []);
  useLayoutEffect(resize, [text, resize]);
  useLayoutEffect(() => {
    const element = input.current;
    if (!element) return;
    let width = element.clientWidth;
    const observer = new ResizeObserver(() => {
      if (element.clientWidth !== width) {
        width = element.clientWidth;
        resize();
      }
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, [resize]);

  return <textarea ref={input} rows={2} wrap="soft" aria-label={t("创作提示词")}
    placeholder={placeholder} value={text} onChange={(event) => updateText(event.target.value)}
    onKeyDown={(event) => {
      if (enterToSend && event.key === "Enter" && !event.shiftKey &&
        !event.nativeEvent.isComposing && event.nativeEvent.keyCode !== 229) {
        event.preventDefault();
        if (canSend) event.currentTarget.form?.requestSubmit();
      }
    }} />;
}
