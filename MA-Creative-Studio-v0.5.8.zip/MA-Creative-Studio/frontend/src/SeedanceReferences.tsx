import { useEffect, useRef, useState } from "react";
import { appFetch, appUrl } from "./appUrl";
import { Audio, FileVideo, Image, LinkIcon, Person, Plus, Trash, Upload, X } from "./icons";
import {
  addReference, isLocalSource, referenceLabels, remoteSourceError, sourceType,
  type Portrait, type SeedRef, type SeedRefType,
} from "./seedance";
import { t } from "./i18n";

type ProjectFile = { name: string; url: string };
type Panel = "" | "project" | "url" | "portraits";

const uploadTypes = /\.(png|jpe?g|webp|mp4|mov|mp3|wav)$/i;
const OFFICIAL_LIBRARY = "https://ark.volcengine.com/region:cn-beijing/experience/vision?modelId=doubao-seedance-2-5-260628&tab=GenVideo";
type PlatformInfo = { family?: string; portrait_library_url?: string };

async function request(path: string, init?: RequestInit) {
  const response = await appFetch("/api" + path, init);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : t("请求失败，请重试。"));
  return data;
}

/** Ordered Seedance references: project files, uploads, web addresses and portrait-library assets. */
export function SeedanceReferences({ pid, refs, onChange, projectFiles, uploadAvailable, disabled, platform }: {
  pid: string; refs: SeedRef[]; onChange: (refs: SeedRef[]) => void;
  projectFiles: ProjectFile[]; uploadAvailable: boolean; disabled?: boolean; platform?: PlatformInfo;
}) {
  const byteplus = platform?.family === "byteplus";
  const library = platform?.portrait_library_url || OFFICIAL_LIBRARY;
  const [panel, setPanel] = useState<Panel>("");
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);
  const [url, setUrl] = useState("");
  const [urlType, setUrlType] = useState<SeedRefType>("image");
  const [portraits, setPortraits] = useState<Portrait[]>([]);
  const [draft, setDraft] = useState({ name: "", asset_id: "", kind: "image" as Portrait["kind"] });
  const fileInput = useRef<HTMLInputElement>(null);
  const labels = referenceLabels(refs);

  useEffect(() => {
    if (panel !== "portraits") return;
    request("/seedance/portraits").then(setPortraits).catch((e) => setError(e.message));
  }, [panel]);

  function add(ref: Omit<SeedRef, "key">) {
    try {
      onChange(addReference(refs, { ...ref, key: `${ref.type}:${ref.source}` }));
      setError("");
      return true;
    } catch (e) {
      setError((e as Error).message);
      return false;
    }
  }

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setUploading(true);
    setError("");
    let next = refs;
    try {
      for (const file of Array.from(files)) {
        const type = sourceType(file.name);
        if (!type || !uploadTypes.test(file.name)) throw new Error(t("支持 PNG、JPG、WEBP 图片、MP4、MOV 视频和 MP3、WAV 音频。"));
        const limit = type === "video" ? 200 : type === "audio" ? 15 : 30;
        if (file.size > limit * 1024 * 1024) throw new Error(t("{name} 超过 {limit} MB。", { name: file.name, limit }));
        const form = new FormData();
        form.append("file", file);
        const saved = await request("/upload?project_id=" + encodeURIComponent(pid), { method: "POST", body: form });
        next = addReference(next, { key: `${type}:${saved.name}`, type, source: saved.name, name: file.name,
          origin: "upload", preview: saved.url });
        onChange(next);
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setUploading(false);
      if (fileInput.current) fileInput.current.value = "";
    }
  }

  function addUrl() {
    const source = url.trim();
    const message = remoteSourceError(source, urlType);
    if (message) return setError(message);
    if (add({ type: urlType, source, name: source.startsWith("asset://") ? source.slice(8) : source,
      origin: "url", preview: urlType === "image" && source.startsWith("https://") ? source : undefined })) setUrl("");
  }

  async function savePortrait() {
    try {
      const item = await request("/seedance/portraits", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(draft),
      });
      setPortraits((current) => [...current, item]);
      setDraft({ name: "", asset_id: "", kind: draft.kind });
      setError("");
    } catch (e) {
      setError((e as Error).message);
    }
  }

  async function removePortrait(item: Portrait) {
    try {
      await request("/seedance/portraits/" + item.id, { method: "DELETE" });
      setPortraits((current) => current.filter((p) => p.id !== item.id));
    } catch (e) {
      setError((e as Error).message);
    }
  }

  const toggle = (next: Panel) => { setPanel(panel === next ? "" : next); setError(""); };
  const localVideo = refs.some((ref) => ref.type === "video" && isLocalSource(ref.source));
  return <section className="seed-references" aria-label={t("参考素材")}>
    <div className="seed-references-head">
      <span>{t("参考素材")}</span>
      <small>{t("用「图片1」「视频1」「音频1」引用；最多 30 张图、10 个视频、10 个音频，视频和音频各合计 ≤ 30 秒")}</small>
    </div>
    {refs.length ? <ul className="seed-reference-list">
      {refs.map((ref, index) => <li key={ref.key}>
        <span className="seed-reference-thumb">
          {ref.type === "image" && ref.preview ? <img src={appUrl(ref.preview)} alt="" />
            : ref.origin === "portrait" ? <Person size={18} /> : ref.type === "image" ? <Image size={18} /> : ref.type === "audio" ? <Audio size={18} /> : <FileVideo size={18} />}
        </span>
        <span className="seed-reference-text">
          <strong>{labels[index]}</strong>
          <span title={ref.source}>{ref.name}</span>
          <small>{t({ project: "项目文件", upload: "已上传", url: ref.source.startsWith("asset://") ? "素材 ID" : "网络地址", portrait: "人像库" }[ref.origin])}</small>
        </span>
        <button type="button" className="icon-button" aria-label={t("移除{label}", { label: labels[index] })} disabled={disabled}
          onClick={() => onChange(refs.filter((item) => item.key !== ref.key))}><X size={14} /></button>
      </li>)}
    </ul> : <p className="seed-reference-empty">{t("未添加参考素材，将仅根据提示词生成（文生视频）。")}</p>}
    <div className="seed-reference-actions">
      <button type="button" className="outline" disabled={disabled} aria-pressed={panel === "project"} onClick={() => toggle("project")}><FileVideo size={14} />{t("项目文件")}</button>
      <button type="button" className="outline" disabled={disabled || uploading} onClick={() => fileInput.current?.click()}><Upload size={14} />{uploading ? t("上传中…") : t("上传素材")}</button>
      <button type="button" className="outline" disabled={disabled} aria-pressed={panel === "url"} onClick={() => toggle("url")}><LinkIcon size={14} />{t("网络地址")}</button>
      <button type="button" className="outline" disabled={disabled} aria-pressed={panel === "portraits"} onClick={() => toggle("portraits")}><Person size={14} />{t("人像库")}</button>
      <input ref={fileInput} type="file" hidden multiple accept=".png,.jpg,.jpeg,.webp,.mp4,.mov,.mp3,.wav,image/png,image/jpeg,image/webp,video/mp4,video/quicktime,audio/mpeg,audio/wav"
        onChange={(e) => void upload(e.target.files)} />
    </div>
    {panel === "project" && <div className="seed-reference-panel">
      {projectFiles.length ? projectFiles.map((file) => {
        const type = sourceType(file.name)!;
        const added = refs.some((ref) => ref.source === file.name);
        return <button type="button" key={file.name} className="seed-pick" disabled={added}
          onClick={() => add({ type, source: file.name, name: file.name, origin: "project", preview: type === "image" ? file.url : undefined })}>
          {type === "image" ? <Image size={14} /> : type === "audio" ? <Audio size={14} /> : <FileVideo size={14} />}<span>{file.name}</span>{added ? <small>{t("已添加")}</small> : <Plus size={14} />}
        </button>;
      }) : <p className="muted">{t("当前项目还没有图片或视频。")}</p>}
    </div>}
    {panel === "url" && <div className="seed-reference-panel seed-url-form">
      <select aria-label={t("网络素材类型")} value={urlType} onChange={(e) => setUrlType(e.target.value as SeedRefType)}>
        <option value="image">{t("图片")}</option><option value="video">{t("视频")}</option><option value="audio">{t("音频")}</option>
      </select>
      <input aria-label={t("素材地址")} placeholder={t("https://… 或 asset://asset-…")} value={url}
        onChange={(e) => { setUrl(e.target.value); const detected = sourceType(e.target.value); if (detected) setUrlType(detected); }}
        onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addUrl(); } }} />
      <button type="button" className="primary" disabled={!url.trim()} onClick={addUrl}>{t("添加")}</button>
    </div>}
    {panel === "portraits" && <div className="seed-reference-panel">
      <p className="muted">{byteplus
        ? t("BytePlus 预置数字人像没有开放检索接口，需在 BytePlus 文档的「预置数字人像」列表中挑选：复制素材 ID，粘贴到下方保存，即可在任意项目中以 asset:// 传给 Seedance。已授权的真人人像素材同样适用。")
        : t("官方虚拟人像库没有开放检索接口，需在方舟体验中心挑选：打开「虚拟人像库」，选中人像后复制素材 ID（或模板代码），粘贴到下方保存，即可在任意项目中以 asset:// 传给 Seedance。已授权的真人人像素材同样适用。")}</p>
      <p className="seed-portrait-link">{t("官方人像库：")}<a href={library} target="_blank" rel="noreferrer">{byteplus
        ? t("docs.byteplus.com → 预置数字人像") : t("ark.volcengine.com 体验中心 → 虚拟人像库")}</a></p>
      {portraits.map((item) => {
        const source = "asset://" + item.asset_id;
        const added = refs.some((ref) => ref.source === source);
        return <div className="seed-portrait" key={item.id}>
          <Person size={16} />
          <span><strong>{item.name}</strong><small>{item.kind === "image" ? t("图片") : t("视频")} · {item.asset_id}</small></span>
          <button type="button" className="outline" disabled={added || disabled}
            onClick={() => add({ type: item.kind, source, name: item.name, origin: "portrait" })}>{added ? t("已添加") : t("添加")}</button>
          <button type="button" className="icon-button" aria-label={t("从人像库删除 {name}", { name: item.name })} onClick={() => void removePortrait(item)}><Trash size={14} /></button>
        </div>;
      })}
      <div className="seed-portrait-form">
        <input aria-label={t("人像名称")} placeholder={t("名称，如：短发女主播")} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
        <input aria-label={t("人像素材 ID")} placeholder={t("粘贴素材 ID、asset:// URI 或控制台代码")} value={draft.asset_id} onChange={(e) => setDraft({ ...draft, asset_id: e.target.value })} />
        <select aria-label={t("人像素材类型")} value={draft.kind} onChange={(e) => setDraft({ ...draft, kind: e.target.value as Portrait["kind"] })}>
          <option value="image">{t("图片")}</option><option value="video">{t("视频")}</option>
        </select>
        <button type="button" className="primary" disabled={!draft.name.trim() || !draft.asset_id.trim()} onClick={() => void savePortrait()}>{t("保存到人像库")}</button>
      </div>
    </div>}
    {localVideo && !uploadAvailable && <p className="inline-error" role="alert">
      {t("先运行 MA 场景创作，即可通过当前 Session 自动上传本地视频，只需现有 API Key。")}
    </p>}
    {error && <p className="inline-error" role="alert">{t(error)}</p>}
  </section>;
}
