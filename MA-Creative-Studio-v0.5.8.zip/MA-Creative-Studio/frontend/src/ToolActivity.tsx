import { useEffect, useState } from "react";
import { agentPhase } from "./chatState";
import { LoaderCircle } from "./icons";
import { t } from "./i18n";
import { formatElapsed, latestToolActivity, type ActivityEvent, type ActivityJob, type ToolStatus, type ToolTelemetry } from "./toolActivityState";
import "./ToolActivity.css";

const statusIcons: Record<ToolStatus, string> = {
  queued: "clock", executing: "terminal", returning: "cloud-upload", sent: "check-all",
  failed: "error", confirmation: "question", waiting: "clock", unknown: "question",
};

export function ToolActivity({ events, jobs, sessionId, telemetry, launching = false }: {
  events: ActivityEvent[]; jobs: ActivityJob[]; sessionId?: string; telemetry?: ToolTelemetry; launching?: boolean;
}) {
  const [now, setNow] = useState(Date.now);
  const running = jobs.some((job) => ["running", "queued"].includes(job.status));
  const observing = running || telemetry?.worker_active === true;
  useEffect(() => {
    setNow(Date.now());
    if (!observing) return;
    // Expire stale execution telemetry even if the backend stops responding.
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [observing]);
  const tool = latestToolActivity(events, jobs, sessionId, telemetry, Math.max(now, Date.now()));
  const seconds = tool?.requestedAt ? Math.max(0, Math.floor((now - tool.requestedAt) / 1000)) : null;
  const elapsed = seconds === null ? t("耗时待同步") : formatElapsed(seconds);
  const phase = agentPhase(events, jobs);
  let label = "等待 Agent 更新…", icon = "clock", status = "waiting";
  if (launching) { label = "正在启动 Blender 并连接 MCP…"; icon = "sync"; status = "executing"; }
  else if (tool) { label = tool.label; icon = statusIcons[tool.status]; status = tool.status; }
  else if (phase === "replying") { label = "正在回复…"; icon = "comment-discussion"; status = "replying"; }
  else if (phase === "thinking") { label = "思考中…"; icon = "sparkle"; status = "thinking"; }
  else if (jobs.some((job) => job.kind === "render" && job.status === "running")) {
    label = "正在渲染…"; icon = "device-camera-video"; status = "returning";
  }
  if (!observing && !launching) return null;
  return <div className="tool-activity" role="status" aria-live="polite">
    <span aria-hidden="true" data-status={status}
      className={`activity-icon codicon codicon-${icon}`} />
    <span className="activity-text">{t(label)}{tool && !launching && <>: <code>{tool.name}</code>{" "}
      <span className="activity-elapsed" title={t("从工具发起至今的累计耗时，包含等待、执行和回传")}>{elapsed}</span>
    </>}</span>
    <LoaderCircle size={15} className="spin activity-loading" />
  </div>;
}
