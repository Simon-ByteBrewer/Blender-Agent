export type MaModel = {
  id: string; name: string; model_id?: string; byok?: boolean; provider?: string; contextWindow?: number; thinking?: string;
  reasoning_effort_options?: string[]; reasoning_effort_default?: string;
};

// Display compatibility only: never rewrite the ID sent to the backend.
export function displayModelId(id: string) {
  return id === "doubao-seed-evolving-latest-version" ? "doubao-seed-evolving" : id;
}

export function formatContextWindow(tokens: number) {
  if (!Number.isFinite(tokens) || tokens <= 0) return "";
  // Catalogs use both decimal and binary token budgets; keep conventional labels.
  const millions = tokens / (tokens % (1024 * 1024) === 0 ? 1024 * 1024 : 1_000_000);
  if (tokens >= 1_000_000) return `${Number(millions.toFixed(1))}M`;
  return `${Math.round(tokens / (tokens % 1000 !== 0 && tokens % 1024 === 0 ? 1024 : 1000))}K`;
}

export function modelOptions(models: MaModel[], selected: string, locked: boolean) {
  const sorted = [...models].sort((a, b) => Number(b.id.startsWith("doubao-")) - Number(a.id.startsWith("doubao-")));
  const current = sorted.find((m) => displayModelId(m.id) === displayModelId(selected));
  return { current, options: current || !selected || !locked ? sorted : [{ id: selected, name: selected }, ...sorted] };
}
