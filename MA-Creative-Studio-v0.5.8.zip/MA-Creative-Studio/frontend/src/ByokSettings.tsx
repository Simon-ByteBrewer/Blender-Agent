import { useEffect, useRef, useState } from "react";
import { appFetch } from "./appUrl";
import { Check, ChevronRight, LoaderCircle, Plus, X } from "./icons";
import { formatContextWindow } from "./modelPresentation";
import ModelLogo from "./ModelLogo";
import { ByokTransfer } from "./ByokTransfer";
import { t } from "./i18n";
import "./ByokSettings.css";

type Model = { id: string; provider: string; base_url: string; protocol: string;
  token_limits: { context_window: number; max_input_token_length: number; max_output_token_length: number } };
export type Profile = { id: string; name: string; model: Model;
  api_key_configured: boolean; api_key_masked: string };
// A new model starts empty: every value comes from the user's own provider.
const blank: Model = { id: "", provider: "", base_url: "", protocol: "",
  token_limits: { context_window: 0, max_input_token_length: 0, max_output_token_length: 0 } };
const protocols: Record<string, string> = { openai_responses: "OpenAI Responses",
  openai_chat_completions: "OpenAI Chat Completions", anthropic_messages: "Anthropic Messages" };
const limits = [['context_window', '上下文窗口'], ['max_input_token_length', '最大输入 Token'], ['max_output_token_length', '最大输出 Token']] as const;

export function ByokSettings({ onChanged }: { onChanged?: () => void | Promise<void> }) {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [editing, setEditing] = useState<Profile | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [name, setName] = useState("");
  const [model, setModel] = useState<Model>(blank);
  const [apiKey, setApiKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const submitting = useRef(false);

  async function request(path: string, method = "GET", body?: unknown) {
    const response = await appFetch(`/api/settings/byok${path}`, { method,
      headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
    const data = await response.json();
    if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : t("操作失败，请重试"));
    return data;
  }
  useEffect(() => {
    let active = true;
    void request("").then(data => {
      if (active) { setProfiles(data.models); setFormOpen(data.models.length === 0); }
    }).catch(e => { if (active) setError(e.message); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);
  function edit(profile: Profile | null) {
    setEditing(profile); setName(profile?.name || ""); setModel(profile?.model || blank);
    setFormOpen(true); setApiKey(""); setError(""); setSuccess(""); setConfirmDelete(null);
  }
  function closeForm() { setFormOpen(false); setEditing(null); setApiKey(""); setError(""); }
  async function notifyChanged() {
    // A stale parent after hot reload may not supply this optional notification.
    // Workspace polling also refreshes the catalog; a refresh failure must not
    // misreport an already successful save/delete as a persistence failure.
    if (typeof onChanged !== "function") return;
    try { await onChanged(); }
    catch { /* The regular workspace poll will retry the refresh. */ }
  }
  async function save() {
    if (submitting.current) return;
    submitting.current = true; setBusy(true); setError(""); setSuccess("");
    try {
      const result: Profile = await request(editing ? `/${editing.id}` : "", editing ? "PUT" : "POST",
        { name: name.trim(), model, api_key: apiKey.trim() });
      setProfiles(previous => editing ? previous.map(p => p.id === result.id ? result : p) : [...previous, result]);
      closeForm(); setSuccess(t("已保存，可在新会话的模型菜单中选择。")); void notifyChanged();
    } catch (e) { setError(e instanceof Error ? e.message : t("保存失败")); }
    finally { submitting.current = false; setBusy(false); }
  }
  async function remove(profile: Profile) {
    if (submitting.current) return;
    submitting.current = true; setBusy(true); setError(""); setSuccess("");
    try {
      await request(`/${profile.id}`, "DELETE");
      setProfiles(previous => previous.filter(p => p.id !== profile.id));
      if (editing?.id === profile.id) closeForm();
      setConfirmDelete(null); setSuccess(t("模型已移除。")); void notifyChanged();
    } catch (e) { setError(e instanceof Error ? e.message : t("移除失败")); }
    finally { submitting.current = false; setBusy(false); }
  }
  return <section className="settings-panel byok-settings" aria-labelledby="byok-title">
    <div className="settings-panel-heading"><h3 id="byok-title">{t("自定义模型 BYOK")}</h3>
      <button type="button" className="byok-add" disabled={busy || loading} onClick={() => edit(null)}><Plus size={14} />{t("添加模型")}</button>
    </div>
    <p className="settings-section-description">{t("使用自己的模型 API Key。仍需配置 MA API Key，以使用 Managed Agent 和创作工具。")}</p>
    <ByokTransfer disabled={busy || loading} count={profiles.length} onBusy={setBusy} onImported={result => {
      setProfiles(result.models); closeForm(); setSuccess(""); setConfirmDelete(null); void notifyChanged();
    }} />
    {loading ? <p role="status">{t("正在读取模型配置…")}</p> : <>
      {profiles.length > 0 && <div className="byok-profiles" aria-label={t("已配置的模型")}>
        {profiles.map(p => <div className={`byok-profile${formOpen && editing?.id === p.id ? " is-editing" : ""}`} key={p.id}>
          <button className="byok-profile-main" type="button" disabled={busy} aria-label={t("编辑 {name}", { name: p.name })}
            aria-expanded={formOpen && editing?.id === p.id} onClick={() => edit(p)}>
            <span className="byok-profile-icon"><ModelLogo modelId={p.model.id} size={20} /></span>
            <span className="byok-profile-info"><strong>{p.name}</strong><small>{p.model.id} · {p.model.provider}</small></span>
            <span className="byok-profile-status">{p.api_key_configured ? <><Check size={12} />{t("已配置")}</> : t("待配置")}</span>
            <ChevronRight size={14} />
          </button>
          <button className="byok-remove" type="button" disabled={busy} aria-label={t("移除 {name}", { name: p.name })} onClick={() => setConfirmDelete(p.id)}><X size={14} /></button>
          {confirmDelete === p.id && <div className="byok-delete-confirm">
            <p>{t("移除后，使用此配置的旧会话将无法继续调用模型。")}</p>
            <button type="button" disabled={busy} onClick={() => void remove(p)}>{t("确认移除")}</button>
            <button type="button" disabled={busy} onClick={() => setConfirmDelete(null)}>{t("取消")}</button>
          </div>}
        </div>)}
      </div>}
      {!profiles.length && !formOpen && <p className="byok-empty">{t("暂无自定义模型，点击「添加模型」开始配置。")}</p>}
    </>}
    {formOpen && !loading && <form className="byok-editor" onSubmit={e => { e.preventDefault(); void save(); }}>
      <div className="byok-editor-heading"><h4>{editing ? t("编辑模型") : t("添加模型")}</h4>
        <button type="button" disabled={busy} onClick={closeForm} aria-label={t("收起模型编辑")}><X size={15} /></button>
      </div>
      <fieldset disabled={busy}>
        <label>{t("显示名称")}<input required maxLength={100} placeholder={t("在模型菜单中显示的名称")} value={name} onChange={e => setName(e.target.value)} /></label>
        {!editing && <>
          <div className="byok-field-grid">
            <label>{t("模型 ID")}<input required placeholder={t("服务商提供的模型 ID")} value={model.id} onChange={e => setModel({ ...model, id: e.target.value })} /></label>
            <label>Provider<input required placeholder={t("如 openai、anthropic")} value={model.provider} onChange={e => setModel({ ...model, provider: e.target.value })} /></label>
          </div>
          <label>{t("模型接口地址")}<input required type="url" placeholder={t("完整 HTTPS 地址，如 https://…/v1/responses")} value={model.base_url} onChange={e => setModel({ ...model, base_url: e.target.value })} /></label>
          <label>{t("API 协议")}<select required value={model.protocol} onChange={e => setModel({ ...model, protocol: e.target.value })}>
            <option value="" disabled>{t("请选择")}</option>
            {Object.entries(protocols).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select></label>
        </>}
        <label>{t("模型 API Key")}<input type="password" required={!editing} autoComplete="new-password" spellCheck={false} maxLength={4096}
          placeholder={editing ? t("输入新 Key 可替换，留空保留原 Key") : t("请输入模型 API Key")} value={apiKey} onChange={e => setApiKey(e.target.value)} /></label>
        {editing && <p className="byok-key-hint">{t("当前 Key")} <code>{editing.api_key_masked}</code></p>}
        <details className="byok-details" key={editing?.id || "new"} onInvalidCapture={e => { e.currentTarget.open = true; }}>
          <summary><span>{editing ? t("模型连接信息") : t("Token 上限")}</span>
            <small>{editing ? protocols[model.protocol] : model.token_limits.context_window
              ? t("{size} 上下文", { size: formatContextWindow(model.token_limits.context_window) }) : t("必填")}</small><ChevronRight size={13} />
          </summary>
          {editing ? <>
            <dl className="byok-connection-info">
              <div><dt>{t("模型 ID")}</dt><dd>{model.id}</dd></div><div><dt>Provider</dt><dd>{model.provider}</dd></div>
              <div className="byok-endpoint"><dt>{t("接口地址")}</dt><dd>{model.base_url}</dd></div>
              {limits.map(([key, label]) => <div key={key}><dt>{t(label)}</dt><dd>{model.token_limits[key].toLocaleString()}</dd></div>)}
            </dl>
            <p className="byok-detail-hint">{t("更换模型或接口请添加新配置，旧会话保持原模型。")}</p>
          </> : <>
            <div className="byok-token-grid">
              {limits.map(([key, label]) => <label key={key}>{t(label)}<input required type="number" min={1} step={1} value={model.token_limits[key] || ""}
                onChange={e => setModel({ ...model, token_limits: { ...model.token_limits, [key]: Number(e.target.value) } })} /></label>)}
            </div>
            <p className="byok-detail-hint">{t("按所选模型服务商公布的上限填写。")}</p>
          </>}
        </details>
        <div className="byok-form-footer"><span>{t("密钥仅保存在本机，保存后不回显。")}</span>
          <button className="primary" disabled={!name.trim() || (!editing && (!apiKey.trim() || !model.protocol))}>
            {busy && <LoaderCircle size={14} className="spin" />}{busy ? t("保存中…") : t("保存模型")}
          </button>
        </div>
      </fieldset>
    </form>}
    {error && <p role="alert" className="inline-error">{error}</p>}
    {success && <p role="status" className="api-key-success"><Check size={15} />{success}</p>}
  </section>;
}
