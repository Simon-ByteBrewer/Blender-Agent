import { useSyncExternalStore } from "react";
import { EN } from "./locales/en";

export type Lang = "zh" | "en";
export const LANGUAGES: { id: Lang; label: string }[] = [
  { id: "en", label: "English" },
  { id: "zh", label: "中文" },
];
export const APP_TITLE = "MA 导演 Agent";

const STORAGE_KEY = "studio.language";
const listeners = new Set<() => void>();

function initialLanguage(): Lang {
  // Outside a browser (tests, server rendering) keep the Chinese source text.
  if (typeof document === "undefined") return "zh";
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === "zh" || saved === "en") return saved;
  } catch { /* Storage may be unavailable; fall back to the browser language. */ }
  return /^zh\b/i.test(navigator.language || "zh") ? "zh" : "en";
}

let current: Lang = initialLanguage();

function applyDocument() {
  if (typeof document === "undefined") return;
  document.documentElement.lang = current === "zh" ? "zh-CN" : "en";
  document.title = t(APP_TITLE);
}

export function getLanguage() {
  return current;
}

export function setLanguage(lang: Lang) {
  if (lang === current) return;
  current = lang;
  try { localStorage.setItem(STORAGE_KEY, lang); } catch { /* Per-browser convenience only. */ }
  applyDocument();
  listeners.forEach((listener) => listener());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => { listeners.delete(listener); };
}

// Components that render translated text re-render on language change.
// Memoized components must call this themselves; others follow their parent.
export function useLanguage() {
  return useSyncExternalStore(subscribe, getLanguage, getLanguage);
}

// The Chinese source text is the key, so untranslated strings degrade to Chinese.
export function t(zh: string, vars?: Record<string, string | number>) {
  const text = current === "en" ? EN[zh] ?? zh : zh;
  return vars ? text.replace(/\{(\w+)\}/g, (match, name) => name in vars ? String(vars[name]) : match) : text;
}

applyDocument();
