import { appFetch } from "./appUrl";
import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import { Check, LoaderCircle, Settings, Sparkles, Terminal, X } from "./icons";
import { ByokSettings } from "./ByokSettings";
import { SelfHostedSettings } from "./ma_self_hosted/Settings";
import { LanguagePicker } from "./LanguageSwitch";
import { t } from "./i18n";

const settingsTabs = [
  { id: "connection", label: "MA API Key", Icon: Sparkles },
  { id: "byok", label: "自定义模型 BYOK", Icon: Sparkles },
  { id: "execution", label: "执行环境", Icon: Terminal },
  { id: "general", label: "语言", Icon: Settings },
] as const;
export type Platform = { id: string; family: string; name: string; region: string; api_key_url?: string };

// Region names are shown in the platform picker; IDs come from the backend.
const regionLabels: Record<string, string> = {
  "cn-beijing": "华北 2（北京）",
  "ap-southeast-1": "亚太（柔佛）",
};
export const platformLabel = (p: Platform) => `${t(p.name)} · ${t(regionLabels[p.region] || p.region)}`;
type SettingsTab = typeof settingsTabs[number]["id"];

export function SettingsDialog({ configured, maskedKey, platform, platforms = [], onClose, onSaved, onModelsChanged, onPlatformChanged }: {
  configured: boolean;
  maskedKey?: string | null;
  platform?: Platform;
  platforms?: Platform[];
  onPlatformChanged?: () => void | Promise<void>;
  onClose: () => void;
  onModelsChanged?: () => void | Promise<void>;
  onSaved: (maskedKey: string) => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const input = useRef<HTMLInputElement>(null);
  const submitting = useRef(false);
  const [apiKey, setApiKey] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  const [platformId, setPlatformId] = useState(platform?.id || "volcengine");
  const [switching, setSwitching] = useState(false);
  const [platformError, setPlatformError] = useState("");
  const selectedPlatform = platforms.find((p) => p.id === platformId) || platform;
  const [activeTab, setActiveTab] = useState<SettingsTab>("connection");
  const [compactNavigation, setCompactNavigation] = useState(() => window.matchMedia("(max-width: 640px)").matches);
  const navigation = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = dialog.current;
    element?.showModal();
    input.current?.focus();
    return () => element?.close();
  }, []);

  useEffect(() => {
    const query = window.matchMedia("(max-width: 640px)");
    const update = () => setCompactNavigation(query.matches);
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);

  function navigateTabs(event: KeyboardEvent<HTMLDivElement>) {
    const index = settingsTabs.findIndex((tab) => tab.id === activeTab);
    let next = index;
    if (event.key === "ArrowDown" || event.key === "ArrowRight") next = (index + 1) % settingsTabs.length;
    else if (event.key === "ArrowUp" || event.key === "ArrowLeft") next = (index + settingsTabs.length - 1) % settingsTabs.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = settingsTabs.length - 1;
    else return;
    event.preventDefault();
    const id = settingsTabs[next].id;
    setActiveTab(id);
    navigation.current?.querySelector<HTMLButtonElement>(`#settings-tab-${id}`)?.focus();
  }

  async function save() {
    if (submitting.current || !apiKey.trim()) return;
    submitting.current = true;
    setSaving(true);
    setError("");
    setSaved(false);
    try {
      const response = await appFetch("/api/settings/api-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ api_key: apiKey.trim() }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : t("保存失败，请重试"));
      setApiKey("");
      setSaved(true);
      onSaved(data.api_key_masked);
    } catch (exc) {
      setError(exc instanceof Error ? exc.message : t("保存失败，请检查本地服务连接"));
    } finally {
      submitting.current = false;
      setSaving(false);
    }
  }

  async function switchPlatform(id: string) {
    if (submitting.current || id === platformId) return;
    const previous = platformId;
    submitting.current = true;
    setPlatformId(id);
    setSwitching(true);
    setPlatformError("");
    setSaved(false);
    try {
      const response = await appFetch("/api/settings/platform", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ platform: id }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : t("切换失败，请重试"));
      await onPlatformChanged?.();
      input.current?.focus();
    } catch (exc) {
      setPlatformId(previous);
      setPlatformError(exc instanceof Error ? exc.message : t("切换失败，请检查本地服务连接"));
    } finally {
      submitting.current = false;
      setSwitching(false);
    }
  }

  return <dialog ref={dialog} className="api-settings-dialog" aria-labelledby="api-settings-title"
    onCancel={(e) => { e.preventDefault(); if (!submitting.current) onClose(); }}
    onClick={(e) => { if (e.target === e.currentTarget && !submitting.current) onClose(); }}>
    <header className="settings-dialog-header">
      <h2 id="api-settings-title">{t("设置")}</h2>
      <button type="button" className="dialog-close" aria-label={t("关闭设置")} disabled={saving || switching} onClick={onClose}><X size={19} /></button>
    </header>
    <div className="settings-dialog-content">
      <div className="settings-navigation" ref={navigation} role="tablist" aria-label={t("设置分类")}
        aria-orientation={compactNavigation ? "horizontal" : "vertical"} onKeyDown={navigateTabs}>
        {settingsTabs.map(({ id, label, Icon }) => <button key={id} type="button" role="tab"
          id={`settings-tab-${id}`} aria-controls={`settings-page-${id}`} aria-selected={activeTab === id}
          tabIndex={activeTab === id ? 0 : -1} onClick={() => setActiveTab(id)}>
          <Icon size={17} /><span>{t(label)}</span>
        </button>)}
      </div>
      <div className="settings-pages">
        <div className="settings-tab-page" id="settings-page-connection" role="tabpanel"
          aria-labelledby="settings-tab-connection" hidden={activeTab !== "connection"}>
          <form className="settings-panel api-key-settings" aria-labelledby="api-key-settings-title"
            onSubmit={(e) => { e.preventDefault(); void save(); }}>
            {platforms.length > 0 && <label className="settings-platform">
              {t("服务平台")}
              <select value={platformId} disabled={saving || switching}
                aria-describedby={platformError ? "platform-error" : "platform-hint"}
                onChange={(e) => void switchPlatform(e.target.value)}>
                {platforms.map((p) => <option key={p.id} value={p.id}>{platformLabel(p)}</option>)}
              </select>
            </label>}
            {platforms.length > 0 && <p id="platform-hint" className="settings-field-hint">
              {switching ? t("切换中…") : t("API Key、模型与 MA 会话按平台和地域隔离，切换后请填写该地域的 API Key。")}
            </p>}
            {platformError && <p id="platform-error" role="alert" className="inline-error">{platformError}</p>}
            <div className="settings-panel-heading">
              <h3 id="api-key-settings-title">API KEY</h3>
              <span className={`settings-connection-status${configured || saved ? " is-configured" : ""}`}>
                {configured || saved ? <><Check size={13} />{t("已配置")}</> : t("待配置")}
              </span>
            </div>
            <p className="settings-section-description">{t("通过 API Key 连接{platform}，开始创作。", { platform: t(selectedPlatform?.name || "火山方舟") })}
              {selectedPlatform?.api_key_url && <> <a href={selectedPlatform.api_key_url} target="_blank" rel="noreferrer">{t("获取 API Key")}</a></>}</p>
            <label>
              ARK API Key
              <input ref={input} type="password" autoFocus autoComplete="new-password" spellCheck={false}
                value={apiKey} maxLength={4096} disabled={saving || switching}
                placeholder={configured ? t("已配置，输入新 Key 可替换") : t("请输入{platform} API Key", { platform: t(selectedPlatform?.name || "火山方舟") })}
                aria-invalid={!!error} aria-describedby={error ? "api-key-error" : "api-key-hint"}
                onChange={(e) => { setApiKey(e.target.value); setError(""); setSaved(false); }} />
            </label>
            {configured && <p className="settings-current-key">{t("当前 Key")} <code className="masked-api-key">{maskedKey || "••••••••"}</code></p>}
            <p id="api-key-hint" className="settings-field-hint">{t("保存后立即生效，下次启动自动读取。")}{configured && t("输入新 Key 可替换当前配置。")}</p>
            {error && <p id="api-key-error" role="alert" className="inline-error">{error}</p>}
            {saved && <p className="api-key-success" role="status"><Check size={15} />{t("API Key 已保存，可以开始创作。")}</p>}
            <button className="primary settings-save-key" disabled={saving || switching || !apiKey.trim()}>
              {saving && <LoaderCircle size={15} className="spin" />}{saving ? t("保存中…") : t("保存 API Key")}
            </button>
          </form>
        </div>
        <div className="settings-tab-page" id="settings-page-byok" role="tabpanel"
          aria-labelledby="settings-tab-byok" hidden={activeTab !== "byok"}>
          <ByokSettings onChanged={onModelsChanged} />
        </div>
        <div className="settings-tab-page" id="settings-page-execution" role="tabpanel"
          aria-labelledby="settings-tab-execution" hidden={activeTab !== "execution"}>
          <SelfHostedSettings />
        </div>
        <div className="settings-tab-page" id="settings-page-general" role="tabpanel"
          aria-labelledby="settings-tab-general" hidden={activeTab !== "general"}>
          <section className="settings-panel" aria-labelledby="language-settings-title">
            <div className="settings-panel-heading"><h3 id="language-settings-title">{t("语言")}</h3></div>
            <p className="settings-section-description">{t("选择界面显示语言，仅保存在当前浏览器。")}</p>
            <LanguagePicker />
          </section>
        </div>
      </div>
    </div>
  </dialog>;
}
