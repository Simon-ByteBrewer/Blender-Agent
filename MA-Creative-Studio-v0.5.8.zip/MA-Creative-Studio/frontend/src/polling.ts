import { t } from "./i18n";

/** Start the next poll only after this one settles; release requests on unmount. */
export function startPolling(
  task: (signal: AbortSignal) => Promise<unknown>,
  intervalMs: number,
  onError: (error: unknown) => void,
  timeoutMs = 15000,
) {
  let stopped = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let controller: AbortController | undefined;
  async function run() {
    controller = new AbortController();
    const timeout = setTimeout(() => controller?.abort(new Error(t("读取超时，请重试"))), timeoutMs);
    try { await task(controller.signal); }
    catch (error) { if (!stopped) onError(error); }
    finally {
      clearTimeout(timeout);
      if (!stopped) timer = setTimeout(() => void run(), intervalMs);
    }
  }
  void run();
  return () => {
    stopped = true;
    if (timer !== undefined) clearTimeout(timer);
    controller?.abort();
  };
}
