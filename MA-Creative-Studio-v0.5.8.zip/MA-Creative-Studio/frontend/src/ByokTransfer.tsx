import { useRef, useState } from "react";
import type { Profile } from "./ByokSettings";
import { appFetch } from "./appUrl";
import { LoaderCircle, X } from "./icons";
import { t } from "./i18n";

export function ByokTransfer({ disabled, count, onBusy, onImported }: {
  disabled: boolean; count: number; onBusy: (busy: boolean) => void;
  onImported: (result: { models: Profile[]; imported: number; skipped: number }) => void;
}) {
  const [mode, setMode] = useState<"import" | "export" | null>(null);
  const [password, setPassword] = useState("");
  const [copied, setCopied] = useState(false);
  const passwordInput = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [busy, setBusy] = useState(false);
  const submitting = useRef(false);

  function open(next: typeof mode) {
    // 24 random bytes encode to 32 URL-safe characters, with no padding.
    const generated = next === "export" ? btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(24))))
      .replace(/\+/g, "-").replace(/\//g, "_") : "";
    setMode(next); setPassword(generated); setCopied(false); setFile(null); setError(""); setSuccess("");
  }
  async function copyPassword() {
    setError("");
    try { await navigator.clipboard.writeText(password); setCopied(true); }
    catch {
      setCopied(false); passwordInput.current?.select();
      setError(t("复制失败，请手动复制已选中的口令"));
    }
  }
  async function submit() {
    if (submitting.current || !mode) return;
    setError(""); setSuccess("");
    submitting.current = true; setBusy(true); onBusy(true);
    try {
      let document: unknown;
      if (mode === "import") {
        if (!file) throw Error(t("请选择加密的 JSON 配置文件"));
        if (file.size > 1024 * 1024) throw Error(t("配置文件不能超过 1 MB"));
        try { document = JSON.parse(await file.text()); }
        catch { throw Error(t("无法读取 JSON 配置文件")); }
      }
      const response = await appFetch(`/api/settings/byok/${mode}`, { method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password, ...(mode === "import" ? { document } : {}) }) });
      const result = await response.json();
      if (!response.ok) throw Error(typeof result.detail === "string" ? result.detail : t("操作失败，请重试"));
      if (mode === "export") {
        const url = URL.createObjectURL(new Blob([JSON.stringify(result, null, 2)], { type: "application/json" }));
        const link = window.document.createElement("a");
        link.href = url; link.download = "byok-config.encrypted.json";
        window.document.body.appendChild(link); link.click(); link.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 1000);
        setSuccess(t("已生成加密配置文件。关闭前请复制并保存口令，遗失后无法恢复文件。"));
      } else {
        onImported(result);
        setSuccess(t("已导入 {imported} 个模型，跳过 {skipped} 个重复模型。现有配置保持不变。", { imported: result.imported, skipped: result.skipped }));
        setMode(null); setFile(null);
      }
    } catch (e) { setError(e instanceof Error ? e.message : t("操作失败，请重试")); }
    finally {
      // Keep the export password available for copying after the download.
      if (mode === "import") setPassword("");
      submitting.current = false; setBusy(false); onBusy(false);
    }
  }

  return <div className="byok-transfer">
    <div className="byok-transfer-actions">
      <button className="byok-add" type="button" disabled={disabled} onClick={() => open("import")}>{t("导入配置")}</button>
      <button className="byok-add" type="button" disabled={disabled || !count} onClick={() => open("export")}>{t("导出配置")}</button>
      <span>{t("使用口令保护的 JSON 文件")}</span>
    </div>
    {mode && <form className="byok-transfer-form" key={mode} onSubmit={e => { e.preventDefault(); void submit(); }}>
      <div className="byok-editor-heading"><h4>{mode === "export" ? t("导出加密配置") : t("导入加密配置")}</h4>
        <button type="button" disabled={disabled} aria-label={t("取消配置导入导出")} onClick={() => open(null)}><X size={15} /></button>
      </div>
      <p className="byok-detail-hint">{mode === "export"
        ? t("导出全部 {count} 个 BYOK 模型及密钥，不包含 MA API Key。已自动生成随机口令，请复制保存，并与文件分开传递。", { count })
        : t("选择此前导出的加密文件，并输入导出时的口令。相同接口、模型和鉴权配置将跳过，保留现有名称和密钥。")}</p>
      <fieldset disabled={disabled}>
        {mode === "import" && <label>{t("配置文件")}<input type="file" accept=".json,application/json" required
          onChange={e => { setFile(e.target.files?.[0] || null); setError(""); }} /></label>}
        {mode === "export" ? <div className="byok-generated-password">
          <label>{t("加密口令")}<input ref={passwordInput} type="text" readOnly autoComplete="off" spellCheck={false}
            value={password} onFocus={e => e.target.select()} /></label>
          <button className="byok-add" type="button" aria-label={copied ? t("已复制") : t("复制口令")} onClick={() => void copyPassword()}>
            <span aria-hidden="true" className={`codicon codicon-${copied ? "check" : "copy"}`} />
            <span role="status">{copied ? t("已复制") : t("复制口令")}</span>
          </button>
        </div> : <label>{t("解密口令")}<input type="password" required minLength={12} maxLength={256}
          autoComplete="new-password" value={password} placeholder={t("输入导出时的口令")} onChange={e => setPassword(e.target.value)} /></label>}
        <div className="byok-form-footer"><span>{mode === "export" ? t("口令仅在当前面板保留，关闭后清除。") : t("口令不会保存，遗失后无法恢复文件。")}</span>
          <button className="primary">{busy && <LoaderCircle size={14} className="spin" />}
            {busy ? t("处理中…") : mode === "export" ? t("加密并下载") : t("解密并导入")}</button>
        </div>
      </fieldset>
    </form>}
    {error && <p role="alert" className="inline-error">{error}</p>}
    {success && <p role="status" className="api-key-success">{success}</p>}
  </div>;
}
