import { t } from "./i18n";

type SessionEvent = {
  id: string;
  type: string;
  processed_at?: string;
  created_at?: string;
  name?: string;
  tool_use_id?: string;
  custom_tool_use_id?: string;
  evaluated_permission?: string;
  result?: string;
  model_request_start_id?: string;
  _streaming?: boolean;
  _stream_incomplete?: boolean;
  stop_reason?: { type?: string; event_ids?: string[] };
};
type ChatJob = { kind: string; status: string; created_at?: number; updated_at?: number };

export type QueuedMessage = {
  id: string; text: string; status: string; created_at: number;
  event_id?: string; error?: string; dismissed?: boolean;
};

// Keep one ordinary transcript message across local delivery and cloud acknowledgement.
export function mergeQueuedMessages<T extends SessionEvent>(events: T[], queue: QueuedMessage[]) {
  const visible = queue.filter((message) => !message.dismissed);
  const byEvent = new Map(visible.filter((message) => message.event_id).map((message) => [message.event_id, message]));
  const eventIds = new Set(events.map((event) => event.id));
  const localEvent = (message: QueuedMessage) => ({
    id: `input:${message.id}`, type: "user.message",
    created_at: new Date(message.created_at * 1000).toISOString(),
    processed_at: undefined,
    content: [{ type: "text", text: message.text }],
    delivery: message,
  });
  return [
    ...events.map((event) => {
      const message = byEvent.get(event.id);
      return message ? { ...event, ...localEvent(message) } : event;
    }),
    ...visible.filter((message) => !message.event_id || !eventIds.has(message.event_id)).map(localEvent),
  ];
}

export function userMessageText(text: string) {
  if (!text.startsWith("[平台项目上下文]")) return text;
  const headerEnd = text.indexOf("\n");
  if (headerEnd < 0) return text;
  const content = text.slice(headerEnd + 1);
  if (!content.startsWith("[平台制作分工：用户最新要求]")) return content;
  const policyEnd = "只有用户明确要求 Blender 本身输出高精模型或写实渲染时，才按该要求提高相应细节。";
  const end = content.indexOf(policyEnd);
  return end < 0 ? content : content.slice(end + policyEnd.length).replace(/^\s*\n/, "");
}

export function eventTime(event: SessionEvent) {
  if (event.type === "user.message" || event.type === "agent.message") {
    const created = Date.parse(event.created_at || "");
    if (Number.isFinite(created)) return created;
    const match = event.id.match(/-(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})-/);
    if (match) return Date.parse(`${match[1]}-${match[2]}-${match[3]}T${match[4]}:${match[5]}:${match[6]}Z`);
  }
  const explicit = Date.parse(event.processed_at || event.created_at || "");
  if (Number.isFinite(explicit)) return explicit;
  const match = event.id.match(/-(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})-/);
  return match ? Date.parse(`${match[1]}-${match[2]}-${match[3]}T${match[4]}:${match[5]}:${match[6]}Z`) : 0;
}

export function isWaitingForTools(events: SessionEvent[], jobs: ChatJob[]) {
  const state = [...events].reverse().find((event) => [
    "session.status_idle", "session.status_running", "session.error",
    "session.status_failed", "session.status_terminated", "session.deleted", "user.interrupt",
  ].includes(event.type));
  if (state?.type !== "session.status_idle" || state.stop_reason?.type !== "requires_action") return false;
  const latestJob = jobs.filter((job) => job.kind === "ma")
    .sort((a, b) => (b.created_at || b.updated_at || 0) - (a.created_at || a.updated_at || 0))[0];
  // Cancellation can stop polling before the cloud's final idle event is cached.
  const interruptedAt = latestJob?.status === "interrupted" ? latestJob.updated_at || 0 : 0;
  return !interruptedAt || interruptedAt * 1000 < eventTime(state);
}

export function pendingToolCalls(events: SessionEvent[], jobs: ChatJob[]) {
  const latestJob = jobs.filter((job) => job.kind === "ma")
    .sort((a, b) => (b.created_at || b.updated_at || 0) - (a.created_at || a.updated_at || 0))[0];
  // A running render or a historical cloud gate doesn't mean an MA tool is active.
  if (latestJob?.status !== "running") return [];
  const ordered = [...events].sort((a, b) => eventTime(a) - eventTime(b));
  const completed = new Set(ordered.filter((event) =>
    ["user.tool_result", "user.custom_tool_result"].includes(event.type))
    .map((event) => event.tool_use_id || event.custom_tool_use_id));
  const confirmations = new Map<string, string | undefined>();
  const pending = new Map<string, SessionEvent>();
  let gateIds: Set<string> | undefined;
  let stoppedAt = 0;
  for (const event of ordered) {
    if (["session.error", "session.status_failed", "session.status_terminated", "session.deleted", "user.interrupt"].includes(event.type)
      || (event.type === "session.status_idle" && event.stop_reason?.type !== "requires_action")) {
      pending.clear();
      gateIds = undefined;
      if (event.type !== "session.status_idle") stoppedAt = eventTime(event) || Infinity;
    } else if (event.type === "session.status_idle" && Array.isArray(event.stop_reason?.event_ids)) {
      gateIds = new Set(event.stop_reason.event_ids);
      for (const id of pending.keys()) if (!gateIds.has(id)) pending.delete(id);
    } else if (event.type === "session.status_running") {
      gateIds = undefined;
    } else if (event.type === "user.tool_confirmation") {
      const id = event.tool_use_id || event.custom_tool_use_id;
      if (id) confirmations.set(id, event.result);
    } else if (["agent.tool_use", "agent.custom_tool_use"].includes(event.type) && !completed.has(event.id)) {
      pending.set(event.id, event);
    }
  }
  // A late tool event must not undo an interruption while /jobs still reports
  // the old job as running. A later explicit MA job can resume normally.
  if (stoppedAt && (latestJob.created_at || 0) * 1000 <= stoppedAt) return [];
  return [...pending.values()].flatMap((event) => {
    // A resumed MA job can continue a gate created earlier. Other calls from
    // before this job belong to history and must not reappear as current work.
    if (latestJob.created_at && eventTime(event) < latestJob.created_at * 1000 && !gateIds?.has(event.id)) return [];
    const permission = event.evaluated_permission === "ask"
      ? confirmations.get(event.id) || "ask" : event.evaluated_permission || "allow";
    if (permission === "deny") return [];
    return [{ id: event.id, name: event.name?.trim() || t("工具"),
      status: permission === "allow" ? "pending" as const : "waiting_confirmation" as const }];
  });
}

export function agentPhase(events: SessionEvent[], jobs: ChatJob[], tools = pendingToolCalls(events, jobs)) {
  const latestJob = jobs.filter((job) => job.kind === "ma")
    .sort((a, b) => (b.created_at || b.updated_at || 0) - (a.created_at || a.updated_at || 0))[0];
  if (latestJob?.status !== "running") return "idle";
  if (tools.length) return "waiting_tools";
  let phase: "waiting" | "thinking" | "replying" | "idle" = "waiting";
  let awaitingNextModel = false;
  const modelRequests = new Set<string>();
  for (const event of [...events].sort((a, b) => eventTime(a) - eventTime(b))) {
    if (latestJob.created_at && eventTime(event) < latestJob.created_at * 1000) continue;
    if (["session.error", "session.status_failed", "session.status_terminated", "session.deleted", "user.interrupt"].includes(event.type)) return "idle";
    if (event.type === "session.status_idle") {
      modelRequests.clear();
      phase = event.stop_reason?.type === "requires_action" ? "waiting" : "idle";
      awaitingNextModel = true;
    } else if (event.type === "session.status_running") {
      awaitingNextModel = false;
      if (phase === "idle") phase = "waiting";
    } else if (event.type === "span.model_request_start") {
      awaitingNextModel = false;
      modelRequests.add(event.id);
      phase = "thinking";
    } else if (event.type === "span.model_request_end") {
      const requestId = event.model_request_start_id;
      // A delayed end for an older request must not end the current request.
      if (!requestId || modelRequests.has(requestId) || modelRequests.size === 0) {
        if (requestId) modelRequests.delete(requestId);
        else modelRequests.clear();
        if (phase !== "idle") phase = modelRequests.size ? "thinking" : "waiting";
      }
    } else if (phase !== "idle" && !awaitingNextModel && event._streaming && !event._stream_incomplete) {
      if (event.type === "agent.thinking") phase = "thinking";
      if (event.type === "agent.message") phase = "replying";
    }
  }
  return phase;
}
