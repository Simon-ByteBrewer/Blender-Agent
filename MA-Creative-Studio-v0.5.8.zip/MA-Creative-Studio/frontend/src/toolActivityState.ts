import { eventTime, pendingToolCalls } from "./chatState";

export function formatElapsed(seconds: number) {
  const s = Math.max(0, Math.floor(seconds));
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m ${s % 60}s`;
  return `${Math.floor(s / 3600)}h ${Math.floor(s / 60) % 60}m ${s % 60}s`;
}

export type ActivityEvent = {
  id: string; type: string; name?: string; processed_at?: string; created_at?: string;
  tool_use_id?: string; custom_tool_use_id?: string; evaluated_permission?: string; result?: string;
  model_request_start_id?: string; _streaming?: boolean; _stream_incomplete?: boolean;
  stop_reason?: { type?: string; event_ids?: string[] };
};
export type ActivityJob = { kind: string; status: string; created_at?: number; updated_at?: number };
export type ToolTelemetry = {
  session_id: string; available: boolean; sampled_at: number | null; worker_active: boolean; truncated?: boolean;
  calls: { id: string; status: "executing" | "ready" | "sending" | "sent" | "rejected" | "unknown" }[];
};
export type ToolStatus = "queued" | "executing" | "returning" | "sent" | "failed" | "confirmation" | "waiting" | "unknown";
export const toolStatusLabels: Record<ToolStatus, string> = {
  queued: "等待执行", executing: "执行中", returning: "回传中", sent: "已回传",
  failed: "回传失败", confirmation: "等待确认", waiting: "等待工具结果", unknown: "状态待更新",
};

export function latestToolActivity(events: ActivityEvent[], jobs: ActivityJob[], sessionId: string | undefined,
  telemetry?: ToolTelemetry, now = Date.now()) {
  // Matching cloud results and terminal events remove calls in pendingToolCalls.
  // Completed history must never cover the Agent's current inference/reply phase.
  const latest = pendingToolCalls(events, jobs).at(-1);
  if (!latest) return null;
  const request = events.find((event) => event.id === latest.id);
  const requestedAt = request ? eventTime(request) : 0;
  let status: ToolStatus = "waiting";
  const age = now / 1000 - (telemetry?.sampled_at ?? NaN);
  const fresh = !!sessionId && telemetry?.session_id === sessionId && telemetry.available === true
    && Number.isFinite(age) && age >= -5 && age <= 15 && Array.isArray(telemetry.calls);
  if (latest.status === "waiting_confirmation") status = "confirmation";
  else if (fresh) {
    const entry = telemetry!.calls.find((call) => call.id === latest.id)?.status;
    if (entry === "executing") status = telemetry!.worker_active === true ? "executing" : "unknown";
    else if (entry === "ready" || entry === "sending") status = "returning";
    else if (entry === "sent") status = "sent";
    else if (entry === "rejected") status = "failed";
    else if (entry || telemetry!.truncated) status = "unknown";
    else {
      status = requestedAt > 0 && (telemetry!.sampled_at ?? 0) * 1000 >= requestedAt ? "queued" : "waiting";
    }
  }
  return { id: latest.id, name: latest.name, status, label: toolStatusLabels[status], requestedAt };
}
