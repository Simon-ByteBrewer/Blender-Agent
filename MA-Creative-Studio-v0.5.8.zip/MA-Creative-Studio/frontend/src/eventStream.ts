import { appUrl } from "./appUrl";
import { t } from "./i18n";
export type LiveEvent = {
  id: string;
  type: string;
  processed_at?: string;
  content?: any[];
  _streaming?: boolean;
  _stream_incomplete?: boolean;
  _archived?: boolean;
};

export function currentSessionEvents<T extends LiveEvent>(events: T[]): T[] {
  return events.filter((event) => !event._archived);
}

function extendsPreview(previous: LiveEvent, next: LiveEvent) {
  return (previous.content || []).every((block, index) =>
    String(next.content?.[index]?.text || "").startsWith(String(block?.text || "")));
}

export function mergeSessionEvents<T extends LiveEvent>(previous: T[], updates: T[]): T[] {
  const merged = new Map(previous.map((event) => [event.id, event]));
  let changed = false;
  for (const event of updates) {
    if (!event?.id || !event.type) continue;
    const old = merged.get(event.id);
    if (old && (event._streaming || event._stream_incomplete) && (
      (!old._streaming && !old._stream_incomplete) || !extendsPreview(old, event))) continue;
    if (old?.processed_at && !event.processed_at) continue;
    if (old && JSON.stringify(old) === JSON.stringify(event)) continue;
    merged.set(event.id, event);
    changed = true;
  }
  return changed ? [...merged.values()] : previous;
}

export async function fetchEventSnapshot<T extends LiveEvent>(projectId: string, request = fetch) {
  const response = await request(appUrl(`/api/events?project_id=${encodeURIComponent(projectId)}`));
  const value = await response.json();
  if (!response.ok || !Array.isArray(value)) {
    throw new Error(typeof value?.detail === "string" ? value.detail : t("无法读取对话记录"));
  }
  return { events: value as T[], sessionId: response.headers.get("X-MA-Session-ID") };
}

type Source = Pick<EventSource, "addEventListener" | "close" | "readyState">;

export function connectEventStream<T extends LiveEvent>(
  projectId: string,
  onEvents: (events: T[], reset: boolean, sessionId: string) => void,
  onStatus: (connected: boolean) => void,
  factory: (url: string) => Source = (url) => new EventSource(url),
) {
  let disposed = false;
  let source: Source | undefined;
  let reconnect: ReturnType<typeof setTimeout> | undefined;
  let sessionId: string | undefined;
  const url = appUrl(`/api/events/stream?project_id=${encodeURIComponent(projectId)}`);
  function open() {
    if (disposed) return;
    try {
      const connection = factory(url);
      source = connection;
      const receive = (raw: globalThis.Event) => {
        if (disposed || source !== connection) return;
        try {
          const value = JSON.parse((raw as MessageEvent).data);
          if (typeof value.session_id !== "string" || !Array.isArray(value.events)) return;
          const reset = sessionId !== undefined && sessionId !== value.session_id;
          sessionId = value.session_id;
          onEvents(value.events, reset, value.session_id);
          onStatus(true);
        } catch { /* A malformed preview must not break the polling fallback. */ }
      };
      connection.addEventListener("snapshot", receive);
      connection.addEventListener("events", receive);
      connection.addEventListener("error", () => {
        if (disposed || source !== connection) return;
        onStatus(false);
        // Native EventSource reconnects transient failures. A not-yet-upgraded
        // backend's 404 can close it permanently; retry that case separately.
        if (connection.readyState === 2 && !reconnect) {
          connection.close();
          reconnect = setTimeout(() => { reconnect = undefined; open(); }, 5000);
        }
      });
    } catch {
      onStatus(false);
      reconnect = setTimeout(() => { reconnect = undefined; open(); }, 5000);
    }
  }
  open();
  return () => {
    disposed = true;
    if (reconnect) clearTimeout(reconnect);
    source?.close();
    onStatus(false);
  };
}
