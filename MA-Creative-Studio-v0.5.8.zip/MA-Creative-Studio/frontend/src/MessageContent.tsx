import React, { memo, useEffect, useMemo, useState } from "react";
import Markdown, { defaultUrlTransform } from "react-markdown";
import { appUrl } from "./appUrl";
import remarkGfm from "remark-gfm";
import hljs from "highlight.js/lib/core";
import python from "highlight.js/lib/languages/python";
import json from "highlight.js/lib/languages/json";
import javascript from "highlight.js/lib/languages/javascript";
import typescript from "highlight.js/lib/languages/typescript";
import bash from "highlight.js/lib/languages/bash";
import css from "highlight.js/lib/languages/css";
import xml from "highlight.js/lib/languages/xml";
import sql from "highlight.js/lib/languages/sql";
import yaml from "highlight.js/lib/languages/yaml";
import type { PreviewImage } from "./ImageLightbox";
import { t, useLanguage } from "./i18n";

for (const [name, language] of Object.entries({ python, json, javascript, typescript, bash, css, xml, sql, yaml })) hljs.registerLanguage(name, language);

export function CopyButton({ text, label = "复制消息", className = "" }: { text: string; label?: string; className?: string }) {
  const [state, setState] = useState("");
  useEffect(() => {
    if (!state) return;
    const timer = setTimeout(() => setState(""), 1800);
    return () => clearTimeout(timer);
  }, [state]);
  return <button type="button" className={`copy-button ${className}`} aria-label={t(state || label)} title={t(state || label)}
    onClick={async () => {
      try { await navigator.clipboard.writeText(text); setState("已复制"); }
      catch { setState("复制失败，请重试"); }
    }}><span aria-hidden="true" className={`codicon codicon-${state === "已复制" ? "check" : "copy"}`} />
    {state && <span className="copy-feedback" role="status">{t(state)}</span>}
  </button>;
}

export function formatJson(text: string): string | null {
  const trimmed = text.trim();
  if (!/^[{[]/.test(trimmed)) return null;
  try { JSON.parse(trimmed); } catch { return null; }
  // Re-indent tokens without rounding large integers or changing string escapes.
  const tokens = trimmed.match(/"(?:\\.|[^"\\])*"|[^\s]/g) || [];
  let depth = 0;
  return tokens.map((token, i) => {
    if (token === "{" || token === "[") {
      depth++;
      return token + (tokens[i + 1] === "}" || tokens[i + 1] === "]" ? "" : "\n" + "  ".repeat(depth));
    }
    if (token === "}" || token === "]") {
      depth--;
      return (tokens[i - 1] === "{" || tokens[i - 1] === "[" ? "" : "\n" + "  ".repeat(depth)) + token;
    }
    if (token === ",") return ",\n" + "  ".repeat(depth);
    return token === ":" ? ": " : token;
  }).join("");
}

export const CodeBlock = memo(function CodeBlock({ code, language = "" }: { code: string; language?: string }) {
  useLanguage();
  const lang = language.toLowerCase();
  const formatted = useMemo(() => lang === "json" ? formatJson(code) ?? code : code, [code, lang]);
  const highlighted = useMemo(() => {
    if (!hljs.getLanguage(lang) || formatted.length > 100_000) return null;
    return hljs.highlight(formatted, { language: lang, ignoreIllegals: true }).value;
  }, [formatted, lang]);
  return <div className="code-block">
    <div className="code-header"><span>{lang || "text"}</span><CopyButton text={formatted} label="复制代码" /></div>
    <pre>{highlighted === null ? <code>{formatted}</code> : <code className="hljs" dangerouslySetInnerHTML={{ __html: highlighted }} />}</pre>
  </div>;
});

export const MessageContent = memo(function MessageContent({ text, onImage }: { text: string; onImage?: (image: PreviewImage) => void }) {
  useLanguage();
  const jsonText = useMemo(() => formatJson(text), [text]);
  return <div className="markdown-content">
    {jsonText !== null ? <CodeBlock code={jsonText} language="json" /> : <Markdown urlTransform={(url) => appUrl(defaultUrlTransform(url))} remarkPlugins={[remarkGfm]} components={{
      pre({ children }) {
        const child = React.Children.toArray(children)[0];
        if (!React.isValidElement<{ className?: string; children?: React.ReactNode }>(child)) return <pre>{children}</pre>;
        return <CodeBlock code={String(child.props.children ?? "").replace(/\n$/, "")} language={child.props.className?.replace(/^language-/, "")} />;
      },
      a({ node, ...props }) { return <a {...props} target="_blank" rel="noopener noreferrer" />; },
      img({ src, alt }) {
        if (!src) return null;
        return onImage ? <button type="button" className="message-image-preview" aria-label={t("放大图片 {name}", { name: alt || t("参考图片") })}
          onClick={() => onImage({ url: src, name: alt || t("参考图片") })}><img src={src} alt={alt || t("参考图片")} /></button>
          : <img src={src} alt={alt || t("参考图片")} />;
      },
      table({ children }) { return <div className="markdown-table"><table>{children}</table></div>; },
    }}>{text}</Markdown>}
  </div>;
});

// Only the MA API's public text blocks belong in the transcript. Never stringify
// signatures, redacted blocks, or other event metadata as a display fallback.
export function thinkingText(content: unknown): string {
  if (!Array.isArray(content)) return "";
  return content.filter((part) => part?.type === "text" && typeof part.text === "string")
    .map((part) => part.text).join("\n\n");
}

export const ThinkingContent = memo(function ThinkingContent({ content, onImage }: { content: unknown; onImage?: (image: PreviewImage) => void }) {
  const text = thinkingText(content);
  if (!text.trim()) return null;
  // An uncontrolled disclosure preserves the user's expanded state while a
  // stable event ID receives progressive text through SSE or polling fallback.
  return <details className="thinking-content">
    <summary>Thinking</summary>
    <MessageContent text={text} onImage={onImage} />
  </details>;
});

export const ToolInput = memo(function ToolInput({ input, name }: { input: Record<string, unknown>; name?: string }) {
  const { code, ...parameters } = input;
  if (typeof code !== "string") return <CodeBlock code={JSON.stringify(input, null, 2)} language="json" />;
  return <>
    <CodeBlock code={code} language={name?.includes("blender") || name?.includes("python") ? "python" : ""} />
    {Object.keys(parameters).length > 0 && <CodeBlock code={JSON.stringify(parameters, null, 2)} language="json" />}
  </>;
});
