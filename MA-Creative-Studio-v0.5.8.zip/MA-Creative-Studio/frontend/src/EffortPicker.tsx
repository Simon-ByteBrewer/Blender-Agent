import { useEffect, useId, useRef, useState, type CSSProperties } from "react";
import { ChevronDown, RefreshCw } from "./icons";
import type { MaModel } from "./modelPresentation";
import { t } from "./i18n";
import "./EffortPicker.css";

export const effortLabel = (value: string) => value ? value[0].toUpperCase() + value.slice(1) : "Default";

export function EffortPicker({ model, value, locked, disabled, onSelect }: {
  model?: MaModel; value?: string | null; locked?: boolean; disabled?: boolean;
  onSelect: (value: string | null) => Promise<void>;
}) {
  const levels = model?.reasoning_effort_options || [];
  // New sessions send the displayed default explicitly; existing sessions only
  // show the effective cloud value, which may differ from the catalog default.
  const effective = value || (locked ? "" : model?.reasoning_effort_default) || "";
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState(effective);
  const [saving, setSaving] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const slider = useRef<HTMLInputElement>(null);
  const panelId = useId();
  useEffect(() => { setDraft(effective); }, [effective, model?.id, open]);
  useEffect(() => {
    if (!open) return;
    slider.current?.focus();
    const close = (event: PointerEvent) => { if (!root.current?.contains(event.target as Node)) setOpen(false); };
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, [open]);
  if (!model || levels.length < 2) return null;
  const index = Math.max(0, levels.indexOf(draft));
  const commit = async (next: string | null) => {
    if (locked || saving || (next === value) || (next === null && value == null)) return;
    setSaving(true);
    try { await onSelect(next); }
    catch { setDraft(effective); }
    finally { setSaving(false); }
  };
  return <div className="effort-picker" ref={root} onBlur={(e) => {
    // Saving can disable a focused button and emit blur with no next target.
    // Only an actual focus move outside the picker should dismiss the panel.
    if (e.relatedTarget && !e.currentTarget.contains(e.relatedTarget as Node)) setOpen(false);
  }} onKeyDown={(e) => {
    if (e.key === "Escape") { e.preventDefault(); setOpen(false); trigger.current?.focus(); }
  }}>
    <button type="button" className="effort-trigger" ref={trigger} disabled={disabled || saving}
      aria-label={t("选择 Reasoning Effort，当前 {value}", { value: effortLabel(effective) })} title={t("Reasoning Effort · 选择推理强度")}
      aria-haspopup="dialog" aria-expanded={open} aria-controls={panelId}
      onClick={() => setOpen(!open)}>
      <span className="effort-trigger-value">{effortLabel(effective)}</span><ChevronDown size={13} />
    </button>
    {open && <div id={panelId} className="effort-popover" role="dialog" aria-label="Reasoning effort">
      <div className="effort-heading">
        <div><span className="effort-caption">Reasoning Effort</span><strong>{effortLabel(draft)}</strong></div>
        <button type="button" className="effort-reset" aria-label={t("恢复默认推理强度")} title={t("恢复默认")}
          disabled={locked || saving || value == null} onClick={() => {
            setDraft(model.reasoning_effort_default || ""); void commit(null);
          }}><RefreshCw size={17} /></button>
      </div>
      <div className="effort-slider" style={{ "--effort-fill": `${index / (levels.length - 1) * 100}%` } as CSSProperties}>
        <div className="effort-dots" aria-hidden="true">{levels.map((level) => <i key={level} />)}</div>
        <input ref={slider} type="range" min={0} max={levels.length - 1} step={1} value={index}
          disabled={locked} aria-disabled={locked || saving} aria-label={t("推理强度")} aria-valuetext={effortLabel(draft)}
          onChange={(e) => { if (!saving) setDraft(levels[Number(e.target.value)]); }}
          onPointerUp={(e) => void commit(levels[Number(e.currentTarget.value)])}
          onPointerCancel={() => setDraft(effective)}
          onKeyUp={(e) => { if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End", "PageUp", "PageDown"].includes(e.key)) void commit(levels[Number(e.currentTarget.value)]); }} />
      </div>
      <div className="effort-scale" aria-hidden="true"><span>{effortLabel(levels[0])}</span><span>{effortLabel(levels.at(-1)!)}</span></div>
    </div>}
  </div>;
}
