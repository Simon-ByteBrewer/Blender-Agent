import { LANGUAGES, setLanguage, t, useLanguage } from "./i18n";

// Compact toggle for the activity bar; the settings page uses the full picker.
export function LanguageToggle() {
  const lang = useLanguage();
  const next = lang === "zh" ? "en" : "zh";
  return <button type="button" className="language-toggle" lang={next === "zh" ? "zh-CN" : "en"}
    title={next === "zh" ? "切换到中文" : "Switch to English"} aria-label={t("语言")}
    onClick={() => setLanguage(next)}>
    {next === "zh" ? "中" : "EN"}
  </button>;
}

export function LanguagePicker() {
  const lang = useLanguage();
  return <div className="language-picker" role="radiogroup" aria-label={t("语言")}>
    {LANGUAGES.map(({ id, label }) => <button key={id} type="button" role="radio" aria-checked={lang === id}
      lang={id === "zh" ? "zh-CN" : "en"} className={lang === id ? "is-selected" : ""}
      onClick={() => setLanguage(id)}>{label}</button>)}
  </div>;
}
