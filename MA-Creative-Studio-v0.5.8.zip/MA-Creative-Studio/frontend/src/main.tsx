import { appFetch, appUrl } from "./appUrl";
import { createClientId } from "./clientId";
import { startPolling } from "./polling";
import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowUp,
  Box,
  Camera,
  Check,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  Download,
  Pencil,
  FileBox,
  FileVideo,
  Folder,
  Image,
  LoaderCircle,
  MessageSquare,
  Plus,
  RefreshCw,
  Send,
  Settings,
  Sparkles,
  Square,
  SquareFilled,
  Terminal,
  Upload,
  X,
  Files,
  Window,
  ExternalLink,
  SidebarIcon,
} from "./icons";
import "./style.css";
import { ImageLightbox, type PreviewImage } from "./ImageLightbox";
import { needsUpload, referencePayload, referenceVideoName, videoPrompt, type SeedRef, type SeedMode } from "./seedance";
import { SeedanceReferences } from "./SeedanceReferences";
import { imageFiles, uploadFile, materialMessage, type DraftMaterial } from "./uploads";
import { SeedanceProgress } from "./SeedanceProgress";
import { SettingsDialog, platformLabel } from "./SettingsDialog";
import { LanguageToggle } from "./LanguageSwitch";
import { APP_TITLE, t, useLanguage } from "./i18n";
import { installClickFocus } from "./clickFocus";
import { ExecutionBadge, RemoteDesktop, type ExecutionInfo } from "./ma_self_hosted/Desktop";
import { VideoCompare } from "./VideoCompare";
import { CopyButton, MessageContent, ThinkingContent, thinkingText, ToolInput } from "./MessageContent";
import { eventTime, isWaitingForTools, userMessageText, mergeQueuedMessages, type QueuedMessage } from "./chatState";
import { connectEventStream, currentSessionEvents, fetchEventSnapshot, mergeSessionEvents } from "./eventStream";
import { ToolActivity } from "./ToolActivity";
import { ModelPicker } from "./ModelPicker";
import { EffortPicker } from "./EffortPicker";
import { ContextUsage } from "./ContextUsage";
import { ComposerInput, type ComposerInputHandle } from "./ComposerInput";
import { displayModelId, type MaModel } from "./modelPresentation";
import { useMobileLayout } from "./useMobileLayout";
import version from "../../VERSION?raw";
import "./mobile.css";

type Project = {
  id: string;
  title: string;
  prompt: string;
  demo: boolean;
  blend: string;
  reference: string;
  session_id?: string;
  execution_info?: ExecutionInfo;
  activity?: { status: string; kind: string } | null;
  settings: { duration: number; fps: number; resolution: string };
};
type Artifact = { name: string; url: string; bytes: number; modified_at?: number;
  video?: { width: number; height: number; duration: number; fps?: number } | null };
const deliveryErrors: Record<string, string> = { cancelled: "已停止发送", failed: "发送失败", unknown: "发送结果待确认", paused: "尚未发送" };
type Job = {
  id: string;
  kind: string;
  status: string;
  error?: string;
  created_at?: number;
  updated_at?: number;
  result?: any;
};
type Event = {
  id: string;
  type: string;
  name?: string;
  processed_at?: string;
  created_at?: string;
  job?: Job;
  delivery?: QueuedMessage;
  input?: any;
  content?: any[];
  error?: any;
  stop_reason?: { type?: string; event_ids?: string[] };
  _streaming?: boolean;
  _stream_incomplete?: boolean;
  _archived?: boolean;
  _session_id?: string;
};
const labels: Record<string, string> = {
  queued: "排队中",
  running: "Running / 进行中",
  succeeded: "已完成",
  failed: "失败",
  interrupted: "已中断",
};
const kindLabel: Record<string, string> = {
  ma: "MA 场景创作",
  render: "Blender 渲染",
  seedance: "Seedance 生成",
  compose: "视频合成",
};
const seedDefault =
  "遵循参考视频的主体、构图、相机运动与剪辑点，提升材质细节和光照真实感，保持时序稳定，不添加字幕。";
async function api(path: string, body?: unknown, pid?: string, signal?: AbortSignal) {
  const r = await appFetch(
    "/api" + path + (pid ? "?project_id=" + encodeURIComponent(pid) : ""),
    body === undefined
      ? { signal }
      : {
          signal,
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        },
  );
  const data = await r.json();
  // A running backend can finish its current task before being upgraded.
  if (path === "/chat/queue" && r.status === 404) return [];
  if (!r.ok)
    throw Error(
      typeof data.detail === "string"
        ? data.detail
        : JSON.stringify(data.detail || data),
    );
  return data;
}
function blockedReferenceImage(error: string) {
  return error.includes("Error while downloading") &&
    error.includes("image_url") && /status code:\s*403\b/.test(error);
}
function errorSummary(error: string) {
  if (error.includes("model.reasoning_effort is not supported"))
    return t("MA 不支持所选的推理强度，请选择可用档位后重新发送。");
  if (error.includes("Could not connect to Blender"))
    return t("Blender MCP 未连接。请启动 Blender，连接成功后继续原任务。");
  if (blockedReferenceImage(error))
    return t("外部参考图片访问被拒绝（403）。可新会话恢复，跳过失效图片继续创作。");
  if (error.includes("model_rate_limited"))
    return t("MA 模型限流，当前任务未完成");
  return error;
}
function JobProgress({job: j}: {job: Job}) {
  return <section className="conversation-progress">
    <div className={"job " + j.status}>
      <div className="job-summary">
        {j.status === "succeeded" ? <Check size={14}/> : j.status === "running" ? <LoaderCircle size={14} className="spin"/> : j.status === "failed" ? <CircleAlert size={14}/> : <Square size={12}/>}
        <strong>{t(kindLabel[j.kind] || j.kind)}</strong>
        <span>{j.kind === "seedance" && j.result?.status === "submitted" ? t("已提交生成") : t(labels[j.status] || j.status)}</span>
        <small>{new Date((j.updated_at || j.created_at || 0) * 1000).toLocaleString()}</small>
      </div>
      {j.error && <details className="error-details"><summary>{errorSummary(j.error) === j.error ? t("查看失败原因") : errorSummary(j.error)}</summary><pre>{j.error}</pre></details>}
      {j.result?.artifact && <a href={appUrl(j.result.artifact)} download>{t("下载任务产物")}</a>}
    </div>
  </section>;
}
function EventContent({ event: e, onImage }: { event: Event; onImage: (image: PreviewImage) => void }) {
  const content = e.content?.map((c, i) =>
    c.type === "text" ? (
      <MessageContent key={i} text={e.type === "user.message" ? userMessageText(c.text) : c.text} onImage={onImage} />
    ) : c.type === "image" ? (
      <button key={i} className="expand-image" aria-label={e.type === "user.message" ? t("放大参考图片") : t("放大 Blender 视窗")}
        onClick={() => onImage({ name: e.type === "user.message" ? t("参考图片") : t("Blender 工具返回的视窗"), url: `data:${c.source.media_type};base64,${c.source.data}` })}><img
        alt={e.type === "user.message" ? t("参考图片") : t("Blender 工具返回的视窗")}
        src={`data:${c.source.media_type};base64,${c.source.data}`}
      /></button>
    ) : null,
  );
  return e.type === "user.custom_tool_result" ? (
    <details className="tool-result">
      <summary>{t("查看执行结果")}</summary>
      {content}
    </details>
  ) : (
    <>{content}</>
  );
}

function messageCopyText(event: Event) {
  if (event.type === "agent.thinking") return thinkingText(event.content);
  if (event.type === "agent.custom_tool_use") return JSON.stringify(event.input, null, 2);
  if (event.type === "session.error") return event.error?.message || t("MA 云端执行失败");
  return (event.content || []).filter((part) => part.type === "text")
    .map((part) => event.type === "user.message" ? userMessageText(part.text) : part.text).join("\n\n");
}

function App() {
  const language = useLanguage();
  const isMobile = useMobileLayout();
  const [mobilePanel, setMobilePanel] = useState<"projects" | "chat" | "preview">("chat");
  const [projects, setProjects] = useState<Project[]>([]);
  const [pid, setPid] = useState(
    new URLSearchParams(location.search).get("project") || "",
  );
  const pidRef = useRef(pid);
  pidRef.current = pid;
  const [health, setHealth] = useState<any>({});
  const [showSettings, setShowSettings] = useState(false);
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const eventStreamProject = useRef("");
  const eventPollAfter = useRef(0);
  const eventSession = useRef("");
  const eventSessionEpoch = useRef(0);
  const [queuedMessages, setQueuedMessages] = useState<QueuedMessage[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [hasText, setHasText] = useState(false);
  const [view, setView] = useState("preview");
  const [selectedFile, setSelectedFile] = useState("");
  const [screen, setScreen] = useState("");
  const [seedPrompt, setSeedPrompt] = useState(seedDefault);
  const [seedDuration, setSeedDuration] = useState(8);
  const [seedResolution, setSeedResolution] = useState("720p");
  const [seedRatio, setSeedRatio] = useState("16:9");
  const [seedAudio, setSeedAudio] = useState(false);
  const [seedMode, setSeedMode] = useState<SeedMode>("auto");
  const [composeClips, setComposeClips] = useState<string[]>([]);
  const [seedRefs, setSeedRefs] = useState<SeedRef[]>([]);
  const seedRefsEdited = useRef(false);
  const [seedError, setSeedError] = useState("");
  const [seedJob, setSeedJob] = useState("");
  const [seedPollingError, setSeedPollingError] = useState("");
  const seedSubmitting = useRef(false);
  const seedPromptEdited = useRef(false);
  const [expandedImage, setExpandedImage] = useState<PreviewImage | null>(null);
  const [comparingVideos, setComparingVideos] = useState(false);
  const [reference, setReference] = useState("");
  const [seedStatus, setSeedStatus] = useState<any>(null);
  const [seedTask, setSeedTask] = useState("");
  const [nameDialog, setNameDialog] = useState<"create" | "rename" | null>(null);
  const [taskName, setTaskName] = useState("");
  const [nameError, setNameError] = useState("");
  const [dialogDraft, setDialogDraft] = useState("");
  const [showLeft, setShowLeft] = useState(true);
  const [leftWidth, setLeftWidth] = useState(() => {
    try {
      return Math.max(
        180,
        Math.min(
          420,
          Number(localStorage.getItem("ma-studio.sidebar-width")) || 240,
        ),
      );
    } catch {
      return 240;
    }
  });
  const leftDrag = useRef<{ x: number; width: number } | null>(null);
  const [resizingLeft, setResizingLeft] = useState(false);
  const [blender, setBlender] = useState<any>({});
  useEffect(() => {
    try {
      localStorage.setItem("ma-studio.sidebar-width", String(leftWidth));
    } catch {}
  }, [leftWidth]);
  const [showRight, setShowRight] = useState(true);
  const [rightWidth, setRightWidth] = useState(30);
  const [offline, setOffline] = useState(false);
  const chatScroll = useRef<HTMLDivElement>(null);
  const followChat = useRef(true);
  const upload = useRef<HTMLInputElement>(null);
  const [materials, setMaterials] = useState<DraftMaterial[]>([]);
  const materialUrls = useRef(new Set<string>());
  const newTaskDraft = useRef<{ text: string; materials: DraftMaterial[] } | null>(null);
  useEffect(() => {
    const current = new Set(materials.map((item) => item.url));
    for (const url of materialUrls.current) if (!current.has(url)) URL.revokeObjectURL(url);
    materialUrls.current = current;
  }, [materials]);
  useEffect(() => () => { for (const url of materialUrls.current) URL.revokeObjectURL(url); }, []);
  const [draggingImages, setDraggingImages] = useState(false);
  const imageDragDepth = useRef(0);
  const composerInput = useRef<ComposerInputHandle>(null);
  const setText = useCallback((value: React.SetStateAction<string>) => composerInput.current?.setText(value), []);
  const composerWrap = useRef<HTMLDivElement>(null);
  const chatPane = useRef<HTMLElement>(null);
  useLayoutEffect(() => {
    const wrapper = composerWrap.current;
    const pane = chatPane.current;
    if (!wrapper || !pane) return;
    const updateInset = () => {
      pane.style.setProperty("--composer-height", `${wrapper.offsetHeight}px`);
    };
    updateInset();
    const observer = new ResizeObserver(updateInset);
    observer.observe(wrapper);
    return () => observer.disconnect();
  }, []);
  const sending = useRef(false);
  const workspace = useRef<HTMLDivElement>(null);
  const refresh = useCallback(async (signal?: AbortSignal) => {
    const current = pidRef.current;
    const eventEpoch = eventSessionEpoch.current;
    const list: Project[] = await api("/projects", undefined, undefined, signal);
    if (signal?.aborted || current !== pidRef.current) return;
    setProjects(list);
    setOffline(false);
    if (!current) {
      const [h, b] = await Promise.all([api("/health", undefined, undefined, signal), api("/blender", undefined, undefined, signal)]);
      if (signal?.aborted || current !== pidRef.current) return;
      setHealth(h);
      setBlender(b);
      setOffline(false);
      return;
    }
    const [h, a, j, e, b, q] = await Promise.allSettled([
      api("/health", undefined, current, signal),
      api("/artifacts", undefined, current, signal),
      api("/jobs", undefined, current, signal),
      eventStreamProject.current === current && Date.now() < eventPollAfter.current
        ? Promise.resolve(null) : fetchEventSnapshot<Event>(current, (url) => fetch(url, { signal })),
      api("/blender", undefined, current, signal),
      api("/chat/queue", undefined, current, signal),
    ]);
    if (signal?.aborted || current !== pidRef.current) return;
    if (h.status === "fulfilled") setHealth(h.value);
    setBlender(b.status === "fulfilled" ? b.value : {
      mcp_connected: false, launching: false, error: String(b.reason?.message || b.reason),
    });
    if (a.status === "fulfilled") setArtifacts(a.value);
    if (j.status === "fulfilled") setJobs(j.value);
    if (e.status === "fulfilled" && e.value && eventEpoch === eventSessionEpoch.current) {
      const sid = e.value.sessionId ?? list.find((entry) => entry.id === current)?.session_id ?? "";
      const reset = eventSession.current !== sid;
      if (reset) eventSessionEpoch.current += 1;
      eventSession.current = sid;
      setEvents((previous) => mergeSessionEvents(reset ? [] : previous, e.value!.events));
      eventPollAfter.current = Date.now() + 15000;
    }
    if (q.status === "fulfilled") setQueuedMessages(q.value);
    setOffline(false);
  }, []);
  useEffect(() => {
    setNameDialog(null);
    followChat.current = true;
    eventSession.current = "";
    eventSessionEpoch.current += 1;
    eventPollAfter.current = 0;
    setDraggingImages(false);
    imageDragDepth.current = 0;
    setArtifacts([]);
    setJobs([]);
    setEvents([]);
    setQueuedMessages([]);
    setScreen("");
    setSelectedFile("");
    setReference("");
    setSeedTask("");
    setSeedStatus(null);
    setSeedJob("");
    setSeedError("");
    setSeedRefs([]);
    setComposeClips([]);
    setSeedMode("auto");
    seedRefsEdited.current = false;
    setExpandedImage(null);
    setComparingVideos(false);
    seedPromptEdited.current = false;
    setText(newTaskDraft.current?.text || "");
    setMaterials(newTaskDraft.current?.materials || []);
    newTaskDraft.current = null;
    setError("");
    setSeedPrompt(seedDefault);
    history.replaceState(null, "", pid ? "?project=" + pid : location.pathname);
  }, [pid]);
  useEffect(() => {
    eventStreamProject.current = "";
    if (!pid) return;
    return connectEventStream<Event>(pid,
      (updates, reset, sid) => {
        if (pidRef.current === pid) {
          const changedSession = eventSession.current !== sid;
          if (changedSession) eventSessionEpoch.current += 1;
          eventSession.current = sid;
          setEvents((previous) => mergeSessionEvents(reset || changedSession ? [] : previous, updates));
        }
      },
      (connected) => {
        if (pidRef.current === pid) eventStreamProject.current = connected ? pid : "";
      });
  }, [pid]);
  useEffect(() => startPolling(refresh, 2500, () => setOffline(true)), [refresh, pid]);
  useLayoutEffect(() => {
    const container = chatScroll.current;
    if (container && followChat.current) container.scrollTop = container.scrollHeight;
  }, [pid, events, jobs.length, queuedMessages.length]);
  const project = projects.find((p) => p.id === pid);
  const selectedMaModel = (health.ma_models || []).find((m: MaModel) => displayModelId(m.id) === displayModelId(health.ma?.model || ""));
  // A model picked during a Session is applied at the next turn boundary; show the choice meanwhile.
  const pendingModel: { model: string; effort?: string | null } | null = health.ma?.pending || null;
  const chosenModelId = pendingModel?.model || health.ma?.model || "";
  const chosenMaModel = (health.ma_models || []).find((m: MaModel) => displayModelId(m.id) === displayModelId(chosenModelId));
  const sessionUsesByok = !!project?.session_id && String(health.ma?.model || "").startsWith("byok:");
  useEffect(() => {
    if (project) {
      setSeedDuration(project.settings.duration);
      setSeedResolution(project.settings.resolution === "1080p" ? "1080p" : "720p");
    }
  }, [project?.id]);
  useEffect(() => {
    if (project && !seedPromptEdited.current) setSeedPrompt(videoPrompt(project));
  }, [project?.id, project?.title, project?.prompt]);
  const running = jobs.some((j) => ["running", "queued"].includes(j.status));
  const activeEvents = currentSessionEvents(events);
  const lastSessionState = [...activeEvents].reverse().find((e) =>
    ["session.error", "session.status_idle"].includes(e.type));
  const referenceRecovery = lastSessionState?.type === "session.error" &&
    blockedReferenceImage(lastSessionState.error?.message || "");
  const waitingForTools = isWaitingForTools(activeEvents, jobs);
  const blenderBusy = !!health.project_busy || running || !!busy;
  const maRunning = jobs.some((j) => j.kind === "ma" && ["running", "queued"].includes(j.status));
  const hasDraft = hasText || materials.length > 0;
  const canSend = hasDraft && !busy && !offline;
  const showStop = maRunning && !hasDraft;
  const files = artifacts.filter((a) => !a.name.endsWith(".json"));
  const selected =
    artifacts.find((a) => a.name === selectedFile) ||
    artifacts.find((a) => a.name === project?.reference) ||
    files.find((a) => a.name.endsWith(".mp4")) ||
    files.find((a) => a.name.endsWith(".png"));
  const blend = artifacts.find((a) => a.name === project?.blend);
  const videos = artifacts.filter((a) => /\.mp4$/i.test(a.name))
    .sort((a, b) => (b.modified_at || 0) - (a.modified_at || 0) || b.name.localeCompare(a.name));
  const referenceName = referenceVideoName(videos.map((a) => a.name), reference, project?.reference);
  const seedFiles = artifacts.filter((a) => /\.(mp4|mov|png|jpe?g|webp|mp3|wav)$/i.test(a.name))
    .sort((a, b) => (b.modified_at || 0) - (a.modified_at || 0) || a.name.localeCompare(b.name));
  // Until edited, the references follow the project's current Blender preview video.
  useEffect(() => {
    if (seedRefsEdited.current) return;
    setSeedRefs(referenceName ? [{ key: "video:" + referenceName, type: "video", source: referenceName,
      name: referenceName, origin: "project" }] : []);
  }, [referenceName]);
  const updateSeedRefs = (next: SeedRef[]) => { seedRefsEdited.current = true; setSeedRefs(next); };
  const currentSeedJob = jobs.find((j) => j.id === seedJob) || [...jobs].reverse().find((j) => j.kind === "seedance");
  const seedPending = jobs.some((j) => j.kind === "seedance" && ["running", "queued"].includes(j.status));
  useEffect(() => {
    if (currentSeedJob?.result?.id) setSeedTask(currentSeedJob.result.id);
  }, [currentSeedJob?.result?.id]);
  const cloudGenerating = !!seedTask && !["succeeded", "failed", "expired", "cancelled"].includes(seedStatus?.status);
  useEffect(() => {
    setSeedStatus(null);
    setSeedPollingError("");
    if (!seedTask || !pid) return;
    let stopped = false;
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      let finished = false;
      try {
        const status = await api("/seedance/" + seedTask, undefined, pid);
        if (stopped || pidRef.current !== pid) return;
        setSeedStatus(status);
        setSeedPollingError("");
        finished = ["succeeded", "failed", "expired", "cancelled"].includes(status.status);
      } catch (e) {
        if (!stopped) setSeedPollingError((e as Error).message);
      }
      if (!stopped && !finished) timer = setTimeout(poll, 4000);
    };
    void poll();
    return () => { stopped = true; clearTimeout(timer); };
  }, [pid, seedTask]);
  async function generateVideo() {
    if (!project || seedSubmitting.current || seedPending || cloudGenerating) return;
    if ((seedMode === "extend" || seedMode === "edit") && !seedRefs.some((ref) => ref.type === "video")) {
      setSeedError(t("延长或编辑需要参考视频；请先添加待处理视频作为「视频1」。"));
      return;
    }
    if (seedMode === "extend" && seedDuration === -1) {
      setSeedError(t("请选择新增时长（4–30 秒）。"));
      return;
    }
    if (needsUpload(seedRefs) && !health.reference_upload_available) {
      setSeedError(t("请先运行 MA 场景创作，本地参考视频即可使用当前 Session 自动上传，只需现有 API Key。"));
      return;
    }
    const current = pid;
    seedSubmitting.current = true;
    setBusy("提交 Seedance");
    setSeedError("");
    setSeedStatus(null);
    setSeedTask("");
    try {
      const job = await api("/seedance", {
        reference: referenceName || project.reference,
        prompt: seedPrompt.trim(), duration: seedDuration, resolution: seedResolution,
        mode: seedMode, ratio: seedRatio, generate_audio: seedAudio, references: referencePayload(seedRefs),
      }, current);
      if (pidRef.current === current) {
        setSeedJob(job.id);
        setJobs((previous) => [...previous.filter((j) => j.id !== job.id), job]);
      }
    } catch (e) {
      if (pidRef.current === current) setSeedError(String((e as Error).message || e));
    } finally {
      seedSubmitting.current = false;
      setBusy("");
    }
  }
  const latestImage = [...events]
    .reverse()
    .flatMap((e) => e.content || [])
    .find((c) => c.type === "image");
  const displayScreen =
    screen ||
    (latestImage
      ? `data:${latestImage.source.media_type};base64,${latestImage.source.data}`
      : "");
  const messages = mergeQueuedMessages(events, queuedMessages).filter((e) =>
    e.type === "agent.thinking" ? !!thinkingText(e.content).trim() :
    [
      "user.message",
      "agent.message",
      "agent.custom_tool_use",
      "user.custom_tool_result",
      "session.error",
    ].includes(e.type),
  );
  const timeline: Event[] = [...messages, ...jobs.map((job) => ({
    id: "job:" + job.id, type: "local.job", job,
    processed_at: new Date((job.updated_at || job.created_at || 0) * 1000).toISOString(),
  }))].sort((a, b) => eventTime(a) - eventTime(b));
  function openBlender() {
    return action("打开 Blender", async () => {
      const r = await api("/blender/open", {}, pid);
      setBlender(r);
    });
  }
  async function action(name: string, fn: () => Promise<void>) {
    setBusy(name);
    setError("");
    try {
      await fn();
      await refresh();
    } catch (e) {
      setError(String(e instanceof Error ? e.message : e));
    } finally {
      setBusy("");
    }
  }
  function addMaterials(files: File[]) {
    if (!files.length) return;
    if (busy) { setError(t("请等待当前操作完成后再添加素材。")); return; }
    try {
      const prepared = files.map(uploadFile);
      const additions = prepared.map((file) => ({ id: createClientId(), file, url: URL.createObjectURL(file) }));
      setMaterials((current) => [...current, ...additions]);
      setError("");
      composerInput.current?.focus();
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
  }
  function removeMaterial(item: DraftMaterial) {
    setMaterials((current) => current.filter((entry) => entry.id !== item.id));
    if (expandedImage?.url === item.url) setExpandedImage(null);
  }
  function newConversation() {
    setDialogDraft(pidRef.current ? "" : composerInput.current?.getText() || "");
    setTaskName("");
    setNameError("");
    setNameDialog("create");
  }
  async function saveTaskName() {
    const name = taskName.trim().replace(/[\s·•・.。…—–－]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
    if (!name) { setNameError(t("请输入任务名称。")); return; }
    if (projects.some((p) => p.title.toLocaleLowerCase() === name.toLocaleLowerCase() && (nameDialog === "create" || p.id !== pid))) {
      setNameError(t("任务名称已存在，请换一个名称。")); return;
    }
    setBusy("保存任务名称");
    setNameError("");
    try {
      if (nameDialog === "create") {
        const p = await api("/projects", {title: name, prompt: dialogDraft});
        setProjects((ps) => [...ps, p]);
        newTaskDraft.current = { text: dialogDraft, materials: pidRef.current ? [] : materials };
        pidRef.current = p.id;
        setPid(p.id);
        setText(dialogDraft);
        setView("preview");
        setMobilePanel("chat");
      } else {
        const response = await appFetch(`/api/projects/${pid}`, {
          method: "PATCH", headers: {"Content-Type": "application/json"},
          body: JSON.stringify({title: name}),
        });
        const p = await response.json();
        if (!response.ok) throw Error(p.detail || t("重命名失败"));
        setProjects((ps) => ps.map((item) => item.id === p.id ? p : item));
      }
      setNameDialog(null);
      composerInput.current?.focus();
      await refresh();
    } catch (e) {
      setNameError(e instanceof Error ? e.message : String(e));
    } finally { setBusy(""); }
  }
  async function send() {
    const draft = composerInput.current?.getText().trim() || "";
    const attachments = [...materials];
    if ((!draft && !attachments.length) || sending.current) return;
    sending.current = true;
    let target = pidRef.current;
    try {
      if (!target) {
        newConversation();
        return;
      }
      const uploaded = [];
      for (const item of attachments) {
        if (pidRef.current !== target) return;
        let saved = item.uploaded;
        if (!saved) {
          const form = new FormData();
          form.append("file", item.file);
          const response = await appFetch("/api/upload?project_id=" + encodeURIComponent(target), { method: "POST", body: form });
          const data = await response.json();
          if (!response.ok) throw Error(typeof data.detail === "string" ? data.detail : t("素材上传失败，请重试。"));
          saved = { name: data.name, url: data.url };
          if (pidRef.current !== target) return;
          const uploadedMaterial = saved;
          setMaterials((current) => current.map((entry) => entry.id === item.id ? { ...entry, uploaded: uploadedMaterial } : entry));
        }
        const image = /\.(png|jpe?g)$/i.test(item.file.name);
        if (!image) setReference(saved.name);
        uploaded.push({ ...saved, image });
      }
      const message = materialMessage(draft, uploaded);
      const result = await api("/chat", { message, message_id: createClientId() }, target);
      if (pidRef.current === target) {
        if (result.message) setQueuedMessages((current) => [...current.filter((m) => m.id !== result.message.id), result.message]);
        setText((current) => current.trim() === draft ? "" : current);
        const sentIds = new Set(attachments.map((item) => item.id));
        setMaterials((current) => current.filter((item) => !sentIds.has(item.id)));
        setExpandedImage(null);
      }
    } catch (error) {
      throw error;
    } finally {
      sending.current = false;
    }
  }
  const choose = (a: Artifact) => {
    setSelectedFile(a.name);
    setView("preview");
    setShowRight(true);
  };
  return (
    <div className="app-shell" data-mobile-panel={mobilePanel}>
      <header className="titlebar">
        <div className="brand">
          <img className="brand-mark creative-brand-mark" src={appUrl("/app-icon.png")} alt="" width={32} height={32} />
          <strong>{t(APP_TITLE)}</strong>
          <span className="brand-labels">
            <span className="execution-badge edition-badge">{health.edition === "cloud" ? t("云版本 · Elsa") : t("本地版本")}</span>
            <span className="version-badge" aria-label={t("版本 {version}", { version: version.trim() })}>v{version.trim().replace(/^v/i, "")}</span>
          </span>
        </div>
        <div className="title-path">
          <Folder size={13} />
          {project?.title || t("创作工作区")}
        </div>
        <div className="window-actions">
          <button
            aria-label={t("切换项目栏")}
            aria-pressed={showLeft}
            title={showLeft ? t("收起左侧栏") : t("展开左侧栏")}
            onClick={() => setShowLeft(!showLeft)}
          >
            <SidebarIcon side="left" open={showLeft} />
          </button>
          <button
            aria-label={t("切换预览栏")}
            aria-pressed={showRight}
            title={showRight ? t("收起预览栏") : t("展开预览栏")}
            onClick={() => setShowRight(!showRight)}
          >
            <SidebarIcon side="right" open={showRight} />
          </button>
        </div>
      </header>
      {isMobile && <nav className="mobile-navigation" aria-label={t("手机工作区导航")}>
        <button type="button" aria-pressed={mobilePanel === "projects"} onClick={() => setMobilePanel("projects")}><Files size={18} />{t("会话")}</button>
        <button type="button" aria-pressed={mobilePanel === "chat"} onClick={() => setMobilePanel("chat")}><MessageSquare size={18} />{t("对话")}</button>
        <button type="button" aria-pressed={mobilePanel === "preview" && view === "preview"} onClick={() => { setView("preview"); setMobilePanel("preview"); }}><Camera size={18} />{t("预览")}</button>
        <button type="button" aria-pressed={mobilePanel === "preview" && view === "seedance"} onClick={() => { setView("seedance"); setMobilePanel("preview"); }}><Sparkles size={18} />{t("视频生成")}</button>
        <button type="button" onClick={() => setShowSettings(true)}><Settings size={18} />{t("设置")}</button>
      </nav>}
      <div className={"shell-body " + (resizingLeft ? "is-resizing" : "")}>
        <nav className="activity-bar" aria-label={t("工作区导航")}>
          <button
            className={showLeft ? "active" : ""}
            title={t("项目资源管理器")}
            aria-label={t("项目管理")}
            onClick={() => setShowLeft(!showLeft)}
          >
            <Files size={23} />
          </button>
          <button
            aria-label={t("视频生成")}
            onClick={() => {
              setView("seedance");
              setShowRight(true);
            }}
          >
            <Sparkles size={21} />
          </button>
          <span className="activity-bottom" />
          <LanguageToggle />
          <button title={t("设置")} aria-label={t("设置")}
            onClick={() => setShowSettings(true)}>
            <Settings size={22} />
          </button>
        </nav>
        {(isMobile ? mobilePanel === "projects" : showLeft) && (
          <>
            <aside
              className="explorer"
              style={{ width: leftWidth }}
              aria-label={t("项目侧边栏")}
            >
              <div className="section-heading">
                <span>
                  <Files size={14} /> {t("工作会话")}
                </span>
                <button aria-label={t("新建项目")} disabled={!!busy} onClick={newConversation}>
                  <Plus size={17} />
                </button>
              </div>
              <button className="new-project" disabled={!!busy} onClick={newConversation}>
                <Plus size={16} />
                {t("新建会话")}
              </button>
              <div className="project-list">
                {projects.map((p) => (
                  <button
                    key={p.id}
                    className={
                      p.id === pid ? "project-item selected" : "project-item"
                    }
                    onClick={() => { setPid(p.id); setMobilePanel("chat"); }}
                  >
                    <Box size={16} />
                    <span className="session-item-text">
                      <span>{p.title}</span>
                      <small>
                        {p.activity
                          ? `${t(kindLabel[p.activity.kind] || p.activity.kind)} · ${t(labels[p.activity.status] || p.activity.status)}`
                          : p.session_id
                            ? t("继续创作")
                            : t("准备就绪")}
                      </small>
                    </span>
                    {p.activity?.status === "running" ||
                    p.activity?.status === "queued" ? (
                      <LoaderCircle size={13} className="spin" />
                    ) : p.activity?.status === "failed" ? (
                      <CircleAlert size={13} />
                    ) : null}
                    {p.demo && <small>Demo</small>}
                  </button>
                ))}
              </div>

              <div className="explorer-bottom">
                <span className={offline ? "status-dot bad" : "status-dot"} />
                {offline ? t("服务离线") : health.edition === "cloud" ? t("Elsa 云端工作区") : project?.execution_info?.mode === "self_hosted" ? t("远程工作区") : t("本地工作区")}
                <small>{health.edition === "cloud" ? t("文件保存在 Elsa 服务器") : project?.execution_info?.mode === "self_hosted" ? t("文件保存在 {server}", { server: project.execution_info.server_name || "" }) : t("文件保存在当前 Mac")}</small>
              </div>
            </aside>
            <div
              className="left-resize-handle"
              role="separator"
              aria-label={t("调整左侧栏宽度")}
              aria-orientation="vertical"
              aria-valuemin={180}
              aria-valuemax={420}
              aria-valuenow={leftWidth}
              tabIndex={0}
              title={t("拖动调整侧边栏宽度，双击恢复默认")}
              onDoubleClick={() => setLeftWidth(240)}
              onKeyDown={(e) => {
                if (e.key === "ArrowLeft") {
                  e.preventDefault();
                  setLeftWidth((v) => Math.max(180, v - 10));
                }
                if (e.key === "ArrowRight") {
                  e.preventDefault();
                  setLeftWidth((v) => Math.min(420, v + 10));
                }
                if (e.key === "Home") setLeftWidth(240);
              }}
              onPointerDown={(e) => {
                leftDrag.current = { x: e.clientX, width: leftWidth };
                e.currentTarget.setPointerCapture(e.pointerId);
                setResizingLeft(true);
              }}
              onPointerMove={(e) => {
                if (
                  leftDrag.current &&
                  e.currentTarget.hasPointerCapture(e.pointerId)
                )
                  setLeftWidth(
                    Math.max(
                      180,
                      Math.min(
                        420,
                        leftDrag.current.width + e.clientX - leftDrag.current.x,
                      ),
                    ),
                  );
              }}
              onPointerUp={(e) => {
                leftDrag.current = null;
                setResizingLeft(false);
                e.currentTarget.releasePointerCapture(e.pointerId);
              }}
              onLostPointerCapture={() => {
                leftDrag.current = null;
                setResizingLeft(false);
              }}
            />
          </>
        )}
        <div className="main-area">
          <div className="editor-workspace" ref={workspace}>
            <section className="chat-pane" ref={chatPane} aria-label={t("创作对话区")}>
              <div className="pane-tabs conversation-header">
                {nameDialog === "rename" ? <form className="conversation-rename" onSubmit={(e) => { e.preventDefault(); if (!busy) void saveTaskName(); }}>
                  <div>
                    <input autoFocus aria-label={t("会话名称")} value={taskName} maxLength={100} disabled={!!busy} aria-invalid={!!nameError}
                      onFocus={(e) => e.currentTarget.select()}
                      onChange={(e) => { setTaskName(e.target.value); setNameError(""); }}
                      onKeyDown={(e) => {
                        if (e.nativeEvent.isComposing || e.keyCode === 229) { if (e.key === "Enter") e.preventDefault(); return; }
                        if (e.key === "Escape" && !busy) { e.preventDefault(); setNameDialog(null); setNameError(""); }
                      }} />
                    <button type="submit" aria-label={t("保存会话名称")} title={t("保存（Enter）")} disabled={!!busy || !taskName.trim()}><Check size={15} /></button>
                    <button type="button" aria-label={t("取消修改名称")} title={t("取消（Esc）")} disabled={!!busy} onClick={() => { setNameDialog(null); setNameError(""); }}><X size={15} /></button>
                  </div>
                  {nameError && <small role="alert">{nameError}</small>}
                </form> : <button type="button" className="pane-tab active conversation-name" aria-label={t("修改会话名称")} title={t("修改会话名称")} disabled={!project || !!busy}
                  onClick={() => { if (project) { setTaskName(project.title); setNameError(""); setNameDialog("rename"); } }}>
                  <MessageSquare size={14} />
                  {project?.title || t("新会话")}
                  {project && <Pencil size={12} className="title-edit-icon" />}
                </button>}
                {project && <span className="project-id" title={project.id}>
                  Project ID: {project.id}
                  <button type="button" className="project-folder-button" title={t("打开项目文件夹")} aria-label={t("打开项目文件夹")}
                    disabled={!!busy} onClick={() => void action("打开项目文件夹", async () => {
                      await api(`/projects/${encodeURIComponent(project.id)}/open-folder`, {});
                    })}><Folder size={15} /></button>
                  <CopyButton className="project-id-copy" text={project.id} label={t("复制 Project ID")} />
                </span>}
                <div className="conversation-meta">
                  <ExecutionBadge info={project?.execution_info} />
                  {project?.session_id ? (
                    <a
                      className="session-link"
                      href={`${health.platform?.console_session_url || "https://console.volcengine.com/ark/region:cn-beijing/managed-agents/sessions/"}${encodeURIComponent(project.session_id)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      title={t("在{platform}打开 {id}", { platform: health.platform ? platformLabel(health.platform) : t("火山方舟"), id: project.session_id })}
                    >
                      MA Session ID: {project.session_id}{" "}
                      <ExternalLink size={11} />
                    </a>
                  ) : (
                    <span>{t("MA Session ID: 尚未创建")}</span>
                  )}
                </div>
              </div>
              <div className="chat-scroll" ref={chatScroll} onScroll={() => {
                const container = chatScroll.current;
                if (container) followChat.current = container.scrollHeight - container.scrollTop - container.clientHeight < 80;
              }}>
                <div className="project-heading">
                  <div className="session-title-row">
                    <h1>{project?.title || t("让想法成为画面")}</h1>
                    {project && <button aria-label={t("重命名会话")} title={t("重命名会话")}
                      onClick={() => { setTaskName(project.title); setNameError(""); setNameDialog("rename"); }}>
                      <Pencil size={16} />
                    </button>}
                  </div>
                  <p>
                    {project
                      ? t("描述空间、人物占位与镜头，先完成轻量预演。")
                      : t("从一句提示词开始，创建你的三维世界。")}
                  </p>
                  {project?.demo && (
                    <span className="demo-note">{t("示例项目 · 三维运镜预演")}</span>
                  )}
                </div>
                {!messages.length && (
                  <div className="welcome">
                    <div className="welcome-symbol">
                      <Sparkles size={27} />
                    </div>
                    <h2>{t("你想创造什么？")}</h2>
                    <p>
                      {t("建筑空间、产品短片、奇幻场景……")}
                      <br />
                      {t("Blender 预演空间与运镜，Seedance 完成写实画面。")}
                    </p>
                    <div className="suggestions">
                      {[
                        t("用简模搭建北欧客厅，明确沙发、窗户和一位人物的站位，镜头缓慢推进，输出 Blender 工程和 8 秒运镜预演，写实细节交给 Seedance。"),
                        t("用低面数体块搭建耳机与产品展台，镜头环绕展示轮廓和遮挡关系，输出工程和参考视频，材质与光影交给 Seedance。"),
                        t("用简模搭建天安门及前方广场，保留建筑轮廓和空间尺度，游客视角步行、转头与仰望，输出 12 秒运镜预演，不细做装饰和贴图。"),
                      ].map((s, i) => (
                        <button
                          key={s}
                          onClick={() => {
                            setText(s);
                            composerInput.current?.focus();
                          }}
                        >
                          {
                            [
                              t("日光下的室内空间"),
                              t("产品环绕展示"),
                              t("游客眼中的北京"),
                            ][i]
                          }
                          <ChevronRight size={15} />
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {timeline.map((e) => e.job ? <JobProgress key={e.id} job={e.job}/> : (
                  <div
                    key={e.id}
                    className={
                      "message " +
                      (e.type === "user.message"
                        ? "user"
                        : e.type.includes("tool")
                          ? "tool"
                          : "assistant") + (e.type === "agent.thinking" ? " thinking" : "")
                    }
                  >
                    <div className="message-label">
                      {e.type === "user.message" ? (
                        <>
                          <span>{t("你")}</span>
                          <span className="user-avatar">
                            <span
                              className="codicon codicon-account"
                              aria-hidden="true"
                            />
                          </span>
                        </>
                      ) : e.type.includes("tool") ? (
                        <>
                          <Terminal size={13} />
                          {t("工具执行")}
                        </>
                      ) : (
                        <>
                          <span className="mini-mark">M</span>MA
                        </>
                      )}
                    </div>
                    {e.type === "agent.thinking" ? (
                      <ThinkingContent content={e.content} onImage={setExpandedImage} />
                    ) : e.type === "agent.custom_tool_use" ? (
                      <details>
                        <summary>{e.name}</summary>
                        <ToolInput input={e.input || {}} name={e.name} />
                      </details>
                    ) : e.type === "session.error" ? (
                      <div>
                        <p className="inline-error">
                          {errorSummary(e.error?.message || t("MA 云端执行失败"))}
                        </p>
                        <details className="error-details">
                          <summary>{t("原始错误详情")}</summary>
                          <pre>{e.error?.message}</pre>
                        </details>
                      </div>
                    ) : (
                      <EventContent event={e} onImage={setExpandedImage} />
                    )}
                    <div className="message-footer">
                      {e._archived && <small className="message-time" title={t("原 Session: {id}", { id: e._session_id || "" })}>{t("历史对话")}</small>}
                      {e._streaming && <small className="message-time">{t("正在输出…")}</small>}
                      {eventTime(e) > 0 && <time className="message-time" dateTime={new Date(eventTime(e)).toISOString()}
                        title={new Date(eventTime(e)).toLocaleString(language === "en" ? "en-US" : "zh-CN", { timeZone: "Asia/Shanghai", hour12: false }) + t("（上海时间）")}>
                        {new Date(eventTime(e)).toLocaleTimeString("zh-CN", { timeZone: "Asia/Shanghai", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false })}
                      </time>}
                      {messageCopyText(e) && <CopyButton className="message-copy" text={messageCopyText(e)} />}
                    </div>
                    {e.delivery && (e.delivery.status === "queued" || deliveryErrors[e.delivery.status]) && <div className="message-delivery">
                      {deliveryErrors[e.delivery.status] && <small title={e.delivery.error}>{t(deliveryErrors[e.delivery.status])}</small>}
                      {e.delivery.status === "queued" && <button type="button" aria-label={t("撤回编辑消息")} title={t("撤回编辑")} disabled={!!busy} onClick={() => void action("编辑消息", async () => {
                        const m = e.delivery!;
                        const current = pid;
                        const response = await appFetch(`/api/chat/queue/${encodeURIComponent(m.id)}?project_id=${encodeURIComponent(current)}`, { method: "DELETE" });
                        if (!response.ok) throw new Error((await response.json()).detail || t("撤回失败"));
                        if (pidRef.current === current) {
                          setText((draft) => draft ? `${m.text}\n${draft}` : m.text);
                          composerInput.current?.focus();
                        }
                      })}><Pencil size={14} /></button>}
                      {["cancelled", "failed", "paused"].includes(e.delivery.status) && <button type="button" aria-label={t("重新编辑消息")} title={t("重新编辑")} onClick={() => { const m = e.delivery!; setText((draft) => draft ? `${m.text}\n${draft}` : m.text); composerInput.current?.focus(); }}><Pencil size={14} /></button>}
                    </div>}
                  </div>
                ))}
                <ToolActivity key={pid} events={activeEvents} jobs={jobs} sessionId={project?.session_id}
                  telemetry={health.tool_activity} launching={!!blender.launching} />
              </div>
              <div className="composer-wrap" ref={composerWrap}>
                <form
                  className={`composer composer-chat${draggingImages ? " dragging-images" : ""}`}
                  onPaste={(e) => {
                    const files = imageFiles(e.clipboardData);
                    if (!files.length) return;
                    e.preventDefault();
                    addMaterials(files);
                  }}
                  onDragEnter={(e) => {
                    if (!e.dataTransfer.types.includes("Files")) return;
                    e.preventDefault();
                    imageDragDepth.current += 1;
                    setDraggingImages(true);
                  }}
                  onDragOver={(e) => {
                    if (!e.dataTransfer.types.includes("Files")) return;
                    e.preventDefault();
                    e.dataTransfer.dropEffect = !busy ? "copy" : "none";
                  }}
                  onDragLeave={(e) => {
                    e.preventDefault();
                    imageDragDepth.current = Math.max(0, imageDragDepth.current - 1);
                    if (!imageDragDepth.current) setDraggingImages(false);
                  }}
                  onDrop={(e) => {
                    if (!e.dataTransfer.types.includes("Files")) return;
                    e.preventDefault();
                    imageDragDepth.current = 0;
                    setDraggingImages(false);
                    const files = imageFiles(e.dataTransfer);
                    if (files.length) addMaterials(files);
                    else setError(t("请拖入 PNG 或 JPG 图片，也可点击＋上传 MP4 视频。"));
                  }}
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (canSend) void action("发送", send);
                  }}
                >
                  {draggingImages && <div className="composer-drop-hint" role="status">
                    <Image size={22} />
                    {busy ? t("请等待当前操作完成") : t("松开以添加参考图片")}
                  </div>}
                  {materials.length > 0 && <div className="composer-materials" aria-label={t("待发送素材")}>
                    {materials.map((item) => <div className="composer-material" key={item.id}>
                      {/\.(png|jpe?g)$/i.test(item.file.name) ? <button type="button" className="composer-material-preview"
                        aria-label={t("放大图片 {name}", { name: item.file.name })} onClick={() => setExpandedImage({ url: item.url, name: item.file.name })}>
                        <img src={item.url} alt={item.file.name} />
                      </button> : <a className="composer-material-preview composer-video-material" href={item.url} download={item.file.name} title={item.file.name}>
                        <FileVideo size={28} /><span>{item.file.name}</span>
                      </a>}
                      <button type="button" className="composer-material-remove" aria-label={t("移除素材 {name}", { name: item.file.name })}
                        title={t("移除素材")} disabled={!!busy} onClick={() => removeMaterial(item)}><X size={16} /></button>
                    </div>)}
                  </div>}
                  <ComposerInput
                    ref={composerInput}
                    enterToSend={!isMobile}
                    placeholder={project
                      ? t("描述空间布局、人物站位、动作和镜头运动…")
                      : t("描述你想创建的场景，发送即可开始创作…")}
                    canSend={canSend}
                    onHasTextChange={setHasText}
                  />
                  <div className="composer-toolbar">
                    <button
                      type="button"
                      title={t("上传参考素材，也可粘贴或拖入图片")}
                      aria-label={t("上传参考素材")}
                      disabled={!!busy}
                      onClick={() => upload.current?.click()}
                    >
                      <Plus size={19} />
                    </button>
                    <div className="composer-model-controls">
                    <ContextUsage key={`context:${pid}:${eventSession.current}`} events={activeEvents} capacity={selectedMaModel?.contextWindow} />
                    <ModelPicker key={pid} models={health.ma_models || []}
                      selected={chosenModelId}
                      locked={sessionUsesByok} disabled={!!busy}
                      onSelect={async (model) => {
                        const current = pid;
                        try {
                          const definition = (health.ma_models || []).find((m: MaModel) => m.id === model);
                          const result = await api("/ma/model", { model, reasoning_effort: definition?.reasoning_effort_default }, current);
                          if (pidRef.current === current) setHealth((h: any) => ({ ...h, ma: { ...h.ma, ...result } }));
                        } catch (err) { if (pidRef.current === current) setError(String(err)); throw err; }
                      }} />
                    <EffortPicker key={`effort:${pid}:${chosenModelId}`} model={chosenMaModel}
                      value={pendingModel ? pendingModel.effort : health.ma?.reasoning_effort} locked={sessionUsesByok} disabled={!!busy}
                      onSelect={async (reasoning_effort) => {
                        const current = pid;
                        try {
                          const result = await api("/ma/model", { model: chosenModelId, reasoning_effort }, current);
                          if (pidRef.current === current) setHealth((h: any) => ({ ...h, ma: { ...h.ma, ...result } }));
                        } catch (err) { if (pidRef.current === current) setError(String(err)); throw err; }
                      }} />
                    {pendingModel && <span className="model-pending-hint" role="status"
                      title={t("当前轮结束后、发送下一条消息前切换到 {model}", { model: chosenMaModel?.name || pendingModel.model })}>
                      {t("下一轮生效")}</span>}
                    </div>
                    {maRunning && hasDraft && <button type="button" aria-label={t("停止生成")} title={t("停止生成，保留输入草稿")} disabled={!!busy} onClick={() => void action("中断", async () => { await api("/ma/interrupt", {}, pid); })}><SquareFilled size={15} /></button>}
                    <button
                      type="button"
                      title={referenceRecovery ? t("新会话恢复：保留项目并跳过失效图片") : waitingForTools ? t("继续执行工具") : t("继续上次 MA 任务")}
                      disabled={!project?.session_id || blenderBusy}
                      onClick={() =>
                        action("继续", async () => {
                          await api("/ma/resume", {}, pid);
                        })
                      }
                    >
                      <RefreshCw size={15} />
                      {referenceRecovery && t("新会话恢复")}
                      {!referenceRecovery && waitingForTools && !running && t("继续执行工具")}
                    </button>
                  </div>
                  <button
                    className="composer-action"
                    type={showStop ? "button" : "submit"}
                    aria-label={busy === "中断" ? t("正在停止") : showStop ? t("停止生成") : t("发送创作指令")}
                    title={showStop ? t("停止生成") : isMobile ? t("发送消息") : t("发送消息（Enter）")}
                    disabled={showStop ? !!busy : !canSend}
                    onClick={showStop ? () => {
                      void action("中断", async () => {
                        await api("/ma/interrupt", {}, pid);
                      });
                    } : undefined}
                  >
                    {busy === "中断" || busy === "发送"
                      ? <LoaderCircle size={18} className="spin" />
                      : showStop ? <SquareFilled size={18} /> : <ArrowUp size={20} />}
                  </button>
                </form>
              </div>
            </section>
            {(isMobile || showRight) && (
              <>
                <div
                  className="resize-handle"
                  role="separator"
                  aria-label={t("调整对话与预览宽度")}
                  aria-orientation="vertical"
                  aria-valuenow={rightWidth}
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === "ArrowLeft")
                      setRightWidth(Math.min(65, rightWidth + 2));
                    if (e.key === "ArrowRight")
                      setRightWidth(Math.max(30, rightWidth - 2));
                  }}
                  onPointerDown={(e) =>
                    e.currentTarget.setPointerCapture(e.pointerId)
                  }
                  onPointerMove={(e) => {
                    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
                      const r = workspace.current!.getBoundingClientRect();
                      setRightWidth(
                        Math.max(
                          30,
                          Math.min(65, ((r.right - e.clientX) / r.width) * 100),
                        ),
                      );
                    }
                  }}
                />
                <section
                  className="preview-pane"
                  style={{ width: `${rightWidth}%` }}
                  aria-label={t("预览与视频生成区")}
                >
                  <div className="pane-tabs">
                    {[
                      ["preview", t("预览")],
                      ["seedance", t("视频生成")],
                    ].map(([v, label]) => (
                      <button
                        key={v}
                        className={
                          "pane-tab " +
                          (view === v ? "active" : "")
                        }
                        onClick={() => setView(v)}
                      >
                        {v === "seedance" ? (
                          <Sparkles size={13} />
                        ) : (
                          <Camera size={13} />
                        )}
                        <span>{label}</span>
                      </button>
                    ))}
                  </div>
                  <div className="blender-monitor">
                    <Window size={18} />
                    <div>
                      <strong>
                        {blender.error ? (project?.execution_info && project.execution_info.mode !== "local"
                          ? t("{server} 未连接", { server: project.execution_info.server_name || t("服务器") }) : t("Blender 状态暂不可用"))
                          : blender.running ? t("Blender 已打开") : t("Blender 未打开")}
                      </strong>
                      <small aria-live="polite">
                        {blender.error || (blender.mcp_connected
                          ? t("MCP 已连接")
                          : blender.launching
                            ? t("正在启动 MCP…")
                            : t("MCP 未连接"))}
                        <span
                          className={`mcp-status-dot${blender.mcp_connected ? " connected" : ""}`}
                          aria-hidden="true"
                        />
                        {blender.project_title
                          ? ` · ${blender.project_title}`
                          : ""}
                      </small>
                    </div>
                    <button
                      className="primary blender-open-button"
                      aria-busy={busy === "打开 Blender" || blender.launching}
                      disabled={!!busy || blender.launching}
                      onClick={openBlender}
                    >
                      {busy === "打开 Blender" || blender.launching ? (
                        <>
                          <LoaderCircle size={14} className="spin" />
                          {t("正在打开…")}
                        </>
                      ) : (
                        <>
                          {blender.running && blender.mcp_connected
                            ? t("打开 Blender")
                            : t("启动 Blender")}
                          <ExternalLink size={13} />
                        </>
                      )}
                    </button>
                  </div>
                  <div className="preview-scroll">
                    <div className="video-library-heading">
                      <span><FileVideo size={16} />{t("视频版本")} <strong>{videos.length}</strong></span>
                      <button type="button" className="outline" disabled={videos.length < 2}
                        title={videos.length < 2 ? t("保存至少两个 MP4 后即可对比") : t("选择两个视频并排对比")}
                        onClick={() => setComparingVideos(true)}>{t("对比视频")}</button>
                    </div>
                    {view === "seedance" ? (
                      <div className="seedance-panel">
                        <span className="eyebrow">VIDEO GENERATION</span>
                        <h2>{t("让场景成为影片")}</h2>
                        <p className="muted">
                          {t("以 Blender 预演运镜为基础，可叠加图片、视频、音频和人像库素材，生成、延长或编辑视频。")}
                        </p>
                        {pid && <SeedanceReferences pid={pid} refs={seedRefs} onChange={updateSeedRefs} platform={health.platform}
                          projectFiles={seedFiles} uploadAvailable={!!health.reference_upload_available}
                          disabled={!!busy || seedPending} />}
                        <label>
                          {t("视频提示词")}
                          <textarea
                            aria-label={t("Seedance 提示词")}
                            value={seedPrompt}
                            onChange={(e) => { seedPromptEdited.current = true; setSeedPrompt(e.target.value); }}
                          />
                        </label>
                        <button className="text-link" onClick={() => {
                          if (project) { seedPromptEdited.current = false; setSeedPrompt(videoPrompt(project)); }
                        }}>{t("根据当前会话重置提示词")}</button>
                        <div className="seed-parameters">
                          <label>{t("生成方式")}<select aria-label={t("Seedance 生成方式")} value={seedMode}
                            onChange={(e) => setSeedMode(e.target.value as SeedMode)}>
                            <option value="auto">{t("自动判断")}</option><option value="reference">{t("参考生成")}</option>
                            <option value="extend">{t("延长视频1")}</option><option value="edit">{t("编辑视频1")}</option>
                          </select></label>
                          <label>{seedMode === "extend" ? t("新增时长") : t("生成时长")}<select aria-label={t("Seedance 生成时长")} value={seedMode === "edit" ? -1 : seedDuration}
                            disabled={seedMode === "edit"}
                            onChange={(e) => setSeedDuration(Number(e.target.value))}>
                            <option value={-1} disabled={seedMode === "extend"}>{seedMode === "edit" ? t("保持原视频时长") : t("智能时长")}</option>
                            {Array.from({ length: 27 }, (_, i) => i + 4).map((seconds) =>
                              <option key={seconds} value={seconds}>{t("{seconds} 秒", { seconds })}</option>)}
                          </select></label>
                          <label>{t("分辨率")}<select aria-label={t("Seedance 分辨率")} value={seedResolution}
                            onChange={(e) => setSeedResolution(e.target.value)}>
                            <option value="480p">480p</option><option value="720p">720p</option><option value="1080p">1080p</option>
                          </select></label>
                          <label>{t("画面比例")}<select aria-label={t("Seedance 画面比例")} value={seedMode === "extend" || seedMode === "edit" ? "adaptive" : seedRatio}
                            disabled={seedMode === "extend" || seedMode === "edit"}
                            onChange={(e) => setSeedRatio(e.target.value)}>
                            {["16:9", "adaptive", "9:16", "4:3", "3:4", "1:1", "21:9"].map((ratio) =>
                              <option key={ratio} value={ratio}>{ratio === "adaptive" ? t("自适应") : ratio}</option>)}
                          </select></label>
                          <label className="seed-audio"><input type="checkbox" aria-label={t("生成声音")} checked={seedAudio}
                            onChange={(e) => setSeedAudio(e.target.checked)} />{t("生成声音")}</label>
                        </div>
                        {(seedMode === "extend" || seedMode === "edit") && <p className="muted">
                          {seedMode === "extend" ? t("从「视频1」结尾续写，生成所选新增时长的片段；下载后可作为下一段的参考视频。") : t("按提示词修改「视频1」，保留它的时长与画面比例。")}
                        </p>}
                        <button
                          className="primary wide"
                          disabled={
                            !project ||
                            !!busy ||
                            seedPending ||
                            cloudGenerating ||
                            !seedPrompt.trim()
                          }
                          onClick={generateVideo}
                        >
                          {busy === "提交 Seedance" || seedPending || cloudGenerating ? <LoaderCircle size={15} className="spin" /> : <Sparkles size={15} />}
                          {busy === "提交 Seedance" || seedPending ? (needsUpload(seedRefs) ? t("正在上传并提交…") : t("正在提交…")) : cloudGenerating ? t("正在生成视频…") : t("生成视频")}
                        </button>
                        {(seedPending || busy === "提交 Seedance" || seedTask) && <SeedanceProgress
                          status={seedStatus} uploading={seedPending || busy === "提交 Seedance"}
                          createdAt={currentSeedJob?.created_at} error={seedPollingError} />}
                        {seedError && <p className="inline-error seed-feedback" role="alert">{seedError}</p>}
                        {!seedError && seedJob && currentSeedJob?.status === "failed" && <p className="inline-error seed-feedback" role="alert">{t("提交失败：{error}", { error: currentSeedJob.error || "" })}</p>}
                        {!seedError && currentSeedJob?.result?.id && <p className="seed-feedback" role="status">
                          {t("已提交至 Seedance：{id}。可在下方查询生成状态并下载成片。", { id: currentSeedJob.result.id })}
                        </p>}
                        <p className="cost-note">{t("Seedance 2.5 · 提交后按模型 API 用量计费")}</p>
                        <details className="advanced-options">
                          <summary>{t("合成多个片段")}</summary>
                          <p className="muted">{t("按点击顺序拼接，保留各片段原声。输出为所选分辨率、24 fps；自动比例时使用 16:9。合成不调用模型。")}</p>
                          <div className="seed-tasks">
                            {videos.map((video) => <button key={video.name} type="button"
                              aria-pressed={composeClips.includes(video.name)}
                              onClick={() => setComposeClips((current) => current.includes(video.name)
                                ? current.filter((name) => name !== video.name) : [...current, video.name])}>
                              {composeClips.includes(video.name) ? `${composeClips.indexOf(video.name) + 1}. ` : "＋ "}{video.name}
                            </button>)}
                          </div>
                          {composeClips.length > 0 && <ol>{composeClips.map((name) => <li key={name}>{name}</li>)}</ol>}
                          <button type="button" className="outline" disabled={!!busy || !composeClips.length || jobs.some((j) => j.kind === "compose" && ["running", "queued"].includes(j.status))}
                            onClick={() => void action("合成视频", async () => {
                              const current = pid;
                              const job = await api("/seedance/compose", { clips: composeClips, resolution: seedResolution,
                                ratio: seedRatio === "adaptive" ? "16:9" : seedRatio }, current);
                              if (pidRef.current === current) setJobs((previous) => [...previous, job]);
                            })}>{t("合成所选片段")}</button>
                        </details>
                        <details className="advanced-options">
                          <summary>{t("查询与下载生成结果")}</summary>
                          <div className="seed-tasks">
                            {jobs
                              .filter(
                                (j) => j.kind === "seedance" && j.result?.id,
                              )
                              .map((j) => (
                                <button
                                  key={j.id}
                                  onClick={() => setSeedTask(j.result.id)}
                                >
                                  <FileVideo size={14} />
                                  {j.result.id}
                                </button>
                              ))}
                          </div>
                          <label>
                            {t("生成任务 ID")}
                            <input
                              aria-label={t("Seedance 任务 ID")}
                              value={seedTask}
                              onChange={(e) => setSeedTask(e.target.value)}
                            />
                          </label>
                          <div className="button-row">
                            <button
                              className="outline"
                              disabled={!seedTask || !!busy}
                              onClick={() =>
                                action("查询", async () =>
                                  setSeedStatus(
                                    await api(
                                      "/seedance/" + seedTask,
                                      undefined,
                                      pid,
                                    ),
                                  ),
                                )
                              }
                            >
                              <RefreshCw size={14} />
                              {t("查询状态")}
                            </button>
                            <button
                              className="outline"
                              disabled={!seedTask || !!busy}
                              onClick={() =>
                                action("下载成片", async () => {
                                  const result = await api(
                                    "/seedance/" + seedTask + "/download",
                                    {},
                                    pid,
                                  );
                                  setSeedStatus((status: any) => ({ ...status, artifact: result.artifact }));
                                })
                              }
                            >
                              <Download size={14} />
                              {t("下载成片到项目")}
                            </button>
                          </div>
                          {seedStatus && (
                            <pre className="result-json">
                              {JSON.stringify(seedStatus, null, 2)}
                            </pre>
                          )}
                        </details>
                      </div>
                    ) : (
                      <>
                        {project?.execution_info && project.execution_info.mode !== "local" && <RemoteDesktop key={project.id} projectId={project.id} info={project.execution_info} />}
                        <div className="preview-toolbar">
                          <h3 className="preview-section-title">{t("文件预览")}</h3>
                          <span>{selected?.name || t("等待首个画面")}</span>
                          {selected && <a href={appUrl(selected.url)} download title={t("下载当前文件")} aria-label={t("下载当前文件")}>
                            <Download size={14} />
                          </a>}
                        </div>
                        <div className="viewer">
                          {selected?.name.endsWith(".mp4") ? (
                            <video
                              key={selected.url}
                              src={appUrl(selected.url)}
                              controls
                              playsInline
                              preload="metadata"
                              poster={
                                artifacts.find(
                                  (a) =>
                                    a.name.startsWith("previews/") &&
                                    a.name.endsWith(".png"),
                                )?.url
                              }
                            />
                          ) : selected && /\.(mp3|wav)$/i.test(selected.name) ? (
                            <audio controls src={appUrl(selected.url)} aria-label={t("播放音频 {name}", { name: selected.name })} />
                          ) : selected &&
                            /\.(png|jpe?g)$/.test(selected.name) ? (
                            <button className="expand-image" aria-label={t("放大图片 {name}", { name: selected.name })}
                              onClick={() => setExpandedImage(selected)}><img alt={selected.name} src={appUrl(selected.url)} /></button>
                          ) : (
                            <div className="empty-view">
                              <Box size={40} />
                              <p>
                                {selected?.name.endsWith(".blend")
                                  ? t("Blender 工程文件")
                                  : t("你的画面将在这里出现")}
                              </p>
                              <small>
                                {selected?.name.endsWith(".blend")
                                  ? t("下载工程，或在下方 Blender 视窗检查模型。")
                                  : t("发送提示词，或打开已有项目文件。")}
                              </small>
                            </div>
                          )}
                        </div>
                        <div className="preview-meta">
                          <span>
                            {selected?.video ? <>
                              {selected.video.height}p · {selected.video.fps ? `${selected.video.fps} fps · ` : ""}
                              {t("{seconds} 秒", { seconds: selected.video.duration })}
                            </> : <>{project?.settings.resolution} ·{" "}
                            {project?.settings.fps} fps · {t("目标 {seconds} 秒", { seconds: project?.settings.duration ?? "" })}</>}
                          </span>
                          {project?.demo && <span>{t("CG 预演")}</span>}
                        </div>
                        {health.render_progress?.status === "running" && (
                          <div className="render-progress">
                            <progress
                              value={
                                health.render_progress.completed ||
                                health.render_progress.frame
                              }
                              max={health.render_progress.total}
                            />
                            <small>
                              {t("渲染帧 {frame} / {total}", { frame: health.render_progress.frame, total: health.render_progress.total })}
                            </small>
                          </div>
                        )}
                        <section className="blender-viewport-section" aria-labelledby="blender-viewport-title">
                          <div className="preview-toolbar">
                            <h3 id="blender-viewport-title" className="preview-section-title">{t("Blender 视窗")}</h3>
                            <button type="button" className="viewport-refresh" aria-label={t("刷新 Blender 视窗")}
                              title={!project ? t("请先选择项目") : !blender.mcp_connected ? t("启动 Blender 并连接后可刷新") : blenderBusy ? t("当前任务结束后可刷新视窗") : t("获取当前 Blender 画面")}
                              disabled={blenderBusy || !blender.mcp_connected || !project}
                              onClick={() => void action("获取视窗", async () => {
                                const current = pid;
                                const result = await api("/blender/screenshot", {}, current);
                                const image = result.content?.find((item: any) => item.type === "image");
                                if (!image) throw Error(result.content?.[0]?.text || t("未返回截图"));
                                if (pidRef.current === current) setScreen(`data:${image.mimeType};base64,${image.data}`);
                              })}>
                              <RefreshCw size={14} className={busy === "获取视窗" ? "spin" : ""} />
                              {busy === "获取视窗" ? t("刷新中…") : t("刷新视窗")}
                            </button>
                          </div>
                          <div className="viewer">
                            {displayScreen ? <button type="button" className="expand-image" aria-label={t("放大当前 Blender 视窗")}
                              onClick={() => setExpandedImage({ url: displayScreen, name: t("Blender 视窗截图.png") })}>
                              <img alt={t("当前项目 Blender 视窗截图")} src={displayScreen} />
                            </button> : <div className="empty-view">
                              <Box size={40} />
                              <p>{t("Blender 视窗画面")}</p>
                              <small>{!project ? t("选择项目后查看模型与镜头") : !blender.mcp_connected ? t("启动 Blender 后，点击刷新视窗获取画面") : t("点击刷新视窗获取当前画面")}</small>
                            </div>}
                          </div>
                        </section>
                        <details className="deliverables" open>
                          <summary className="section-heading">
                            {t("产物")}<span>{files.length}</span>
                          </summary>
                          {files.map((a) => (
                            <article className="artifact-card" key={`${pid}:${a.name}`}>
                              {/\.(png|jpe?g)$/i.test(a.name) && (
                                <button
                                  className="artifact-image-preview"
                                  onClick={() => setExpandedImage(a)}
                                  aria-label={t("预览图片 {name}", { name: a.name })}
                                  title={t("点击查看大图")}
                                >
                                  <img src={appUrl(a.url)} alt={a.name} loading="lazy" decoding="async" />
                                </button>
                              )}
                              {/\.mp4$/i.test(a.name) && (
                                <video
                                  className="artifact-video-preview"
                                  src={appUrl(a.url)}
                                  controls
                                  playsInline
                                  preload="metadata"
                                  aria-label={t("播放视频 {name}", { name: a.name })}
                                />
                              )}
                              {/\.(mp3|wav)$/i.test(a.name) && <audio controls src={appUrl(a.url)}
                                preload="metadata" aria-label={t("播放音频 {name}", { name: a.name })} />}
                            <div className="artifact-row" key={a.name}>
                              <button onClick={() => choose(a)}>
                                {a.name.endsWith(".blend") ? (
                                  <FileBox size={17} />
                                ) : a.name.endsWith(".mp4") ? (
                                  <FileVideo size={17} />
                                ) : (
                                  <Image size={17} />
                                )}
                                <span>
                                  {a.name}
                                  <small>
                                    {a.name.endsWith(".blend") ? t("Blender 工程 · ") : a.name.endsWith(".mp4") ? t("视频 · ") : t("检查帧 · ")}
                                    {(a.bytes / 1024 / 1024).toFixed(1)} MB
                                  </small>
                                </span>
                              </button>
                              <button
                                className="artifact-reveal"
                                title={t("打开所在文件夹")}
                                aria-label={t("打开 {name} 所在文件夹", { name: a.name })}
                                disabled={!!busy}
                                onClick={() => action("打开文件夹", async () => {
                                  await api("/artifacts/open-folder", { name: a.name }, pid);
                                })}
                              >
                                <Folder size={14} />
                              </button>
                              <a href={appUrl(a.url)} download title={t("下载 {name}", { name: a.name })}>
                                <Download size={14} />
                              </a>
                            </div>
                            </article>
                          ))}
                          {!files.length && (
                            <p className="muted">
                              {t("开始创作后，自动保存的 Blender 工程、检查帧和视频会显示在这里。")}
                            </p>
                          )}
                        </details>
                        {blend && (
                          <a className="open-blend" href={appUrl(blend.url)} download>
                            <Download size={14} />
                            {t("下载 Blender 工程")}
                            <ChevronRight size={14} />
                          </a>
                        )}
                      </>
                    )}
                  </div>
                </section>
              </>
            )}
          </div>
        </div>
      </div>
      <footer className="statusbar">
        <span>
          <span className={offline ? "status-dot bad" : "status-dot"} />
          {offline ? t("服务连接中断") : health.edition === "cloud" ? t("Elsa 云端执行") : project?.execution_info?.mode === "self_hosted" ? t("{server} 远程执行", { server: project.execution_info.server_name || "" }) : t("Mac 本地执行")}
        </span>
        <span>
          {health.api_key_configured ? t("API Key 已配置") : t("API Key 待配置")}
          <span
            className={`api-key-status-dot${health.api_key_configured ? " configured" : ""}`}
            aria-hidden="true"
          />
        </span>
        <span className="status-right">
          {busy ? t(busy) : "MA → Blender → Seedance"}
        </span>
      </footer>
      {error && (
        <div role="alert" className="toast">
          <CircleAlert size={18} />
          <span>{error}</span>
          <button aria-label={t("关闭错误提示")} onClick={() => setError("")}>
            <X size={16} />
          </button>
        </div>
      )}
      <input
        ref={upload}
        type="file"
        hidden
        multiple
        accept=".mp4,.png,.jpg,.jpeg"
        onChange={(e) => {
          addMaterials(Array.from(e.target.files || []));
          e.target.value = "";
        }}
      />

      <ImageLightbox image={expandedImage} onClose={() => setExpandedImage(null)} />
      {comparingVideos && <VideoCompare key={pid} videos={videos} onClose={() => setComparingVideos(false)} />}
      {showSettings && <SettingsDialog configured={!!health.api_key_configured}
        maskedKey={health.api_key_masked}
        platform={health.platform} platforms={health.platforms}
        onPlatformChanged={() => refresh().catch(() => setOffline(true))}
        onModelsChanged={() => { void refresh().catch(() => setOffline(true)); }}
        onClose={() => setShowSettings(false)}
        onSaved={(maskedKey) => {
          setHealth((h: any) => ({ ...h, api_key_configured: true, api_key_masked: maskedKey }));
          void refresh().catch(() => setOffline(true));
        }} />}
      {nameDialog === "create" && (
        <div className="modal-backdrop" onMouseDown={(e) => {
          if (e.target === e.currentTarget && !busy) setNameDialog(null);
        }}>
          <form className="new-dialog task-name-dialog" role="dialog" aria-modal="true"
            aria-labelledby="task-name-title" onSubmit={(e) => { e.preventDefault(); if (!busy) void saveTaskName(); }}
            onKeyDown={(e) => { if (e.key === "Escape" && !busy) setNameDialog(null); }}>
            <button type="button" className="dialog-close" aria-label={t("关闭命名窗口")}
              disabled={!!busy} onClick={() => setNameDialog(null)}><X size={19} /></button>
            <h2 id="task-name-title">{nameDialog === "create" ? t("新建任务") : t("重命名任务")}</h2>
            <label>
              {t("任务名称")}
              <input autoFocus aria-label={t("任务名称")} placeholder={t("例如：拙政园-见山楼漫游")}
                value={taskName} maxLength={100} disabled={!!busy}
                onBlur={(e) => setTaskName(e.currentTarget.value.trim())}
                aria-invalid={!!nameError} aria-describedby={nameError ? "task-name-error" : "task-name-hint"}
                onChange={(e) => { setTaskName(e.target.value); setNameError(""); }} />
            </label>
            <small id="task-name-hint">{t("使用连字符分隔，名称不能与已有任务重复。")}</small>
            {nameError && <p id="task-name-error" role="alert" className="inline-error">{nameError}</p>}
            <button className="primary wide" disabled={!!busy || !taskName.trim()}>
              {busy ? <LoaderCircle size={15} className="spin" /> : null}
              {nameDialog === "create" ? t("创建任务") : t("保存名称")}
            </button>
          </form>
        </div>
      )}

    </div>
  );
}
installClickFocus();
createRoot(document.getElementById("root")!).render(<App />);
