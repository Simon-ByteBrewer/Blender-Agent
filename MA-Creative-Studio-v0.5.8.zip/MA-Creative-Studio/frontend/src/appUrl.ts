/** Resolve app-owned URLs under either the local root or the cloud mount. */
export function appUrl(path: string, base = typeof window === "undefined" ? "/" : new URL(".", window.location.href).pathname): string {
  if (!path.startsWith("/") || path.startsWith("//") || base === "/") return path;
  if (path === base.slice(0, -1) || path.startsWith(base)) return path;
  return base + path.slice(1);
}

export function appFetch(path: string, init?: RequestInit): Promise<Response> {
  return fetch(appUrl(path), init);
}
