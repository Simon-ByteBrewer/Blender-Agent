import { appUrl } from "./appUrl";
import { useEffect, useRef, useState } from "react";
import { Download, X } from "./icons";
import { t } from "./i18n";

export type PreviewImage = { url: string; name: string };

export function ImageLightbox({ image, onClose }: { image: PreviewImage | null; onClose: () => void }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [original, setOriginal] = useState(false);
  useEffect(() => {
    if (!image) return;
    setOriginal(false);
    dialog.current?.showModal();
    return () => dialog.current?.close();
  }, [image]);
  if (!image) return null;
  return <dialog ref={dialog} className="image-lightbox" aria-label={t("图片预览：{name}", { name: image.name })}
    onCancel={(e) => { e.preventDefault(); onClose(); }}
    onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
    <div className="image-lightbox-header">
      <span title={image.name}>{image.name}</span>
      <button type="button" onClick={() => setOriginal(!original)} aria-pressed={original}>
        {original ? t("适应窗口") : t("原始尺寸")}
      </button>
      <a href={appUrl(image.url)} download={image.name.split("/").pop()} aria-label={t("下载原图")}><Download size={18} /></a>
      <button type="button" autoFocus onClick={onClose} aria-label={t("关闭图片预览")}><X size={21} /></button>
    </div>
    <div className={`image-lightbox-canvas${original ? " original-size" : ""}`}>
      <img src={appUrl(image.url)} alt={image.name} />
    </div>
  </dialog>;
}
