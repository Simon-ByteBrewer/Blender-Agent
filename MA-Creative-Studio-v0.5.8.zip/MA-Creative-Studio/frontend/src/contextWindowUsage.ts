import { eventTime } from "./chatState";

export type ContextEvent = {
  id: string; type: string; processed_at?: string; created_at?: string;
  session_thread_id?: string | null; model_request_start_id?: string;
  is_error?: boolean; _streaming?: boolean; _stream_incomplete?: boolean;
  model_usage?: { input_tokens?: number; output_tokens?: number } | null;
};

export function formatTokenCount(tokens: number) {
  if (tokens >= 1_000_000) return `${Number((tokens / 1_000_000).toFixed(2))}M`;
  if (tokens >= 1000) return `${Number((tokens / 1000).toFixed(1))}K`;
  return String(tokens);
}

// This is a last-request estimate, not Session billing totals or the runtime's
// exact retained context. The event API defines input_tokens as total input;
// cache counters are not added again. Output can include non-retained reasoning.
export function contextUsage(events: ContextEvent[]) {
  const ordered = [...new Map(events.map(e => [e.id, e])).values()]
    .sort((a, b) => eventTime(a) - eventTime(b));
  const byId = new Map(ordered.map(e => [e.id, e]));
  const thread = (e: ContextEvent) => e.session_thread_id
    || byId.get(e.model_request_start_id || "")?.session_thread_id || null;
  const requests = ordered.filter(e => e.type === "span.model_request_end");
  const threads = new Set(requests.map(thread));
  // Legacy single-agent events have no thread ID. Never substitute a child
  // thread's usage for the main Agent; ambiguous multi-agent histories stay unknown.
  const primary = threads.has(null) ? null : threads.size === 1
    && !ordered.some(e => e.type === "session.thread_created") ? [...threads][0] : undefined;
  if (primary === undefined) return { status: "unavailable" as const };
  let result: { status: "available"; tokens: number; updatedAt: string | undefined } |
    { status: "unavailable" | "compacted" } = { status: "unavailable" };
  for (const event of ordered) {
    if (thread(event) !== primary) continue;
    if (event.type === "agent.thread_context_compacted") {
      result = { status: "compacted" };
      continue;
    }
    if (event.type !== "span.model_request_end" || event.is_error || event._streaming || event._stream_incomplete) continue;
    const { input_tokens: input, output_tokens: output } = event.model_usage || {};
    if (!Number.isSafeInteger(input) || input! < 0 || !Number.isSafeInteger(output) || output! < 0) {
      result = { status: "unavailable" };
      continue;
    }
    const tokens = input! + output!;
    result = Number.isSafeInteger(tokens)
      ? { status: "available", tokens, updatedAt: event.processed_at }
      : { status: "unavailable" };
  }
  return result;
}
