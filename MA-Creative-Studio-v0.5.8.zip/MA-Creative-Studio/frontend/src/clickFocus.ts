// WebKit (Safari and the macOS app's WKWebView) does not focus buttons on mouse
// click. Focus then leaves the previous element with no next target,
// and popovers that close on blur swallow the click. Chromium focuses them, so
// give every engine Chromium's behaviour once, for all current and future UI.
// Links are left alone so text selection and link dragging in messages still work.
const FOCUSABLE_ON_CLICK = 'button, summary, [role="option"], [role="tab"], [role="menuitem"]';

export function installClickFocus(doc: Document = document) {
  doc.addEventListener("mousedown", (event) => {
    if (event.button !== 0) return;
    const target = (event.target as Element | null)?.closest?.(FOCUSABLE_ON_CLICK);
    if (!(target instanceof HTMLElement) || target.matches(":disabled") || doc.activeElement === target) return;
    target.focus({ preventScroll: true });
    // Required: WebKit's default mousedown handling would move focus away again.
    event.preventDefault();
  }, true);
}
