const common: Record<string, string> = {
  "MA 导演 Agent": "MA Director Studio",
  "语言": "Language",
  "火山方舟": "Volcengine Ark",
  "已完成": "Completed",
};

export default common;
