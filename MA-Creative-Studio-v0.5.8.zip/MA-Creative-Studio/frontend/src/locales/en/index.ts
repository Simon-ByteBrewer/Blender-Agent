// English UI text keyed by the Chinese source string. One file per area of
// the app keeps translations next to the components that own them.
import common from "./common";
import main from "./main";
import settings from "./settings";
import media from "./media";

export const EN: Record<string, string> = { ...common, ...main, ...settings, ...media };
