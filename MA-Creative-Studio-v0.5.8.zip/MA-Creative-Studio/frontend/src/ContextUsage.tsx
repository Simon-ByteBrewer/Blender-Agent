import { useId, useMemo, useState } from "react";
import { contextUsage, formatTokenCount, type ContextEvent } from "./contextWindowUsage";
import { t } from "./i18n";
import "./ContextUsage.css";

export function ContextUsage({ events, capacity }: { events: ContextEvent[]; capacity?: number }) {
  const usage = useMemo(() => contextUsage(events), [events]);
  const [open, setOpen] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const id = useId();
  const knownCapacity = typeof capacity === "number" && Number.isFinite(capacity) && capacity > 0;
  const available = usage.status === "available" && knownCapacity;
  const percent = available ? Math.round(usage.tokens / capacity! * 100) : null;
  const used = percent == null ? "" : t("约 {used}% 已用（{left}% 剩余）", { used: percent, left: Math.max(0, 100 - percent) });
  return <div className="context-usage" onMouseEnter={() => { setDismissed(false); setOpen(true); }}
    onMouseLeave={() => setOpen(false)} onFocus={() => { setDismissed(false); setOpen(true); }}
    onBlur={() => setOpen(false)} onKeyDown={e => { if (e.key === "Escape") { setOpen(false); setDismissed(true); } }}>
    <button type="button" className="context-usage-trigger" aria-label={used ? t("上下文窗口：{usage}", { usage: used }) : t("上下文窗口：暂无用量数据")}
      aria-describedby={open && !dismissed ? id : undefined} onClick={() => { setDismissed(false); setOpen(true); }}>
      <svg width="18" height="18" viewBox="0 0 20 20" aria-hidden="true">
        <circle className="context-ring-track" cx="10" cy="10" r="7" fill="none" strokeWidth="2.5" />
        {percent !== null && <circle className="context-ring-used" cx="10" cy="10" r="7" fill="none" strokeWidth="2.5"
          pathLength="100" strokeDasharray={`${Math.min(100, percent)} 100`} transform="rotate(-90 10 10)" strokeLinecap="round" />}
      </svg>
    </button>
    {open && !dismissed && <div className="context-usage-tooltip" role="tooltip" id={id}>
      <span className="context-usage-heading">Context window</span>
      {available ? <>
        <strong>{used}</strong>
        <span title={`${usage.tokens.toLocaleString()} / ${capacity!.toLocaleString()} tokens`}>
          {formatTokenCount(usage.tokens)} / {formatTokenCount(capacity!)} tokens
        </span>
        <small>{t("最近一次请求估算 · 非累计消耗")}<br />{t("窗口上限参考模型配置，MA 可能提前压缩")}</small>
      </> : <>
        <strong>{usage.status === "compacted" ? t("上下文已压缩，等待更新") : t("等待上下文用量数据")}</strong>
        {knownCapacity && <span>{t("模型窗口 {size} tokens", { size: formatTokenCount(capacity!) })}</span>}
      </>}
    </div>}
  </div>;
}
