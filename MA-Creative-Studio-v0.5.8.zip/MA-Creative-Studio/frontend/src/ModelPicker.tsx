import { useEffect, useId, useRef, useState } from "react";
import { Check, ChevronDown } from "./icons";
import ModelLogo from "./ModelLogo";
import { t } from "./i18n";
import "./ModelPicker.css";
import { displayModelId, formatContextWindow, modelOptions, type MaModel } from "./modelPresentation";

export function ModelPicker({ models, selected, locked = false, disabled = false, onSelect }: {
  models: MaModel[]; selected: string; locked?: boolean; disabled?: boolean;
  onSelect: (id: string) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const listId = useId();
  const { current, options } = modelOptions(models, selected, locked);
  const selectedName = current?.name || selected;
  const isByok = (model: MaModel) => model.byok || model.id.startsWith("byok:");
  const groups = [
    { label: t("MA 模型"), models: options.filter(model => !isByok(model)) },
    { label: t("自定义模型 BYOK"), models: options.filter(isByok) },
  ].filter(group => group.models.length);
  useEffect(() => {
    if (!open) return;
    const close = (e: PointerEvent) => { if (!root.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, [open]);
  useEffect(() => {
    if (open) (root.current?.querySelector<HTMLButtonElement>('[aria-selected="true"]')
      || root.current?.querySelector<HTMLButtonElement>('[role="option"]'))?.focus();
  }, [open]);
  return <div className="model-picker" ref={root} onBlur={(e) => {
    // WebKit (Safari, the macOS app) does not focus a clicked button, so pressing
    // an option blurs with no next target; closing then would swallow the click.
    // Outside clicks are handled by the pointerdown listener above.
    if (e.relatedTarget && !e.currentTarget.contains(e.relatedTarget as Node)) setOpen(false);
  }} onKeyDown={(e) => {
    if (e.key === "Escape") { e.preventDefault(); setOpen(false); trigger.current?.focus(); }
    if (["ArrowDown", "ArrowUp", "Home", "End"].includes(e.key)) {
      e.preventDefault();
      if (!open) { setOpen(true); return; }
      const buttons = Array.from(root.current?.querySelectorAll<HTMLButtonElement>('[role="option"]') || []);
      const i = buttons.indexOf(document.activeElement as HTMLButtonElement);
      const next = e.key === "Home" ? 0 : e.key === "End" ? buttons.length - 1
        : (i + (e.key === "ArrowDown" ? 1 : -1) + buttons.length) % buttons.length;
      buttons[next]?.focus();
    }
  }}>
    <button className="model-picker-trigger" ref={trigger} type="button" title={current?.model_id || selected}
      aria-label={t("选择模型")} aria-haspopup="listbox" aria-expanded={open} aria-controls={listId}
      disabled={disabled || saving || !models.length} onClick={() => setOpen(!open)}>
      <ModelLogo modelId={current?.model_id || selected} size={16} />
      <span className="model-picker-name">{selectedName || t("选择模型")}</span>
      <ChevronDown size={13} />
    </button>
    {open && <div className="model-picker-popover">
      <div id={listId} role="listbox" aria-label={t("可用模型")}>
        {groups.map(group => <div className="model-picker-group" role="group" aria-label={group.label} key={group.label}>
          <div className="model-picker-heading" aria-hidden="true">{group.label}</div>
        {group.models.map((model) => <button type="button" role="option" key={model.id}
          aria-selected={displayModelId(model.id) === displayModelId(selected)} aria-disabled={locked || saving}
          title={model.model_id || model.id} className="model-picker-option" onClick={async () => {
            if (locked || saving) return;
            if (model.id === selected) { setOpen(false); trigger.current?.focus(); return; }
            setSaving(true);
            try { await onSelect(model.id); setOpen(false); trigger.current?.focus(); }
            catch { /* The parent displays the API error; keep the current model. */ }
            finally { setSaving(false); }
          }}>
          <ModelLogo modelId={model.model_id || model.id} size={16} />
          <span className="model-picker-name">{model.name}</span>
          {model.contextWindow ? <span className="model-context" title={`${model.contextWindow.toLocaleString()} tokens`}>{formatContextWindow(model.contextWindow)}</span> : null}
          <span className="model-selected">{displayModelId(model.id) === displayModelId(selected) && <Check size={14} />}</span>
        </button>)}
        </div>)}
      </div>
    </div>}
  </div>;
}
