import { useEffect, useState } from "react";
import { getLanguage, t } from "./i18n";

function clockTime(seconds: number) {
  seconds = Math.max(0, Math.round(seconds));
  return seconds < 60 ? t("{s} 秒", { s: seconds }) : t("{m} 分 {s} 秒", { m: Math.floor(seconds / 60), s: seconds % 60 });
}

export function SeedanceProgress({ status, uploading, createdAt, error }: {
  status: any; uploading: boolean; createdAt?: number; error: string;
}) {
  const [now, setNow] = useState(Date.now() / 1000);
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now() / 1000), 1000);
    return () => clearInterval(timer);
  }, []);
  const info = status?.studio_progress;
  const finished = info?.finished || ["succeeded", "failed", "expired", "cancelled"].includes(status?.status);
  const succeeded = status?.status === "succeeded";
  const elapsed = uploading ? Math.max(0, now - (createdAt || now))
    : finished ? info?.elapsed_seconds || 0 : info?.started_at ? Math.max(0, now - info.started_at) : 0;
  const expected = info?.estimated_seconds || 0;
  const percent = succeeded ? 100 : expected ? Math.min(99, Math.floor(elapsed / expected * 100)) : 0;
  const remaining = Math.max(0, expected - elapsed);
  return <section className="seed-progress" aria-label={t("Seedance 生成进度")}>
    <div className="seed-progress-title"><strong>
      {t(uploading ? "正在上传并提交" : succeeded ? "视频已生成" : finished ? "生成未完成" : status?.status === "queued" ? "排队生成中" : "视频生成中")}
    </strong><span>{succeeded ? "100%" : finished ? t("已停止") : t("预计进度 {percent}%", { percent })}</span></div>
    <progress aria-label={succeeded ? t("生成完成") : t("预计生成进度")} max={100}
      value={uploading || (!expected && !finished) ? undefined : percent} />
    <div className="seed-progress-times"><span>{t("已耗时 {time}", { time: clockTime(elapsed) })}</span>
      <span>{finished ? succeeded ? t("已完成") : t("已结束") : uploading ? t("提交后估算完成时间")
        : expected ? remaining > 0 ? t("预计剩余 {time}", { time: clockTime(remaining) }) : t("已超过预估，仍在生成") : t("正在获取预估时间")}</span></div>
    {!finished && !uploading && expected > 0 && remaining > 0 && <small>
      {t("预计 {time} 完成", { time: new Date((info.started_at + expected) * 1000).toLocaleTimeString(getLanguage() === "zh" ? "zh-CN" : "en", { hour: "2-digit", minute: "2-digit" }) })}
    </small>}
    {!finished && !uploading && <small>{info?.estimate_source === "history" ? t("根据历史成功任务耗时估算，以实际生成状态为准。") : t("暂无历史样本，使用初始耗时估算，以实际生成状态为准。")}</small>}
    {finished && !succeeded && <p role="alert">{status?.error?.message || t("任务已停止，请调整提示词或参数后重试。")}</p>}
    {error && <p role="status">{t("状态查询暂时失败，正在重试：{error}", { error })}</p>}
  </section>;
}
