import { t } from "./i18n";

export function referenceVideoName(names: string[], chosen: string, preferred?: string) {
  return [chosen, preferred, ...names.filter((name) => !name.startsWith("seedance_")), ...names]
    .find((name) => name && names.includes(name)) || "";
}

export function videoPrompt(project: { title: string; prompt: string }) {
  const description = project.prompt
    .replace(/^\[平台项目上下文\].*\n/g, "")
    .replace(/使用\s*Blender\s*MCP\s*[，,]?/gi, "")
    .replace(/创建用于运镜验证的简化\s*3D\s*场景[，,。]?/g, "")
    .replace(/(?:无需|不要)联网[，,。]?/g, "")
    .replace(/不追求精细装饰[，,。]?/g, "")
    .split(/\n|(?<=[。；])/)
    .filter((line) => !/(?:保存|输出|写入).*(?:\.blend|目录|路径)|bpy\.|无需联网|不要联网|MCP|\/Users\/|\/artifacts\//i.test(line))
    .join("\n").trim().slice(0, 3500);
  return [
    `影片主题：${project.title}。`,
    description ? `场景与镜头描述：\n${description}` : "场景内容以参考视频中呈现的主体和环境为准。",
    "参考片分工：输入视频是轻量 3D 空间与运镜预演。灰模、纯色色块和简模人物仅表示体块、位置、朝向与动作，不是最终外观。根据内容描述重建成片的真实材质、人物外观、建筑装饰、环境细节和自然光照；如指定其他美术风格则遵循该风格。",
    "运镜参考：以参考视频为相机运动和机位切换依据，保持主体位置、真实尺度、空间连通、遮挡关系、人物数量/站位/朝向/走位、构图、运动方向及镜头先后顺序。按所选生成时长调整各段节奏，视角变化自然连贯。",
    "画面要求：遵循场景描述中的视觉风格，完善材质、光照、阴影和环境细节，保持主体外观与空间结构一致。避免闪烁、几何变形、物体漂移和无依据的场景切换；不增加字幕、标题或水印。",
  ].join("\n\n");
}

export type SeedRefType = "image" | "video" | "audio";
export type SeedMode = "auto" | "reference" | "extend" | "edit";
export type SeedRef = {
  key: string; type: SeedRefType; source: string; name: string;
  origin: "project" | "upload" | "url" | "portrait"; preview?: string;
};
export type Portrait = { id: string; name: string; asset_id: string; kind: "image" | "video"; note?: string };

// Seedance 2.5 omni-reference limits.
export const SEED_LIMITS = { image: 30, video: 10, audio: 10 } as const;

/** The prompt refers to materials as 图片N / 视频N, numbered within each type. */
export function referenceLabels(refs: Pick<SeedRef, "type">[]): string[] {
  const count = { image: 0, video: 0, audio: 0 };
  return refs.map((ref) => `${{ image: "图片", video: "视频", audio: "音频" }[ref.type]}${++count[ref.type]}`);
}

export function isLocalSource(source: string) {
  return !/^(https?:\/\/|asset:\/\/|data:)/i.test(source);
}

export function needsUpload(refs: SeedRef[]) {
  return refs.some((ref) => ref.type === "video" && isLocalSource(ref.source));
}

export function sourceType(source: string): SeedRefType | null {
  const path = source.split(/[?#]/)[0].toLowerCase();
  if (/\.(mp4|mov)$/.test(path)) return "video";
  if (/\.(mp3|wav)$/.test(path)) return "audio";
  if (/\.(png|jpe?g|webp|bmp|gif|heic|heif|tiff?)$/.test(path)) return "image";
  return null;
}

/** Returns an error message, or "" when the address can be sent to Seedance. */
export function remoteSourceError(source: string, type: SeedRefType) {
  if (/^asset:\/\/asset-[A-Za-z0-9-]{4,120}$/.test(source)) return "";
  if (!/^https:\/\//i.test(source)) return t("请填写 https:// 地址或 asset://asset-xxxx 素材 ID");
  try { new URL(source); } catch { return t("地址格式不正确"); }
  const detected = sourceType(source);
  return detected && detected !== type ? t("该地址看起来是{type}，请切换素材类型", { type: t({ image: "图片", video: "视频", audio: "音频" }[detected]) }) : "";
}

export function addReference(refs: SeedRef[], ref: SeedRef): SeedRef[] {
  if (refs.some((item) => item.type === ref.type && item.source === ref.source)) return refs;
  if (refs.filter((item) => item.type === ref.type).length >= SEED_LIMITS[ref.type])
    throw new Error(t({ image: "最多添加 {n} 个参考图", video: "最多添加 {n} 个参考视频", audio: "最多添加 {n} 个参考音频" }[ref.type], { n: SEED_LIMITS[ref.type] }));
  return [...refs, ref];
}

export function referencePayload(refs: SeedRef[]) {
  return refs.map(({ type, source }) => ({ type, source }));
}
