import { t } from "./i18n";

const imageExtensions = /\.(png|jpe?g)$/i;
const imageTypes = new Map([['image/png', 'png'], ['image/jpeg', 'jpg']]);

export type DraftMaterial = {
  id: string; file: File; url: string;
  uploaded?: { name: string; url: string };
};

export function materialMessage(text: string, materials: { name: string; url: string; image: boolean }[]) {
  return [text, ...materials.map((item) => {
    const label = `参考素材 ${item.name}`.replace(/[\\\[\]]/g, '\\$&').replace(/[\r\n]/g, ' ');
    const url = item.url.split('/').map((part) => encodeURIComponent(part).replace(/[!'()*]/g, (char) => '%' + char.charCodeAt(0).toString(16))).join('/');
    return `${item.image ? '!' : ''}[${label}](${url})`;
  })].filter(Boolean).join('\n\n');
}

export function imageFiles(data: DataTransfer): File[] {
  const files = Array.from(data.files);
  if (!files.length) {
    for (const item of Array.from(data.items)) {
      if (item.kind !== 'file') continue;
      const file = item.getAsFile();
      if (file) files.push(file);
    }
  }
  return files.filter((file) => file.type.startsWith('image/') || imageExtensions.test(file.name));
}

export function uploadFile(file: File): File {
  const extension = imageTypes.get(file.type);
  const isImage = extension || (!file.type && imageExtensions.test(file.name));
  const isVideo = file.type === 'video/mp4' || (!file.type && /\.mp4$/i.test(file.name));
  if (!isImage && !isVideo) throw new Error(t('仅支持 PNG、JPG 图片和 MP4 视频。'));
  if (file.size > 50 * 1024 * 1024) throw new Error(t('{name} 超过 50 MB，请缩小后重试。', { name: file.name || t('素材') }));
  if (extension && !imageExtensions.test(file.name)) {
    return new File([file], `${file.name || t('粘贴图片')}.${extension}`, { type: file.type });
  }
  return file;
}
