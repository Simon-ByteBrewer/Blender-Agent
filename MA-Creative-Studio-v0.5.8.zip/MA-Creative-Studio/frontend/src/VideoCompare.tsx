import { appUrl } from "./appUrl";
import { useEffect, useRef, useState } from "react";
import { Download, Play, Square, X } from "./icons";
import { getLanguage, t } from "./i18n";

type Video = { name: string; url: string; bytes: number; modified_at?: number };

export function VideoCompare({ videos, onClose }: { videos: Video[]; onClose: () => void }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const players = useRef<(HTMLVideoElement | null)[]>([]);
  const [names, setNames] = useState([videos[0]?.name || "", videos[1]?.name || ""]);
  const [error, setError] = useState("");
  const [starting, setStarting] = useState(false);
  const playbackAttempt = useRef(0);
  const selected = names.map((name) => videos.find((video) => video.name === name));
  const pause = () => {
    playbackAttempt.current += 1;
    players.current.forEach((player) => player?.pause());
    setStarting(false);
  };
  useEffect(() => {
    const modal = dialog.current;
    const activePlayers = players.current;
    modal?.showModal();
    return () => {
      playbackAttempt.current += 1;
      activePlayers.forEach((player) => player?.pause());
      modal?.close();
    };
  }, []);
  async function playTogether() {
    pause();
    const attempt = playbackAttempt.current;
    setStarting(true);
    setError("");
    const active = players.current.filter((player): player is HTMLVideoElement => !!player);
    try {
      active.forEach((player) => { player.currentTime = 0; player.playbackRate = 1; });
      const results = await Promise.allSettled(active.map((player) => player.play()));
      if (attempt !== playbackAttempt.current) return;
      if (results.some((result) => result.status === "rejected")) {
        active.forEach((player) => player.pause());
        setError("视频暂时无法播放，请检查文件或使用各自的播放控件重试。");
      }
    } catch {
      if (attempt === playbackAttempt.current) {
        active.forEach((player) => player.pause());
        setError("视频尚未就绪，请稍后重试。");
      }
    } finally {
      if (attempt === playbackAttempt.current) setStarting(false);
    }
  }
  return <dialog ref={dialog} className="video-compare" aria-label={t("视频版本对比")}
    onCancel={(event) => { event.preventDefault(); onClose(); }}
    onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <header className="video-compare-header">
      <div><strong>{t("视频版本对比")}</strong><p>{t("选择两个版本并排查看，或从头一起播放。")}</p></div>
      <button type="button" autoFocus onClick={onClose} aria-label={t("关闭视频对比")}><X size={21} /></button>
    </header>
    <div className="video-compare-grid">
      {selected.map((video, index) => <section key={index} className="video-compare-side">
        <label>{t("版本 {name}", { name: index === 0 ? "A" : "B" })}
          <select aria-label={t("对比视频 {name}", { name: index === 0 ? "A" : "B" })} value={names[index]}
            onChange={(event) => {
              pause();
              setError("");
              setNames((previous) => previous.map((name, slot) => slot === index ? event.target.value : name));
            }}>
            {videos.map((item) => <option key={item.name} value={item.name}
              disabled={item.name === names[1 - index]}>{item.name}</option>)}
          </select>
        </label>
        {video && <>
          <video key={video.url} ref={(player) => { players.current[index] = player; }}
            src={appUrl(video.url)} controls playsInline muted preload="metadata"
            aria-label={t("对比播放器 {name}", { name: index === 0 ? "A" : "B" })}
            onError={() => setError("有视频加载失败，请切换版本或检查文件是否完整。")} />
          <div className="video-version-meta">
            <span>{(video.bytes / 1024 / 1024).toFixed(1)} MB
              {video.modified_at ? ` · ${new Date(video.modified_at * 1000).toLocaleString(getLanguage() === "zh" ? "zh-CN" : "en", { timeZone: "Asia/Shanghai", hour12: false })}` : ""}</span>
            <a href={appUrl(video.url)} download aria-label={t("下载版本 {name}", { name: index === 0 ? "A" : "B" })}><Download size={16} />{t("下载")}</a>
          </div>
        </>}
      </section>)}
    </div>
    <footer className="video-compare-controls">
      <button type="button" className="primary" disabled={starting || selected.some((video) => !video)} onClick={() => void playTogether()}>
        <Play size={16} />{starting ? t("正在加载…") : t("从头一起播放")}
      </button>
      <button type="button" className="outline" onClick={pause}><Square size={15} />{t("全部暂停")}</button>
      <span>{t("默认静音，可分别拖动进度条检查细节。")}</span>
    </footer>
    {error && <p className="video-compare-error" role="alert">{t(error)}</p>}
  </dialog>;
}
