import { useEffect, useState } from "react";

// Keep this breakpoint in sync with mobile.css. Desktop panel preferences stay separate.
const mobileQuery = "(max-width: 820px)";

export function useMobileLayout() {
  const [mobile, setMobile] = useState(() => window.matchMedia(mobileQuery).matches);

  useEffect(() => {
    const query = window.matchMedia(mobileQuery);
    const update = () => setMobile(window.matchMedia(mobileQuery).matches);
    query.addEventListener("change", update);
    window.addEventListener("resize", update);
    window.visualViewport?.addEventListener("resize", update);
    update();
    return () => {
      query.removeEventListener("change", update);
      window.removeEventListener("resize", update);
      window.visualViewport?.removeEventListener("resize", update);
    };
  }, []);

  useEffect(() => {
    if (!mobile) return;
    const viewport = window.visualViewport;
    const root = document.documentElement;
    const update = () => {
      // Follow the software keyboard without resizing the layout during pinch zoom.
      if (viewport && viewport.scale === 1) {
        root.style.setProperty("--mobile-viewport-height", `${viewport.height}px`);
        root.toggleAttribute("data-mobile-compact", viewport.height < 500);
      }
    };
    update();
    viewport?.addEventListener("resize", update);
    return () => {
      viewport?.removeEventListener("resize", update);
      root.style.removeProperty("--mobile-viewport-height");
      root.removeAttribute("data-mobile-compact");
    };
  }, [mobile]);

  return mobile;
}
