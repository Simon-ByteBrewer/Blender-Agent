#!/bin/zsh
# Create a launcher for this copy of the application, without copying credentials.
set -euo pipefail
STUDIO_PROJECT="$(cd "$(dirname "$0")" && pwd)"
STUDIO_SHORTCUT="$HOME/Desktop/MA Creative Studio.command"

fail() {
  echo "$1"
  if [[ -t 0 ]]; then
    read -r "?按 Enter 关闭窗口…"
  fi
  exit 1
}

[[ -f "$STUDIO_PROJECT/start.command" ]] || fail "请完整解压应用后再创建快捷方式。"
mkdir -p "$HOME/Desktop"
if [[ -e "$STUDIO_SHORTCUT" || -L "$STUDIO_SHORTCUT" ]]; then
  [[ -f "$STUDIO_SHORTCUT" && ! -L "$STUDIO_SHORTCUT" ]] || fail "桌面已有同名项目，未覆盖。"
  if ! /usr/bin/grep -Fq '# MA Creative Studio desktop launcher' "$STUDIO_SHORTCUT" \
      && ! /usr/bin/grep -Fq '# Start the local Studio using the project' "$STUDIO_SHORTCUT"; then
    fail "桌面已有同名文件，未覆盖。请先重命名该文件后重试。"
  fi
fi

STUDIO_TEMP="$(mktemp "$HOME/Desktop/.ma-studio-launcher.XXXXXX")"
trap 'rm -f "$STUDIO_TEMP"' EXIT
{
  printf '#!/bin/zsh\n# MA Creative Studio desktop launcher\n'
  printf 'STUDIO_PROJECT=%q\n' "$STUDIO_PROJECT"
  cat <<'LAUNCHER'
if [[ ! -f "$STUDIO_PROJECT/start.command" ]]; then
  echo "找不到应用目录：$STUDIO_PROJECT"
  echo "移动应用后，请在新目录中重新运行 create-desktop-shortcut.command。"
  if [[ -t 0 ]]; then
    read -r "?按 Enter 关闭窗口…"
  fi
  exit 1
fi
exec /bin/zsh "$STUDIO_PROJECT/start.command"
LAUNCHER
} > "$STUDIO_TEMP"
chmod 755 "$STUDIO_TEMP"
mv -f "$STUDIO_TEMP" "$STUDIO_SHORTCUT"
STUDIO_ICON="$STUDIO_PROJECT/frontend/public/app-icon.png"
if [[ -f "$STUDIO_ICON" ]]; then
  # NSWorkspace stores the custom icon on the newly created file. Applying it
  # after extraction avoids depending on ZIP preservation of resource forks.
  if /usr/bin/osascript -l JavaScript - "$STUDIO_ICON" "$STUDIO_SHORTCUT" <<'ICON'
ObjC.import('AppKit');
function run(args) {
  const icon = $.NSImage.alloc.initWithContentsOfFile($(args[0]));
  if (!icon || icon.isNil()) throw new Error('Cannot load the application icon');
  if (!$.NSWorkspace.sharedWorkspace.setIconForFileOptions(icon, $(args[1]), 0)) {
    throw new Error('Cannot set the desktop shortcut icon');
  }
}
ICON
  then
    echo "已设置工作室图标。"
  else
    echo "图标未能设置，快捷方式仍可正常启动。"
  fi
else
  echo "未找到图标素材，快捷方式仍可正常启动。"
fi
echo "已创建桌面快捷方式：$STUDIO_SHORTCUT"
echo "以后双击它即可启动工作室并打开浏览器；保持启动终端运行，按 Ctrl+C 停止服务。"
