# Blender Action API 兼容与失败恢复

## 已验证的真实问题

项目 `260909-212525-094149` 的相机脚本先成功插入关键帧，随后在 `obj.animation_data.action.fcurves` 遍历处抛出：

```text
AttributeError: 'Action' object has no attribute 'fcurves'
```

改用 channelbag 后，相机和头部各检测到 3 条曲线，脚本执行成功。因此这是有状态的部分执行失败，不是整段脚本都没有生效。

版本描述应准确：Blender **4.4 引入** slotted／layered Action；**5.0 移除**旧的 `Action.fcurves` 等接口，5.2 沿用新方式。参见 [4.4 迁移说明](https://developer.blender.org/docs/release_notes/4.4/upgrading/slotted_actions/) 和 [5.0 Python API 发行说明](https://developer.blender.org/docs/release_notes/5.0/python_api/)。

## 区分对象槽位与整个 Action

- 调整某个对象：用 `wb.object_fcurves(obj)`。内部依据 `obj.animation_data.action_slot`，逐层逐 strip 取对应 `strip.channelbag(slot)`。
- 整个已烘焙场景重定时：去重 Action 后用 `wb.fcurves(action)` 遍历所有 channelbags，确保每条曲线只改一次。
- 不使用 `channelbags[0]` 或 `action.slots[0]` 猜归属。一个 Action 可以包含多个对象的 slot；取第一个可能改错角色。
- 兼容旧版时仅在接口实际存在时使用 `action.fcurves`，不要用宽泛 `except Exception: pass` 隐藏真实错误。

## 失败后如何重建

先读取当前场景，确认相机、目标、关键帧已生成到哪一步；不要重复创建 `Camera.001`，也不要默认清空所有动画。

```python
cam = wb.find("CAM-follow")
# 本段负责相机位置，因此只清理位置曲线；其他旋转、镜头参数保留。
wb.clear_keys(cam, {"location"})
for frame, position in camera_keys:
    cam.location = position
    cam.keyframe_insert("location", frame=frame)
wb.linear_keys(cam, {"location"})
```

只修复某段时可传 `frame_range=(start, end)`。`clear_keys()` 只作用于当前对象 slot；共享 Action 先复制，避免影响其他对象。它拒绝含 drivers／NLA 的对象，需要先明确归属并烘焙。移除的是目标通道的关键帧，不会清空整个文件的 Action。

重复在完全相同的帧插入同一通道通常是更新值，不必一律先清空。清理的价值在于完整重建时删除上次留下、此次不再需要的帧，或解决部分执行后范围不一致的问题。

`animation_data_clear()` 会解绑整套动画数据，包括非本段负责的动画。只有确认该对象全部动画均由当前构建器生成、且确实要整体重建时才使用。

## 验证

重新枚举当前对象 slot 的通道、关键帧数量和首尾时间，确认没有遗留帧；读取首／中／尾帧验证实际姿态，再另存工程。技能的 `test_regressions.py` 覆盖多 slot、指定通道清理、重复重建和共享 Action 重定时，不只验证代码能执行。
