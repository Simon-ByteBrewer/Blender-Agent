# wb_lib API 与验收范围

辅助库在 Blender Python 中导入；单位为米，Z 向上，角度为弧度。

```python
import sys
sys.path.insert(0, "<skill>/scripts")
import wb_lib as wb
# 修改库后，交互进程需要 importlib.reload(wb)
```

## 场景、集合与命名

```python
scene = wb.new_scene("Whitebox_v01", fps=24, frame_end=168)
sets = wb.collection(scene, "01-set")
hero = wb.find("SUB-hero", scene=scene)
```

`wb.attach_scene(scene)` 可为宿主已创建的项目场景分配命名空间，不删除、重建或改动已有几何；MA Studio 会在激活项目时调用。

同名场景已存在时 `new_scene()` 抛错；继续编辑应显式取 `bpy.data.scenes[name]`，新修订用新场景名或独立后台进程。实际对象名包含场景命名空间，跨 MCP 调用不要硬编码 `bpy.data.objects["SUB-hero"]`。

同一命名空间内构造同名对象会替换它。若对象、集合或材质被人为共享到其他场景，辅助函数拒绝修改共享资源。调用构造器前将目标场景设为活动场景，不应把其他场景的集合传入当前场景构造过程。

## 材质与几何

```python
mat = wb.material("MAT-kitchen", (0.30, 0.55, 0.50), rough=0.75)
wb.box(sets, "SET-wall", loc=(0, 5, 1.5), size=(10, 0.2, 3), mat=mat)
wb.cylinder(sets, "SET-column", (2, 3, 1.6), radius=0.4, height=3.2, mat=mat)
wb.sphere(sets, "PROP-ball", (0, 0, 0.5), radius=0.5, mat=mat)
wb.ground(sets, size=80)
wb.room(sets, "SET-lobby", size=(12, 9), height=3, open_sides=("-y",), mat=mat)
wb.blocks(sets, "SET-block", [((0, 0, 1), (2, 2, 2))], mat=mat)
```

几何以 `loc` 为中心，`size` 为完整尺寸。球半径也可用 `(rx, ry, rz)`。`room()` 在原点创建地面和墙，返回对象列表；移动整个房间时将其父级设为空对象，或统一平移所有返回对象。保留门洞时使用分段墙体，不能用删整面墙替代需要拍摄的出入口。

材质同时设置 Principled Base Color 和 `diffuse_color`，保证 Workbench 色块可见。`GREY` 为默认灰色，`SUBJECT_COLORS` 为角色候选颜色，`TAPE` 为默认朝向标记。颜色可按参考项目覆盖。

## 角色

```python
hero = wb.subject(actors, "hero", (0, 0, 0), height=1.75,
                  head_ratio=6, color=(0.9, 0.9, 0.9), facing=0)
wb.subject_row(actors, "extra", count=4, start=(-3, 2, 0), spacing=(1.2, 0, 0))
```

返回根 Empty，包含躯干、头和朝向标记。局部 `−Y` 为正面，根节点默认位于脚底支撑面；这个默认角色没有可活动四肢。仅整体走位时动画根节点；坐下、踩台阶等任务扩展局部姿态，见 `example_continuous.py`。

## 运动与相机

```python
wb.path(hero, points, start=1, end=168, easing="linear", face_travel=True,
        look_at=None, bob=0.0, append=False)
wb.face_target(hero, target, frame=57)
cam = wb.camera(cams, "wide", (6, -9, 2), lens=35, look_at=(0, 0, 1))
ots = wb.over_shoulder(cams, "ots", actor, target, frame=57,
                       back=1.1, side=0.45, height=1.55, lens=40)
wb.orbit(cam, target, radius=7, start=1, end=168, height=2, turns=0.25)
```

`path()` 两点为直线，多点为 Catmull–Rom，并建立弧长表后按距离采样。`easing` 支持 `linear / in / out / inout`，对整条路径生效。`look_at` 可为位置或动画对象；后者逐帧求值。人物朝向水平展开，相机使用连续四元数。`bob` 只是微小躯干起伏，不代表真实脚步。

默认清除该对象的位置／旋转通道关键帧，保留其他通道；`append=True` 保留已有动画并写入指定范围，调用者负责避免重叠及不连续。`orbit()` 同样替换相机位置／旋转关键帧。复杂连续动作优先使用 `ArcPath`、`travel_distance` 与每帧自定义姿态，详见 [一镜到底](continuous-shot.md)。

`wb.at_frame(n)` 必须先于动画位置读取；读取后 `.copy()`，避免引用随帧变化。`camera(..., look_at=object)` 只设创建时朝向，不会自动建立持续跟踪约束；持续跟拍使用 `path(..., look_at=object)` 或自定义逐帧朝向。

## 切镜与事件

```python
wb.cut_sequence(scene, [(1, wide, "全景"), (57, ots, "肩后"), (113, low, "低机位")])
scene.timeline_markers.new("开始入座", frame=229)
```

`cut_sequence()` 仅移除旧的相机绑定标记，保留普通事件；新切镜帧必须唯一，相机必须在场景内。首个切镜建议从 `frame_start` 开始。单镜头只需 `scene.camera = cam`，普通事件无需绑定相机。

## 渲染、保存与重定时

```python
wb.previz_render(scene, resolution=(1280, 720), outline=True, cavity=True,
                 color_type="MATERIAL")
wb.save(scene, "out/v01/scene.blend")
wb.retime(scene, frame_end=720)
wb.save(scene, "out/v02/scene_30s.blend")
info = wb.report(scene)
```

`save()` 打包依赖并停在首帧保存；默认拒绝已有路径。只有明确打算覆盖时传 `overwrite=True`。`.blend` 包含文件内所有场景，因此用独立后台进程构建可保持交付干净。

`retime()` 适用于场景、对象和对象数据的已烘焙 Action，保留插值类型并映射首尾及事件；限制见 [重定时](continuous-shot.md#重定时与保留版本)。

## 验收范围

`check_scene.py` 默认逐帧检查：

- 当前活动相机和相机切镜标记；普通事件不触发“缺少相机”错误。
- 角色每帧位置差，当前镜头的相机位移；角速度作为诊断指标输出，不自动判定所有快速摇镜为错误。
- 人物支撑面：无脚部标记时检查根节点；有脚时检查 `wb_contact >= 0.5` 的脚底。
- 显式 `wb_collider="BOX"` 的对象，按求值后的局部包围盒做保守胶囊体碰撞检测，包括相机处于实体内部的情况。`wb.box()` 自动标记，角色后代不当作场景障碍。

可用属性：

| 属性 | 含义 |
|---|---|
| `wb_role="subject"`、`wb_height_m` | 角色识别、站立高度 |
| `wb_speed_max` | 该对象允许的最大速度，m/s；默认走路 3、跑步 9、相机 25 |
| `wb_radius_m` | 碰撞代理半径；默认人物 0.18、相机 0.12 米 |
| `wb_collision_bottom_m`、`wb_collision_height_m` | 人物代理的下缘与上缘；可随坐姿调整 |
| `wb_ground_tolerance` | 支撑高度误差容限；默认 0.06 米 |
| 子节点 `wb_role="foot"`、`wb_contact` | 支撑脚及接触状态；状态键使用 CONSTANT 插值 |

BOX 应用于真正的长方体或人为设计的保守代理，不应直接给空心车厢、门框整体标 BOX。应拆成车顶、门柱、墙片等独立碰撞体。包围体在拐角处会高估碰撞，剪切变换、一般凹网格、肢体互穿、跳跃腾空、相机近裁剪面及整段帧间扫掠均需要另外检查。非 BOX 网格会列在 `unsupported_meshes` 中。

示例的有肢体人物采用躯干碰撞体＋脚部支撑检查，允许座面接触；这不代表膝盖、手臂已完整检测。报告 `passed` 只说明已覆盖项目通过，交付仍需看帧和动态预览。

## 分层 Action 与定向重建

`wb.object_fcurves(obj)` 遍历当前对象 slot；`wb.fcurves(action)` 遍历整个 Action。`wb.clear_keys(obj, {"location"}, frame_range=None)` 只清理指定通道，`wb.linear_keys(obj, {"location"})` 只调整这些通道的插值。详见 [Blender Action 兼容](blender-actions.md)。
